These files are taken from a BCPL compiler kit distribution from the early
1980s. None of the files bears a copyright notice in the original. On the basis
of other files in the distribution, it seems reasonable to assume these are:

    (c) Copyright 1978-1980 Tripos Research Group
        University of Cambridge
        Computer Laboratory

For more on BCPL see <http://www.cl.cam.ac.uk/users/mr/BCPL.html>.
