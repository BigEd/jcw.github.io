# BCPL-16

A trip back to the 16-bit BCPL world.

## Copyright

Most of the files here are taken from a BCPL compiler kit distribution
dating from the early 1980s.  None of the files bears a copyright
notice in the original, but -- on the basis of other files in the
distribution -- it seems reasonable to assume these are:

    (c) Copyright 1978-1980 Tripos Research Group
        University of Cambridge
        Computer Laboratory

Changes and additions to the intcode interpreter are
_(c) Copyright 2004, 2012 Robert Nordier_
and are freely redistributable.

For more on BCPL see <http://www.cl.cam.ac.uk/users/mr/BCPL.html>.
