#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "blib.h"
#include "ucode.h"

#define FSHIFT 13
#define IBIT  0x1000
#define PBIT  0x0800
#define GBIT  0x0400
#define DBIT  0x0200
#define ABITS 0x01FF

uint16_t M [1<<16];

struct { uint16_t A, B, C, D, G, P, W; } regs, next;
int UC;

static int16_t alu (int op, int16_t x, int16_t y) {
    switch (op) {
        case 0:  return x;      // mux
        case 1:  return      y; // mux
        case 2:  return     -y;
        case 3:  return     ~y;
        // 4 not used
        case 5:  return x *  y;
        case 6:  return x /  y;
        case 7:  return x %  y;
        case 8:  return x +  y;
        case 9:  return x -  y;
        case 10: return x == y ? ~0 : 0;
        case 11: return x <  y ? ~0 : 0;
        case 12: return x != y ? ~0 : 0;
        case 13: return x >= y ? ~0 : 0;
        case 14: return x >  y ? ~0 : 0;
        case 15: return x <= y ? ~0 : 0;
        case 16: return x << y;
        case 17: return x >> y;
        case 18: return x &  y;
        case 19: return x |  y;
        case 20: return x ^  y;
        case 21: return x ^ ~y;
        // 22..31 not used
    }
    return 0;
}

static void microstep (void) {
    UInstr ui = ucode[UC++];

    uint16_t alu_x = ui.sel_bd ? regs.B : regs.D;
    uint16_t alu_y = ui.sel_ap ? regs.A : regs.P;
    uint16_t mem_a = ui.sel_cd ? regs.C : regs.D;
    uint16_t mem_o = ui.sel_wr ? mem_a : alu_x;
    uint16_t incr = mem_a + 1;

    uint16_t mem_i = M[mem_a];
    uint16_t alu_z = alu(ui.alu_op, alu_x, alu_y);

    next = regs;

    if (ui.wr_a) {
        next.B = regs.A;
        next.A = alu_z;
    }
    if (ui.wr_c)
        next.C = ui.inc_cd ? incr : regs.D;
    if (ui.wr_d)
        switch (ui.sel_d) {
            case 0: next.D = regs.W & ABITS; break;
            case 1: next.D = mem_i; break;
            case 2: next.D = ui.inc_cd ? incr : alu_z; break;
            case 3: next.D = alu_y; break;
        }
    if (ui.wr_p)
        next.P = regs.D;
    if (ui.wr_w)
        next.W = mem_i;

    if (ui.mem_we)
        M[mem_a] = mem_o;

    switch (ui.bra) {
        case 1: UC += 4 * (regs.W >> 13);       break;
        case 2: UC += 4 * (regs.W & 0x3F);      break;
        case 3: if (regs.A == 0) UC = ui.unext; break;
        case 4: if (regs.A != 0) UC = ui.unext; break;
        case 5: UC = ui.unext;                  break;
    }

    regs = next;
}

int main (int argc, const char **argv) {
    if (argc != 2) {
        write(2, "usage: uex file\n", 16);
        return 1;
    }

    int fp = open(argv[1], O_RDONLY);
    if (fp == -1) {
        perror(argv[1]);
        return 2;
    }
    read(fp, M, 5 * sizeof(uint16_t));
    
    regs.G = M[1];
    regs.C = M[2];
    regs.P = M[3];

    read(fp, M, sizeof M);
    close(fp);
    initio();

    while (1)
        microstep();
}
