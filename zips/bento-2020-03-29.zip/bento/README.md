See <https://jeelabs.org/projects/bento/>.
