# GPIB interface on a Blue Pill

This code uses a Blue Pill (STM32F103C8 board) to create a GPIB-USB bridge:

![](bluepill.jpg)

Some Python wrapper code can be found in the `instruments/` area.

![](connector.jpg)

```text
GPIB    STM32   Signal  Other
----    -----   ------  --------
  1     PB8     DIO1
  2     PB9     DIO2
  3     PB10    DIO3
  4     PB11    DIO4
  5     PB3     EIO
  6     PA15    DAV
  7     PA8     NRFD
  8     PA9     NDAC
  9     PB6     IFC
 10     PA10    SRQ
 11     PB7     ATN
 13     PB12    DIO5
 14     PB13    DIO6
 15     PB14    DIO7
 16     PB15    DIO8
 17     PB4     REN
 24                     GND
        PA11            USB
        PA12            USB
        PA2             UART2 TX
        PA3             UART2 RX
----    -----   ------  --------
GPIB    STM32   Signal  Other
```
