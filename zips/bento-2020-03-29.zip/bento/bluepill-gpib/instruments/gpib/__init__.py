import serial

[PING, STATUS, INIT, LOCKREAD, CONTROLLER, REMOTE, TALKER, LISTENER, UNLISTEN,
 UNTALK, LOCKOUT, CLEAR, UNLOCK, TRIGGER, READ, WRITE, CMD] = range(17)

FLAG = 0x40

[PONG, CHUNK, STRING, REQUEST] = range(4)

class GPIB:
    def __init__(self, addr, port):
        self.addr = addr
        try: # re-use the connection if port is an existing GPIB object
            self.conn = port.conn
        except:
            self.conn = serial.serial_for_url(port)
            self.send(PING)
            assert self.recv1() == PONG
            self.send(INIT, 0, CONTROLLER)
        self.done(False)

    def send(self, *args):
        self.conn.write(bytes(args))

    def recv1(self):
        return ord(self.conn.read())

    def cmd(self, msg):
        "Send a message to this GPIB device"
        b = bytes(msg, encoding='utf8')
        self.send(TALKER, 0, UNLISTEN, LISTENER, self.addr, WRITE+FLAG, len(b))
        self.conn.write(b)

    def req(self, msg=None):
        "Optionally send a message, then read the reply from this GPIB device"
        if (msg):
            self.cmd(msg)
        self.send(TALKER, self.addr, UNLISTEN, LISTENER, 0, READ)
        t = self.recv1()
        if t == CHUNK+FLAG:
            b = self.conn.read(self.recv1())
            return b.decode("utf-8").strip()

    def done(self, local=True):
        "Stop comms on the GPIB bus and switch to local or remote mode"
        if local:
            self.send(UNTALK, UNLISTEN, REMOTE)
        else:
            self.send(REMOTE+FLAG, CLEAR+FLAG)
