#!/usr/bin/env python3

import gpib

hp = gpib.GPIB(22, '/dev/cu.usbmodemGPIB1')

print(hp.req('*IDN?'))
print(hp.req('SYST:VERS?'))
print(hp.req('FUNC?'))
print(hp.req('READ?'))

# report how long it takes to take one reading (avg of 10 requests)
import time
t = time.time()
for _ in range(10):
    hp.req('READ?')
print(round((time.time()-t)*100, 2), 'ms')

hp.done()

# Sample output:
#
#   $ python3 hp.py
#   HEWLETT-PACKARD,34401A,0,10-5-2
#   1991.0
#   "VOLT"
#   -8.62700000E-06
#   415.17 ms
