#!/usr/bin/env python3

# measure current consumption over a 1.9V..3.4V range, 700 ms settling time

import gpib
import time

smu = gpib.GPIB(15, 'rfc2217://touwtje.fritz.box:1000')

smu.cmd('F0,1 X')
smu.cmd('R1 X')
smu.cmd('Q1,1.9,3.4,0.1,2,700 X')
smu.cmd('N1 X')
time.sleep(0.01)
smu.cmd('H0 X')
time.sleep(20)
s = smu.req('G4,2,2 X')
#print(s)

for i, v in enumerate(s.split(',')):
    print("{:6.1f} V {:10.4f} µA".format(1.9+0.1*i, float(v)*1e6))

smu.cmd('N0 X')  # operate off
time.sleep(0.01) # make sure N0 gets processed before going LOCAL
smu.done()

# Sample output:
#
#  1.9 V     2.1751 µA
#  2.0 V     1.8373 µA
#  2.1 V     1.0592 µA
#  2.2 V     0.9645 µA
#  2.3 V     0.9502 µA
#  2.4 V     0.9676 µA
#  2.5 V     1.0069 µA
#  2.6 V     1.1348 µA
#  2.7 V     1.9705 µA
#  2.8 V     5.7553 µA
#  2.9 V    22.4570 µA
#  3.0 V    39.7180 µA
#  3.1 V    58.6090 µA
#  3.2 V    23.1270 µA
#  3.3 V    12.8650 µA
#  3.4 V    10.1460 µA
