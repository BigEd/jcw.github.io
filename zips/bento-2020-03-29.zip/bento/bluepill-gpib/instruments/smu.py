#!/usr/bin/env python3

import gpib

smu = gpib.GPIB(15, 'rfc2217://touwtje.fritz.box:1000')

for i in range(12):
    print(i, smu.req('U{} X'.format(i)))

smu.cmd('G5,1,0 N1 X') # instrument setup
print(smu.req('H0X'))  # single reading

# report how long it takes to take one reading (avg of 10 requests)
import time
t = time.time()
for _ in range(10):
    smu.req('H0X')
print(round((time.time()-t)*100, 2), 'ms')

smu.cmd('N0 X')  # operate off
time.sleep(0.01) # make sure N0 gets processed before going LOCAL
smu.done()

# Sample output:
#
#   $ python3 smu.py
#   0 238A10
#   1 ERS00000000000000000000000000
#   2 DSP~AL 10-24-2000
#   3 MSTG01,0,0K0M000,0N0R1T4,0,0,0V0Y0
#   4 IMPL,00F0,0O0P0S3W1Z0
#   5 ICP010.000E-03
#   6 ISP+00.0000E+00
#   7 CSP00,1,1
#   8 DSS0000
#   9 WRS0000000000
#   10
#   11 SMS0000
#   NSDCV+02.500E+00,NMDCI-0.00089E-09
#   419.49 ms
