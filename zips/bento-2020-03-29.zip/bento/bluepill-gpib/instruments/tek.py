#!/usr/bin/env python3

import gpib

tek = gpib.GPIB(7, '/dev/cu.usbmodemGPIB1')

print(tek.req('*IDN?'))

tek.done()

# Sample output:
#
#   $ python3 tek.py
#   TEKTRONIX,TDS 784D,0,CF:91.1CT FV:v6.6e
