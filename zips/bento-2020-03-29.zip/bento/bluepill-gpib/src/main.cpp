// An exploration into interfacing to the GPIB bus

#include <jee.h>
#include "usb.h"

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

enum {
    Q_PING, Q_STATUS, Q_INIT, Q_LOCKREAD, Q_CONTROLLER, Q_REMOTE,
    Q_TALKER, Q_LISTENER, Q_UNLISTEN, Q_UNTALK, Q_LOCKOUT, Q_CLEAR,
    Q_UNLOCK, Q_TRIGGER, Q_READ, Q_WRITE, Q_CMD,
};

enum {
    W_PONG, W_CHUNK, W_STRING, W_REQUEST,
};

PinC<13> NLED;

// PB8..PB15 is DIO1..DIO8
Port<'B'> DIO;

PinA<8>  NRFD;  // open-collector
PinA<9>  NDAC;  // open-collector
PinA<10> SRQ;   // open-collector
PinA<15> DAV;
PinB<3>  EOI;
PinB<4>  REN;
PinB<6>  IFC;
PinB<7>  ATN;

int myAddr;
int talker = -1; // -1 when no talker
uint32_t listeners; // bit map

static uint8_t dioGet () {
    return ~MMIO32(DIO.idr) >> 8;
}

static void dioSet (uint8_t v) {
    MMIO32(DIO.bsrr) = 0xFF00FF00 ^ (v << 8);
    MMIO32(DIO.crh) = 0x22222222; // p-p output, 2 MHz
}

static void dioFloat () {
    MMIO32(DIO.crh) = 0x88888888; // input, pull-up
    MMIO32(DIO.bsrr) = 0x0000FF00;
}

static void initBus (bool control) {
    // set up all pins, without affecting the output levels
    Port<'A'>::modeMap(0b1000011100000000, Pinmode::in_float);
    Port<'B'>::modeMap(0b0000000011011000, Pinmode::in_float);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    // (looks like this has to be done *after* some GPIO mode inits)
    MMIO32(Periph::afio+0x04) |= (2<<24); // disable JTAG, keep SWD enabled

    // set levels before switching pins to open-drain outputs, to avoid glitches
    NRFD = !control; // open-collector
    NDAC = 1;        // open-collector
    SRQ = 1;         // open-collector
    DAV = 1;
    EOI = 1;
    REN = 1;
    IFC = 1;
    ATN = 1;

    // input signals,    5432109876543210
    Port<'A'>::modeMap(0b1000011100000000, Pinmode::out_od);
    Port<'B'>::modeMap(0b0000000011011000, Pinmode::out_od);

    dioFloat();
}

template< typename T >
static void waitForLow (T pin) {
    while (pin) {}
}

template< typename T >
static void waitForHigh (T pin) {
    while (!pin) {}
}

static void gpibWrite (uint8_t data, bool cmd, bool end) {
    NLED = 0;
    ATN = !cmd;
    EOI = 1;
    DAV = 1;
    NRFD = 1;
    waitForLow(NDAC);
    waitForHigh(NRFD);
    dioSet(data);
    EOI = !end;
    DAV = 0;
    waitForHigh(NDAC);
    DAV = 1;
    dioFloat();
    ATN = 1;
    EOI = 1;
    NLED = 1;
}

static bool gpibRead(uint8_t& data) {
    NLED = 0;
    NDAC = 0;
    NRFD = 1;
    waitForLow(DAV);
    NRFD = 0;
    data = dioGet();
    bool done = !EOI;
    NDAC = 1;
    waitForHigh(DAV);
    NDAC = done;
    NLED = 1;
    return done;
}

static void sendCmd (uint8_t data) {
    gpibWrite(data, true, false);
}

static void untalk () {
    if (talker >= 0)
        sendCmd(0x5F); // UNT
    talker = -1;
}

int main() {
    // silence warnings about unused static functions in JeeH
    (void) enableClkAt8MHz;
    (void) powerDown;

    Iwdg watchdog (4); // max 6.5s

    console.init();
    console.baud(115200, fullSpeedClock()/2);
    NLED.mode(Pinmode::out); NLED = 1; // inverted logic

    usb.init();

    initBus(false);

    int n, lastSRQ = 1;
    uint8_t addr, cmd, buf [255];

    while (true) {
        watchdog.kick();

        // report negative edge transition on SRQ
        if (lastSRQ && !SRQ)
            sendCmd(W_REQUEST);
        lastSRQ = SRQ;

        if (usb.readable()) {
            const int req = usb.getc();
            const bool flag = (req & 0x40) != 0;
            switch (req & 0x3F) {
                default:
                    printf("? req 0x%02x\n", req);
                    break;

                case Q_PING:
                    usb.putc(W_PONG);
                    break;

                case Q_STATUS:
                    printf("E%dD%dN%dC%dI%dS%dA%dR%d:%02x>%08x:%02x\n",
                            !EOI, !DAV, !NRFD, !NDAC, !IFC, !SRQ, !ATN, !REN,
                            talker & 0xFF, listeners, dioGet());
                    break;

                case Q_INIT:
                    myAddr = usb.getc() & 0x1F;
                    initBus(!flag);
                    break;

                case Q_LOCKREAD:
                    NRFD = !flag;
                    NDAC = 1;
                    break;

                case Q_CONTROLLER:
                    IFC = 0;
                    wait_ms(3);
                    IFC = 1;
                    break;

                case Q_REMOTE:
                    REN = !flag;
                    break;

                case Q_TALKER:
                    addr = usb.getc() & 0x1F;
                    if (addr != talker) {
                        sendCmd(0x40 | addr); // TAD
                        talker = addr;
                        if (addr == myAddr) {
                            NRFD = 1;
                            NDAC = 1;
                        }
                        listeners &= ~(1<<addr);
                    }
                    break;

                case Q_LISTENER:
                    addr = usb.getc() & 0x1F;
                    if ((listeners & (1<<addr)) == 0) {
                        sendCmd(0x20 | addr); // LAD
                        listeners |= 1<<addr;
                    }
                    break;

                case Q_UNTALK:
                    untalk();
                    break;

                case Q_UNLISTEN:
                    if (listeners != 0)
                        sendCmd(0x3F); // UNL
                    listeners = 0;
                    break;

                case Q_LOCKOUT:
                case Q_UNLOCK:
                    sendCmd(0x11); // LLO
                    break;

                case Q_CLEAR:
                    if (flag) {
                        talker = -1;
                        listeners = 0;
                        sendCmd(0x14); // DCL
                    } else {
                        if (myAddr == talker)
                            untalk();
                        listeners &= ~(1<<myAddr);
                        sendCmd(0x04); // SDC
                    }
                    break;

                case Q_TRIGGER:
                    sendCmd(0x08); // GET
                    break;

                case Q_READ:
                    cmd = W_CHUNK;
                    n = 0;
                    while (n < (int) sizeof buf)
                        if (gpibRead(buf[n++])) {
                            cmd |= 0x40;
                            break;
                        }
                    usb.putc(cmd);
                    usb.putc(n);
                    for (int i = 0; i < n; ++i)
                        usb.putc(buf[i]);
                    break;

                case Q_WRITE:
                    n = usb.getc();
                    for (int i = 0; i < n; ++i)
                        gpibWrite(usb.getc(), false, flag && i == n-1);
                    break;

                case Q_CMD:
                    sendCmd(usb.getc());
                    break;
            }
        }
    }
}
