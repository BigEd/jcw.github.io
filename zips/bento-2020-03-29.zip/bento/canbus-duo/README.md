See <https://jeelabs.org/2018/canbus-part-6/>
