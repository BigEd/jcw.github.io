Works on stm32f4-disco, serial needs PA2 (f407) - PA3 (f103) wire, see UM1472.
