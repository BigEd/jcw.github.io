#include <jee.h>

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinD<12> greenLed;
PinD<13> orangeLed;
PinD<14> redLed;
PinD<15> blueLed;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/4);
    redLed.mode(Pinmode::out);
    blueLed.mode(Pinmode::out);
    greenLed.mode(Pinmode::out);
    orangeLed.mode(Pinmode::out);

    while (true) {
        printf("%d\n", ticks);
        redLed = 1; wait_ms(100); redLed = 0;
        blueLed = 1; wait_ms(100); blueLed = 0;
        greenLed = 1; wait_ms(100); greenLed = 0;
        orangeLed = 1; wait_ms(100); orangeLed = 0;
    }
}
