See <https://jeelabs.org/2019/disco-l053/>
and <https://jeelabs.org/2019/disco-l053-2/>.
