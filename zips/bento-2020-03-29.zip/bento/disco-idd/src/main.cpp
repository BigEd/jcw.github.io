#include <jee.h>
#include "mfx.h"

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinA<5> led;
I2cBus< PinB<9>, PinB<8> > bus;
MFX< decltype(bus) > mfx;

int main() {
    console.init();
    enableSysTick();
    led.mode(Pinmode::out);
    mfx.init();

    while (true) {
        printf("%04d: %d\n", ticks % 10000, mfx.measure());
        led.toggle();
    }
}
