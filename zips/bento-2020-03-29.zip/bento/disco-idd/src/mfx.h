// driver for MFX current measurement extension (L152 connected as I2C slave)

template< typename I2C, int addr =0x42 >
struct MFX {
    static PinC<13> iddIrq;

    static void init () {
        iddIrq.mode(Pinmode::in_float);

        writeReg(0x40, 0x80); // Initialize MFX
        wait_ms(100);
        writeReg(0x41, 0x03); // IRQ pin -> push-pull, active high
        wait_ms(1);
        writeReg(0x42, 0x06); // IRQ source -> error and IDD
        writeReg(0x40, 0x04); // Enable IDD function

        static uint8_t config [] = {
            0x03, 0xE8,   // SH0 = 1000 mohm
            0x00, 0x18,   // SH1 = 24 ohm
            0x02, 0x6C,   // SH2 = 620 ohm
            0x00, 0x00,   // SH3 = not included
            0x27, 0x10,   // SH4 = 10,000 ohm
            0x13, 0x7E,   // Gain = 49.9 (4990)
            0x0B, 0xB8,   // VDD_MIN = 3000 mV
        };

        I2C::start(addr<<1);
        I2C::write(0x82);
        for (int i = 0; i < (int) sizeof config; ++i)
            I2C::write(config[i]);
        I2C::stop();
    }

    static uint32_t measure (int delay =1) {
        writeReg(0x81, delay); // pre-delay, in steps of 0.5 ms or 20 ms
        writeReg(0x80, 0x09); // request Idd measurement

        while (iddIrq == 0) {} // wait for the irq signal

        I2C::start(addr<<1); // check for errors
        I2C::write(0x08);

        I2C::start((addr<<1)+1);
        uint32_t t = I2C::read(true);
        I2C::stop();

        if (t & 0x04) {
            init();
            return 0;
        }

        I2C::start(addr<<1); // retrieve the 24-bit reading
        I2C::write(0x14);

        I2C::start((addr<<1)+1);
        uint32_t v = I2C::read(false) << 16;
        v |= I2C::read(false) << 8;
        v |= I2C::read(true);
        I2C::stop();

        writeReg(0x44, 0x02);  // acknowledge Idd from MFX
        return v * 10; // nA
    }

    static void writeReg (uint8_t reg, uint8_t val) {
        I2C::start(addr<<1);
        I2C::write(reg);
        I2C::write(val);
        I2C::stop();
    }
};

template< typename I2C, int addr >
PinC<13> MFX<I2C,addr>::iddIrq;
