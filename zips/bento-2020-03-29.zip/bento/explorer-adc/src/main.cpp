#include <jee.h>

UartBufDev< PinA<2>, PinA<3>, 100 > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinA<5> led;
ADC adc;
PinA<0> a0;
PinA<1> a1;
PinA<4> a2;
PinB<0> a3;
PinC<1> a4;
PinC<0> a5;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());
    led.mode(Pinmode::out);

    adc.init();

    while (true) {
        int v0 = (adc.read(a0) * 3300 * 2) / 4095;
        int v1 = (adc.read(a1) * 3300 * 2) / 4095;
        int v2 = (adc.read(a2) * 3300 * 2) / 4095;
        int v3 = (adc.read(a3) * 3300 * 2) / 4095;
        int v4 = (adc.read(a4) * 3300 * 2) / 4095;
        int v5 = (adc.read(a5) * 3300 * 2) / 4095;
        printf("%4d %4d %4d %4d %4d %4d\r", v0, v1, v2, v3, v4, v5);
        led.toggle();
        wait_ms(500);
    }
}
