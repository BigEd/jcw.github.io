// simple test of the range switch and calibrator

#include <jee.h>

UartBufDev< PinA<2>, PinA<3>, 100 > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

ADC adc;
DAC dac;

PinA<4> dacPin;

PinB<0> vRef;
PinA<1> vOut;
PinA<0> vFeed;
PinC<1> vDiff;

PinA<5> rangeA;
PinA<6> rangeB;
PinB<9> rangeEna;

PinB<6> calibA;
PinC<7> calibB;
PinA<9> calibC;
PinA<7> calibEna;

static void initPins () {
    dacPin.mode(Pinmode::in_analog);

    rangeA.mode(Pinmode::out);
    rangeB.mode(Pinmode::out);
    rangeEna.mode(Pinmode::out); rangeEna = 1; // inverted logic

    calibA.mode(Pinmode::out);
    calibB.mode(Pinmode::out);
    calibC.mode(Pinmode::out);
    calibEna.mode(Pinmode::out); calibEna = 1; // inverted logic
}

static void initDac () {
    // generate a 2500-point sawtooth with values 0..2499
    static uint16_t wave [2500];
    for (int i = 0; i < 2500; ++i)
        wave[i] = i;

    // set up the DAC to automatically produce a periodic wave via DMA
    dac.init();
    dac.dmaWave(wave, 2500, 256*5); // 32 MHz / 256 / 5 = 25 ksps = 10 Hz
}

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());

    initPins();
    adc.init();

#if 0
    // default range switch is off, leaving 1M in the feedback loop
    rangeA = 0;
    rangeB = 1;
    rangeEna = 1;
#endif

    // calibrator setup for 100..1G ohm load resistors
    calibA = 0;
    calibB = 1;
    calibC = 0;
    calibEna = 0;

    wait_ms(1);
    initDac();
    wait_ms(94);

    printf("\n Vref  Vout Vfeed Vdiff  ticks\n");
    for (int i = 0; i < 25; ++i) {
        int val [4];
        val[0] = adc.read(vRef);
        val[1] = adc.read(vOut);
        val[2] = adc.read(vFeed);
        val[3] = adc.read(vDiff);
        for (int i = 0; i < 4; ++i)
            printf("%5d ", (val[i] * 3300 * 2) / 4095);
        printf(" %d\n", ticks);
        wait_ms(5);
    }

    while (true) {}
}
