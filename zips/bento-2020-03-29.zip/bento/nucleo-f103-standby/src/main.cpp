#include <jee.h>

PinA<5> led;
Iwdg dog (5);  // approx 13s

int main() {
    enableSysTick();

    led.mode(Pinmode::out);
    led = 1;
    wait_ms(10);
    led = 0;

    powerDown();
}
