See <https://jeelabs.org/2019/pio-cli/>.
