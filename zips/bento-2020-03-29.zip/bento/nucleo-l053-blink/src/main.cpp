#include <jee.h>

PinA<5> led;

int main() {
    enableSysTick();
    led.mode(Pinmode::out);

    while (true) {
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);
    }
}
