#include <jee.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

// the board has no LEDs, this is for a small 6-led board sitting on top
PinC<10> led1;
PinC<12> led2;
PinD<1> led3;
PinD<3> led4;
PinD<5> led5;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());
    led1.mode(Pinmode::out);
    led2.mode(Pinmode::out);
    led3.mode(Pinmode::out);
    led4.mode(Pinmode::out);
    led5.mode(Pinmode::out);

    while (true) {
        printf("%d\n", ticks);
        led1 = 1; wait_ms(100); led1 = 0;
        led2 = 1; wait_ms(100); led2 = 0;
        led3 = 1; wait_ms(100); led3 = 0;
        led4 = 1; wait_ms(100); led4 = 0;
        led5 = 1; wait_ms(100); led5 = 0;
    }
}
