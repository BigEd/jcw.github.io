// Simple on-board LED blink demo, with periodic messages to the serial port.

#include <jee.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinA<6> led1;
PinA<7> led2;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/2);
    led1.mode(Pinmode::out); led1 = 1;
    led2.mode(Pinmode::out); led2 = 1;

    while (1) {
        printf("%d\n", ticks);
        led1 = 0; wait_ms(100); led1 = 1; wait_ms(150);
        led2 = 0; wait_ms(100); led2 = 1; wait_ms(150);
    }
}
