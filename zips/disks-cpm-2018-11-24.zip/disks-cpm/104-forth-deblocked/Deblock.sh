for i in *.fb
do
	f=`basename $i .fb`
	dd if=$f.fb of=$f.txt cbs=64 conv=unblock
done
