for i in *.BLK
do
	f=`basename $i .BLK`
	dd if=$f.BLK of=$f.txt cbs=64 conv=unblock
done
