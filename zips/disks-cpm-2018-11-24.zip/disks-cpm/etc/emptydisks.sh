function makeDisk {
    dsk=$1
    bps=$2
    spt=$3
    ntr=$4
    printf '\xE5%.0s' `seq 1 $bps` >$dsk.tmp
    >$dsk
    for i in `seq 1 $spt`; do cat $dsk.tmp >>$dsk; done
    mv $dsk $dsk.tmp
    for i in `seq 1 $ntr`; do cat $dsk.tmp >>$dsk; done
    rm $dsk.tmp
    ls -l $dsk
}

makeDisk empty-8sssd.dsk 128 26 77
makeDisk empty-1440k.dsk 512 18 160
makeDisk empty-hd8mb.dsk 128 256 256
