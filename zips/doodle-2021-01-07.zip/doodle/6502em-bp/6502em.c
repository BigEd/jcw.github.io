#define ROM "ehbasic.hdr"

static const unsigned char rom [] = {
#include ROM
};

#include "../6502em/6502em.c"
