#include <stdint.h>
#include <stdio.h>

const uint8_t rom [] = {
#include "ehbasic.hdr"
};

int main () {
    FILE* fp = fopen("ehbasic.rom", "wb");
    fwrite(rom, 1, sizeof rom, fp);
    fclose(fp);
    return 0;
}
