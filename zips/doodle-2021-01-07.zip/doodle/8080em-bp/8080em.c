#define ROM "4kbas32.hdr"

static const unsigned char rom [] = {
#include ROM
};

#include "../8080em/8080em.c"
