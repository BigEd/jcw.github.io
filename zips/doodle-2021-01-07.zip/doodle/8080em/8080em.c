#include "../common/console.h"

struct {
    union {
        struct {
            union {
                struct { uint8_t fc:1,f1:1,fp:1,f3:1,fh:1,f5:1,fz:1,fs:1; };
                uint8_t f;
            };
            uint8_t a;
        };
        uint16_t af;
    };
    union { struct { uint8_t c, b; }; uint16_t bc; };
    union { struct { uint8_t e, d; }; uint16_t de; };
    union { struct { uint8_t l, h; }; uint16_t hl; };
    uint16_t sp;
    uint16_t pc;
} R;

#ifndef MEMORY_SIZE
// don't set to full 64K ram, as this may cause ram size tests to loop forever
//#define MEMORY_SIZE ((1<<16)-1)
#define MEMORY_SIZE (1<<14)
#endif

uint8_t mem [MEMORY_SIZE];

static uint8_t i8080_hal_io_input(uint8_t port) {
    //printf("\t%04x: IN %02x\r\n", R.pc, port);
    switch (port) {
        case 0x01: return consoleIn();
    }
    return 0;
}

static void i8080_hal_io_output(uint8_t port, uint8_t value) {
    //printf("\t%04x: OUT %02x = %02x\r\n", R.pc, port, value);
    switch (port) {
        case 0x01: consoleOut(value & 0x7F); break;
    }
}

static void i8080_hal_iff (uint8_t flag) {
    (void) flag;
}

static uint8_t rdB (uint16_t addr) {
    return addr < sizeof mem ? mem[addr] : 0;
}

static uint16_t rdW (uint16_t addr) {
    return rdB(addr) | (rdB(addr+1) << 8);
}

static void wrB (uint16_t addr, uint8_t value) {
    if (addr < sizeof mem)
        mem[addr] = value;
}

static void wrW (uint16_t addr, uint16_t value) {
    wrB(addr, value);
    wrB(addr+1, value >> 8);
}

static uint16_t Pop (void) {
    uint16_t result = rdW(R.sp);
    R.sp += 2;
    return result;
}

static void Push(uint16_t reg) {
    R.sp -= 2;
    wrW(R.sp, reg);
}

static uint8_t getParity(int val) {
    return (0b1001011001101001 >> ((val & 0xF) ^ (val >> 4))) & 1;
}

static void Inc (uint8_t* reg) {
    ++*reg;
    R.fs = *reg >> 7;
    R.fz = *reg == 0;
    R.fh = (*reg & 0x0F) == 0;
    R.fp = getParity(*reg);
}

static void Dec (uint8_t* reg) {
    --*reg;
    R.fs = *reg >> 7;
    R.fz = *reg == 0;
    R.fh = (*reg & 0x0F) != 0x0F;
    R.fp = getParity(*reg);
}

static void Add (uint8_t val) {
    uint16_t w = R.a + val;
    int index = ((R.a & 8) >> 1) | ((val & 8) >> 2) | ((w & 8) >> 3);
    R.a = w;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0b11010100 >> index;
    R.fp = getParity(R.a);
    R.fc = w >> 8;
}

static void Adc (uint8_t val) {
    uint16_t w = R.a + val + R.fc;
    int index = ((R.a & 8) >> 1) | ((val & 8) >> 2) | ((w & 8) >> 3);
    R.a = w;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0b11010100 >> index;
    R.fp = getParity(R.a);
    R.fc = w >> 8;
}

static void Sub (uint8_t val) {
    uint16_t w = R.a - val;
    int index = ((R.a & 8) >> 1) | ((val & 8) >> 2) | ((w & 8) >> 3);
    R.a = w;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0b01110001 >> index;
    R.fp = getParity(R.a);
    R.fc = w >> 8;
}

static void Sbb (uint8_t val) {
    uint16_t w = R.a - val - R.fc;
    int index = ((R.a & 8) >> 1) | ((val & 8) >> 2) | ((w & 8) >> 3);
    R.a = w;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0b01110001 >> index;
    R.fp = getParity(R.a);
    R.fc = w >> 8;
}

static void Cmp (uint8_t val) {
    uint16_t w = R.a - val;
    int index = ((R.a & 8) >> 1) | ((val & 8) >> 2) | ((w & 8) >> 3);
    R.fs = w >> 7;
    R.fz = (uint8_t) w == 0;
    R.fh = 0b01110001 >> index;
    R.fp = getParity(w & 0xFF);
    R.fc = w >> 8;
}

static void Ana (uint8_t val) {
    R.fh = (R.a | val) >> 3;
    R.a &= val;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fp = getParity(R.a);
    R.fc = 0;
}

static void Xra (uint8_t val) {
    R.a ^= val;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0;
    R.fp = getParity(R.a);
    R.fc = 0;
}

static void Ora (uint8_t val) {
    R.a |= val;
    R.fs = R.a >> 7;
    R.fz = R.a == 0;
    R.fh = 0;
    R.fp = getParity(R.a);
    R.fc = 0;
}

static void Dad (uint16_t reg) {
    uint32_t q = R.hl + reg;
    R.hl = q;
    R.fc = q >> 16;
}

static void Call (void) {
    Push(R.pc + 2);
    R.pc = rdW(R.pc);
}

static void Rst (uint16_t addr) {
    Push(R.pc);
    R.pc = (addr);
}

static void i8080_init (void) {
    R.f = 0;
    R.f1 = 1;
    R.pc = 0; //0xF800;
}

static void i8080_execute (int opcode) {
    //printf("\t%04x: %02x\r\n", R.pc-1, opcode);
    switch (opcode) {
        case 0x01: R.bc = rdW(R.pc); R.pc += 2; break;
        case 0x02: wrB(R.bc, R.a); break;
        case 0x03: ++R.bc; break;
        case 0x04: Inc(&R.b); break;
        case 0x05: Dec(&R.b); break;
        case 0x06: R.b = rdB(R.pc++); break;
        case 0x07: R.fc = R.a >> 7; R.a = (R.a << 1) | R.fc; break;
        case 0x09: Dad(R.bc); break;
        case 0x0A: R.a = rdB(R.bc); break;
        case 0x0B: --R.bc; break;
        case 0x0C: Inc(&R.c); break;
        case 0x0D: Dec(&R.c); break;
        case 0x0E: R.c = rdB(R.pc++); break;
        case 0x0F: R.fc = R.a & 0x01; R.a = (R.a >> 1) | (R.fc << 7); break;
        case 0x11: R.de = rdW(R.pc); R.pc += 2; break;
        case 0x12: wrB(R.de, R.a); break;
        case 0x13: ++R.de; break;
        case 0x14: Inc(&R.d); break;
        case 0x15: Dec(&R.d); break;
        case 0x16: R.d = rdB(R.pc++); break;

        case 0x17: {
            uint8_t b = R.fc;
            R.fc = R.a >> 7;
            R.a = (R.a << 1) | b;
            break;
        }

        case 0x19: Dad(R.de); break;
        case 0x1A: R.a = rdB(R.de); break;
        case 0x1B: --R.de; break;
        case 0x1C: Inc(&R.e); break;
        case 0x1D: Dec(&R.e); break;
        case 0x1E: R.e = rdB(R.pc++); break;

        case 0x1F: {
            uint8_t b = R.fc;
            R.fc = R.a;
            R.a = (R.a >> 1) | (b << 7);
            break;
        }

        case 0x21: R.hl = rdW(R.pc); R.pc += 2; break;
        case 0x22: wrW(rdW(R.pc), R.hl); R.pc += 2; break;
        case 0x23: ++R.hl; break;
        case 0x24: Inc(&R.h); break;
        case 0x25: Dec(&R.h); break;
        case 0x26: R.h = rdB(R.pc++); break;

        case 0x27: {
            uint8_t carry = R.fc;
            uint8_t add = 0;
            if (R.fh || (R.a & 0x0F) > 9)
                add = 0x06;
            if (R.fc || (R.a>>4) > 9 || ((R.a>>4) >= 9 && (R.a & 0x0F) > 9)) {
                add |= 0x60;
                carry = 1;
            }
            Add(add);
            R.fp = getParity(R.a);
            R.fc = carry;
            break;
        }

        case 0x29: Dad(R.hl); break;
        case 0x2A: R.hl = rdW(rdW(R.pc)); R.pc += 2; break;
        case 0x2B: --R.hl; break;
        case 0x2C: Inc(&R.l); break;
        case 0x2D: Dec(&R.l); break;
        case 0x2E: R.l = rdB(R.pc++); break;
        case 0x2F: R.a ^= 0xFF; break;
        case 0x31: R.sp = rdW(R.pc); R.pc += 2; break; 
        case 0x32: wrB(rdW(R.pc), R.a); R.pc += 2; break; 
        case 0x33: ++R.sp; break;
        case 0x34: { uint8_t b = rdB(R.hl); Inc(&b); wrB(R.hl, b); break; }
        case 0x35: { uint8_t b = rdB(R.hl); Dec(&b); wrB(R.hl, b); break; }
        case 0x36: wrB(R.hl, rdB(R.pc++)); break; 
        case 0x37: R.fc = 1; break;
        case 0x39: Dad(R.sp); break;
        case 0x3A: R.a = rdB(rdW(R.pc)); R.pc += 2; break;
        case 0x3B: --R.sp; break;
        case 0x3C: Inc(&R.a); break;
        case 0x3D: Dec(&R.a); break;
        case 0x3E: R.a = rdB(R.pc++); break;
        case 0x3F: R.fc = !R.fc; break;
        case 0x41: R.b = R.c; break;
        case 0x42: R.b = R.d; break;
        case 0x43: R.b = R.e; break;
        case 0x44: R.b = R.h; break;
        case 0x45: R.b = R.l; break;
        case 0x46: R.b = rdB(R.hl); break;
        case 0x47: R.b = R.a; break;
        case 0x48: R.c = R.b; break;
        case 0x4A: R.c = R.d; break;
        case 0x4B: R.c = R.e; break;
        case 0x4C: R.c = R.h; break;
        case 0x4D: R.c = R.l; break;
        case 0x4E: R.c = rdB(R.hl); break;
        case 0x4F: R.c = R.a; break;
        case 0x50: R.d = R.b; break;
        case 0x51: R.d = R.c; break;
        case 0x53: R.d = R.e; break;
        case 0x54: R.d = R.h; break;
        case 0x55: R.d = R.l; break;
        case 0x56: R.d = rdB(R.hl); break;
        case 0x57: R.d = R.a; break;
        case 0x58: R.e = R.b; break;
        case 0x59: R.e = R.c; break;
        case 0x5A: R.e = R.d; break;
        case 0x5C: R.e = R.h; break;
        case 0x5D: R.e = R.l; break;
        case 0x5E: R.e = rdB(R.hl); break;
        case 0x5F: R.e = R.a; break;
        case 0x60: R.h = R.b; break;
        case 0x61: R.h = R.c; break;
        case 0x62: R.h = R.d; break;
        case 0x63: R.h = R.e; break;
        case 0x65: R.h = R.l; break;
        case 0x66: R.h = rdB(R.hl); break;
        case 0x67: R.h = R.a; break;
        case 0x68: R.l = R.b; break;
        case 0x69: R.l = R.c; break;
        case 0x6A: R.l = R.d; break;
        case 0x6B: R.l = R.e; break;
        case 0x6C: R.l = R.h; break;
        case 0x6E: R.l = rdB(R.hl); break;
        case 0x6F: R.l = R.a; break;
        case 0x70: wrB(R.hl, R.b); break;
        case 0x71: wrB(R.hl, R.c); break;
        case 0x72: wrB(R.hl, R.d); break;
        case 0x73: wrB(R.hl, R.e); break;
        case 0x74: wrB(R.hl, R.h); break;
        case 0x75: wrB(R.hl, R.l); break;
        case 0x76: --R.pc; break;
        case 0x77: wrB(R.hl, R.a); break;
        case 0x78: R.a = R.b; break;
        case 0x79: R.a = R.c; break;
        case 0x7A: R.a = R.d; break;
        case 0x7B: R.a = R.e; break;
        case 0x7C: R.a = R.h; break;
        case 0x7D: R.a = R.l; break;
        case 0x7E: R.a = rdB(R.hl); break;
        case 0x80: Add(R.b); break;
        case 0x81: Add(R.c); break;
        case 0x82: Add(R.d); break;
        case 0x83: Add(R.e); break;
        case 0x84: Add(R.h); break;
        case 0x85: Add(R.l); break;
        case 0x86: Add(rdB(R.hl)); break;
        case 0x87: Add(R.a); break;
        case 0x88: Adc(R.b); break;
        case 0x89: Adc(R.c); break;
        case 0x8A: Adc(R.d); break;
        case 0x8B: Adc(R.e); break;
        case 0x8C: Adc(R.h); break;
        case 0x8D: Adc(R.l); break;
        case 0x8E: Adc(rdB(R.hl)); break;
        case 0x8F: Adc(R.a); break;
        case 0x90: Sub(R.b); break;
        case 0x91: Sub(R.c); break;
        case 0x92: Sub(R.d); break;
        case 0x93: Sub(R.e); break;
        case 0x94: Sub(R.h); break;
        case 0x95: Sub(R.l); break;
        case 0x96: Sub(rdB(R.hl)); break;
        case 0x97: Sub(R.a); break;
        case 0x98: Sbb(R.b); break;
        case 0x99: Sbb(R.c); break;
        case 0x9A: Sbb(R.d); break;
        case 0x9B: Sbb(R.e); break;
        case 0x9C: Sbb(R.h); break;
        case 0x9D: Sbb(R.l); break;
        case 0x9E: Sbb(rdB(R.hl)); break;
        case 0x9F: Sbb(R.a); break;
        case 0xA0: Ana(R.b); break;
        case 0xA1: Ana(R.c); break;
        case 0xA2: Ana(R.d); break;
        case 0xA3: Ana(R.e); break;
        case 0xA4: Ana(R.h); break;
        case 0xA5: Ana(R.l); break;
        case 0xA6: Ana(rdB(R.hl)); break;
        case 0xA7: Ana(R.a); break;
        case 0xA8: Xra(R.b); break;
        case 0xA9: Xra(R.c); break;
        case 0xAA: Xra(R.d); break;
        case 0xAB: Xra(R.e); break;
        case 0xAC: Xra(R.h); break;
        case 0xAD: Xra(R.l); break;
        case 0xAE: Xra(rdB(R.hl)); break;
        case 0xAF: Xra(R.a); break;
        case 0xB0: Ora(R.b); break;
        case 0xB1: Ora(R.c); break;
        case 0xB2: Ora(R.d); break;
        case 0xB3: Ora(R.e); break;
        case 0xB4: Ora(R.h); break;
        case 0xB5: Ora(R.l); break;
        case 0xB6: Ora(rdB(R.hl)); break;
        case 0xB7: Ora(R.a); break;
        case 0xB8: Cmp(R.b); break;
        case 0xB9: Cmp(R.c); break;
        case 0xBA: Cmp(R.d); break;
        case 0xBB: Cmp(R.e); break;
        case 0xBC: Cmp(R.h); break;
        case 0xBD: Cmp(R.l); break;
        case 0xBE: Cmp(rdB(R.hl)); break;
        case 0xBF: Cmp(R.a); break;
        case 0xC0: if (!R.fz) R.pc = Pop();break;
        case 0xC1: R.bc = Pop(); break;
        case 0xC2: if (!R.fz) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xC3:
        case 0xCB: R.pc = rdW(R.pc); break;
        case 0xC4: if (!R.fz) Call(); else R.pc += 2; break;
        case 0xC5: Push(R.bc); break;
        case 0xC6: Add(rdB(R.pc++)); break;
        case 0xC7: Rst(0x0000); break;
        case 0xC8: if (R.fz) R.pc = Pop(); break;
        case 0xC9:            /* ret */
        case 0xD9: R.pc = Pop(); break;
        case 0xCA: if (R.fz) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xCC: if (R.fz) Call(); else R.pc += 2; break;
        case 0xCD:
        case 0xDD:
        case 0xED:
        case 0xFD: Call(); break;
        case 0xCE: Adc(rdB(R.pc++)); break;
        case 0xCF: Rst(0x0008); break;
        case 0xD0: if (!R.fc) R.pc = Pop();break;
        case 0xD1: R.de = Pop(); break;
        case 0xD2: if (!R.fc) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xD3: i8080_hal_io_output(rdB(R.pc++), R.a); break;
        case 0xD4: if (!R.fc) Call(); else R.pc += 2; break;
        case 0xD5: Push(R.de); break;
        case 0xD6: Sub(rdB(R.pc++)); break;
        case 0xD7: Rst(0x0010); break;
        case 0xD8: if (R.fc) R.pc = Pop(); break;
        case 0xDA: if (R.fc) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xDB: R.a = i8080_hal_io_input(rdB(R.pc++)); break;
        case 0xDC: if (R.fc) Call(); else R.pc += 2; break;
        case 0xDE: Sbb(rdB(R.pc++)); break;
        case 0xDF: Rst(0x0018); break;
        case 0xE0: if (!R.fp) R.pc = Pop(); break;
        case 0xE1: R.hl = Pop(); break;
        case 0xE2: if (!R.fp) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xE3: { uint16_t w = rdW(R.sp); wrW(R.sp, R.hl); R.hl = w; break; }
        case 0xE4: if (!R.fp) Call(); else R.pc += 2; break;
        case 0xE5: Push(R.hl); break;
        case 0xE6: Ana(rdB(R.pc++)); break;
        case 0xE7: Rst(0x0020); break;
        case 0xE8: if (R.fp) R.pc = Pop(); break;
        case 0xE9: R.pc = R.hl; break;
        case 0xEA: if (R.fp) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xEB: { uint16_t w = R.de; R.de = R.hl; R.hl = w; break; }
        case 0xEC: if (R.fp) Call(); else R.pc += 2; break;
        case 0xEE: Xra(rdB(R.pc++)); break;
        case 0xEF: Rst(0x0028); break;
        case 0xF0: if (!R.fs) R.pc = Pop(); break;
        case 0xF1: R.af = Pop(); break;
        case 0xF2: if (!R.fs) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xF3: i8080_hal_iff(0); break;
        case 0xF4: if (!R.fs) Call(); else R.pc += 2; break;
        case 0xF5: Push(R.af); break;
        case 0xF6: Ora(rdB(R.pc++)); break;
        case 0xF7: Rst(0x0030); break;
        case 0xF8: if (R.fs) R.pc = Pop(); break;
        case 0xF9: R.sp = R.hl; break;
        case 0xFA: if (R.fs) R.pc = rdW(R.pc); else R.pc += 2; break;
        case 0xFB: i8080_hal_iff(1); break;
        case 0xFC: if (R.fs) Call(); else R.pc += 2; break;
        case 0xFE: Cmp(rdB(R.pc++)); break;
        case 0xFF: Rst(0x0038); break;
    }
}

void run (void) {
#ifdef ROM
    memcpy(mem, rom, sizeof rom);
#else
    loadMem(mem, sizeof mem);
#endif

    i8080_init();
    while (!done)
        i8080_execute(rdB(R.pc++));
}
