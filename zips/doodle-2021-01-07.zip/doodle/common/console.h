extern void consoleOut (char c);
extern void consoleOuts (const char* s);
extern int consoleHit (void);
extern int consoleIn (void);
extern int consoleWait (void);

static void run (void);

#if defined(linux) || defined(__amd64)
#include "linux-console.h"
#else
#include "usb-console.h"
#endif
