Simple experiment with parsing a HTTP request using [Ragel][R].

[R]: http://www.colm.net/open-source/ragel/
