#line 1 "parse.rl"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace std;

struct Buffer {
	Buffer() {}
	~Buffer() { free(data); }
	
	void append (char c) {
		if (fill >= size) {
			size = 10 + fill * 2;
			data = (char*) realloc(data, size);
		}
		data[fill++] = c;
	}
	
	void clear () { fill = 0; }
	
	char* data {nullptr};
	int size {0};
	int fill {0};
};

struct HttpScanner {
	Buffer headName;
	Buffer headContent;
	int cs, top, stack[1];
	
	void init ();
	int exec (char const* data, int len, bool isEof);
	int done ();
};


#line 68 "parse.rl"



#line 43 "parse.cpp"
static const signed char _HttpScanner_actions[] = {
	0, 1, 0, 1, 1, 1, 2, 1,
	3, 1, 4, 1, 5, 2, 4, 3,
	0
};

static const signed char _HttpScanner_key_offsets[] = {
	0, 0, 1, 2, 3, 4, 5, 6,
	11, 12, 15, 21, 22, 24, 24, 25,
	0
};

static const char _HttpScanner_trans_keys[] = {
	71, 69, 84, 32, 13, 10, 13, 33,
	57, 59, 126, 10, 58, 33, 126, 13,
	32, 33, 57, 59, 126, 10, 9, 32,
	13, 9, 13, 32, 0
};

static const signed char _HttpScanner_single_lengths[] = {
	0, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 2, 1, 2, 0, 1, 3,
	0
};

static const signed char _HttpScanner_range_lengths[] = {
	0, 0, 0, 0, 0, 0, 0, 2,
	0, 1, 2, 0, 0, 0, 0, 0,
	0
};

static const signed char _HttpScanner_index_offsets[] = {
	0, 0, 2, 4, 6, 8, 10, 12,
	16, 18, 21, 26, 28, 31, 32, 34,
	0
};

static const signed char _HttpScanner_cond_targs[] = {
	2, 0, 3, 0, 4, 0, 5, 0,
	6, 5, 7, 0, 8, 9, 9, 0,
	13, 0, 10, 9, 0, 8, 10, 9,
	9, 0, 12, 0, 15, 15, 0, 13,
	11, 14, 15, 11, 15, 14, 0, 1,
	2, 3, 4, 5, 6, 7, 8, 9,
	10, 11, 12, 13, 14, 15, 0
};

static const signed char _HttpScanner_cond_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 1, 1, 0,
	3, 0, 11, 1, 0, 0, 0, 1,
	1, 0, 0, 5, 0, 0, 5, 0,
	0, 7, 0, 9, 0, 13, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 5, 5, 0, 0, 9, 0
};

static const signed char _HttpScanner_eof_trans[] = {
	39, 40, 41, 42, 43, 44, 45, 46,
	47, 48, 49, 50, 51, 52, 53, 54,
	0
};

static const int HttpScanner_start = 1;
static const int HttpScanner_first_final = 13;
static const int HttpScanner_error = 0;

static const int HttpScanner_en_printHeader = 14;
static const int HttpScanner_en_main = 1;


#line 70 "parse.rl"


void HttpScanner::init () {
	
#line 120 "parse.cpp"
	{
		cs = (int)HttpScanner_start;
		top = 0;
	}
	
#line 73 "parse.rl"
	
}

int HttpScanner::exec (char const* data, int len, bool isEof) {
	char const* p = data;
	char const* pe = data + len;
	char const* eof = isEof ? pe : 0;
	
	
#line 136 "parse.cpp"
	{
		int _klen;
		unsigned int _trans = 0;
		const char * _keys;
		const signed char * _acts;
		unsigned int _nacts;
		_resume: {}
		if ( p == pe && p != eof )
			goto _out;
		if ( p == eof ) {
			if ( _HttpScanner_eof_trans[cs] > 0 ) {
				_trans = (unsigned int)_HttpScanner_eof_trans[cs] - 1;
			}
		}
		else {
			_keys = ( _HttpScanner_trans_keys + (_HttpScanner_key_offsets[cs]));
			_trans = (unsigned int)_HttpScanner_index_offsets[cs];
			
			_klen = (int)_HttpScanner_single_lengths[cs];
			if ( _klen > 0 ) {
				const char *_lower = _keys;
				const char *_upper = _keys + _klen - 1;
				const char *_mid;
				while ( 1 ) {
					if ( _upper < _lower ) {
						_keys += _klen;
						_trans += (unsigned int)_klen;
						break;
					}
					
					_mid = _lower + ((_upper-_lower) >> 1);
					if ( ( (*( p))) < (*( _mid)) )
						_upper = _mid - 1;
					else if ( ( (*( p))) > (*( _mid)) )
						_lower = _mid + 1;
					else {
						_trans += (unsigned int)(_mid - _keys);
						goto _match;
					}
				}
			}
			
			_klen = (int)_HttpScanner_range_lengths[cs];
			if ( _klen > 0 ) {
				const char *_lower = _keys;
				const char *_upper = _keys + (_klen<<1) - 2;
				const char *_mid;
				while ( 1 ) {
					if ( _upper < _lower ) {
						_trans += (unsigned int)_klen;
						break;
					}
					
					_mid = _lower + (((_upper-_lower) >> 1) & ~1);
					if ( ( (*( p))) < (*( _mid)) )
						_upper = _mid - 2;
					else if ( ( (*( p))) > (*( _mid + 1)) )
						_lower = _mid + 2;
					else {
						_trans += (unsigned int)((_mid - _keys)>>1);
						break;
					}
				}
			}
			
			_match: {}
		}
		cs = (int)_HttpScanner_cond_targs[_trans];
		
		if ( _HttpScanner_cond_actions[_trans] != 0 ) {
			
			_acts = ( _HttpScanner_actions + (_HttpScanner_cond_actions[_trans]));
			_nacts = (unsigned int)(*( _acts));
			_acts += 1;
			while ( _nacts > 0 ) {
				switch ( (*( _acts)) )
				{
					case 0:  {
						{
#line 39 "parse.rl"
							headName.append((( (*( p))))); }
						
#line 219 "parse.cpp"
						
						break; 
					}
					case 1:  {
						{
#line 41 "parse.rl"
							printf("Done.\n"); }
						
#line 228 "parse.cpp"
						
						break; 
					}
					case 2:  {
						{
#line 45 "parse.rl"
							
							headContent.append(0);
							printf("%s\n", headContent.data);
							headContent.clear();
							{p = p - 1; }
							{top -= 1;cs = stack[top];goto _again;}
						}
						
#line 243 "parse.cpp"
						
						break; 
					}
					case 3:  {
						{
#line 54 "parse.rl"
							headContent.append((( (*( p))))); }
						
#line 252 "parse.cpp"
						
						break; 
					}
					case 4:  {
						{
#line 55 "parse.rl"
							headContent.append(' '); }
						
#line 261 "parse.cpp"
						
						break; 
					}
					case 5:  {
						{
#line 58 "parse.rl"
							
							headName.append(0);
							printf("%s:", headName.data);
							headName.clear();
							{stack[top] = cs; top += 1;cs = 14;goto _again;}}
						
#line 274 "parse.cpp"
						
						break; 
					}
				}
				_nacts -= 1;
				_acts += 1;
			}
			
		}
		
		_again: {}
		if ( p == eof ) {
			if ( cs >= 13 )
				goto _out;
		}
		else {
			if ( cs != 0 ) {
				p += 1;
				goto _resume;
			}
		}
		_out: {}
	}
	
#line 81 "parse.rl"
	
	
	return done();
}

int HttpScanner::done () {
	return cs == HttpScanner_error ? -1 : cs >= HttpScanner_first_final ? 1 : 0;
}

HttpScanner scanner;
char buf[512];

int main () {
	scanner.init();
	
	bool eof = false;
	while (!eof) {
		int len = fread(buf, 1, sizeof buf, stdin);
		eof = len != sizeof buf;
		scanner.exec(buf, len, eof);
	}
	
	if (scanner.done() <= 0)
		fprintf(stderr, "scanner: error parsing input\n");
	return 0;
}
