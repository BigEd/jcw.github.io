#define ROM "newcleus.hdr"

static const unsigned char rom [] = {
#include ROM
};

#include "../j1em/j1em.c"
