This is a port of Matthias Koch's _Ice Cream Machine_ from Pascal to C code.
It emulates James Bowman's "j1a" stack machine, using the "Mecrisp Ice" variant.
To try it out, type `make`, then `words`. Use CTRL-D to terminate.

* <https://github.com/jamesbowman/swapforth>
* <http://mecrisp.sourceforge.net/>
