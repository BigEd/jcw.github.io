// This is a port of Matthias Koch's Ice Cream Machine from Pascal to C.
// -jcw, 2017-12-29

#include "../common/console.h"

static void cpuStep (void);

#define DSTACK_SIZE 16
#define RSTACK_SIZE 16

uint16_t cycles, pc, depth, rdepth;
uint16_t dstack [DSTACK_SIZE], rstack [RSTACK_SIZE], mem [0x1000];

static void dpush (uint16_t content) {
    memmove(dstack+1, dstack, sizeof dstack - sizeof dstack[0]);
    dstack[0] = content;
    ++depth;
}

static uint16_t dpop (void) {
    uint16_t result = dstack[0];
    memmove(dstack, dstack+1, sizeof dstack - sizeof dstack[0]);
    --depth;
    return result;
}

static void rpush (uint16_t content) {
    memmove(rstack+1, rstack, sizeof rstack - sizeof rstack[0]);
    rstack[0] = content;
    ++rdepth;
}

static uint16_t rpop (void) {
    uint16_t result = rstack[0];
    memmove(rstack, rstack+1, sizeof rstack - sizeof rstack[0]);
    --rdepth;
    return result;
}

static void writeio (uint16_t addr, uint16_t data) {
    if (addr & 0x1000)
        consoleOut(data);
    if (addr & 0x4000)
        cycles = data;
}

static uint16_t readio (uint16_t addr) {
    uint16_t result = 0;
    if (addr & 0x1000)
        result |= consoleWait();
    if (addr & 0x2000)
        result |= 0x000F;
    if (addr & 0x4000)
        result |= cycles;
    return result;
}

static void cpuStep (void) {
    ++cycles;
    uint16_t insn = mem[pc & 0xFFF];
    if (pc & 0x1000) {
        dpush(insn);
        pc = rpop() >> 1;
    } else if (insn & 0x8000) {
        dpush(insn & 0x7FFF);
        ++pc;
    } else {
        switch (insn & 0xE000) {
            case 0x0000:
                pc = insn & 0x1FFF;
                break;
            case 0x2000:
                if (dpop() == 0)
                    pc = insn & 0x1FFF;
                else
                    ++pc;
                break;
            case 0x4000:
                rpush((pc+1) << 1);
                pc = insn & 0x1FFF;
                break;
            case 0x6000: {
                uint16_t rtos = rstack[0], tos = dstack[0], nos = dstack[1];
                uint16_t tosN = 0;
                switch (insn & 0x0F00) {
                    case 0x0000: tosN = tos; break;
                    case 0x0100: tosN = nos; break;
                    case 0x0200: tosN = tos + nos; break;
                    case 0x0300: tosN = tos & nos; break;
                    case 0x0400: tosN = tos | nos; break;
                    case 0x0500: tosN = tos ^ nos; break;
                    case 0x0600: tosN = ~tos; break;
                    case 0x0700: tosN = -(nos == tos); break;
                    case 0x0800: tosN = -((int16_t) nos < (int16_t) tos); break;
                    case 0x0900: tosN = (int16_t) tos >> 1; break;
                    case 0x0A00: tosN = tos << 1; break;
                    case 0x0B00: tosN = rtos; break;
                    case 0x0C00: tosN = nos - tos; break;
                    case 0x0D00: tosN = readio(tos); break;
                    case 0x0E00: tosN = depth; break;
                    case 0x0F00: tosN = -(nos < tos); break;
                }
                if (insn & 0x0080)
                    pc = rtos >> 1;
                else
                    ++pc;
                switch (insn & 0x0003) {
                    case 3: dpop(); break;
                    case 2: dpop(); dpop(); break;
                    case 1: dpush(tos); break;
                }
                switch (insn & 0x000C) {
                    case 0xC: rpop(); break;
                    case 0x8: rpop(); rpop(); break;
                    case 0x4: rpush(tos); break;
                }
                switch (insn & 0x0070) {
                    case 0x10: dstack[1] = tos; break;
                    case 0x20: rstack[0] = tos; break;
                    case 0x30: mem[tos>>1] = nos; break;
                    case 0x40: writeio(tos, nos); break;
                }
                dstack[0] = tosN;
            }
            break;
        }
    }
}

void run (void) {
#ifdef ROM
    memcpy(mem, rom, sizeof rom);
#else
    loadMem(mem, sizeof mem);
#endif

    //ungetc('\n', stdin);
    while (!done)
        cpuStep();

#ifndef ROM
    saveMem(mem, sizeof mem);
#endif
}
