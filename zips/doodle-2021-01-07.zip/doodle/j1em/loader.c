// convert hex to binary

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

uint16_t mem [4096];

static int loader (FILE* fp) {
    uint16_t addr;
    printf("HEX to ROM converter:");
    char line [10];
    for (addr = 0; fgets(line, sizeof line, fp) != 0; ++addr) {
        int value;
        if (sscanf(line, "%x", &value) != 1) {
            printf("can't convert hex: %s\n", line);
            exit(1);
        }
        //printf("%4d: %04x\n", addr, value);
        mem[addr] = value;
    }
    printf(" %04x\n", addr);
    return addr;
}

int main (int argc, const char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s loadhex savebin\n", argv[0]);
        return 1;
    }
    FILE* ifp = fopen(argv[1], "r");
    if (ifp == 0) {
        perror(argv[1]);
        return 1;
    }
    if (loader(ifp) == 0) {
        puts("loader error");
        return 1;
    }
    FILE *ofp = fopen(argv[2], "wb");
    if (ofp == 0) {
        perror(argv[2]);
        return 1;
    }
    fwrite(mem, 1, sizeof mem, ofp);
    return fclose(ofp) == 0 ? 0 : 1;
}
