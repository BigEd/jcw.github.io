Simple experiment with parsing a JSON message using [Ragel][R].

[R]: http://www.colm.net/open-source/ragel/
