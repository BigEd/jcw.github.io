#line 1 "parse.rl"
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace std;

struct Buffer {
	Buffer() {}
	~Buffer() { free(data); }
	
	void append (char c) {
		if (fill >= size) {
			size = 10 + fill * 2;
			data = (char*) realloc(data, size);
		}
		data[fill++] = c;
	}
	
	void clear () { fill = 0; }
	
	char* data {nullptr};
	int size {0};
	int fill {0};
};

struct JsonScanner {
	Buffer buffer;
	int cs, top, stack[1];
	uint64_t u64;
	bool neg;
	
	void init ();
	int exec (char const* data, int len, bool isEof);
	int done ();
};


#line 63 "parse.rl"



#line 45 "parse.cpp"
static const signed char _JsonScanner_actions[] = {
	0, 1, 0, 1, 1, 1, 2, 1,
	3, 1, 4, 1, 5, 1, 6, 1,
	7, 1, 8, 1, 9, 1, 10, 1,
	11, 2, 1, 2, 2, 2, 0, 2,
	2, 3, 2, 2, 6, 2, 2, 9,
	2, 2, 10, 2, 2, 11, 0
};

static const int JsonScanner_start = 1;
static const int JsonScanner_first_final = 7;
static const int JsonScanner_error = 0;

static const int JsonScanner_en_main = 1;


#line 65 "parse.rl"


void JsonScanner::init () {
	neg = false;
	u64 = 0;
	
#line 69 "parse.cpp"
	{
		cs = (int)JsonScanner_start;
	}
	
#line 70 "parse.rl"
	
}

int JsonScanner::exec (char const* data, int len, bool isEof) {
	char const* p = data;
	char const* pe = data + len;
	char const* eof = isEof ? pe : 0;
	
	
#line 84 "parse.cpp"
	{
		const signed char * _acts;
		unsigned int _nacts;
		
		_resume: {}
		if ( p == pe )
			goto _out;
		switch ( cs ) {
			case 1:
			switch( ( (*( p))) ) {
				case 34: {
					goto _ctr2;
				}
				case 39: {
					goto _ctr3;
				}
				case 40: {
					goto _ctr4;
				}
				case 41: {
					goto _ctr5;
				}
				case 44: {
					goto _ctr6;
				}
				case 45: {
					goto _ctr7;
				}
				case 58: {
					goto _ctr6;
				}
				case 91: {
					goto _ctr4;
				}
				case 93: {
					goto _ctr5;
				}
				case 123: {
					goto _ctr4;
				}
				case 125: {
					goto _ctr5;
				}
			}
			if ( 48 <= ( (*( p))) && ( (*( p))) <= 57 ) {
				goto _ctr8;
			}
			goto _ctr0;
			case 0:
			goto _again;
			case 2:
			if ( ( (*( p))) == 34 ) {
				goto _ctr11;
			}
			goto _ctr10;
			case 3:
			switch( ( (*( p))) ) {
				case 10: {
					goto _ctr13;
				}
				case 34: {
					goto _ctr2;
				}
				case 39: {
					goto _ctr3;
				}
				case 40: {
					goto _ctr4;
				}
				case 41: {
					goto _ctr5;
				}
				case 44: {
					goto _ctr6;
				}
				case 45: {
					goto _ctr7;
				}
				case 58: {
					goto _ctr6;
				}
				case 91: {
					goto _ctr4;
				}
				case 93: {
					goto _ctr5;
				}
				case 123: {
					goto _ctr4;
				}
				case 125: {
					goto _ctr5;
				}
			}
			if ( 48 <= ( (*( p))) && ( (*( p))) <= 57 ) {
				goto _ctr8;
			}
			goto _ctr0;
			case 7:
			goto _ctr0;
			case 4:
			if ( ( (*( p))) == 39 ) {
				goto _ctr16;
			}
			goto _ctr15;
			case 5:
			if ( 48 <= ( (*( p))) && ( (*( p))) <= 57 ) {
				goto _ctr8;
			}
			goto _ctr0;
			case 6:
			switch( ( (*( p))) ) {
				case 10: {
					goto _ctr19;
				}
				case 34: {
					goto _ctr20;
				}
				case 39: {
					goto _ctr21;
				}
				case 40: {
					goto _ctr22;
				}
				case 41: {
					goto _ctr23;
				}
				case 44: {
					goto _ctr24;
				}
				case 45: {
					goto _ctr25;
				}
				case 58: {
					goto _ctr24;
				}
				case 91: {
					goto _ctr22;
				}
				case 93: {
					goto _ctr23;
				}
				case 123: {
					goto _ctr22;
				}
				case 125: {
					goto _ctr23;
				}
			}
			if ( 48 <= ( (*( p))) && ( (*( p))) <= 57 ) {
				goto _ctr26;
			}
			goto _ctr0;
		}
		
		_ctr0: cs = 0; goto _again;
		cs = 1; goto _again;
		cs = 2; goto _again;
		_ctr2: cs = 2; goto f0;
		_ctr10: cs = 2; goto f7;
		_ctr20: cs = 2; goto f12;
		cs = 3; goto _again;
		_ctr4: cs = 3; goto f2;
		_ctr5: cs = 3; goto f3;
		_ctr6: cs = 3; goto f4;
		_ctr11: cs = 3; goto f8;
		_ctr16: cs = 3; goto f10;
		_ctr22: cs = 3; goto f14;
		_ctr23: cs = 3; goto f15;
		_ctr24: cs = 3; goto f16;
		cs = 4; goto _again;
		_ctr3: cs = 4; goto f1;
		_ctr15: cs = 4; goto f9;
		_ctr21: cs = 4; goto f13;
		cs = 5; goto _again;
		_ctr7: cs = 5; goto f5;
		_ctr25: cs = 5; goto f17;
		cs = 6; goto _again;
		_ctr8: cs = 6; goto f6;
		_ctr26: cs = 6; goto f18;
		_ctr13: cs = 7; goto _again;
		_ctr19: cs = 7; goto f11;
		
		f5: _acts = ( _JsonScanner_actions + (1)); goto execFuncs;
		f6: _acts = ( _JsonScanner_actions + (3)); goto execFuncs;
		f11: _acts = ( _JsonScanner_actions + (5)); goto execFuncs;
		f1: _acts = ( _JsonScanner_actions + (7)); goto execFuncs;
		f9: _acts = ( _JsonScanner_actions + (9)); goto execFuncs;
		f10: _acts = ( _JsonScanner_actions + (11)); goto execFuncs;
		f0: _acts = ( _JsonScanner_actions + (13)); goto execFuncs;
		f7: _acts = ( _JsonScanner_actions + (15)); goto execFuncs;
		f8: _acts = ( _JsonScanner_actions + (17)); goto execFuncs;
		f2: _acts = ( _JsonScanner_actions + (19)); goto execFuncs;
		f3: _acts = ( _JsonScanner_actions + (21)); goto execFuncs;
		f4: _acts = ( _JsonScanner_actions + (23)); goto execFuncs;
		f18: _acts = ( _JsonScanner_actions + (25)); goto execFuncs;
		f17: _acts = ( _JsonScanner_actions + (28)); goto execFuncs;
		f13: _acts = ( _JsonScanner_actions + (31)); goto execFuncs;
		f12: _acts = ( _JsonScanner_actions + (34)); goto execFuncs;
		f14: _acts = ( _JsonScanner_actions + (37)); goto execFuncs;
		f15: _acts = ( _JsonScanner_actions + (40)); goto execFuncs;
		f16: _acts = ( _JsonScanner_actions + (43)); goto execFuncs;
		
		execFuncs:
		_nacts = (unsigned int)(*( _acts));
		_acts += 1;
		while ( _nacts > 0 ) {
			switch ( (*( _acts)) ) {
				case 0: {
					{
#line 42 "parse.rl"
						neg = true; }
					
#line 298 "parse.cpp"
					
					break; 
				}
				case 1: {
					{
#line 43 "parse.rl"
						u64 = 10 * u64 + ((( (*( p)))) - '0'); }
					
#line 307 "parse.cpp"
					
					break; 
				}
				case 2: {
					{
#line 44 "parse.rl"
						printf("INT %lld\n", neg ? -u64 : u64); }
					
#line 316 "parse.cpp"
					
					break; 
				}
				case 3: {
					{
#line 47 "parse.rl"
						buffer.clear(); }
					
#line 325 "parse.cpp"
					
					break; 
				}
				case 4: {
					{
#line 48 "parse.rl"
						buffer.append((( (*( p))))); }
					
#line 334 "parse.cpp"
					
					break; 
				}
				case 5: {
					{
#line 49 "parse.rl"
						buffer.append(0); printf("BSTR '%s'\n", buffer.data); }
					
#line 343 "parse.cpp"
					
					break; 
				}
				case 6: {
					{
#line 52 "parse.rl"
						buffer.clear(); }
					
#line 352 "parse.cpp"
					
					break; 
				}
				case 7: {
					{
#line 53 "parse.rl"
						buffer.append((( (*( p))))); }
					
#line 361 "parse.cpp"
					
					break; 
				}
				case 8: {
					{
#line 54 "parse.rl"
						buffer.append(0); printf("QSTR \"%s\"\n", buffer.data); }
					
#line 370 "parse.cpp"
					
					break; 
				}
				case 9: {
					{
#line 57 "parse.rl"
						printf("OPEN %c\n", (( (*( p))))); }
					
#line 379 "parse.cpp"
					
					break; 
				}
				case 10: {
					{
#line 58 "parse.rl"
						printf("CLOSE %c\n", (( (*( p))))); }
					
#line 388 "parse.cpp"
					
					break; 
				}
				case 11: {
					{
#line 59 "parse.rl"
						printf("SEP %c\n", (( (*( p))))); }
					
#line 397 "parse.cpp"
					
					break; 
				}
			}
			_acts += 1;
			_nacts -= 1;
		}
		
		goto _again;
		
		_again: {}
		if ( cs != 0 ) {
			p += 1;
			goto _resume;
		}
		_out: {}
	}
	
#line 78 "parse.rl"
	
	
	return done();
}

int JsonScanner::done () {
	return cs == JsonScanner_error ? -1 : cs >= JsonScanner_first_final ? 1 : 0;
}

JsonScanner scanner;
char buf [1000];


int main () {
	while (fgets(buf, sizeof buf, stdin) != nullptr) {
		printf("  >>>  %s", buf);
		scanner.init();
		scanner.exec(buf, strlen(buf), true);
		if (scanner.done() <= 0)
			fprintf(stderr, "scanner: error parsing input\n");
	}
	return 0;
}
