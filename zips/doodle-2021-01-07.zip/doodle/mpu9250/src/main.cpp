#include <Arduino.h> 

#include "MPU9250.h"

// an MPU9250 object with the MPU-9250 sensor on I2C bus 0 with address 0x68
MPU9250 IMU(Wire,0x68);

void setup() {
  // serial to display data
  Serial.begin(115200);
  while(!Serial) {}

  // start communication with IMU 
  int status = IMU.begin();
  if (status < 0) {
    Serial.println("IMU initialization unsuccessful");
    Serial.println("Check IMU wiring or try cycling power");
    Serial.print("Status: ");
    Serial.println(status);
    while(1) {}
  }
  // setting the accelerometer full scale range to +/-2G 
  IMU.setAccelRange(MPU9250::ACCEL_RANGE_2G);
  // setting the gyroscope full scale range to +/-250 deg/s
  IMU.setGyroRange(MPU9250::GYRO_RANGE_250DPS);
  // setting DLPF bandwidth to 20 Hz
  IMU.setDlpfBandwidth(MPU9250::DLPF_BANDWIDTH_20HZ);
  // setting SRD to 19 for a 50 Hz update rate
  IMU.setSrd(19);
}

void loop() {
  // read the sensor
  int t = micros();
  IMU.readSensor();
  t = micros() - t;

  // display the data
  Serial.print(IMU.getAccelX_mss(),3);
  Serial.print("\t");
  Serial.print(IMU.getAccelY_mss(),3);
  Serial.print("\t");
  Serial.print(IMU.getAccelZ_mss(),3);
  Serial.print("\t");
  Serial.print(IMU.getGyroX_rads(),4);
  Serial.print("\t");
  Serial.print(IMU.getGyroY_rads(),4);
  Serial.print("\t");
  Serial.print(IMU.getGyroZ_rads(),4);
  Serial.print("\t");
  Serial.print(IMU.getMagX_uT(),3);
  Serial.print("\t");
  Serial.print(IMU.getMagY_uT(),3);
  Serial.print("\t");
  Serial.print(IMU.getMagZ_uT(),3);
  Serial.print("\t");
  Serial.print(IMU.getTemperature_C(),3);
  Serial.print("\t");
  Serial.println(t);
  delay(200);
}
