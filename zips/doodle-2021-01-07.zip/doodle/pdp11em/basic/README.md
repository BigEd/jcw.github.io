PDP-11 BASIC with 16K memory
see <http://avitech.com.au/?page_id=709>
