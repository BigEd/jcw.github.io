// Convert ABS loader file to ROM, i.e. in-core memory image format.
// see https://www.pcjs.org/apps/pdp11/tapes/absloader/

#include <stdint.h>
#include <stdio.h>

uint8_t memory [1<<16];

const char* loader (FILE* fp) {
    printf("BIN to ROM converter:\n");

    // skip leader
    for (;;) {
        int c = fgetc(fp);
        if (c < 0)
            return "data";
        if (c != 0) {
            ungetc(c, fp);
            break;
        }
    };

    uint16_t addr = 0;
    while (!feof(fp)) {
        struct { uint16_t sig, len, pos; } header;
        if (fread(&header, 1, sizeof header, fp) != sizeof header)
            return "header";
        if (header.sig == 0)
            break; // assume trailer
        if (header.sig != 1)
            return "sig";
        //printf("%d %d %d\n", header.sig, header.len, header.pos);
        addr = header.pos;
        if (header.len == 0) {
            printf("start $%04x %#o\n", addr, addr);
            return 0;
        }
        for (int i = sizeof header; i < header.len; ++i)
            memory[addr++] = fgetc(fp);
        if (fgetc(fp) < 0)
            return "eof";
    }

    return 0;
}

int main (int argc, const char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s loadrim savebin\n", argv[0]);
        return 1;
    }

    FILE* ifp = fopen(argv[1], "rb");
    if (ifp == 0) {
        perror(argv[1]);
        return 1;
    }

    const char* msg = loader(ifp);
    if (msg != 0) {
        printf("loader error: %s\n", msg);
        return 1;
    }

    FILE *ofp = fopen(argv[2], "wb");
    if (ofp == 0) {
        perror(argv[2]);
        return 1;
    }

    int end = sizeof memory;
    while (end > 0 && memory[end-2] == 0 && memory[end-1] == 0)
        end -= 2;
    printf("size %d bytes\n", end);

    fwrite(memory, 1, end, ofp);
    return fclose(ofp) == 0 ? 0 : 1;
}
