#include "../common/console.h"

#include <assert.h>

#define MEM_SIZE (1<<14)
union {
    uint8_t  b [MEM_SIZE];
    uint16_t w [MEM_SIZE>>1];
} mem;

uint16_t R [8];
#define SP R[6]
#define PC R[7]

union {
    struct { uint16_t c :1, v :1, z :1, n :1, t :1, p :3, _8 :8; };
    struct { uint16_t f :4, _12 :12; };
    uint16_t w;
} PS;

#define I0(x)  (((x) << 2) | 0)
#define I1(x)  (((x) << 2) | 1)
#define I2(x)  (((x) << 2) | 2)
#define I3(x)  (((x) << 2) | 3)

enum {
    MOV, CMP, BIT, BIC, BIS, ADD, SUB,
    CLR, COM, INC, DEC, NEG, ADC, SBC, TST,
    ROR, ROL, ASR, ASL, MRK, MFP, MTP, SXT,
    MUL, DIV, ASH, ASC, XOR, FLT, SYS, SOB,
    BRA, EMT,
    _X_,
};

const uint8_t itab [256] = {
    I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA), // 00x
    I0(_X_),I0(_X_),I2(CLR),I2(CLR),I2(CLR),I2(CLR),I0(_X_),I0(_X_), // 01x
    I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV), // 02x
    I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV), // 03x
    I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP), // 04x
    I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP), // 05x
    I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT), // 06x
    I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT), // 07x

    I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC), // 10x
    I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC), // 11x
    I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS), // 12x
    I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS), // 13x
    I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD), // 14x
    I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD),I1(ADD), // 15x
    I3(MUL),I3(MUL),I3(DIV),I3(DIV),I3(ASH),I3(ASH),I3(ASC),I3(ASC), // 16x
    I3(XOR),I3(XOR),I0(FLT),I0(FLT),I0(SYS),I0(SYS),I0(SOB),I0(SOB), // 17x

    I0(_X_),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA),I0(BRA), // 20x
    I0(EMT),I0(EMT),I2(CLR),I2(CLR),I2(CLR),I2(CLR),I0(_X_),I0(_X_), // 21x
    I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV), // 22x
    I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV),I1(MOV), // 23x
    I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP), // 24x
    I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP),I1(CMP), // 25x
    I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT), // 26x
    I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT),I1(BIT), // 27x

    I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC), // 30x
    I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC),I1(BIC), // 31x
    I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS), // 32x
    I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS),I1(BIS), // 33x
    I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB), // 34x
    I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB),I1(SUB), // 35x
    I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_), // 36x
    I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_),I0(_X_), // 37x

};

static const uint16_t btab [16] = {
    0b0000000000000000, // (not used)
    0b1111111111111111, // br
// TODO !!!
    0b0000000000000000, // bne
    0b0000000000000000, // beq
    0b0000000000000000, // bge
    0b0000000000000000, // blt
    0b0000000000000000, // bgt
    0b0000000000000000, // ble
    0b0000000000000000, // bpl
    0b0000000000000000, // bmi
    0b0000000000000000, // bhi
    0b0000000000000000, // blos
    0b0000000000000000, // bvc
    0b0000000000000000, // bvs
    0b0000000000000000, // bcc, bhis
    0b0000000000000000, // bcs, blo
};

static int isReg (uint16_t a) {
    return (a & 0177770) == 0170000;
}

static uint16_t rdW (uint16_t a) {
    assert((a & 1) == 0);
    if (a < sizeof mem)
        return mem.w[a>>1];
    if (isReg(a))
        return R[a&7];
    if (a == 0177776)
        return PS.w;
    printf("rdW $%04x %#o\r\n", a, a);
    assert(0); // unibus
    return 0;
}

static uint8_t rdB (uint16_t a) {
    if (a < sizeof mem)
        return mem.b[a];
    if (isReg(a))
        return R[a&7];
    uint16_t v = rdW(a & ~1);
    return a & 1 ? v >> 8 : v;
}

static uint16_t rdN (uint16_t a, int l) {
    assert(l == 1 || l == 2);
    return l == 1 ? rdB(a) : rdW(a);
}

static void wrW (uint16_t a, uint16_t v) {
    assert((a & 1) == 0);
    if (a < sizeof mem)
        mem.w[a>>1] = v;
    else if (isReg(a))
        R[a&7] = v;
    else {
        printf("wrW $%04x %#o = $%04x %#o\r\n", a, a, v, v);
        assert(0); // unibus
    }
}

static void wrB (uint16_t a, uint8_t v) {
    if (a < sizeof mem)
        mem.b[a] = v;
    else if (isReg(a))
        R[a&7] = (R[a&7] & 0xFF00) | v;
    else {
        printf("wrB $%04x %#o = $%02x %#o\r\n", a, a, v, v);
        assert(0); // unibus
    }
}

static void wrN (uint16_t a, uint16_t v, int l) {
    assert(l == 1 || l == 2);
    if (l == 1)
        wrB(a, v);
    else
        wrW(a, v);
}

static void push (uint16_t v) {
    SP -= 2;
    wrW(SP, v);
}

static uint16_t pop (void) {
    uint16_t v = rdW(SP);
    SP += 2;
    return v;
}

static uint16_t aget (uint16_t v, int l) {
    uint16_t a;
    uint8_t r = v & 7;
    if (r >= 6 || (v & 010))
        l = 2;
    switch ((v >> 4) & 3) {
        case 0: a = 0170000 | r; break;
        case 1: a = R[r]; R[r] += l; break;
        case 2: R[r] -= l; a = R[r]; break;
        case 3: a = rdW(PC); PC += 2; a += R[r]; break;
    }
    if (v & 010)
        a = rdW(a);
    return a;
}

static void branch (int8_t o) {
    PC += o << 1;
}

static void init (void) {
}

static void step (void) {
    uint16_t op = rdW(PC);
    PC += 2;

    // type b7..b3 = opcode enum, b1..0 = src/dst ref decoding
    uint8_t type = itab[op>>8];
    printf("%06o: op $%02x %#o (%#o:%#o) type $%02x %#o (%#o:%#o)\r\n",
            PC-2, op, op, op>>8, (uint8_t) op, type, type, type>>2, type&3);

    uint16_t src = (op>>6) & 077, dst = op & 077, len = 2 - (op>>15);
    uint16_t arg = 0, val = 0;

    if ((type & 3) == 1) { // src ref in b15 + b11..b6
        src = aget(src, len);
        arg = rdN(src, len);
    }
    if ((type & 3) != 0) { // dst ref in b15 + b5..b0
        dst = aget(dst, len);
        if (type != I2(MRK) && type != I2(MFP) && type != I2(MTP))
            val = rdN(dst, len);
        if ((type & 3) == 2) // adjust to CLR..SXT opcodes
            type += (op & 01700) >> 4;
    }
    printf("\tsrc $%04x %#o arg $%04x %#o dst $%04x %#o dst $%04x %#o\r\n",
            src, src, arg, arg, dst, dst, val, val);

    int action = 0, vFlag = 0, cFlag = PS.c;

    switch (type >> 2) {
        case MOV:
            val = arg;
            action = 1;
            break;
        case CMP:
            cFlag = (arg - val) >> 8*len;
            val = arg - val;
            vFlag = ((arg - val) >> (8*len-1)) ^ cFlag;
            action = 2;
            break;
        case BIT:
            val &= arg;
            action = 2;
            break;
        case BIC:
            val &= ~ arg;
            action = 1;
            break;
        case BIS:
            val |= arg;
            action = 1;
            break;
        case ADD:
            cFlag = (val + arg) >> 8*len;
            val += arg;
            vFlag = ((val + arg) >> (8*len-1)) ^ cFlag;
            action = 1;
            break;
        case SUB:
            cFlag = (val - arg) >> 8*len;
            val -= arg;
            vFlag = ((val - arg) >> (8*len-1)) ^ cFlag;
            action = 1;
            break;
        case CLR:
            cFlag = 0;
            val = 0;
            action = 1;
            break;
        case COM:
            cFlag = 0;
            val = ~ val;
            action = 1;
            break;
        case INC:
            ++val;
            vFlag = val >> (8*len-1);
            action = 1;
            break;
        case DEC:
            vFlag = val == 0;
            --val;
            action = 1;
            break;
        case NEG:
            cFlag = val == 0;
            val = -val;
            vFlag = val == 1<<15;
            action = 1;
            break;
        case ADC:
            val += cFlag;
            action = 1;
            break;
        case SBC:
            val -= cFlag;
            action = 1;
            break;
        case TST:
            action = 2;
            break;
        case ROR:
            val = ((cFlag << 8*len) | val) >> 1;
            action = 1;
            break;
        case ROL:
            val = (val << 1) | cFlag;
            action = 1;
            break;
        case ASR:
            if (len == 1)
                val = (int8_t) val;
            val = (int16_t) val >> 1;
            action = 1;
            break;
        case ASL:
            val = val << 1;
            action = 1;
            break;
        case MRK:
            SP = PC + (dst << 1);
            PC = R[5];
            R[5] = pop();
            break;
        case MFP:
            assert(0);
            break;
        case MTP:
            assert(0);
            break;
        case SXT:
            val = - ((val >> (8*len-1)) & 1);
            vFlag = PS.v;
            action = 1;
            break;
        case MUL:
            break;
        case DIV:
            break;
        case ASH:
            break;
        case ASC:
            break;
        case XOR:
            break;
        case FLT:
            assert(0);
            break;
        case SYS:
            assert(0);
            break;
        case SOB:
            break;
        case BRA:
            val = (op >> 12) | ((op >> 8) & 7);
            if (val == 0)
                switch (op >> 5) {
                    case 5:
                        if (op & 020)
                            PS.f |= op; // se<f>
                        else
                            PS.f &= ~ op; // cl<f>
                        break;
                    default:
                        assert(0);
                }
            else if ((btab[val] >> PS.f) & 1)
                PC += (int8_t) op << 1;
            break;
        case EMT:
            assert(0);
        default:
            switch (op) {
                case 000000: // HALT
                    puts("HALT\r"); break;
                case 000001: // WAIT
                    puts("WAIT\r"); break;
                case 000002: // RTI
                    puts("RTI\r"); break;
                case 000004: // IOT
                    puts("IOT\r"); break;
                case 000005: // RESET
                    puts("RESET\r"); break;
                default:
                    assert(0);
            }
            assert(0);
    }

    switch (action) {
        case 1: // set flags and write
            PS.n = val >> (8*len-1);
            PS.z = val == 0;
            PS.v = vFlag;
            PS.c = cFlag;
            wrN(dst, val, len);
            break;
        case 2: // set flags
            PS.n = val >> (8*len-1);
            PS.z = val == 0;
            PS.v = vFlag;
            PS.c = cFlag;
            break;
    }
}

void run (void) {
#ifdef ROM
    memcpy(mem.b, rom, sizeof rom);
#else
    loadMem(mem.b, sizeof mem);
#endif
    assert(_X_ < 64); // needs to fit in 6 bits

    init();
    while (!done) {
        step();
        consoleWait();
    }
}
