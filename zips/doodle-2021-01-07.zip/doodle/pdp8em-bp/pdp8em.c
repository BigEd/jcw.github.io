#if 0
#define ROM "focal.hdr"

static const unsigned char rom [] = {
#include ROM
};
#endif

// FIXME these are just quick hacks to get rid of arm-side warnings
int printf (const char*,...);
void cleanup (void);
void abort (void);
void loadMem (void*,unsigned);
unsigned char diskBuf [1];
void setbuf (void*,int);
void* stdout;

#include "../pdp8em/pdp8em.c"
