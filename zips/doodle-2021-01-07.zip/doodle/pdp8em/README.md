See <http://jeelabs.org/2016/09/tfoc---pdp-8-in-256-lines-of-c/>.

The `pal.c` cross-assembler and `welcome.pal` files are slightly modified  
versions of Bernhard Bähr's code, from his amazing [PDP-8/e simulator][BB] site.

[BB]: http://www.bernhard-baehr.de/pdp8e/pdp8e.html
