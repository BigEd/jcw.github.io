// DEIF - Disk Emulation In Flash
//
// - flash is rewritten via a ram buffer
// - support for I/O on arbitrary byte ranges
// - use allocated RAM buffer when compiled for linux

#if 0
#define DEIF_PAGESIZE   (1<<10) // flash page size in bytes
#define DEIF_DISKPAGES  64      // number of pages for disk
#endif

#ifdef linux
static uint8_t diskBuf [DEIF_DISKPAGES * DEIF_PAGESIZE];
#define DEIF_DISKADDR   diskBuf
#else
#include <libopencm3/stm32/flash.h>
#define DEIF_DISKADDR   ((uint8_t*) (0x08020000-DEIF_DISKPAGES*DEIF_PAGESIZE))
#endif

#define DEIF_SHADOWED   (DEIF_DISKADDR + deif.pageInBuf * DEIF_PAGESIZE)

struct {
    int16_t pageInBuf; // -1 = clean, i.e. empty
    uint8_t buffer [DEIF_PAGESIZE];
} deif;

// initialise the deif state
static void deif_init (void) {
    deif.pageInBuf = -1;
}

// flush buffer to emulated disk if it contains unsaved data
static void deif_flush (void) {
    if (deif.pageInBuf >= 0) {
        uint8_t* shadow = DEIF_SHADOWED;
#ifdef linux
        memcpy(shadow, deif.buffer, DEIF_PAGESIZE);
#else
        flash_unlock();
        flash_erase_page((uint32_t) shadow);
        for (uint16_t i = 0; i < sizeof deif.buffer; i += 4)
            flash_program_word((uint32_t) shadow + i,
                                *(uint32_t*) (deif.buffer + i));
#endif
        deif.pageInBuf = -1;
    }
}

// read <len> bytes into <ptr> from emulated disk at <pos>
static void deif_read (uint32_t pos, void* ptr, unsigned len) {
    for (unsigned i = 0; i < len; ++i) {
        const uint8_t* disk = DEIF_DISKADDR + pos + i;
        uint16_t page = (pos+i) / DEIF_PAGESIZE;
        if (page == deif.pageInBuf)
            disk = deif.buffer + (pos+i) % DEIF_PAGESIZE;
        ((uint8_t*) ptr)[i] = *disk;
    }
}

// write <len> bytes from <ptr> to emulated disk at <pos>
static void deif_write (uint32_t pos, const void* ptr, unsigned len) {
    for (unsigned i = 0; i < len; ++i) {
        uint16_t page = (pos+i) / DEIF_PAGESIZE;
        if (page != deif.pageInBuf) {
            deif_flush();
            deif.pageInBuf = page;
            memcpy(deif.buffer, DEIF_SHADOWED, DEIF_PAGESIZE);
        }
        uint8_t* disk = deif.buffer + (pos+i) % DEIF_PAGESIZE;
        *disk = ((const uint8_t*) ptr)[i];
    }
}
