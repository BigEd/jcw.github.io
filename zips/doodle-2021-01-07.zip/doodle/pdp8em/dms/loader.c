// Convert BIN loader file to ROM, i.e. in-core memory image format.

#include <stdint.h>
#include <stdio.h>

uint16_t memory [32768];

uint16_t mask(uint16_t w) { return w & 07777; }

void loader (FILE* fp) {
    printf("MIF to ROM converter:");
    char line [100];
    int i = 0;
    while (fgets(line, sizeof line, fp) != 0) {
        int addr, val;
        if (sscanf(line, "%o:%o", &addr, &val) == 2) {
            memory[addr] = val;
            ++i;
        }
    }
    printf(" %d words\n", i);
}

int main (int argc, const char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s loadmif savebin\n", argv[0]);
        return 1;
    }
    FILE* ifp = fopen(argv[1], "r");
    if (ifp == 0) {
        perror(argv[1]);
        return 1;
    }
    loader(ifp);
    FILE *ofp = fopen(argv[2], "wb");
    if (ofp == 0) {
        perror(argv[2]);
        return 1;
    }
    fwrite(memory, 1, sizeof memory, ofp);
    return fclose(ofp) == 0 ? 0 : 1;
}
