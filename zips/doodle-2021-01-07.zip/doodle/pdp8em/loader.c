// Convert BIN loader file to ROM, i.e. in-core memory image format.

#include <stdint.h>
#include <stdio.h>

uint16_t memory [4096];

uint16_t mask(uint16_t w) { return w & 07777; }

int loader (FILE* fp) {
    uint16_t addr = 0;
    printf("BIN to ROM converter:");
    uint16_t b = 0;
    while (!feof(fp)) {
        // read next uint16_t
        b = fgetc(fp);
        if (b & 0200) // skip run-in
            continue;
        b = (b << 6) | fgetc(fp);

        // look for run-out, to ignore word before it as being a checksum
        int c = fgetc(fp);
        if (c & 0200)
            break;
        ungetc(c, fp);

        // process one word
        if (b & 010000) {
            if (addr != 0)
                printf("-%04o", addr - 1);
            addr = mask(b);
            printf(" %04o", addr);
        } else
            memory[addr++] = b;
    }
    printf("-%04o CHECK %04o\n", mask(addr - 1), mask(b));
    return addr;
}

int main (int argc, const char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s loadrim savebin\n", argv[0]);
        return 1;
    }
    FILE* ifp = fopen(argv[1], "r");
    if (ifp == 0) {
        perror(argv[1]);
        return 1;
    }
    if (loader(ifp) == 0) {
        puts("loader error");
        return 1;
    }
    FILE *ofp = fopen(argv[2], "wb");
    if (ofp == 0) {
        perror(argv[2]);
        return 1;
    }
    fwrite(memory, 1, sizeof memory, ofp);
    return fclose(ofp) == 0 ? 0 : 1;
}
