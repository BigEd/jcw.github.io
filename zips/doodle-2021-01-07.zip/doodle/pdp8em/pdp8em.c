// PDP-8 emulator w/ 8 Kw memory.

// 1 = instruction trace
// 2 = disk I/O actions
// 4 = disk I/O dump
// 8 = abort on unknown iot
// 16 = trace without JMS, JMP, IOT
#ifdef linux
#define V (1+2+8+16)
#define D
#else
#define V 0
#define D if (1) ; else
#endif

#include "../common/console.h"

#define DEIF_PAGESIZE   (1<<10) // flash page size in bytes
#define DEIF_DISKPAGES  64      // number of pages for disk

#include "deif.h"

uint16_t pc, mem [1<<13];

static uint16_t mask12(uint16_t w) { return w & 07777; }
static uint16_t mask13(uint16_t w) { return w & 017777; }
static uint16_t mask14(uint16_t w) { return w & 037777; }

// simulated DF32 disk

#define DF32_WC mem[07750]
#define DF32_MA mem[07751]

struct {
    union {
        struct { uint16_t err :3, fld :3, ext :5, _1 :1; } s;
        uint16_t status;
    };
    uint16_t daddr;
    uint8_t write, sched, done;
} df32;

static void df32io (void) {
    uint16_t daddr = (df32.s.ext << 12) | df32.daddr;
    uint16_t* field = mem + (df32.s.fld << 12);
    if (V & 2)
        printf("\t\t%s %06o WC %04o MA %o.%04o",
                df32.write ? "WRITE" : "READ ",
                daddr, DF32_WC, df32.s.fld, DF32_MA);
    if (V & 4) {
        if ((DF32_MA+1) & 7)
            printf("\r\n\t%04o:%*s", DF32_MA & 07770, ((DF32_MA+1) & 7) * 5, "");
    } else if (V & 2)
        printf("\r\n");

    do {
        if (daddr >= DEIF_DISKPAGES * DEIF_PAGESIZE / 2) {
            df32.s.err |= 02; // error, past disk end
            break;
        }
        DF32_WC = mask12(DF32_WC+1);
        DF32_MA = mask12(DF32_MA+1);
        if (df32.write)
            deif_write(daddr<<1, field + DF32_MA, 2);
        else
            deif_read(daddr<<1, field + DF32_MA, 2);
        if (V & 4) {
            if ((DF32_MA & 7) == 0)
                printf("\r\n\t%04o:", DF32_MA & 07770);
            printf(" %04o", field[DF32_MA]);
        }
        daddr = mask14(daddr+1);
    } while (DF32_WC != 0);

    if (V & 4)
        printf("\r\n");
    if (df32.write)
        daddr = mask14(daddr-1);
    df32.done = 1;
    df32.s.ext = daddr >> 12;
    df32.daddr = mask12(daddr);
}

static uint16_t opAddr (int ir) {
    uint16_t a = ir & 0177;
    if (ir & 0200)
        a |= (pc-1) & 07600;
    if (ir & 0400) {
        if ((a & 07770) == 010)
            mem[a] = mask12(mem[a]+1);
        a = mem[a];
    }
    return a;
}

void run (void) {
    D setbuf(stdout, 0);

    deif_init();
#ifdef ROM
    memcpy(mem, rom, sizeof rom);
#else
    // DF32 bootstrap loader
    D loadMem(diskBuf, sizeof diskBuf);

    mem[00200] = 07600;
    mem[00201] = 06603;
    mem[00202] = 06622;
    mem[00203] = 05202;
    mem[00204] = 05600;
    mem[07750] = 07576;
    mem[07751] = 07576;
#endif
    pc = 0200; 

    uint16_t sr = 0, ac = 0, mq = 0;
    int iena = 0;
    while (!done) {
        iena >>= 1; // delayed interrupt enabling, relies on sign extension

        //static short limit; if (++limit >= 10000) return; // limited run

        static short counter; // HACK: every 1024 ops, we fake an interrupt
        if (0 && (iena & 1) && (++counter & 0x03FF) == 0) {
            mem[0] = pc;
            pc = 1;
            iena = 0;
        }

        df32.sched >>= 1; // df32 I/O happens a few instructions later
        if (df32.sched & 1)
            df32io();

        int ir = mem[pc];
        if (V & 1) {
            static const char* const names [] = {
                "and", "tad", "isz", "dca", "jms", "jmp", "iot", "opr"
            };
            if ((V & 16) == 0 || (ir>>9) < 4 || (ir>>9) > 6)
                printf("%04o: %04o\t%s %c%c %#o\t ac=%#o\r\n",
                        pc, ir, names[ir>>9], ir & 0400 ? 'i' : ' ',
                        ir & 0200 ? ' ' : 'z', ir & 0177, ac);
        }
        pc = mask12(pc+1);
        switch ((ir >> 9) & 07) {

            case 0: // AND
                ac &= mem[opAddr(ir)] | 010000;
                break;

            case 1: // TAD
                ac = mask13(ac + mem[opAddr(ir)]);
                break;

            case 2: { // ISZ
                uint16_t ma = opAddr(ir);
                mem[ma] = mask12(mem[ma]+1);
                if (mem[ma] == 0)
                    pc = mask12(pc+1);
                break;
            }

            case 3: { // DCA
                uint16_t ma = opAddr(ir);
                mem[ma] = mask12(ac);
                ac &= 010000;
                break;
            }

            case 4: { // JMS
                uint16_t ma = opAddr(ir);
                mem[ma] = pc;
                pc = mask12(ma+1);
                break;
            }

            case 5: // JMP
                pc = opAddr(ir);
                break;

            case 6: // IOT
                D if ((ir & 0770) == 0) printf("%04o: %04o IOT\r\n", pc-1, ir);
                switch ((ir >> 3) & 077) {
                    case 00:
                        switch (ir) {
                            case 06001: iena = ~1; break; // delays one cycle
                            case 06002: iena = 0; break;
                        }
                        break;
                    case 03: { // keyboard
                        static int lastc = 0;
                        switch (ir & 7) {
                            case 1: // KSF
                                if (lastc || consoleHit()) {
                                    pc = mask12(pc+1);
                                    D printf("skip %d\r\n", lastc);
                                }
                                break;
                            case 2: // KCC
                            case 4: // KRS
                            case 6: // KRB
                                if (ir & 4) {
                                    if (!lastc)
                                        lastc = consoleIn();
                                    if (lastc)
                                        ac = (ac & 010000) | lastc;
                                    D printf("<%o>", ac);
                                }
                                if (ir & 2)
                                    lastc = 0;
                                break;
                            default:
                                D printf("key? %04o\r\n", ir);
                        }
                        break;
                    }
                    case 04: // teleprinter
                        if (ir & 01) // skip if ready
                            pc = mask12(pc+1);
                        if (ir & 04) // send byte
                            consoleOut(ac & 0177); // strip off parity
                        if (ir & 02) // clear flag
                            ac &= 010000;
                        break;
                    case 020: case 021: case 022: case 023:
                    case 024: case 025: case 026: case 027:
                        break; // ignored for now, MMU
                    case 060:
                        if (ir & 1) // DCMA
                            df32.s.err = df32.daddr = df32.done = 0;
                        if (ir & 6) { // DMAR, DMAW
                            df32.daddr |= mask12(ac);
                            df32.write = ir & 4;
#if 1
                            df32.sched = 1 << 5; // postpone 5 instr cycles
#else
                            df32io();
#endif
                            ac = 0;
                        }
                        break;
                    case 061:
                        switch (ir) {
                            case 06615: df32.status = ac; break; // DEAL
                        }
                        break;
                    case 062:
                        switch (ir) {
                            case 06621: // DFSE, skip if no error
                                if (df32.s.err == 0)
                                    pc = mask12(pc+1);
                                break;
                            case 06622: // DFSC, skip if done
                                if (df32.done)
                                    pc = mask12(pc+1);
                                break;
                        }
                        break;
                    default:
                        if (V & 8) {
                            printf("%04o: %04o?\r\n", pc-1, ir);
                            cleanup();
                            abort();
                        }
                }
                break;

            case 7: // OPR
                if ((ir & 0400) == 0) { // group 1
                    if (ir & 0200) // CLA
                        ac &= 010000;
                    if (ir & 0100) // CLL
                        ac &= 07777;
                    if (ir & 040) // CMA
                        ac ^= 07777;
                    if (ir & 020) // CML
                        ac ^= 010000;
                    if (ir & 01) // IAC
                        ac = mask13(ac+1);
                    switch (ir & 016) {
                        case 012: // RTR
                            ac = mask13((ac >> 1) | (ac << 12)); // fall through
                        case 010: // RAR
                            ac = mask13((ac >> 1) | (ac << 12));
                            break;
                        case 06: // RTL
                            ac = mask13((ac >> 12) | (ac << 1)); // fall through
                        case 04: // RAL
                            ac = mask13((ac >> 12) | (ac << 1));
                            break;
                        case 02: // BSW
                            ac = (ac & 010000) | ((ac >> 6) & 077)
                                                | ((ac << 6) & 07700);
                            break;
                    }
                } else if ((ir & 01) == 0) { // group 2
                    // SMA, SPA, SZA, SNA, SNL, SZL
                    int s = ((ir & 0100) && (ac & 04000)) ||
                            ((ir & 040) && (ac & 07777) == 0) ||
                            ((ir & 020) && (ac & 010000) != 0) ? 0 : 010;
                    if (s == (ir & 010))
                        pc = mask12(pc+1);
                    if (ir & 0200) // CLA
                        ac &= 010000;
                    if (ir & 04) // OSR
                        ac |= sr;
                    if (ir & 02) { // HLT
                        consoleOuts("\r\nHALT\r\n");
                        return;
                    }
                } else { // group 3
                    uint16_t t = mq;
                    if (ir & 0200) // CLA
                        ac &= 010000;
                    if (ir & 020) { // MQL
                        mq = ac & 07777;
                        ac &= 010000;
                    }
                    if (ir & 0100)
                        ac |= t;
                }
                break;
        }
    }
}
