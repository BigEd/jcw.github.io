An experiment with proportional fonts for 128x32 and 128x64 OLEDs using SSD1306.

> **TL;DR** - Type `make` for a demo, then `make font.hdr` or `make font.fs`.

These displays have the data organised in 8-pixels-down per byte, which makes it
very easy to generate characters as long as they stay on a 8-fold vertical grid.
With this approach, a copy of the display pixels need not be stored in the µC.

The `pixels.c` program takes a font definition file, such as `font.txt`, and
converts if to a compact table with the following layout:

    byte 0: first character position in the font
    byte 1: N, i.e. number of characters in the font
    bytes 2..N+1: pixel width of each glyph, excluding the final empty column
    bytes N+2..end: font data, packed in the same 8-pixel vertical-byte format

When given a second argument, `pixel` generates a text file for use in C code.
If the name of the output file ends in `.fs`, a Forth source is generated.

Finally, `pixel` produces an ASCII-art demo of some text on a 128x64 simulated
display - set your terminal window to at least 130 wide to view the result:

![](example.png)

The output can be proportional text (or monospaced, if you make all chars the
same width) and the font can be displayed in double-wide or double-high mode,
or both. This is done by pixel-doubling as needed in the requested direction.
With a suitable font, logos, icons, and other special characters can be created,
since each _glyph_ can be up to 64 pixels wide. Note that a font of 16 such wide
entries could be used to fill the entire display with arbitrary pixel images.

For 128x32 displays, vertical pixel-doubling is needed to get the proper output.
