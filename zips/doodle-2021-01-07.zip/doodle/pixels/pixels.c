#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

uint8_t widths [256], font [64*256], data [2+65*256], display [1024];

static void loadImage (const char* filename) {
    FILE* fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);
    }
    char line [20];
    int i;
    if (fgets(line, sizeof line, fp) == 0 ||
            sscanf(line, "%d", &i) != 1 || 0 < 0 || i >= 256) {
        printf("skip count 0..255 expected: %s\n", line);
        exit(1);
    }
    int total = 0;
    while (fgets(line, sizeof line, fp) != 0) {
        int width;
        if (sscanf(line, "%d", &width) != 1 || width < 0 || width > 64) {
            printf("width 0..64 expected: %s (total %d)\n", line, total);
            exit(1);
        }
        if (width > 0)
            for (int j = 0; j < 8; ++j) {
                fgets(line, sizeof line, fp);
                if (strlen(line) != width + 1 || line[width] != '\n') {
                    printf("width %d expected: %s (total %d)\n",
                            width, line, total);
                    exit(1);
                }
                for (int k = 0; k < width; ++k)
                    if (line[k] != '.')
                        font[total+k] |= 1 << j;
            }
        widths[i++] = width;
        total += width;
    }
    printf("total %d\n", total);
    fclose(fp);
}

static void saveImage (const char* infile, const char* outfile, int len) {
    FILE* fp = fopen(outfile, "w");
    if (fp == 0) {
        perror(outfile);
        exit(1);
    }

    int chdr = strcmp(outfile+strlen(outfile)-3, ".fs") != 0;
    fprintf(fp, "%s generated from file: %s\n", chdr ? "//" : "\\", infile);

    char buf [10];
    int width = 0;
    for (int i = 0; i < len; ++i) {
        sprintf(buf, chdr ? "%d," : "%d c, ", data[i]);
        if (width + strlen(buf) >= 80) {
            fputc('\n', fp);
            width = 0;
        }
        fputs(buf, fp);
        width += strlen(buf);
    }
    fputc('\n', fp);

    fclose(fp);
}

static int fontIndex (uint8_t ch) {
    int pos = 0;
    for (int k = 0; k < ch-data[0]; ++k)
        pos += data[2+k];
    return pos;
}

static void showText (const char* s) {
    int n = strlen(s);

    int w = n;
    for (int i = 0; i < n; ++i)
        w += widths[s[i]];

    putchar('+');
    for (int i = 0; i < w; ++i)
        putchar('-');
    putchar('+');
    putchar('\n');

    for (int i = 0; i < 8; ++i) {
        putchar('|');
        for (int j = 0; j < n; ++j) {
            int pos = fontIndex(s[j]);
            for (int k = 0; k < widths[s[j]]; ++k) {
                int f = (font[pos+k] >> i) & 1;
                putchar(f ? '#' : ' ');
            }
            putchar(' ');
        }
        putchar('|');
        putchar('\n');
    }

    putchar('+');
    for (int i = 0; i < w; ++i)
        putchar('-');
    putchar('+');
    putchar('\n');
}

static void clear (void) {
    memset(display, 0, sizeof display);
}

static void show (void) {
    putchar('+');
    for (int i = 0; i < 128; ++i)
        putchar('-');
    putchar('+');
    putchar('\n');

    for (int i = 0; i < 64; ++i) {
        putchar('!');
        const uint8_t* start = display + 128 * (i / 8);
        int shift = i % 8;
        for (int j = 0; j < 128; ++j)
            putchar((start[j] >> shift) & 1 ? '#' : ' ');
        putchar('!');
        putchar('\n');
    }

    putchar('+');
    for (int i = 0; i < 128; ++i)
        putchar('-');
    putchar('+');
    putchar('\n');
}

static const uint8_t v2x [] = {
    0x00, 0x03, 0x0C, 0x0F, 0x30, 0x33, 0x3C, 0x3F,
    0xC0, 0xC3, 0xCC, 0xCF, 0xF0, 0xF3, 0xFC, 0xFF,
};

static void emitText (uint32_t mode, const char* s) {
    union { uint32_t w; struct { uint8_t col, row, hx, vx; }; } m;
    m.w = mode;
    for (int r = 0; r < m.vx; ++r) {
        uint8_t* start = display + m.col + 128 * (m.row + r);
        for (int i = 0; s[i] != 0; ++i) {
            if (s[i] < data[0] || s[i] > data[0] + data[1])
                continue;
            int pos = 2 + data[1] + fontIndex(s[i]);
            int width = data[2+s[i]-data[0]];
            for (int j = 0; j < width; ++j) {
                uint8_t b = data[pos+j];
                if (m.vx > 1)
                    b = v2x[(b >> (4*r)) & 0x0F];
                for (int k = 0; k < m.hx; ++k)
                    *start++ = b;
            }
            start += m.hx;
        }
    }
}

int main (int argc, char** argv) {
    if (argc < 2 || argc > 3) {
        printf("Usage: %s loadtxt ?savehdr?\n", argv[0]);
        exit(1);
    }

    loadImage(argv[1]);

    int lo = 0;
    while (widths[lo] == 0 && lo < 256)
        ++lo;
    int hi = 256;
    while (widths[hi-1] == 0 && hi > 0)
        --hi;

    data[0] = lo;
    data[1] = hi - lo;

    int total = 0;
    for (int i = lo; i < hi; ++i) {
        uint8_t w = widths[i];
        data[2+i-lo] = w;
        total += w;
    }

    memcpy(data+2+hi-lo, font, total);
    printf("range %d .. %d, %d bytes\n", lo, hi-1, 2+hi-lo+total);

    if (argc < 3) {
#if 0
        showText("Hello, World!");
        showText("The quick brown fox jumps over the lazy dog.");
        showText("[1+2-3] 0 (4*5/6) @ <7&8%9> # {a:\"bcd\"}");
#else
        clear();
        // the first arg indicates where and how to draw the characters
        // hi-to-lo: vscale (1..2), hscale (1..8), vpos (0..7), hpos (0..127)
        emitText(0x01010000, "Hello, World!");
        emitText(0x01010100, "The quick brown fox jumps over the lazy dog.");
        emitText(0x02010300, "[1+2-3] (4*5/6) <7&8%9> {a:'b'}");
        emitText(0x0102050A, "123456789.0");
        emitText(0x02020601, "ABCDE -123.456");
        show();
#endif
    } else
        saveImage(argv[1], argv[2], 2+hi-lo+total);

    return 0;
}
