# Create a GUI window in a C++ app on Linux

Example adapted from <https://samulinatri.com/blog/sdl-window-opengl-context-cpp-tutorial/>.

Needs `apt-get install libsdl2-dev libglew-dev`. Code tested under Ubuntu 19.10.
