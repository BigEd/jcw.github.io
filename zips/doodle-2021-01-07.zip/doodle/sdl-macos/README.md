# Create a GUI window in a C++ app on MacOS

Example adapted from <https://samulinatri.com/blog/sdl-window-opengl-context-cpp-tutorial/>.

Needs `brew install sdl2`. Code tested under macOS Catalina (10.15.1).
