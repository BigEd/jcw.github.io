#include <iostream>
#include <iomanip>
using namespace std;

int main () {
    cout << "haha" << endl;
    cout << "<" << setw(9) << 123 << ">" << 456 << "." << endl;
    cout << "<" << showbase
         << setw(9) << setfill('#') << left << hex << 123
         << ">" << noshowbase << endl;
    cout << true << boolalpha << true << noboolalpha
         << false << boolalpha << false << noboolalpha << endl;
    return 0;
}
