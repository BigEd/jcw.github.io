// g++ -std=c++11 -o main main.cpp && ./main

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <pthread.h>

volatile uint32_t ticks;

auto ticker = []() {
    if (++ticks % 1000 == 0)
        printf("<TICK>");
};

auto typer = [](int ch) {
    printf("[%c]", ch);
};

void sleeping () {
    struct timespec ts {0, 100*1000}; // 100 µs
    nanosleep(&ts, nullptr);
}

void wait_ms (int ms) {
    auto limit = ticks + ms;
    while (limit - ticks > 0)
        sleeping();
}

void send (char const* msg) {
    while (*msg) {
        putchar(*msg++);
        wait_ms(50);
    }
    putchar('\n');
}

enum Ops : uint8_t { One, Ten, Delay, Hello, World, Back, Exit };

void run (Ops const* ip) {
    int v;

    while (true)
        switch (*ip++) {
            case One:   v = 1; break;
            case Ten:   v = 10; break;
            case Delay: wait_ms(100 * v); break;
            case Hello: send("hello"); break;
            case World: send("world"); break;
            case Back:  ip -= *ip; break;
            case Exit:  return;
            default:    assert(false);
        }
}

Ops const program [] = {
    Hello,
    Hello,
    One,
    Delay,
    World,
    Ten,
    Delay,
    Back,
    (Ops) 7,
    //Exit,
};

void* tickThread (void* arg) {
    struct timespec const ts {0, 1000*1000}; // 1 ms
    while (true) {
        nanosleep(&ts, nullptr);
        ticker();
    }
}

void* typeThread (void* arg) {
    char line [100];
    while (fgets(line, sizeof line, stdin) != nullptr) {
        for (size_t i = 0; i < sizeof line && line[i] >= ' '; ++i) {
            wait_ms(42);
            typer(line[i]);
        }
        typer('\n');
    }
    pthread_exit(nullptr);
}

int main(int argc, char *argv[]) {
    setbuf(stdout, nullptr);

    pthread_t tickId, typeId;
    pthread_create(&tickId, nullptr, tickThread, nullptr);
    pthread_create(&typeId, nullptr, typeThread, nullptr);

    run(program);

    pthread_join(typeId, nullptr);
}
