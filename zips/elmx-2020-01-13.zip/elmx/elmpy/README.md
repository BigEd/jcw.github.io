The `client/` implements a crude calculator in the browser, and uses PureCSS:

![](calculator.png)

> Note: the `client2/` version implements a "responsive" CSS/JS variant.

The `server/` is a web server based on MicroWebSrv2 (also works in MicroPython).

To launch the client in live-development mode, use `make`.  
To generate an `elm.js` production version:

```text
% make build
elm make src/Main.elm --output=elm.js --optimize
Success! Compiled 1 module.

    Main ───> elm.js

full size:    117470 b
minified:      88585 b
compressed:    20699 b
```

The client does not really need this server, other than to serve static files.  
This merely combines Elm + µPy to explore dev-setup and size implications.

Elm needs to be installed, along with a few extra tools, perhaps like this:  
`  npm install -g elm elm-live elm-format terser`

-jcw, 2020-01-09
