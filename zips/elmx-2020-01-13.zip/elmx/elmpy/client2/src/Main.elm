module Main exposing (main)

import Browser
import Html exposing (..)
import Html.Attributes exposing (class, href, id, readonly, value)
import Html.Events exposing (onClick, onInput)



-- MODEL


type alias Model =
    { last : Float, top : Float }


init : () -> ( Model, Cmd Msg )
init _ =
    ( { last = 111, top = 222 }, Cmd.none )



-- SUBSCRIPTIONS


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.none



-- UPDATE


type Msg
    = DoAdd
    | DoSub
    | DoMul
    | DoDiv
    | ChangedTop String


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    let
        newTop =
            case msg of
                DoAdd ->
                    model.last + model.top

                DoSub ->
                    model.last - model.top

                DoMul ->
                    model.last * model.top

                DoDiv ->
                    model.last / model.top

                ChangedTop str ->
                    case String.toFloat str of
                        Just val ->
                            val

                        Nothing ->
                            model.top

        newLast =
            case msg of
                ChangedTop str ->
                    model.last

                _ ->
                    model.top
    in
    ( { model | top = newTop, last = newLast }, Cmd.none )



-- VIEW


view : Model -> Html Msg
view model =
    div [ id "layout" ]
        [ a [ href "#menu", id "menuLink", class "menu-link" ] [ span [] [] ]
        , div [ id "menu" ] [ menuView model ]
        , div [ id "main" ] [ headerView model, contentView model ]
        ]


menuView : Model -> Html Msg
menuView model =
    div [ class "pure-menu" ]
        [ a [ href "#", class "pure-menu-heading" ] [ text "Company" ]
        , ul [ class "pure-menu-list" ]
            [ li [ class "pure-menu-item" ]
                [ a [ href "#", class "pure-menu-link" ] [ text "Home" ] ]
            , li [ class "pure-menu-item" ]
                [ a [ href "#", class "pure-menu-link" ] [ text "About" ] ]
            , li [ class "pure-menu-item menu-item-divided pure-menu-selected" ]
                [ a [ href "#", class "pure-menu-link" ] [ text "Services" ] ]
            , li [ class "pure-menu-item" ]
                [ a [ href "#", class "pure-menu-link" ] [ text "Contact" ] ]
            ]
        ]


headerView : Model -> Html Msg
headerView model =
    div [ class "header" ]
        [ h1 [] [ text "Calculator" ]
        , h2 [] [ text "My first exploration in Elm!" ]
        ]


contentView : Model -> Html Msg
contentView model =
    div [ class "content" ]
        [ h2 [ class "content-subhead" ] [ text "TODO: add stack ..." ]
        , div [ class "pure-form" ]
            [ p []
                [ input
                    [ readonly True
                    , value (String.fromFloat model.last)
                    ]
                    []
                ]
            , p []
                [ input
                    [ onInput ChangedTop
                    , value (String.fromFloat model.top)
                    ]
                    []
                ]
            , p []
                (rowOfButtons
                    [ "ADD", "SUB", "MUL", "DIV" ]
                    [ DoAdd, DoSub, DoMul, DoDiv ]
                )
            ]
        ]


rowOfButtons labels msgs =
    List.intersperse (text " \u{00A0} ") (List.map2 singleButton labels msgs)


singleButton label msg =
    button [ onClick msg, class "pure-button" ] [ text label ]



-- MAIN


main =
    Browser.element
        { init = init
        , subscriptions = subscriptions
        , update = update
        , view = view
        }
