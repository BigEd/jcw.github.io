#include <Arduino.h>

#if LOLIN32
constexpr int LED = 22; // not 5!
#elif TTGOLED
// https://electricnoodlebox.wordpress.com/tutorials/esp32-ttgo-dev-board-with-oled-display-tutorial/
constexpr int LED = 16;
#endif

void setup() {
    Serial.begin(115200);
    pinMode(LED, OUTPUT);
}

void loop() {
    Serial.printf("%lu\n", millis());

    digitalWrite(LED, 0);
    delay(100);
    digitalWrite(LED, 1);
    delay(400);
}
