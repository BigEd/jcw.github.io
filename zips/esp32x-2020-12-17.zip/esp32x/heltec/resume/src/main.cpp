#include <Arduino.h>
#include <setjmp.h>

struct {
    int stack [1000];
    jmp_buf top;
    void (*task)();
} stacks [3], *current;

jmp_buf* caller;

void suspend () {
    int callee [1];
    if (setjmp(current->top) == 0) {
        // suspending: copy stack out and jump to caller
        memcpy(current->stack, callee, (uintptr_t) caller - (uintptr_t) callee);
        longjmp(*caller, 1);
    } else {
        // resuming: copy stack in and prevent re-resuming
        memcpy(callee, current->stack, (uintptr_t) caller - (uintptr_t) callee);
        memset(current->top, 0, sizeof current->top);
    }
}

void resume (int num) {
    current = &stacks[num];
    jmp_buf bottom;
    caller = &bottom;
    if (setjmp(bottom) == 0) {
        // either call for the first time, or resume saved state
        if (current->task != nullptr)
            current->task();
        else
            longjmp(current->top, 1);
    }
    // state has been saved, return to caller
    current->task = nullptr;
}

void hiya () {
    while (true) {
        puts("hiya, dude");
        suspend();
    }
}

void gday () {
    while (true) {
        puts("gday, mate");
        suspend();
        puts("wuzzup?");
        suspend();
    }
}

void howdy () {
    while (true) {
        puts("howdy, folks");
        suspend();
        suspend();
    }
}

void demoGreetings () {
    stacks[0].task = hiya;
    stacks[1].task = gday;
    stacks[2].task = howdy;

    for (int i = 0; i < 12; ++i)
        resume(i % 3);
}

void demoPinToggle () {
    stacks[0].task = []() {
        while (true) {
            digitalWrite(BUILTIN_LED, 1);
            suspend();
        }
    };

    stacks[1].task = []() {
        while (true) {
            digitalWrite(BUILTIN_LED, 0);
            suspend();
        }
    };

    for (int i = 0; i < 1000000; ++i)
        resume(i % 2);

    while (true)
        resume(0);
}

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.printf("\nBUILTIN_LED = %d\n", BUILTIN_LED);
    pinMode(BUILTIN_LED, OUTPUT);

    demoGreetings();
    demoPinToggle();
}

void loop() {
    Serial.printf("%lu\n", millis());

    digitalWrite(BUILTIN_LED, 1);
    delay(100);
    digitalWrite(BUILTIN_LED, 0);
    delay(400);
}
