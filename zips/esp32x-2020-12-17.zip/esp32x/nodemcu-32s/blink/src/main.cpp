#include <Arduino.h>

#define printf Serial.printf

constexpr int LED = 2;

void setup () {
    Serial.begin(115200);
    pinMode(LED, OUTPUT);
}

void loop () {
    printf("%d\n", millis());

    digitalWrite(LED, 1);
    delay(100);
    digitalWrite(LED, 0);
    delay(400);
}
