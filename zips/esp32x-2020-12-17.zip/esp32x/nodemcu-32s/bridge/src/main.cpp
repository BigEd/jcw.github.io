#include <WiFi.h>
#include <PubSubClient.h>
#include <CAN.h>

#include <../../../ssidpass.h>

#define DEBUG 0

const char* mqttServer = "192.168.188.86";
const char* myTopic = "test/can";
char outTopicBuf [sizeof myTopic + 5]; // room to add "/xyz"

WiFiClient espClient;
PubSubClient client (espClient);

void callback (char* topic, byte* payload, unsigned int len) {
    if (DEBUG) {
        Serial.printf(" IN [%s] ", topic);
        for (int i = 0; i < len; i++)
            Serial.print((char)payload[i]);
        Serial.println();
    }

    // convert "xxx#[xx]*" hex data to binary values and send it out
    if (len < 4 || len > 20 || (len & 1) || payload[3] != '#')
        Serial.println("bad length");
    else {
        int v;
        if (sscanf((const char*) payload, "%x", &v)) {
            CAN.beginPacket(v);
            for (int i = 4; i < len; i += 2)
                if (sscanf((const char*) payload + i, "%2x", &v))
                    CAN.write(v);
                else
                    Serial.printf("bad byte #%d\n", (i-4)/2);
            CAN.endPacket();
        } else
            Serial.println("bad id");
    }
}

void reconnect () {
    Serial.print("MQTT connect ...");
    if (client.connect("ESP32Client")) {
        Serial.println("connected");
        client.subscribe(myTopic);
    } else {
        Serial.println("failed, try again in 5s");
        delay(5000);
    }
}

void setup () {
    pinMode(BUILTIN_LED, OUTPUT);

    Serial.begin(115200);
    Serial.print("HTTP connect ");

    WiFi.begin(ssid, pass);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println(WiFi.localIP());

    if (!CAN.begin(1000000))
        printf("CAN init failed\n");

    client.setServer(mqttServer, 1883);
    client.setCallback(callback);
}

void loop () {
    while (!client.connected())
        reconnect();

    client.loop();

    int len = CAN.parsePacket();
    if (len > 0) {
        digitalWrite(BUILTIN_LED, !digitalRead(BUILTIN_LED));

        int id = CAN.packetId();
        sprintf(outTopicBuf, "%s/%03x", myTopic, id);

        char msgBuf [17];
        for (int i = 0; i < len; ++i)
            sprintf(msgBuf + 2*i, "%02x", CAN.read());
        msgBuf[2*len] = 0;

        if (DEBUG)
            printf("OUT [%s] %s\n", outTopicBuf, msgBuf);
        client.publish(outTopicBuf, msgBuf);
    }
}
