#include <Arduino.h>
#include <CAN.h>

#define printf Serial.printf

constexpr int LED = 2;

void setup () {
    pinMode(LED, OUTPUT);
    Serial.begin(115200);

    if (!CAN.begin(1000000))
        printf("CAN init failed\n");
}

void loop () {
    int len = CAN.parsePacket();
    if (len > 0) {
        printf("%d\n", millis());
        digitalWrite(LED, !digitalRead(LED));

        int id = CAN.packetId();
        printf("id %x len %d\n", id, len);
    }

    static uint32_t last;
    if (millis() / 3000 != last) {
        last = millis() / 3000;

        printf("begin %d\n", millis());
        CAN.beginPacket(0x222);
        CAN.write(0xFF);
        CAN.endPacket();
        printf("  end %d\n", millis());
    }
}
