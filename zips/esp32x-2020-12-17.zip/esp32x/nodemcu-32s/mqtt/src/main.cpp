// from "mqtt_esp8266" example, https://platformio.org/lib/show/89/PubSubClient
/*
   Basic ESP32 MQTT example

   This sketch demonstrates the capabilities of the pubsub library in
   combination with the ESP32 board/library.

   It connects to an MQTT server then:
   - publishes "hello world" to the topic "outTopic" every two seconds
   - subscribes to the topic "inTopic", printing out any messages
   it receives. NB - it assumes the received payloads are strings not binary
   - If the 1st character of the topic "inTopic" is an 1, switch ON the ESP Led,
   else switch it off

   It will reconnect to the server if the connection is lost using a blocking
   reconnect function. See the 'mqtt_reconnect_nonblocking' example for how to
   achieve the same result without blocking the main loop.
*/

#include <WiFi.h>
#include <PubSubClient.h>

#include <../../../ssidpass.h>

const char* mqtt_server = "broker.mqtt-dashboard.com";

WiFiClient espClient;
PubSubClient client (espClient);

void callback (char* topic, byte* payload, unsigned int length) {
    Serial.printf("Message IN [%s] ", topic);
    for (int i = 0; i < length; i++)
        Serial.print((char)payload[i]);
    Serial.println();

    digitalWrite(BUILTIN_LED, !digitalRead(BUILTIN_LED)); // toggle, active low
}

void reconnect () {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect("ESP32Client")) {
        Serial.println("connected");
        client.publish("outTopic", "hello world");
        client.subscribe("inTopic");
    } else {
        Serial.println("failed, try again in 5s");
        delay(5000);
    }
}

void setup () {
    pinMode(BUILTIN_LED, OUTPUT);

    Serial.begin(115200);
    Serial.print("Connecting ");

    WiFi.begin(ssid, pass);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println(WiFi.localIP());

    client.setServer(mqtt_server, 1883);
    client.setCallback(callback);
}

void loop () {
    while (!client.connected())
        reconnect();

    client.loop();

    static int value;
    static uint32_t lastMsg;
    uint32_t now = millis();
    if (now - lastMsg > 2000) {
        lastMsg = now;

        char msg[50];
        snprintf(msg, sizeof msg, "hello world #%d", ++value);
        Serial.printf("Message OUT: %s\n", msg);
        client.publish("outTopic", msg);
    }
}
