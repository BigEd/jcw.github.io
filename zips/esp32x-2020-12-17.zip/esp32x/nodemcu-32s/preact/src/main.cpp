#include <ESPAsyncWebServer.h>
#include <SPIFFS.h>

#include "../../../ssidpass.h"

AsyncWebServer server (80);

void setup () {
    Serial.begin(115200);

    WiFi.begin(ssid, pass);
    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(500);
    }
    Serial.println(WiFi.localIP());

    SPIFFS.begin();

    server.on("/heap", HTTP_GET, [](AsyncWebServerRequest* req) {
        req->send(200, "text/plain", String(ESP.getFreeHeap()));
    });

    server.serveStatic("/", SPIFFS, "/").setDefaultFile("index.html");

    server.onNotFound([](AsyncWebServerRequest *req) {
        req->send(404);
    });

    server.begin();
}

void loop () {}
