#include <Arduino.h>

#define printf Serial.printf

void setup () {
    Serial.begin(115200);

    delay(100);

    printf("### ALL:\n\n");
    heap_caps_print_heap_info(MALLOC_CAP_INTERNAL);
    printf("\n");

    printf("### DATA:\n\n");
    heap_caps_print_heap_info(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    printf("\n");

    printf("64K: %08x\n", malloc(65536));
    printf("64K: %08x\n", malloc(65536));
    printf("64K: %08x\n", malloc(65536));
    printf("\n");

    printf("### DATA:\n\n");
    heap_caps_print_heap_info(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
}

void loop () {}
