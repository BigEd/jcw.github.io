// see https://circuits4you.com/2019/01/05/connecting-esp32-to-wifi-network/
 
#include <WiFi.h>

//const char* ssid = "SSID";
//const char* pass = "PASS";
#include <../../../ssidpass2.h>

void setup() {
    Serial.begin(115200);

    WiFi.begin(ssid, pass);
    Serial.print("Connecting to ");
    Serial.print(ssid);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(" .");
    }

    Serial.print(" connected as ");  
    Serial.println(WiFi.localIP());
}

void loop() {}
