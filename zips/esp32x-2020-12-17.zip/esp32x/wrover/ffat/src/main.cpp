#include <Arduino.h>
#include <FFat.h>

#define printf Serial.printf

constexpr int LED = 22;

void listDir(fs::FS &fs, const char * dirname, uint8_t levels){
    printf("Listing directory: %s\n", dirname);

    File root = fs.open(dirname);
    if(!root){
        Serial.println("Failed to open directory");
        return;
    }
    if(!root.isDirectory()){
        Serial.println("Not a directory");
        return;
    }

    File file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            Serial.print("  DIR : ");
            Serial.println(file.name());
            if(levels){
                listDir(fs, file.name(), levels -1);
            }
        } else {
            Serial.print("  FILE: ");
            Serial.print(file.name());
            Serial.print("  SIZE: ");
            Serial.println(file.size());
        }
        file = root.openNextFile();
    }
}

void setup () {
    Serial.begin(115200);
    pinMode(LED, OUTPUT);

    if(!FFat.begin(true)){
        Serial.println("Mount Failed");
        return;
    }
    Serial.println("File system mounted");

    File file = FFat.open("/testfat.txt", FILE_WRITE);
 
    if (!file) {
      Serial.println("There was an error opening the file for writing");
      return;
    }
    if (file.print("TEST"))
      Serial.println("File was written");
 
    file.close();

    listDir(FFat, "/", 0);
}

void loop () {
    printf("%d\n", millis());

    digitalWrite(LED, 1);
    delay(100);
    digitalWrite(LED, 0);
    delay(400);
}
