# Flow example

This area illustrates how to set up a Go application based on Flow.
The `warmup.json` file contains groups which define the actual application.
Compile and launch with: **`go run main.go`** (`-h` for help).
