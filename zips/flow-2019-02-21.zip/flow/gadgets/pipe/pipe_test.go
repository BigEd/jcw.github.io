package gadgets

import (
	"github.com/jcw/flow"
)

func ExamplePipe() {
	g := flow.NewCircuit()
	g.Add("p", "Pipe")
	g.Feed("p.In", 123)
	g.Run()
	// Output:
	// Lost int: 123
}
