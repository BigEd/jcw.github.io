package flow

type RPC struct {
	Args  []interface{}
	Reply chan<- interface{}
}

func Call(service Output, args ...interface{}) interface{} {
	replyChan := make(chan interface{})
	defer close(replyChan)
	service.Send(&RPC{Args: args, Reply: replyChan})
	return <-replyChan
}
