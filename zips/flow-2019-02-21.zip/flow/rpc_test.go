package flow_test

import (
	"github.com/jcw/flow"
	_ "github.com/jcw/flow/gadgets"
)

func init() {
	flow.Registry["DemoRpc"] = func() flow.Circuitry { return new(DemoRpc) }
	flow.Registry["TestRpc"] = func() flow.Circuitry { return new(TestRpc) }
}

type DemoRpc struct {
	flow.Gadget
	Rpc flow.Input
}

func (g *DemoRpc) Run() {
	for m := range g.Rpc {
		rpc := m.(*flow.RPC)
		arg := rpc.Args[0].(int)
		rpc.Reply <- 2 * arg
	}
}

type TestRpc struct {
	flow.Gadget
	In  flow.Input
	Out flow.Output
	Req flow.Output `service:"Demo"`
}

func (g *TestRpc) Run() {
	for m := range g.In {
		v := flow.Call(g.Req, m)
		g.Out.Send(v)
	}
}

func ExampleRPC() {
	g := flow.NewCircuit()
	g.Add("service", "DemoRpc")
	g.Add("caller", "TestRpc")
	g.Connect("caller.Req", "service.Rpc", 0)
	g.Feed("caller.In", 123)
	g.Feed("caller.In", 234)
	g.Run()
	// Output:
	// Lost int: 246
	// Lost int: 468
}

func ExampleRPC2() {
	g := flow.NewCircuit()
	g.Add("service", "DemoRpc")
	g.Add("caller", "TestRpc")
	g.Connect("caller.Req", "service.Rpc", 0)
	g.Feed("caller.In", 123)
	g.Feed("caller.In", 234)
	g.Run()
	// Output:
	// Lost int: 246
	// Lost int: 468
}
