An experimental tiny MQTT <=> Mecrisp bridge.
