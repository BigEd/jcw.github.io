A miniature version of Folie, only for interactive mode. No uploads, sends, etc.
