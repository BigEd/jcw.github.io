### Dabbling in the world of FPGAs

[stiv-fsmc](quartus/stiv-fsmc/) :
Fast data transfers with an STM32 using its FSMC hardware  
[mini-sramtest](quartus/mini-sramtest/) :
This adds a 512Kx8 SRAM, connected via a custom PCB  
[stiv-sdramtest](quartus/stiv-sdramtest/) :
Adapted from SDRAM code which came with the Storm IV board  
[stiv-vgaout](quartus/stiv-vgaout/) :
VGA test ported to the Storm IV board, 8 colours  
[vgaout](quartus/vgaout/) :
Generate a 64-colour 640x480 VGA test signal  
[tvout](quartus/tvout/) :
Generate a PAL monochrome composite video out signal  
[spiSim](verilator/spiSim/) :
Writing a minimal SPI master controller from scratch  
[sdramSim](verilator/sdramSim/) :
Simulation of [fpga4fun][F4F]'s simple SDRAM memory controller  
[edgeSim](verilator/edgeSim/) :
An example of simulating a circuit without hardware  
[lite8080](quartus/lite8080/) :
A microcoded [8080 core][l80] running a Small-C demo - cystarter  
[fourHex](quartus/fourHex/) :
Display "1234" on the multiplexed 7-segment display - cy4easy  
[grayLeds](quartus/grayLeds/) :
Count in Gray code on the eight built-in LEDs - cy4mini  
[tinyUart](quartus/tinyUart/) :
Send out E's @ 115200 baud over a tiny UART - cy4starter  
[vga1024](quartus/vga1024/) :
Generate a 1024x600 VGA'ish test pattern - cy4starter  
[de10l-blink](quartus/de10l-blink/) :
Blink/counter demo for Terasic DE10-Lite, based on Max 10  
[de10l-clock](quartus/de10l-clock/) :
Alternate clock demo using PLL  
[de10l-vga](quartus/de10l-vga/) :
VGA demo for 800x600 display  
[de10l-spi](quartus/de10l-spi/) :
Interface Blue Pill with DE10-Lite via SPI  
[ice-example](icestorm/ice-example/) :
Breathing LED demo using icestorm and TinyFPGA-B board  
[icebreaker](icestorm/icebreaker/) :
Blinking an LED on the iCEBreaker board (up5k)  
[goboard](icestorm/goboard/) :
Blinking an LED on the NandLand Go board (hx1k)  
[uart](verilator/uart/) :
UART rx & tx, tied to a "verilated" UART w/ named pipes  
[arty-blink](vivado/arty-blink/) :
Blinking LEDs on the Arty A7-35 board  
[qmc4sk-explore](quartus/qmc4sk-explore/) :
First exploration of the QMTech Cyclone IV Starter Kit

See <http://jeelabs.org/>.

[F4F]: http://www.fpga4fun.com/SDRAM2.html
[l80]: http://opencores.org/project,light8080,demos
