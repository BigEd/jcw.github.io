EP4CE6 - $46 on eBay w/ USB Blaster - <http://www.ebay.com/itm/272135503067>

![](image.jpg)
