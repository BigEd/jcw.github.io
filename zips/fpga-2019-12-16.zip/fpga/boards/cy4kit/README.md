EP4CE6 - €34 on AliExpress w/ USB Blaster - <https://www.aliexpress.com/item/x/32691369830.html>

![](image.jpg)
