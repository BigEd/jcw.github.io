EP4CE6 - $45 on eBay - <http://www.ebay.com/itm/111975895262>

![](image.jpg)
