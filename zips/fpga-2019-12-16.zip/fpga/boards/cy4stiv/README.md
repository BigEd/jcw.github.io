EP4CE6, labeled "Storm IV" - origin unknown - similar to [this one](
https://www.aliexpress.com/item/1637446763.html) - about $50 on AliExpress.

![](image.jpg)
