Examples of running Icarus Verilog simulations.

* **hello/hello** - trivial demo, uses `$display` to print info
* **hello/counter** - uses `$monitor` to dump changes
* **counter/** - example of using GTKWave for graphical waveform display

Assumes `iverilog` and `gtkwave` packages are installed, tested on Linux.
