## Breathing LED demo for [TinyFPGA-B](https://www.tindie.com/products/tinyfpga/tinyfpga-b2/)

Derived from [icotools](https://github.com/cliffordwolf/icotools) and
[tinyfpga](https://github.com/tinyfpga/TinyFPGA-B-Series) examples, to get all
the basics right for use with the icestorm toolchain, see these links:

* https://github.com/tinyfpga/TinyFPGA-B-Series/tree/master/icestorm_template
* https://github.com/cliffordwolf/icotools/tree/master/examples/blinky

Extracts from a sample run:

```text
$ make
yosys -p 'synth_ice40 -top example -blif example.blif' example.v
[...]
End of script. Logfile hash: 64faa58217, CPU: user 0.47s system 0.02s
Yosys 0.7+     336 (git sha1 adf17547, clang 9.0.0 -fPIC -Os)
Time spent: 25% 9x read_verilog (0 sec), 17% 26x opt_expr (0 sec), ...
arachne-pnr -d 8k -P cm81 -o example.asc -p pins.pcf example.blif
[...]
After packing:
IOs          2 / 63
GBs          0 / 8
  GB_IOs     0 / 8
LCs          86 / 7680
  DFF        18
  CARRY      16
  CARRY, DFF 20
  DFF PASS   0
  CARRY PASS 1
BRAMs        0 / 32
WARMBOOTs    0 / 1
PLLs         0 / 2
[...]
place...
  initial wire length = 2364
  at iteration #50: temp = 17.5219, wire length = 1245
[...]
  at iteration #250: temp = 0.0992939, wire length = 139
  final wire length = 137

After placement:
PIOs       3 / 63
PLBs       13 / 960
BRAMs      0 / 32

  place time 0.12s
route...
  pass 1, 0 shared.

After routing:
span_4     38 / 29696
span_12    9 / 5632

  route time 0.07s
write_txt example.asc...
icetime -d lp8k -mtr example.rpt example.asc
[...]
icepack example.asc example.bin
$ make prog
python tinyfpgab.py -p example.bin

    TinyFPGA B-series Programmer CLI
    --------------------------------
    Programming /dev/cu.usbmodem1411 with example.bin
    Waking up SPI flash
    135100 bytes to program
    Erasing designated flash pages
    Writing bitstream
    Verifying bitstream
    Success!
$
```
