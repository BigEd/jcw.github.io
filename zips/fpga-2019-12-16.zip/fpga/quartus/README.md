These projects can be built with Altera's Quartus Prime Lite 19.1.0 IDE.
