forgetram

create 7h-dig
  %00111111 c, \ 0
  %00000110 c, \ 1
  %01011011 c, \ 2
  %01001111 c, \ 3
  %01100110 c, \ 4
  %01101101 c, \ 5
  %01111101 c, \ 6
  %00000111 c, \ 7
  %01111111 c, \ 8
  %01100111 c, \ 9
  %01110111 c, \ A
  %01111100 c, \ b
  %00111001 c, \ C
  %01011110 c, \ d
  %01111001 c, \ E
  %01110001 c, \ F

: >7h ( b -- )
  $F and 7h-dig + c@ >spi2 ;

: .7h ( u -- )
  dup 20 rshift >7h
  dup 16 rshift >7h
  dup 12 rshift >7h
  dup  8 rshift >7h
  dup  4 rshift >7h
                >7h ;

: 7h-demo
  spi2-init
  0 begin
    dup .7h 1+ 1 ms
  key? until drop ;

  1234 ms 7h-demo
