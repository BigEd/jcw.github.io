// generate an 800x600 test image bitmap
//
// still to do:
//	currently, top border is 3 pixels and right side is 4 pixels, i.s.o. 1
//	they show up as single-pixel borders, probably due to timing off-by-N's
//
// convert the generated binray file to hex with this command:
//	arm-none-eabi-objcopy -I binary -O ihex img-data.bin img-data.hex

package main

import "os"

func main() {
	f, _ := os.Create("img-data.bin")
	for i := 0; i < 3; i++ {
		genline(f, 0xFF, 0xFF, 0xFF)
	}
	for i := 0; i < 596; i++ {
		genline(f, 0x80, 0x00, 0x0F)
	}
	genline(f, 0xFF, 0xFF, 0xFF)
	f.Close()
}

func genline(f *os.File, a, b, c byte) {
	f.Write([]byte{a})
	for i := 0; i < 98; i++ {
		f.Write([]byte{b})
	}
	f.Write([]byte{c})
}
