See <https://jeelabs.org/2016/09/running-a-simulated-fpga/>.
