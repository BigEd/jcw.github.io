See <https://jeelabs.org/2016/08/cplds-and-fpgas/>.
