See <https://jeelabs.org/2016/09/i-never-had-an-intel-8080/>.

This code was adapted from <http://opencores.org/project,light8080,demos>.
