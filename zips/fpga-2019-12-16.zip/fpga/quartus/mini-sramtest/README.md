See <https://jeelabs.org/2016/11/so-many-memories/>.
