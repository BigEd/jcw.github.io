See <https://jeelabs.org/2016/11/a-fast-µc-to-fpga-bus/>.
