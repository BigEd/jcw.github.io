See <https://jeelabs.org/2016/11/composite-video-from-fpga/>.
