See <https://jeelabs.org/2016/08/lets-build-half-a-uart/>.
