See <https://jeelabs.org/2016/08/vga-in-verilog/>.
