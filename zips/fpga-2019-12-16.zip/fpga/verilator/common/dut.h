template <class VMODEL>
class DUT : public VMODEL {
    VerilatedVcdC tracer;

    void next (vluint64_t t) {
        VMODEL::eval();
        tracer.dump(t);
    }

public:
    DUT () {
        Verilated::traceEverOn(true);
        VMODEL::trace(&tracer, 99);
        tracer.open("data.vcd");
    }

    ~DUT () {
        VMODEL::final();
        tracer.close();
    }

    void tick () {
        ++clockTime;

        // combinational results
        next(10*clockTime - 2);

        // positive clock edge
        VMODEL::clk = 1;
        next(10*clockTime);

        // negative clock edge
        VMODEL::clk = 0;
        next(10*clockTime + 5);
    }

    void reset () {
        VMODEL::rst = 1;
        tick();
        VMODEL::rst = 0;
    }
};
