# Verilated CPU, first exploration
