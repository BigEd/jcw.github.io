#include <verilated.h>
#include <verilated_vcd_c.h>
#include "Vtop.h"
#include <fcntl.h>
#include <sys/ioctl.h>

vluint64_t clockTime;

double sc_time_stamp() {
    return clockTime; // 64-bit int to double
}

#include "../common/dut.h"

int main (int argc, const char** argv) {
    Verilated::commandArgs(argc, argv);

    DUT<Vtop> dut;
    dut.reset();

    VL_PRINTF("mem size %lu\n", sizeof dut.top__DOT__mem);
    //memset(dut.top__DOT__mem, 0, sizeof dut.top__DOT__mem);
    dut.top__DOT__mem[0] = 0x0111; // L273  : A 0111 B 0000
    dut.top__DOT__mem[1] = 0x0123; // L291  : A 0123 B 0111
    dut.top__DOT__mem[2] = 0x0001; // L1    : A 0001 B 0123
    dut.top__DOT__mem[3] = 0x0200; // L4660 : D-bit
    dut.top__DOT__mem[4] = 0x1234; //       : A 1234 B 0001
    dut.top__DOT__mem[5] = 0x0002; // L2    : A 0002 B 1234

    while (clockTime < 40 && !Verilated::gotFinish()) {
        dut.tick();
    }

    return 0;
}
