See <https://jeelabs.org/2016/09/running-a-simulated-fpga/>.

This code was adapted from <http://www.fpga4fun.com/SDRAM2.html>.
