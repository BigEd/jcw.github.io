See <https://jeelabs.org/2016/09/diving-deep-into-spi/>.
