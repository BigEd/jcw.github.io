# Verilated UART demo
> Based on a some intriguing ideas by Dan Gisselquist, see
<https://github.com/ZipCPU/wbuart32>.

This implements the two sides of a UART in Verilog - as logic gates, and with
a simulated "mirror UART" which bridges simulated serial I/O and character I/O.

To run this, create two named pipes, once:

    mkfifo recv
    mkfifo xmit

Then, build and run using Verilator:

    make

Meanwhile, in a second shell, type:

    cat xmit

And in a third shell, enter this:

    echo 01 >recv

The verilator output will report the three bytes, including a newline:

    data: 30
    data: 31
    data: 0a

And the second shell will show the received data:

    01

To see the trace visually, use:

    open data.vcd       # on macOS
    gtkwave data.vcd    # on Linux

![](screenshot.png)

Let's unravel this - the path taken for the three bytes (including newline), is:

1. first, `echo` sends 3 bytes into the `xmit` fifo (i.e. named pipe)
2. these are converted to a series of bit toggles by the `MirrorUART` class
3. the `uartrx` module decodes them, and generates 3 bytes with ready strobes
4. the `$display` line in the `top` module shows each received byte
5. the `uarttx` module converts it back into a serial bit stream
6. the `MirrorUART` class then decodes this and writes it to the `recv` fifo
7. and finally, the `cat` process reads from the named pipe and prints it all

It's a bit of a mind twister, and a fascinating approach to designing HDL code
for an FPGA, while using simulation to develop everything without any hardware.
