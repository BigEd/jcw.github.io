#include <verilated.h>
#include <verilated_vcd_c.h>
#include "Vtop.h"
#include <fcntl.h>
#include <sys/ioctl.h>

vluint64_t clockTime;

double sc_time_stamp() {
    return clockTime; // 64-bit int to double
}

#include "../common/dut.h"

class BidirIO {
public:
    virtual int getChar () = 0;
    virtual void putChar(char ch) = 0;
};

class DualFileIO : public BidirIO {
    int ifd = -1, ofd = -1;

public:
    DualFileIO (const char* inPath, const char* outPath) {
        ifd = open(inPath ? inPath : "/dev/null", O_RDONLY);
        if (ifd < 0)
            perror("dfio in");
        ofd = open(outPath ? outPath : "/dev/null", O_WRONLY);
        if (ofd < 0)
            perror("dfio out");
    }

    virtual ~DualFileIO () {
        close(ifd);
        close(ofd);
    }

    virtual int getChar () {
        int n;
        if (ioctl(ifd, FIONREAD, &n) < 0 || n <= 0)
            return -1; // no data available
        uint8_t b;
        return read(ifd, &b, 1) == 1 ? b : -1; // this won't block
    }

    virtual void putChar(char ch) {
        if (write(ofd, &ch, 1) < 0)
            perror("dfio write");
    }
};

template <int BAUD_DIV>
class MirrorUART {
    BidirIO& bdio;
    int outPending = 0, outBits = ~0;
    vluint64_t outTimer = 0;
    int inCollected = -1, inBits = 0;
    vluint64_t inTimer = 0;

    void sampleIn (int input) {
        if (inCollected < 0) {
            if (input)
                return;
            inTimer = clockTime + BAUD_DIV/2; // sample on midpoints
        }
        if (++inCollected > 8) {
            inCollected = -1;
            if (!input)
                VL_PRINTF("framing error: 0x%02x\n", inBits);
            else
                bdio.putChar(inBits);
        } else {
            inTimer += BAUD_DIV;
            inBits >>= 1;
            inBits |= (input & 1) << 7;
        }
    }

    void updateOut () {
        if (outPending == 0) {
            int ch = bdio.getChar();
            if (ch < 0)
                return;
            outPending = 10;
            outTimer = clockTime;
            outBits = (~0U << 9) | (ch << 1); // 1 start, 8 data, 1 stop
        } else
            outBits >>= 1;
        --outPending;
        outTimer += BAUD_DIV;
    }

public:
    MirrorUART (BidirIO& handler) : bdio (handler) {}

    int operator () (int tx) {
        if (clockTime >= inTimer)
            sampleIn(tx);
        if (clockTime >= outTimer)
            updateOut();
        return outBits & 1;
    }
};

int main (int argc, const char** argv) {
    Verilated::commandArgs(argc, argv);

    DUT<Vtop> dut;
    dut.rx = 1;
    dut.reset();

    DualFileIO dfio ("recv", "xmit");
    MirrorUART<10> uart (dfio);

    while (clockTime < 450 && !Verilated::gotFinish()) {
        dut.rx = uart (dut.tx);

        dut.tick();
    }

    return 0;
}
