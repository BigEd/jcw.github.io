// Simple chunked memory manager with mark/sweep garbage collection.
// Main code parses text files given as cmdline args as quick test.
// -jcw, 2017-12-01

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHUNK_BITS  3
#define CHUNK_SIZE  (1 << CHUNK_BITS)
#define STORE_BITS  12
#define STORE_SIZE  (1 << STORE_BITS)

static int nthRef (int cnum, int index);
static void showObject (int cnum);

//------------------------------------------------------------------------------

#define TYPE(cnum)  tags[cnum].type
#define NEXT(cnum)  tags[cnum].next
#define MARK(cnum)  tags[cnum].mark

#define FREE        NEXT(0)

struct {
    uint16_t type :3;
    uint16_t next :STORE_BITS;
    uint16_t mark :1;
} tags [STORE_SIZE];

static int countFreeChunks (void) {
    int n = 0;
    for (int first = FREE; first != 0; first = NEXT(first))
        ++n;
    return n;
}

static int chunkSize (int cnum) {
    int sz = 0;
    while (NEXT(cnum) > CHUNK_SIZE) {
        sz += CHUNK_SIZE;
        cnum = NEXT(cnum);
    }
    return sz + NEXT(cnum);
}

static void markChunk (int cnum) {
    if (cnum <= CHUNK_SIZE || MARK(cnum))
        return;
    MARK(cnum) = 1;
    if (TYPE(cnum) == 0) {
        int n = chunkSize(cnum) >> 1;
        for (int i = 0; i < n; ++i)
            markChunk(nthRef(cnum, i));
    }
    for (;;) {
        cnum = NEXT(cnum);
        if (cnum <= CHUNK_SIZE)
            break;
        markChunk(cnum);
    }
}

static void sweepChunks (void) {
    int f = 0;
    // release in reverse order, so new ones get allocated in forward order
    // for (int i = CHUNK_SIZE + 1; i < STORE_SIZE; ++i)
    for (int i = STORE_SIZE - 1; i > CHUNK_SIZE; --i)
        if (MARK(i))
            MARK(i) = 0;
        else
            NEXT(i) = f, f = i;
    FREE = f;
}

//------------------------------------------------------------------------------

typedef struct {
    int16_t  i :15;
    uint16_t f :1;
} Value;

//------------------------------------------------------------------------------

enum { T_OBJ, T_STR, T_INT, T_FLT };

union {
    char      m [CHUNK_SIZE];
    long      l;
    double    d;
    Value     v;
} store [STORE_SIZE];

static void* chunkOffset (int cnum, int off) {
    while (off >= CHUNK_SIZE) {
        if (NEXT(cnum) <= CHUNK_SIZE)
            return 0;
        cnum = NEXT(cnum);
    }
    return store[cnum].m + off;
}

static int nthRef (int cnum, int index) {
    Value* p = chunkOffset(cnum, index << 1);
    return p != 0 && p->f ? p->i : 0;
}

static Value newChunk (int type, int size) {
    Value v;
    v.i = FREE;
    v.f = 1;
    for (;;) {
        assert(FREE != 0); // fails when out of memory
        if (size <= CHUNK_SIZE)
            break;
        size -= CHUNK_SIZE;
        FREE = NEXT(FREE);
    }
    int next = NEXT(FREE);
    NEXT(FREE) = size;
    FREE = next;
    TYPE(v.i) = type;
    return v;
}

static Value longToVal (long l) {
    Value v;
    v.i = l;
    if (v.i == l)
        v.f = 0;
    else {
        v = newChunk(T_INT, sizeof (long));
        store[v.i].l = l;
    }
    return v;
}

static Value doubleToVal (double d) {
    Value v = newChunk(T_FLT, sizeof (double));
    store[v.i].d = d;
    return v;
}

static Value stringToVal (const char* s) {
    int n = strlen(s) + 1;
    Value v = newChunk(T_STR, n);
    int cnum = v.i;
    while (n > 0) {
        strncpy(store[cnum].m, s, CHUNK_SIZE);
        s += CHUNK_SIZE;
        n -= CHUNK_SIZE;
        cnum = NEXT(cnum);
    }
    return v;
}

static void pushValue (int cnum, Value v) {
// FIXME assert(TYPE(cnum) = T_OBJ);
    while (NEXT(cnum) > CHUNK_SIZE)
        cnum = NEXT(cnum);
    if (NEXT(cnum) == CHUNK_SIZE) {
        assert(FREE != 0); // out of memory
        cnum = NEXT(cnum) = FREE;
        FREE = NEXT(cnum);
        NEXT(cnum) = 0;
    }
    *(Value*) (store[cnum].m + NEXT(cnum)) = v;
    NEXT(cnum) += sizeof (Value);
}

//------------------------------------------------------------------------------

static void showString (int cnum) {
    printf("'");
    do {
        printf("%.*s", CHUNK_SIZE, store[cnum].m);
        cnum = NEXT(cnum);
    } while (cnum > CHUNK_SIZE);
    printf("'");
}

static void showValue (Value v) {
    if (v.f == 0)
        printf("%d", v.i);
    else
        switch (TYPE(v.i)) {
            case T_OBJ: showObject(v.i);             break;
            case T_STR: showString(v.i);             break;
            case T_INT: printf("%ld", store[v.i].l); break;
            case T_FLT: printf("%g",  store[v.i].d); break;
            default:    printf("?");                 break;
        }
}

static void showObject (int cnum) {
    printf("[");
    int first = 1;
    do {
        const char* p = store[cnum].m;
        cnum = NEXT(cnum);
        for (int i = 0; i < cnum && i < CHUNK_SIZE; i += sizeof (Value)) {
            if (first)
                first = 0;
            else
                printf(" ");
            showValue(*(Value*) (p + i));
        }
    } while (cnum > CHUNK_SIZE);
    printf("]");
}

//------------------------------------------------------------------------------

static Value parseToken (const char* s) {
    char* end;
    long l = strtol(s, &end, 0);
    if (end > s && *end == 0) {
        return longToVal(l);
    }
    double d = strtod(s, &end);
    if (end > s && *end == 0) {
        return doubleToVal(d);
    }
    return stringToVal(s);
}

// note: buf is clobbered, strtok is not reentrant
static Value parseLine (char* buf) {
    Value r = newChunk(T_OBJ, 0);
    int curr = 0, stack [10];
    stack[0] = r.i;
    for (int i = 0; ; ++i) {
        char* p = strtok(buf, " \t\r\n");
        if (p == 0)
            break;
        buf = 0;
        if (strcmp(p, "[") == 0) {
            Value v = newChunk(T_OBJ, 0);
            pushValue(stack[curr], v);
            assert(curr < 9); // too deeply nested
            stack[++curr] = v.i;
        } else if (strcmp(p, "]") == 0) {
            assert(curr > 0); // too many closing brackets
            --curr;
        } else {
            Value v = parseToken(p);
            pushValue(stack[curr], v);
        }
    }
    return r;
}

static Value parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }
    Value r = newChunk(T_OBJ, 0);
    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        Value v = parseLine(buf);
        pushValue(r.i, v);
        printf("  ");
        showObject(v.i);
        printf("\n");
    }
    fclose(fp);
    return r;
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof store[0] == CHUNK_SIZE);
    assert(sizeof tags[0] == 2);
    assert(sizeof (Value) == 2);
    assert(T_OBJ == 0);
    sweepChunks(); // this inits the free chain, assuming tags are all-zero
    printf("store %lub, free %d x %db = %db\n",
            sizeof store, countFreeChunks(), CHUNK_SIZE, chunkSize(0));
    for (int i = 1; i < argc; ++i) {
        Value v = parseFile(argv[i]);
        int n = countFreeChunks();
        markChunk(v.i);
        sweepChunks();
        printf("free %d => %d\n", n, countFreeChunks());
    }
    return 0;
}
