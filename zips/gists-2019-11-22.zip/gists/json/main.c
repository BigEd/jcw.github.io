// Second JSON push scanner experiment.

#include <stdio.h>
#include <stdint.h>
#include <string.h>

enum { Sini, Snum, Sexp, Skey, Sstr, Sesc, Suni };

typedef struct {
    uint8_t state;
    uint8_t level;
    uint8_t minus;
    int8_t  decimals;
    int32_t value;
    int16_t exponent;
} JsonState;

static char feed (JsonState* jp, uint8_t c) {
    char r = 0;
    //printf(" <%d:%c>", jp->state, c ? c : '^');
    switch (jp->state++) {
        case Sini:
       ini: jp->state = Sini;
            jp->value = 0;
            jp->decimals = -1;
            jp->exponent = 0;
            if ('a' <= c && c <= 'z') {
                jp->value = c;
                jp->state = Skey;
                goto key;
            }
            if ('0' <= c && c <= '9') {
                jp->minus = 0;
                jp->state = Snum;
                goto num;
            }
            if (c == '-') {
                jp->minus = 1;
                jp->state = Snum;
            } else if (c == '"') {
                printf(" str<B>");
                jp->state = Sstr;
            } else if (c == '[' || c == '{') {
                printf(" vec<%c>", c);
                ++jp->level;
            } else if (c == ']' || c == '}') {
                printf(" vec<%c>", c);
                --jp->level;
                r = c == ']' ? 'v' : 'm';
            } else if (c == ',' || c == ':') {
                r = 0;
            } else if (r == 0 && c < ' ')
                return '?';
            break;
        case Snum:
       num: jp->state = Snum;
            if ('0' <= c && c <= '9') {
                if (jp->value >= (1U<<31)/10)
                    break; // drop decimals when precision is exceeded
                if (jp->decimals >= 0)
                    ++jp->decimals; // FIXME wrong if jp->decimals < 0
                jp->value = 10 * jp->value + (c - '0');
                break;
            }
            if (c == '.') {
                jp->decimals = 0;
                break;
            }
            if (jp->minus)
                jp->value = -jp->value;
            jp->minus = 0;
            if (c == 'e' || c == 'E') {
                jp->state = Sexp;
                break;
            }
       val: if (jp->minus)
                jp->exponent = -jp->exponent;
            if (jp->decimals > 0)
                jp->exponent -= jp->decimals;
            const char* plus = jp->exponent >= 0 ? "+" : "";
            printf(" num<%d%s%d>", jp->value, plus, jp->exponent);
            r = 'n';
            goto ini;
        case Sexp:
            jp->state = Sexp;
            if ('0' <= c && c <= '9') {
                jp->exponent = 10 * jp->exponent + (c - '0');
                break;
            }
            if (c != '-')
                goto val;
            jp->minus = !jp->minus;
            break;
        case Skey:
       key: if ('a' <= c && c <= 'z') {
                jp->state = Skey;
                break;
            }
            printf(" key<%c>", jp->value);
            r = 'k';
            goto ini;
        case Sstr:
            if (c == '\\')
                break;
            if (c == '"') {
                printf(" str<E>");
                r = 's';
                jp->state = Sini;
                break;
            }
            printf(" chr<%c>", c);
            jp->state = Sstr;
            break;
        case Sesc:
            if (c == 'u') {
                jp->value = 0;
                jp->decimals = 0;
                break;
            }
            printf(" esc<%c>", c);
            jp->state = Sstr;
            break;
        case Suni:
            if (c > '9')
                c -= 7;
            jp->value = (jp->value << 4) + (c & 0x0F);
            if (++jp->decimals < 4) {
                jp->state = Suni;
                break;
            }
            printf(" uni<%04x>", jp->value);
            jp->state = Sstr;
            break;
        default:
            return '?';
    }
    return jp->level ? 0 : r;
}

static void feeds (const char* str) {
    puts(str);
    JsonState j;
    memset(&j, 0, sizeof j);

    char r;
    do {
        r = feed(&j, *str);
        if (*str)
            ++str;
    } while (r == 0);
    printf(" => %c\n", r);
}

int main () {
    feeds("");
    feeds("123");
    feeds("-123");
    feeds("12.34");
    feeds("12.34e56");
    feeds("12.34e-56");
    feeds("-12.34e56");
    feeds("-12.34e-56");
    feeds("[]");
    feeds("[[]]");
    feeds("[45]");
    feeds("[67,89]");
    feeds("[[789]]");
    feeds("\"\"");
    feeds("\"abc\"");
    feeds("[\"abc\"]");
    feeds("[1,\"abc\",2]");
    feeds("{}");
    feeds("{\"def\":123}");
    feeds("\"a\\\\c\"");
    feeds("\"a\\\"c\"");
    feeds("\"a\\u89ABc\"");
    feeds("null");
    feeds("false");
    feeds("true");
    feeds("[null]");
    feeds("[false]");
    feeds("[true]");
    feeds("[123,{\"abc\":1234},\"\\\"\",123456,[1,2],3]");
    feeds("[123,{\"abc\":-12.34},\"\\\"\",12.34e-56,[1,2],3]");
    feeds("0.1234567890123456e-123");
    feeds("-0.1234567890123456e-123");
    feeds("[-0.1234567890123456e-123]");
    return 0;
}