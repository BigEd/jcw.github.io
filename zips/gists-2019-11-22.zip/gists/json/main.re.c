// JSON push scanner experiment based on re2c.
//
// build using:
//  re2c -s -c -f --input custom -o main.c main.re.c
//  gcc main.c -o main

#include <stdio.h>
#include <stdint.h>
#include <string.h>

/*!max:re2c*/
/*!types:re2c*/

typedef struct {
    uint8_t b [28]; // fits -0.1234567890123456e-123, the longest double

    uint8_t i;  // start, ini
    uint8_t m;  // marker
    uint8_t c;  // cursor
    uint8_t e;  // limit, end

    uint8_t s;  // state
    uint8_t d;  // cond
    uint8_t f;  // fill
    uint8_t l;  // level
} JsonState;

// see http://skvadrik.github.io/aleph_null/posts/re2c/
//              2015-01-15-input_model_custom.html

#define YYPEEK()       jp->b[jp->c]
#define YYSKIP()       ++jp->c
#define YYBACKUP()     jp->m = jp->c
#define YYRESTORE()    jp->c = jp->m
#define YYLESSTHAN(n)  jp->e - jp->c < n

#define YYMARKER jp->m
#define YYCURSOR jp->c
#define YYLIMIT jp->e
#define YYCTYPE uint8_t

#define YYFILL(n) { jp->f = n; return 0; }
#define SKIP { jp->i = jp->c; goto yy0; }
#define CHECK(n) { if (jp->l == 0) return n; SKIP; }

#define YYGETSTATE() jp->s
#define YYSETSTATE(x) { jp->s = (x); }

#define YYGETCONDITION() jp->d
#define CONTEXT(x) { jp->d = yyc##x; }

static void outs (JsonState* jp, const char* s) {
    printf(" %s<%.*s>", s, jp->c-jp->i, jp->i + jp->b);
}

static int feed (JsonState* jp, uint8_t ch) {
    //printf("\t\tfeed %c\n", ch ? ch : ' ');
    if (jp->e >= sizeof jp->b) {
        if (jp->i == 0)
            return -2;
        memcpy(jp->b, jp->b + jp->i, jp->e-jp->i);
        jp->m -= jp->i;
        jp->c -= jp->i;
        jp->e -= jp->i;
        jp->i = 0;
    }
    jp->b[jp->e++] = ch;
    //jp->f = YYMAXFILL;
    if (jp->e - jp->c < jp->f)
        return 0;
    uint8_t yych;
    int yyaccept;
    /*!re2c
        re2c:startlabel = 0;

        DIG = [0-9] ;
        HEX = DIG | [a-fA-F] ;
        INT = "-"? DIG+ ;
        FLT = INT "." DIG+ ;
        EXP = ( INT|FLT ) [eE] [+-]? DIG+ ;

        <J> [:, \n\r\t]  { SKIP; }

        <J> "["          { outs(jp, "vec"); ++jp->l; SKIP; }
        <J> "]"          { outs(jp, "vec"); --jp->l; CHECK(1); }

        <J> "{"          { outs(jp, "map"); ++jp->l; SKIP; }
        <J> "}"          { outs(jp, "map"); --jp->l; CHECK(2); }

        <J> INT|FLT|EXP  { outs(jp, "num"); CHECK(4); }

        <J> [a-zA-Z_]+   { outs(jp, "key"); CHECK(5); }

        <J> "\""         { outs(jp, "str"); CONTEXT(S); SKIP; }
        <S> [^\\"]       { outs(jp, "chr"); SKIP; }
        <S> "\\u" HEX{4} { outs(jp, "uni"); SKIP; }
        <S> "\\" .       { outs(jp, "esc"); SKIP; }
        <S> "\""         { outs(jp, "str"); CONTEXT(J); CHECK(3); }

        <*> *            { return -1; }
    */
}

static void feeds (const char* str) {
    puts(str);
    JsonState j;
    memset(&j, 0, sizeof j);

    int r;
    do {
        r = feed(&j, *str);
        if (*str)
            ++str;
    } while (r == 0);
    printf(" => %d\n", r);
}

int main () {
    feeds("");
    feeds("[]");
    feeds("{}");
    feeds("\"abc\"");
    feeds("\"a\\\\c\"");
    feeds("\"a\\\"c\"");
    feeds("\"a\\u0000c\"");
    feeds("123456789");
    feeds("null");
    feeds("false");
    feeds("true");
    feeds("[null]");
    feeds("[false]");
    feeds("[true]");
    feeds("[123,{\"abc\":-12.34},\"\\\"\",12.34e-56,[1,2],3]");
    feeds("0.1234567890123456e-123");
    feeds("-0.1234567890123456e-123");
    feeds("[-0.1234567890123456e-123]");
    return 0;
}

// vim: ft=c
