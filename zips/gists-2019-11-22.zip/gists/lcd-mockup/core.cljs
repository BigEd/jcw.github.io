(ns cljs7.core
  (:require [reagent.core :as reagent :refer [atom]]))

(defonce app-state (atom {:text "Display viewer"}))

(defn dark? [i]
  (even? (bit-xor (quot i 128) (mod i 128))))

(defn hello-world []
  [:div
   [:h1 (:text @app-state)]
   [:div.grid {:style {:width 640 :height 160}}
    (for [i (range 4096)]
      ^{:key i}
      [:div.pixel {:class (if (dark? i) "black" "white")}])]
   [:p.red (:counter @app-state)]])

(reagent/render-component [hello-world]
                          (. js/document (getElementById "app")))

(defn on-js-reload []
  ;; optionally touch your app-state to force rerendering depending on
  ;; your application
  (swap! app-state update-in [:counter] inc)
  ) 