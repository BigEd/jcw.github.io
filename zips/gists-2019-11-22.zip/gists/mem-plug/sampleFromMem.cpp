// Dump readings stored on a Memory Plug as collected by the sampleToMem sketch.
// 2011-10-03 <jc@wippler.nl> http://opensource.org/licenses/mit-license.php
//
// see http://jeelabs.org/2011/10/04/capturing-no-go-part-2/

#include <JeeLib.h>
#include <avr/eeprom.h>

#define MEM_PORT 4  // the Memory Plug is on port 4

PortI2C i2cBus (MEM_PORT);
MemoryPlug mem (i2cBus);
MemoryStream memStream (mem, 0, 0);

#define BUFCNT 128

#define EE_ADDR 0 // this byte in EEPROM stores the next free buffer

static void DumpNextBlock() {
  for (byte i = 0; i < BUFCNT; ++i) {
    byte b1 = memStream.get();
    byte b2 = memStream.get();
    Serial.println(b1 * 256 + b2);
  }
}

void setup () {
  Serial.begin(57600);
  Serial.println("\n[sampleFromMem]");
  
  if (!mem.isPresent()) {
    Serial.println("No memory card !");
    while (true)
      ; // don't do anything else
  }

  word endSave = eeprom_read_word(EE_ADDR);
  Serial.print("Sample count ");
  Serial.println(endSave * BUFCNT);
  
  for (word i = 0; i < endSave; ++i)
    DumpNextBlock();
    
  Serial.println("Dump end.");
}

void loop () {}
