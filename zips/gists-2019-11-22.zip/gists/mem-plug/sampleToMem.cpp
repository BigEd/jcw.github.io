// Sample readings from the analog pin at 1 KHz to a 128 Kb Memory Plug.
// 2011-10-03 <jc@wippler.nl> http://opensource.org/licenses/mit-license.php
//
// see http://jeelabs.org/2011/10/04/capturing-no-go-part-2/

#include <JeeLib.h>
#include <avr/eeprom.h>

#define AIO_PORT 2  // sample from AIO2, i.e. analog pin 1
#define MEM_PORT 4  // the Memory Plug is on port 4

PortI2C i2cBus (MEM_PORT);
MemoryPlug mem (i2cBus);
MemoryStream memStream (mem);
word nextSave;

// Data collection happens through a periodic timer 2 interrupt, every 1000 us,
// i.e. 1 KHz sample rate. Every 128 samples, about 8x per second, the data
// gets copied to a second buffer and the vready flag is set. It is up to the
// main loop to check this flag, copy the data to EEPROM, and clear the flag.

#define BUFCNT 128
volatile word vbuf[BUFCNT], buffer[BUFCNT];
volatile byte vready, vpos;

#define EE_ADDR 0 // this byte in EEPROM stores the next free buffer

ISR(TIMER2_COMPA_vect) {
  vbuf[vpos++] = ADC;     // read out last ADC measurement
  bitSet(ADCSRA, ADSC);   // start next conversion
  if (vpos >= BUFCNT) {
    vpos = 0;
    memcpy((void*) buffer, (const void*) vbuf, sizeof buffer);
    ++vready;
  }
}

static void SaveNextBlock() {
  for (byte i = 0; i < BUFCNT; ++i) {
    memStream.put(buffer[i] >> 8);
    memStream.put(buffer[i]);
  }
  eeprom_write_word(EE_ADDR, ++nextSave);
}

void setup () {
  Serial.begin(57600);
  Serial.println("\n[sampleToMem]");
  
  if (!mem.isPresent()) {
    Serial.println("No memory card !");
    while (true)
      ; // don't do anything else
  }

  analogRead(AIO_PORT-1); // run once to set up the ADC
  
  TCCR2A = bit(WGM21);  // CTC mode
  TCCR2B = bit(CS22);   // 64 prescaler, 1 tick is 4 us
  TIMSK2 = bit(OCF2A);  // use output compare interrupts
  OCR2A = 249;          // reset every 250 ticks, i.e. 1000 us = 1 KHz

  eeprom_write_word(EE_ADDR, nextSave);
}

void loop () {
  if (vready) {
    SaveNextBlock();
    Serial.println(nextSave);
    if (vready > 1)
      Serial.println("OVERRUN!");
    vready = 0;
  }
}
