# MCPU emulator, see https://github.com/cpldcpu/MCPU
#   python asm.py <... | python emu.py
# optional arg is # of cycles to run
# show instruction trace if cycles < 1000

from __future__ import print_function
import sys

try:
    cycles = int(sys.argv[1])
except:
    cycles = 20

mem = [int(x, 16) for x in sys.stdin.readlines()]
assert len(mem) == 64

pc, acc, cf = 0, 0, 0

for _ in range(cycles):
    ir = mem[pc & 0x3F]
    pc += 1
    op, arg = ir >> 6, ir & 0x3F

    if cycles < 1000:
        print('pc,ir,acc,cf:', pc-1, hex(ir), acc, cf >> 8, sep='\t')

    if op == 0:
        acc = (acc | mem[arg]) ^ 0xFF
    elif op == 1:
        acc += mem[arg]
        cf = acc & 0x100
        acc &= 0xFF
    elif op == 2:
        mem[arg] = acc
    else:
        if ir == 0xFF:
            print(acc)
        elif cf == 0:
            pc = arg
        cf = 0
