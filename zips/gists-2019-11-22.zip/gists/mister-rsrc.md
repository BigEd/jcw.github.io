# MiSTer Resources

| Core | B-RAM | SDRAM | DDR3 | Video | 2nd SD | ALMs |
|------|------:|-------:|-----:|:-----:|:--------:|-----:|
| [a-pacman](https://github.com/MiSTer-devel/Arcade-Pacman_MiSTer)  | 29K | - | - | ? | no | 3K |
| [ao486](https://github.com/MiSTer-devel/ao486_MiSTer)             | 270K | - | 256M | 640x480 | no | 31K |
| [apple-ii](https://github.com/MiSTer-devel/Apple-II_MiSTer)       | 236K | - | - | ? | no | 5K |
| [c64](https://github.com/MiSTer-devel/C64_MiSTer)                 | 106K | - | - | ? | no | 5K |
| [fpgagen](https://github.com/MiSTer-devel/FpgaGen_MiSTer)         | 120K | - | - | ? | no | 9K |
| [macplus](https://github.com/MiSTer-devel/MacPlus_MiSTer)         | 33K | 4096K | - | 512x342 | no | 5K |
| [ql](https://github.com/MiSTer-devel/QL_MiSTer)                   | 248K | 1024K | - | ? | yes | 4K |
| [vector-06c](https://github.com/MiSTer-devel/Vector-06C_MiSTer)   | 349K | - | - | ? | no | 6K |
| [x68000](https://github.com/MiSTer-devel/X68000_MiSTer)           | 171K | - | - | ? | yes | 13K |
| [zxspectrum](https://github.com/MiSTer-devel/ZX-Spectrum_MISTer)  | 200K | 1024K | - | ? | no | 7K |

Sizes are for the "lite" (non-scaler) builds.

<!--
| [blah]() | - | - | - | - | - | - |
-->
