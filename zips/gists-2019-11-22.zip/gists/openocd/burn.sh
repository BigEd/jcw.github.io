#!/bin/sh
# Upload to attached µC via SWD.

case "$2" in
  "") echo "need target type (f1x/l0) and name of image to burn as args"
      exit 1 ;;
esac

TARGET=$1 IMAGE=$2 /usr/local/bin/openocd