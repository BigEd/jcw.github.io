#!/bin/sh
# Upload to attached µC via Serial & GPIO for RESET/BOOT0.

case "$2" in
  "") echo "need target type (f1x/l0) and name of image to burn as args"
      exit 1 ;;
esac

case "$1" in
  l0) extra="-e 254" ;;
esac

stm32flash -i 23,-18,18:-23,-18,18 $extra -w images-$1/$2.hex /dev/ttyAMA0