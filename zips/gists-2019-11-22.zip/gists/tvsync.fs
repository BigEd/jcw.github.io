\ these routines generate a PAL composite video for display on a TV or monitor
\ timing is not 100% standard, and non-interlaced to avoid single-line flicker
\ requires a 470 Ω resistor on PA2 and a 1 kΩ on PA3, combined at the RCA jack
\ -jcw, 2016-09-04

reset

\ alternate version, this works without system tick interrupts
: us2 ( n -- )  \ microsecond delay using a busy loop, this won't switch tasks
  72 * 100 - >r $E000E018 @ begin
    dup $E000E018 @ - $FFFFF and
  r@ > until rdrop drop ;

omode-pp pa2 io-mode!  \ vout
omode-pp pa3 io-mode!  \ sync

: zero  pa3 ioc! pa2 ioc! ;
: black pa3 ios! pa2 ioc! ;
: white pa3 ios! pa2 ios! ;

: zr-us ( u -- ) pa3 ioc! pa2 ioc! us2 ;
: bl-us ( u -- ) pa3 ios! pa2 ioc! us2 ;
: wh-us ( u -- ) pa3 ios! pa2 ios! us2 ;

: pulses ( u -- ) 0 do zero 2 us2 black 29 us2 loop ;
: vsyncs ( u -- ) 0 do zero 29 us2 black 2 us2 loop ;
: blanks ( u -- )
  0 do
    zero 5 us2 black 29 us2 black 10 us2 black 17 us2 black black
  1 +loop ;

: try  \ full vertical bar
  begin
    5 vsyncs
    5 pulses
     36  4 do  4 zr-us  18 bl-us  1 bl-us  41 bl-us  loop
    304 36 do  4 zr-us  18 bl-us  1 wh-us  41 bl-us  loop
    2 blanks
    4 pulses
  key? until ;

: try1  \ flickers due to interlaced display
  begin
    128 zr-us
    2 pulses
    25 blanks
    300 28 do  4 zr-us  18 bl-us  1 wh-us  41 bl-us  loop
    12 blanks
  key? until ;

: bbb  0 do  4 zr-us  6 bl-us  1 bl-us  48 bl-us  1 bl-us  4 bl-us  loop ;
: www  0 do  4 zr-us  6 bl-us  1 wh-us  48 wh-us  1 wh-us  4 bl-us  loop ;
: wbw  0 do  4 zr-us  6 bl-us  1 wh-us  48 bl-us  1 wh-us  4 bl-us  loop ;

: try2  \ show two short vertical segments
  begin
      5 vsyncs
      5 pulses
    128 bbb
     46 wbw
    128 bbb
      4 pulses
  key? until ;

: try3  \ fill the entire screen
  begin
      5 vsyncs
      5 pulses
     32 bbb
    268 www
      2 bbb
      4 pulses
  key? until ;

: try4  \ draw a big rectangle
  begin
      5 vsyncs
      5 pulses
     32 bbb
     16 www
    236 wbw
     16 www
      2 bbb
      4 pulses
  key? until ;

: check-us micros 150 us2 micros swap - . ;

$800000 $E000E014 !   \ prevent timing errors use power of 2 for systick
dint                  \ turn off interrupts, avoids occasional glitches

\ now generate the video signal until a key is pressed
try3