// Convenience package to wrap all the gadgets available in HouseMon.
package jeebus

import (
	// "github.com/jcw/flow"
	_ "github.com/jcw/housemon/gadgets/decoders"
	_ "github.com/jcw/housemon/gadgets/rfdata"
	_ "github.com/jcw/housemon/gadgets/stats"
	_ "github.com/jcw/jeebus/gadgets"
)
