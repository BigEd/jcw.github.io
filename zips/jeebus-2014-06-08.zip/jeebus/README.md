# JeeBus

A messaging and data storage infrastructure for low-end hardware.  

[![GoDoc][G]][D] [![Travis Status][S]][T] [![License][B]][L]

The [homepage][H], [discussion forum][F], and [issue tracker][I] are at JeeLabs.

[G]: https://godoc.org/github.com/jcw/jeebus?status.png
[D]: https://godoc.org/github.com/jcw/jeebus
[S]: https://travis-ci.org/jcw/jeebus.png?branch=master
[T]: https://travis-ci.org/jcw/jeebus
[B]: http://img.shields.io/badge/license-MIT-brightgreen.svg
[L]: http://opensource.org/licenses/MIT

[H]: http://jeelabs.net/projects/housemon/wiki/jeebus
[F]: http://jeelabs.net/projects/cafe/boards/9
[I]: http://jeelabs.net/projects/development/issues
