# JeeBus application area

This area contains client-side pages, code, templates, styles, etc.
