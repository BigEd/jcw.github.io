# JeeBus base: AngularJS + Zurb Foundation

* bower used for main dependencies (angular, foundation, raphael)
* angular-ui-router downloaded separately
