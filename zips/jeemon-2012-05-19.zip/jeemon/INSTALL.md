Getting started with JeeMon
===========================

JeeMon is a portable runtime for Physical Computing and Home Automation. It has
been designed to be infinitely extensible and to operate on a very wide range
of hardware, from mainstream Windows, Mac OSX, and Linux desktops and notebooks
to some really low-power Linux boxes and cards having just an Ethernet port.

JeeMon can read out and control all sorts of hardware devices via built-in or
custom software extensions. The user interaction with JeeMon takes places via
your own web browser, connected to the built-in web server. The look & feel and
the behavior of each setup is determined entirely by the installed "features".

JeeMon is more a framework and a set of conventions than a specific application.
Stretching to adapt to a huge range of tasks, while pulling everything together.

*Let's get started, shall we?*

There is no installation
------------------------

Let me rub that in: there is no installer or installation procedure. No filling
your disk with files all over the place. No need to "grant" any administrator
privileges, hence no risk that the code does really bad things. No changes to
registries. No dependence on other installed packages. No conflicts with other
packages. No steps that can fail. No big installation requirements. No waiting.

And perhaps best of all: *this is a two-way street.* Because there is also no
un-installation. If you just wish to try things out, or change your mind later
on, all you need to do is remove JeeMon and the files and directories it created
next to itself. Everything related to JeeMon 'll be gone at the blink of an eye.

Here's what "trying out JeeMon for the very first time" boils down to:

* you [download][1] a build of the JeeMon runtime suitable for your system
* you unpack the ZIP archive (usually by double-clicking on it)
* you launch the executable which came out of it (again: double-click)

In all fairness, you do need to be aware of a few details:

* JeeMon will create stuff next to itself, so start in an empty directory
* JeeMon will download a [jeemon-rev][2] file (once!), so you need to be online
* JeeMon may want access to hardware ports and you'll have to administer that

This doesn't mean that nothing will ever go wrong, by the way. There are too
many unknowns out there to be infallible. But if there ever is a problem, then
it's JeeMon's problem (i.e. the developers), not yours: so please get in touch.

This is how it works out in practice
------------------------------------

Since there is no real installation, the process to get going is as follows:

* start with the download + unpack + launch steps described above
* now click on the following link in your browser: <http://127.0.0.1:8181/>
* browse around, start reading, try out stuff - you're up and running

If you mess up really badly, no worries: you can always pull the plug, delete
the entire directory, and start all over again. There is no dead end. Ever.

If you want to try out something new without messing with what you've already
set up: just set up a second system - download, unpack, etc. You get the idea.

If you want to be able to revert to a previous state ("just in case"), then
make a copy of the whole area with JeeMon, etc. Back it up, archive it, move it
off-site, whatever. The state of your setup is all inside a *single* directory.

JeeMon is a fairly ambitious project... as far as its goals and development go.
But that shall not carry over to its day-to-day use. If its functionality meets
your needs, then it ought to take virtually no effort to put it to work for you.
If it doesn't and you're a software developer: dive in, it's all open source.

There is really not much more to say
------------------------------------

End of story. The functionality of JeeMon depends on the set of features which
have been built and included so far, and which of those you have enabled.

[1]: http://dl.jeelabs.org/jeemon/
[2]: http://dl.jeelabs.org/jeemon-rev
