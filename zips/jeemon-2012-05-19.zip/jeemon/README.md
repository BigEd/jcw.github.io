JeeMon v1.5
===========

JeeMon is a portable runtime for Physical Computing and Home Automation.

The standard library for this runtime is provided by the [JeeRev][1] project.

Getting started
---------------

For x86-based Windows, Mac OSX, and Linux platforms there's no need to build
anything: there are ready-to-use runtimes at <http://dl.jeelabs.org/jeemon/>.
Just download the archive, unzip it, and launch JeeMon to start things going.

> Note: the 64-bit builds have had less testing than the 32-bit ones so far.

For an explanation of the ideas behind this approach, see the [INSTALL][3] doc.

If you'd rather do everything yourself and see the code that drives it, read on.

Build instructions
------------------

JeeMon is nothing more than a slightly extended version of [Tclkit][2].

To build JeeMon, you'll need a `tclkit` executable. There are several in the
`exes` directory. Use one of the following commands to set up a suitable one:

  * `make linux` (on an x86-based 32-bit Linux)
  * `make linux64` (on an x86-based 64-bit Linux)
  * `make macosx` (on Mac OSX)
  
Then type `make` to build JeeMon for all platforms in the `exes` directory.

The result is a set of ZIP archives in the `zips` directory.

When done, type `make clean` to remove the builds.

Usage and configuration
-----------------------

Each ZIP file is for a specific platform. Once unpacked, the `jeemon` runtime
(`jeemon.exe` on Windows) can be launched as is with no further installation.
For convenience, you can move the runtime to a directory on the exe search PATH.

With an existing file as first argument, JeeMon behaves the same as `tclkit` and
`tclsh` (the Tcl command shell) and runs the script.

Otherwise, JeeMon will look for a `kit/main.tcl` or `jeemon-rev` file to launch.
If not found, the rev file is downloaded from a fixed HTTP web address.

The complete startup sequence is as follows:

> ![flowchart](http://jeelabs.org/pub/jeemon-startup-flowchart.png)

The following environment variables will affect this behavior:

* **JEEMON\_LIB** = the directory where the rev file is stored
                    (default: next to the executable)
* **JEEMON\_URL** = the web path from which to download the rev file
                    (default: http://dl.jeelabs.org/)

Note: the name of the rev file depends on the name of the executable, i.e. if
`jeemon` is renamed to `FooBar`, then the rev file name will be `foobar-rev`.

  [1]: http://jeelabs.org/jeerev
  [2]: http://equi4.com/tclkit/
  [3]: https://github.com/jcw/jeemon/blob/master/INSTALL.md