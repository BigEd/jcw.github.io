**JeeRev** is the default support library for [JeeMon][1], with domain-specific code needed to create applications for Physical Computing and Home Automation.

For more information about JeeRev, see the [JeeRev home page][2].

  [1]: http://jeelabs.org/jeemon
  [2]: http://jeelabs.org/jeerev
