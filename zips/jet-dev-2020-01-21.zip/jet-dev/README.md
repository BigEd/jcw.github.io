# JET

An experimental dataflow framework and server for multi-node embedded systems.  
Live reload: `go get github.com/cortesi/modd/cmd/modd` (or `brew install modd`).  
Type `modd` to launch a dev-mode server + console, see `modd.conf` for details.  
Then open browser on <http://localhost:7489> (not npm's default port 5000).
