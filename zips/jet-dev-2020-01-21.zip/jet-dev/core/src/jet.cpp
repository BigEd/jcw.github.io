#include <cassert>
#include <csetjmp>
#include <cstdint>
#include <cstdlib>
#include <cstring>

#include "gc.h"
#include "jet.h"

extern "C" int printf(const char* fmt, ...);

using namespace jet;

Stacklet* Stacklet::current;
void* Stacklet::resumer;
uint32_t volatile Stacklet::pending;
Vector jet::stacklets;
Vector jet::ready;

Value::Value (char const* arg) : v ((uintptr_t) arg * 4 + 2) {
    assert((char const*) *this == arg); // make sure that address is preserved
}

Value::operator char const* () const {
#if 1
    // TODO other cases
    assert(isStr());
    return (char const*) (v >> 2);
#else
    if (!isStr())
        return asType<struct Str>();
    auto p = v >> 2;
    return p < QID_RAM_LAST ? Q::str(p) : (char const*) p;
#endif
}

void jet::markVec (Vector const& vec) {
    for (auto e : vec)
        e.marker();
}

Stacklet::Stacklet () {
    auto n = stacklets.find({});
    if (n >= stacklets.size())
        stacklets.insert(n);
    stacklets[n] = this;
    ready.append(this);
}

Stacklet::~Stacklet () {
    auto n = id();
    assert(n < stacklets.size());
    stacklets[n] = {};
}

// note: don't make this static, as then it might get inlined - see below
void resumeFixer (void* p) {
    assert(Stacklet::resumer != nullptr);
    assert(Stacklet::current != nullptr);
    auto need = (uint8_t*) Stacklet::resumer - (uint8_t*) p;
    memcpy(p, (uint8_t*) Stacklet::current->end(), need);
}

void Stacklet::suspend () {
    assert(current != nullptr);
    jmp_buf top;
    assert(resumer > &top);

    uint32_t need = (uint8_t*) resumer - (uint8_t*) &top;
    assert(need % sizeof (Value) == 0);
    assert(need > sizeof (jmp_buf));

    current->adj(current->fill + need / sizeof (Value));
    if (setjmp(top) == 0) {
        // suspending: copy stack out and jump to caller
        memcpy((uint8_t*) current->end(), (uint8_t*) &top, need);
        longjmp(*(jmp_buf*) resumer, 1);
    }

    // resuming: copy stack back in
    // note: the key is that this calls ANOTHER function, to avoid reg issues
    resumeFixer(&top);
}

void Stacklet::resume () {
    jmp_buf bottom;
    if (resumer == nullptr)
        resumer = &bottom;
    assert(resumer == &bottom);

    current = this;
    if (setjmp(bottom) == 0) {
        if (cap() > fill)
            longjmp(*(jmp_buf*) end(), 1);
        while (run()) {}
        adj(fill);
    }
    current = nullptr;
}

void Stacklet::dump () {
    for (auto e : stacklets)
        if (!e.isNil()) {
            auto p = (Stacklet*)(Object*) e;
            printf("st: %3d [%p] size %d cap %d ms %d sema %d\n",
                    p->id(), p, p->size(), p->cap(), p->ms, p->sema);
        }
}

void Event::set () {
    value = true;
    if (size() > 0) {
        // insert all entries at head of ready and remove them from this event
        ready.insert(0, size());
        memcpy(ready.begin(), begin(), size() * sizeof (Value));
        remove(0, size());
    }
}

void Event::wait () {
    if (value)
        return;
    assert(Stacklet::current != nullptr);
    append(Stacklet::current);
    Stacklet::suspend();
}
