namespace jet {
    struct Object; // forward

    class Q {
        uint16_t id;
    public:
        constexpr Q (uint16_t i, char const* =nullptr) : id (i) {}
        constexpr operator int () const { return id; }
        operator char const* () const;
    };

    class Value {
        union {
            uintptr_t v;
            const void* p;
        };
    public:
        constexpr Value () : v (0) {}
        constexpr Value (int arg) : v (arg * 2 + 1) {}
        constexpr Value (Q const& arg) : v (arg * 4 + 2) {}
                  Value (char const* arg);
        constexpr Value (Object const* arg) : p (arg) {}

        auto isNil () const -> bool { return v == 0; }
        auto isInt () const -> bool { return (v&1) == Int; }
        auto isStr () const -> bool { return (v&3) == Str; }
        auto isObj () const -> bool { return (v&3) == 0 && v != 0; }

        enum Tag { Nil, Int, Str, Obj };
        auto tag () const -> Tag {
            return isNil() ? Nil : isInt() ? Int : isStr() ? Str : Obj;  
        }

        // careful: these casts don't verify their type tags
        operator int () const { return (intptr_t) v >> 1; }
        operator char const* () const;
        operator Object* () const { return (Object*) p; }
        auto operator -> () const -> Object* { return (Object*) p; }

        auto asObj () const -> Object&; // may involve allocation or conversion
        auto id () const -> uintptr_t { return v; }

        auto operator== (Value v) const -> bool { return id() == v.id(); }

        void marker () const { if (isObj()) mark((gc::Obj*) p); }
    };

    template< typename T >
    struct VecOf : private gc::Vec {
        uint32_t fill = 0;

        constexpr VecOf () {}
        constexpr VecOf (T const* ptr, uint32_t num =0)
                    : gc::Vec (ptr, num * sizeof (T)), fill (num) {}

        auto cap () const -> uint32_t { return gc::Vec::cap() / sizeof (T); }
        auto adj (uint32_t n) -> bool { return gc::Vec::adj(n * sizeof (T)); }

        auto size () const -> uint32_t { return fill; }
        auto begin () const -> T* { return (T*) gc::Vec::ptr(); }
        auto end () const -> T* { return begin() + fill; }
        auto operator[] (uint32_t idx) const -> T& { return begin()[idx]; }

        auto relPos (int i) const -> uint32_t { return i < 0 ? i + fill : i; }

        void move (uint32_t pos, uint32_t num, int off) {
            memmove((void*) (begin() + pos + off),
                        (void const*) (begin() + pos), num * sizeof (T));
        }
        void wipe (uint32_t pos, uint32_t num) {
            memset((void*) (begin() + pos), 0, num * sizeof (T));
        }

        void insert (uint32_t idx, uint32_t num =1) {
            if (fill > cap())
                fill = cap();
            if (idx > fill) {
                num += idx - fill;
                idx = fill;
            }
            auto need = fill + num;
            if (need > cap())
                adj(need);
            move(idx, fill - idx, num);
            wipe(idx, num);
            fill += num;
        }

        void remove (uint32_t idx, uint32_t num =1) {
            if (fill > cap())
                fill = cap();
            if (idx >= fill)
                return;
            if (num > fill - idx)
                num = fill - idx;
            move(idx + num, fill - (idx + num), -num);
            fill -= num;
        }

        auto find (T v) -> uint32_t {
            for (auto& e : *this)
                if (e == v)
                    return &e - begin();
            return fill;
        }

        auto append (T v) -> uint32_t {
            auto n = fill;
            insert(n);
            begin()[n] = v;
            return n;
        }

        auto pull (uint32_t idx) -> T {
            if (idx >= fill)
                return {};
            T v = begin()[idx];
            remove(idx);
            return v;
        }
    };

    using Vector = VecOf<Value>;
    void markVec (Vector const&);

    class ArgVec {
        Vector const& vec;
        int num;
        int off;
    public:
        ArgVec (Vector const& vec, int num, Value const* ptr)
            : ArgVec (vec, num, ptr - vec.begin()) {}
        ArgVec (Vector const& v ={}, int n =0, int o =0)
            : vec (v), num (n), off (o) {}

        auto size () const -> uint32_t { return num; }
        auto begin () const -> Value const* { return vec.begin() + off; }
        auto end () const -> Value const* { return begin() + num; }
        auto operator[] (uint32_t idx) const -> Value& { return vec[off+idx]; }
    };

    struct Object : protected gc::Obj {
        int aaa = 123; // TODO clean up

        using Obj::operator new;
    };

    struct List : Object, Vector {
        void marker () const override { markVec(*this); }
    };

    extern Vector stacklets;

    struct Stacklet : List {
        uint16_t ms = 0;
        int8_t sema = -1;

        Stacklet ();
        ~Stacklet () override;

        auto id () -> uint16_t { return stacklets.find(this); }

        static void suspend ();
        void resume ();

        virtual auto run () -> bool =0;

        static void dump ();

        // see https://en.cppreference.com/w/c/atomic and
        // https://gcc.gnu.org/onlinedocs/gcc/_005f_005fatomic-Builtins.html
        static void setPending (uint32_t n) {
            __atomic_fetch_or(&pending, 1<<n, __ATOMIC_RELAXED);
        }
        static uint32_t checkPending () {
            return __atomic_fetch_and(&pending, 0, __ATOMIC_RELAXED); // clears
        }

        static volatile uint32_t pending;
        static Stacklet* current;
        static void* resumer;
    };

    struct Event : List {
        operator bool () const { return value; }
        void set ();
        void clear () { value = false; }
        void wait ();
    private:
        bool value = false;
    };

    extern Vector ready;

    // struct Context : Stacklet { ... };
}
