#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <cstring>

#include "gc.h"
#include "jet.h"

using namespace jet;

struct MyStacklet : Stacklet {
    int arg;
    int num = 3;

    MyStacklet (int n ) : arg (n) {
        printf("run %d\n", arg);
    }

    auto run () -> bool override {
        if (--num < 0)
            return false;
        printf("suspending %d #%d\n", arg, num);
        ready.append(this);
        suspend();
        printf("resuming %d #%d\n", arg, num);
        return true;
    }
};

struct Collector : Stacklet {
    static Event trigger;

    auto run () -> bool override {
        trigger.wait();
        trigger.clear();
        printf("GC...\n");
        markVec(stacklets);
        gc::sweep();
        gc::compact();
        gc::report();
        return true;
    }
};

Event Collector::trigger;

namespace ticker {
    void init ();

    volatile uint32_t ticks;

    void isr () {
        if (++ticks % 1000 == 0)
            Stacklet::setPending(0);
    }
}

struct Ticker : Stacklet {
    Event timeout;

    Ticker () { ticker::init(); }

    auto run () -> bool override {
        timeout.wait();
        timeout.clear();
        printf("<TICK>\n");
        return true;
    }
};

namespace serial {
    // TODO not good enough for next incoming data, should be a ring buffer
    char buf [100];
    uint32_t fill;

    extern void (*putFun)(int); // must be valid even before init is called
    Event outgoing;

    void init ();
    auto canWrite () -> bool;   // wraps console.writable
    void putRaw (int);          // wraps console.putc

    void isrRx (char c) {
        if (c == '\n') {
            buf[fill] = 0;
            fill = 0;
            Stacklet::setPending(1);
        } else if (c != '\r' && fill < sizeof buf - 1)
            buf[fill++] = c;
    }

    void isrTx () {
        Stacklet::setPending(2);
    }

    void (*putFun)(int) = putRaw;

    void putWait (int c) {
        while (!canWrite() && Stacklet::current != nullptr)
            outgoing.wait();
        outgoing.clear();
        putRaw(c);
    }
}

struct Serial : Stacklet {
    Event incoming;

    Serial () { serial::init(); }

    auto run () -> bool override {
        incoming.wait();
        incoming.clear();
        if (strcmp(serial::buf, "?") == 0)
            printf("gc gr ps tb\n");
        else if (strcmp(serial::buf, "gc") == 0) // gc collect
            Collector::trigger.set();
        else if (strcmp(serial::buf, "gr") == 0) // gc report
            gc::report();
        else if (strcmp(serial::buf, "ps") == 0) // print stacklets
            Stacklet::dump();
        else if (strcmp(serial::buf, "tb") == 0) // test blocking output
            for (int i = 0; i < 20; ++i)
                printf("...................................................\n");
        else
            printf("in? %s\n", serial::buf);
        return true;
    }
};

auto appMain () -> int {
    printf("<------------------------------------------------------------->\n");
    gc::setup(memPool, sizeof memPool);
    Collector collector;
    Ticker ticker;
    Serial serial;

    MyStacklet one (11), two (22);
    Stacklet::dump();

    while (true) {
        auto pend = Stacklet::checkPending();
        if (pend != 0) {
            if (pend & (1<<0))
                ticker.timeout.set();
            if (pend & (1<<1))
                serial.incoming.set();
            if (pend & (1<<2))
                serial::outgoing.set();
        }
        auto p = (Stacklet*)(Object*) ready.pull(0);
        if (p != nullptr)
            p->resume();
    }
}
