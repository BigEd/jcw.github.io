#include <cstdio>
#include <ctime>
#include <pthread.h>
#include <unistd.h>

char memPool [10000];

#include "main.h"

namespace ticker {
    pthread_t id;

    void* proc (void*) {
        struct timespec const ts {0, 1000*1000}; // 1 ms
        while (true) {
            nanosleep(&ts, nullptr);
            isr();
        }
    }

    void init () { pthread_create(&id, nullptr, proc, nullptr); }
}

namespace serial {
    pthread_t id;

    void* proc (void*) {
        while (true) {
            int c = getchar();
            if (c == EOF)
                return nullptr;
            isrRx(c);
        }
    }

    void init () { pthread_create(&id, nullptr, proc, nullptr); }

    auto canWrite () -> bool { return true; }

    void putRaw (int c) { putchar(c); }
}

int main () {
    setbuf(stdout, nullptr);
    return appMain();
}
