#include <jee.h>

#if STM32F103xB
UartBufDev< PinA<2>, PinA<3> > console;
#elif STM32L432xx
UartBufDev< PinA<2>, PinA<15> > console;
#endif

extern "C" void __assert_func (char const* f, int l, char const* n, char const* e) {
    printf("assert(%s) in %s\n\t%s:%d\n", e, n, f, l);
    while (true) {}
}

extern "C" void __assert (char const* f, int l, char const* e) {
    __assert_func(f, l, "-", e);
}

char memPool [10000];

#include "main.h"

namespace ticker {
    void init () { VTableRam().systick = isr; }
}

namespace serial {
    static void (*prevIrq)();

    void init () {
        prevIrq = console.handler();
        putFun = putWait;

        console.handler() = []() {
            prevIrq();
            if (console.readable())
                isrRx(console.getc());
            if (console.writable())
                isrTx();
        };
    }

    auto canWrite () -> bool {
        return console.writable();
    }

    void putRaw (int c) { console.putc(c); }
}

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    veprintf(serial::putFun, fmt, ap);
    va_end(ap);
    return 0; // not really
}

int main () {
    console.init();
#if STM32F103xB
    enableSysTick(); // no HSE crystal
#else
    console.baud(115200, fullSpeedClock());
#endif
    wait_ms(500);
    printf("\r");
    wait_ms(10);

    return appMain();
}

extern "C" void SystemInit () {}
