# see https://www.pyinvoke.org
from invoke import task

@task
def native(c):
    """run in native mode"""
    c.run("pio run -e native -s", pty=True)
    c.run(".pio/build/native/program", pty=True)

@task
def f103(c):
    """run on Nucleo-64 F103RB µC board"""
    c.run("pio run -e nucleo-f103 -s", pty=True)

@task
def l432(c):
    """run on Nucleo-32 L432KC µC board"""
    c.run("pio run -e nucleo-l432 -s", pty=True)
