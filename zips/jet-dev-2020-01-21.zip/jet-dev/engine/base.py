# Some very basic gadget definitions.

from core import register, Gadget
import timers

channels = {}

class G_pass(Gadget):
    'Pass all msgs from inlet 0 to outlet 0.'

    nin, nout= 1, 1

    def dispatch(self, inlet, msg):
        self.emit(0, msg)

class G_bang(Gadget):
    'Bang, the non-data message and button.'

    nin, nout= 1, 1

    def __init__(self):
        super().__init__()

    def dispatch(self, inlet, msg):
        self.propagate('B')
        self.emit(0, ())

class G_bangs(Gadget):
    'Multi-outlet bang emitter.'

    nin = 1

    def __init__(self, num):
        super().__init__()
        self.nout = num

    def dispatch(self, inlet, msg):
        for i in range(self.nout):
            self.emit(i, ())

class G_toggle(Gadget):
    'Toggle between zero and non-zero.'

    nin, nout= 1, 1

    def __init__(self):
        super().__init__()
        self.value = 1
        self.on = False

    def dispatch(self, inlet, msg):
        if msg == () or msg == []:
            self.on = not self.on
        elif msg == 0:
            self.on = False
        else:
            self.on = True
            self.value = msg
        result = 1 if self.on else 0
        self.propagate('V',result)
        self.emit(0, result)

class G_print(Gadget):
    'Print all msgs, with initial args used as prefix.'

    nin = 1

    def __init__(self, *prefix):
        super().__init__()
        self.prefix = prefix

    def dispatch(self, inlet, msg):
        self.propagate('P', self.prefix, msg)

class G_moses(Gadget):
    'Split messages, < arg goes to outlet 0, >= arg goes to outlet 1.'

    nin, nout= 2, 2

    def __init__(self, split=0):
        super().__init__()
        self.split = split

    def dispatch(self, inlet, msg):
        if inlet == 0:
            self.emit(0 if msg < self.split else 1, msg)
        else:
            self.split = msg

class G_spigot(Gadget):
    'Only pass messages when inlet 1 is non-zero.'

    nin, nout= 2, 1

    def __init__(self, enable=0):
        super().__init__()
        self.enable = enable

    def dispatch(self, inlet, msg):
        if inlet == 0:
            if self.enable and self.enable != 0:
                self.emit(0, msg)
        else:
            self.enable = msg

class G_metro(Gadget):
    'Metronome to send out periodic bangs.'

    nin, nout= 2, 1

    def __init__(self, ms):
        super().__init__()
        self.ms = ms
        self.timer = lambda: None

    def dispatch(self, inlet, msg):
        if inlet == 0:
            self.timer() # cancel if pending
            if msg != 0:
                self.tick()
        else:
            self.ms = msg

    def tick(self):
        self.emit(0, ())
        self.timer = timers.schedule(self.ms, self.tick)

class G_s(Gadget):
    'Send messages to named receivers.'

    nin = 1

    def __init__(self, name):
        self.name = name

    def dispatch(self, inlet, msg):
        if self.name in channels:
            for g in channels[self.name]:
                g.emit(0, msg)

class G_r(Gadget):
    'Receive messages from named senders.'

    nout = 1

    def __init__(self, name):
        if name not in channels:
            channels[name] = []
        channels[name].append(self)

class G_v(Gadget):
    'Global store for named values.'

    nin, nout= 1, 1

    data = {} # TODO untested

    def __init__(self, name):
        super().__init__()
        self.name = name
        self.data[name] = ()

    def dispatch(self, inlet, msg):
        if msg == [] or msg == (): # TODO yuck
            self.emit(0, self.data[self.name])
        else:
            self.data[self.name] = msg

class G_number(Gadget):
    'Number variable (can store anything, in fact).'

    nin, nout= 1, 1

    def __init__(self, value=0):
        super().__init__()
        self.value = value

    def dispatch(self, inlet, msg):
        if msg != [] and msg != (): # TODO yuck
            self.value = msg
        self.propagate('V',msg)
        self.emit(0, self.value)

class G_slider(Gadget):
    'Number variable, used as visual slider.'

    nin, nout= 1, 1

    def __init__(self, value=0):
        super().__init__()
        self.value = value

    def dispatch(self, inlet, msg):
        if msg != [] and msg != (): # TODO yuck
            self.value = msg
        self.propagate('V',msg)
        self.emit(0, self.value)

register(globals())
