#!/usr/bin/env micropython

from core import registry, make, Gadget, Circuit
import base

def test_dummy():
    print()
    gnames = list(registry.keys())
    gnames.sort()
    assert ' '.join(gnames) == \
        '# bang bangs c inlet metro midiin midiparse moses ' + \
        'number outlet pass print r s slider spigot toggle v'

def test_spigot():
    g = make('spigot')
    g.dispatch(0, 1)
    assert g.outlets == []
    g.dispatch(1, 1)
    assert g.outlets == []
    g.dispatch(0, 2)
    assert g.outlets == [2]
    g.dispatch(0, 3)
    assert g.outlets == [3]
    g.dispatch(1, 0)
    assert g.outlets == [3]
    g.dispatch(0, 4)
    assert g.outlets == [3]
    Circuit.pending = None

if __name__ == '__main__':
    test_dummy()
    test_spigot()
