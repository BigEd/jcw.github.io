# The core engine for gadgets, circuits, and messages.

import heapq, json, os, sys

registry = {}

def register(g):
    'Register all gadget definitions, use as: register(globals()).'
    for k in g:
        if k[:2] == 'G_':
            registry[k[2:]] = g[k]

def parse(cmd):
    'Parse a command string, return it as vector of cmd plus args.'
    vec = cmd.split()
    for i, v in enumerate(vec):
        try:
            vec[i] = int(v)
        except ValueError:
            try:
                vec[i] = float(v)
            except ValueError:
                pass
    return vec

def make(cmd):
    name, *args = parse(cmd)
    factory = maker(name)
    return factory(*args)

def maker(name):
    'Return a callable gadget "maker", given its name.'
    if name in registry:
        return registry[name]
    try:
        lib = __import__('lib.' + name)
        return getattr(getattr(lib, name), 'factory')
    except ImportError:
        pass

class Gadget:
    'A gadget acts on msgs dispatched to it, and can respond by emitting msgs.'

    nin, nout = 0, 0
    pending = None

    def __init__(self):
        self.chain = None
        self.outlets = []
        self.fanout = None

    def embed(self, parent, props):
        'Called after construction to tie this gadget into a circuit.'
        self.parent = parent
        self.wires = [[] for _ in range(self.nout)]
        props['i'] = self.nin
        props['o'] = self.nout
        self.props = props

    def configure(self, msg):
        'Stub. Called to configure this gadget.'
        pass

    def propagate(self, *args):
        'Send a message up the chain of enclosing circuits.'
        i = self.parent.children.index(self)
        self.parent.propagate(i, *args)

    def dispatch(self, inlet, msg):
        'Stub. Called to process incoming messages.'
        raise NotImplementedError

    def emit(self, outlet, msg):
        'Send a message to an outlet, for dispatching to connected gadgets.'
        if outlet >= len(self.outlets):
            if not self.outlets:
                self.chain = Gadget.pending
                Gadget.pending = self
            self.outlets += (outlet + 1 - len(self.outlets)) * [None]
        self.outlets[outlet] = msg

    @staticmethod
    def pump():
        'The message pump loops until there is no more work.'
        while Gadget.pending:
            g = Gadget.pending         # first gadget which has work to do
            if g.outlets:
                o = g.outlets.pop()    # only process one outlet each time
                if o is not None:
                    n = len(g.outlets) # the outlet index this comes from
                    pairs = iter(g.wires[n])
                    for t in pairs:    # the index of the next target gadget
                        g.parent.children[t].dispatch(next(pairs), o)
                    # note that pending may have changed: depth first!
            else:
                Gadget.pending = g.chain
                g.chain = None

class Circuit(Gadget):
    'A circuit is a collection of gadgets (and sub-circuits), wired together.'

    def __init__(self, name=''):
        super().__init__()
        self.ins = []
        self.wires = []
        self.children = []

    def configure(self, msg):
        c = self
        while type(msg[0]) is int:
            c = c.children[msg[0]]
            msg = msg[1:]
        typ, *args = msg
        if typ == 'd': # dispatch
            c.dispatch(*args)
        elif typ == 'g': # add gadget
            if args[0][0] == '!':
                name = args[0][1:]
                if name == '':
                    self.dump(sys.stdout, True)
                elif name == '!':
                    self.dump(sys.stderr, False)
                else:
                    with open('lib/' + name + '.jbp') as f:
                        self.load(f)
                return

            cmd, props = args
            name, *avec = parse(cmd)
            factory = maker(name)
            g = (factory or Circuit)(*avec)
            g.embed(c, props)
            g.cmd = cmd # TODO messy ...
            i = len(c.children)
            c.children.append(g)
            if not factory: # TODO also messy ...
                with open('lib/' + name + '.jbp') as f:
                    g.load(f)
            g.props['i'] = g.nin
            g.props['o'] = g.nout
            c.propagate('G', i, *args)
        elif typ == 'w': # add wire(s)
            # TODO maybe: avoid adding duplicate wires
            c.wires[args[0]] += args[1:]
            c.propagate('W', *args)
        elif typ == 'u': # update props
            c.props.update(*args)
        else:
            raise NotImplementedError

    def load(self, fd):
        off = len(self.children)
        for line in fd:
            msg = json.loads(line)
            if msg[1] == 'w': # TODO yuck, may need to "relocate" wires
                msg[0] += off
                msg[3] += off
            self.configure(msg)

    def dump(self, fd, indexed):
        for i, g in enumerate(self.children):
            if indexed:
                json.dump(['G', i, g.cmd, g.props], fd)
            else: # TODO messy: remove 'i' and 'o' props from the dump
                info = {}
                info.update(g.props)
                del info['i']
                del info['o']
                json.dump(['g', g.cmd, info], fd)
            print(file=fd)
        tag = 'W' if indexed else 'w'
        for i, g in enumerate(self.children):
            for j, w in enumerate(g.wires):
                pairs = iter(w)
                for t in pairs:
                    msg = [i, tag, j, t, next(pairs)]
                    json.dump(msg, fd)
                    print(file=fd)

    def dispatch(self, inlet, msg):
        self.ins[inlet].emit(0, msg)

class G_inlet(Gadget):
    'The inlet gadget acts an entry point for messages sent into a circuit.'

    nout = 1

    def embed(self, parent, props):
        super().embed(parent, props)
        parent.ins.append(self)
        parent.nin += 1

class G_outlet(Gadget):
    'The outlet gadget acts an exit point for messages sent out of a circuit.'

    nin = 1

    def embed(self, parent, props):
        super().embed(parent, props)
        self.outnum = parent.nout
        parent.wires.append([])
        parent.nout += 1

    def dispatch(self, inlet, msg):
        self.parent.emit(self.outnum, msg)

register(globals())
registry['#'] = Gadget
registry['c'] = Circuit
