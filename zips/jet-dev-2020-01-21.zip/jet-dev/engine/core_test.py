#!/usr/bin/env micropython

from testing import *
from core import make, Gadget, Circuit
import base, timers

def test_print():
    print()
    g = make('print abc 1 2 3')
    assert len(g.outlets) == 0
    result = capturePropagates(g)
    g.dispatch(0, 'def')
    assert result == [('P', ('abc', 1, 2, 3), 'def')]

def test_moses():
    g = make('moses 10')
    g.dispatch(0, 5)
    assert g.outlets == [5]
    g.dispatch(0, 15)
    assert g.outlets == [5, 15]
    g.dispatch(1, 20)
    assert g.outlets == [5, 15]
    g.dispatch(0, 15)
    assert g.outlets == [15, 15]
    Gadget.pending = None

def test_circuit():
    c = Circuit()
    result = capturePropagates(c)
    for msg in [
        # add gadgets
        ['g', "moses Y",     {}],
        ['g', "pass",        {}],
        ['g', "print a b c", {}],
        ['g', "pass",        {}],
        ['g', "bang",        {}],
        # add wires
        [0, 'w', 0, 1, 0],
        [0, 'w', 1, 1, 0],
        [0, 'w', 1, 3, 0],
        [1, 'w', 0, 2, 0],
        [3, 'w', 0, 4, 0],
        # dispatch messages
        (2, 'd', 0, 'left'),
        (3, 'd', 0, 'right'),
        (0, 'd', 0, 'X'),
        (0, 'd', 0, 'Y'),
        (0, 'd', 0, 'Z'),
    ]:
        c.configure(msg)
        c.pump()
    assert result == [
        ('G', 0, 'moses Y', {'i': 2, 'o': 2}),
        ('G', 1, 'pass', {'i': 1, 'o': 1}),
        ('G', 2, 'print a b c', {'i': 1, 'o': 0}),
        ('G', 3, 'pass', {'i': 1, 'o': 1}),
        ('G', 4, 'bang', {'i': 1, 'o': 1}),
        (0, 'W', 0, 1, 0),
        (0, 'W', 1, 1, 0),
        (0, 'W', 1, 3, 0),
        (1, 'W', 0, 2, 0),
        (3, 'W', 0, 4, 0),
        (2, 'P', ('a', 'b', 'c'), 'left'),
        (4, 'B'),
        (2, 'P', ('a', 'b', 'c'), 'X'),
        (4, 'B'),
        (2, 'P', ('a', 'b', 'c'), 'Y'),
        (4, 'B'),
        (2, 'P', ('a', 'b', 'c'), 'Z'),
    ]

def test_nested():
    c = Circuit()
    result = capturePropagates(c)
    for msg in [
        ('g', "c test", {}),
        (0, 'g', "inlet", {}),
        (0, 'g', "print nested", {}),
        (0, 'g', "outlet", {}),
        [0, 0, 'w', 0, 1, 0],
        [0, 0, 'w', 0, 2, 0],
        ('g', "print top", {}),
        [0, 'w', 0, 1, 0],
        (0, 'd', 0, 123),
        (0, 1, 'd', 0, 456),
    ]:
        c.configure(msg)
        c.pump()
    assert result == [
        ('G', 0, 'c test', {'i': 0, 'o': 0}),
        (0, 'G', 0, 'inlet', {'i': 0, 'o': 1}),
        (0, 'G', 1, 'print nested', {'i': 1, 'o': 0}),
        (0, 'G', 2, 'outlet', {'i': 1, 'o': 0}),
        (0, 0, 'W', 0, 1, 0),
        (0, 0, 'W', 0, 2, 0),
        ('G', 1, 'print top', {'i': 1, 'o': 0}),
        (0, 'W', 0, 1, 0),
        (0, 1, 'P', ('nested',), 123),
        (1, 'P', ('top',), 123),
        (0, 1, 'P', ('nested',), 456),
    ]

def test_bad_gadget():
    c = Circuit()
    try:
        c.configure(('g', "blah", {}))
        assert False
    except:
        pass

def test_timers():
    timers.now = 0
    timers.schedule(1, lambda: "one")
    timers.schedule(2, lambda: "two")
    timers.schedule(3, lambda: "three")
    timers.schedule(4, lambda: "four")
    assert timers.peek() == 1
    timers.schedule(0, lambda: "zero")
    assert timers.peek() == 0
    assert timers.fire() == "zero"
    assert timers.peek() == 1
    assert timers.fire() == "one"
    assert timers.peek() == 2
    timers.schedule(1, lambda: "two+")
    assert timers.peek() == 2
    assert timers.fire() == "two"
    assert timers.peek() == 2
    assert timers.fire() == "two+"
    assert timers.peek() == 3
    assert timers.fire() == "three"
    assert timers.peek() == 4
    assert timers.fire() == "four"
    assert timers.now == 4
    assert timers.peek() is None

def test_metro():
    timers.now = 0
    g = make('metro 500')
    assert timers.peek() == None
    g.dispatch(0, [])
    assert timers.peek() == 500
    assert g.outlets == [()]
    timers.fire()
    assert g.outlets == [()]
    assert timers.peek() == 1000
    Gadget.pending = None
    timers.pending = [] # clean up, avoids trouble later

if __name__ == '__main__':
    test_print()
    test_moses()
    test_circuit()
    test_nested()
    test_bad_gadget()
    test_timers()
    test_metro()
