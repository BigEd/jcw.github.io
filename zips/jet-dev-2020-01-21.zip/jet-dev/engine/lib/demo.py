from core import Gadget

class G_demo(Gadget):
    "Just a silly demo of a custom gadget."

    nin, nout = 2, 3

    def __init__(self, *args):
        super().__init__()
        self.args = args

    def dispatch(self, inlet, msg):
        print("demo", self.args, inlet, msg)

factory = G_demo
