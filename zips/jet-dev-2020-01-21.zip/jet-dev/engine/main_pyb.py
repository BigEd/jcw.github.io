# For PyBoard, etc - the "main.py" file should contain "import main_pyb".

import json, pyb, sys
from core import pump, Circuit, Timers
import base

sys.path.append('.') # TODO looks like a hack, needed by plugins in lib/

def sendReply(*args):
    print(json.dumps(args))

def start():
    top = Circuit()
    top.propagate = sendReply

    serial = pyb.repl_uart() or pyb.USB_VCP()
    print('main_pyb start')

    while True:

        if serial.any:
            msg = sys.stdin.readline().strip()
            if msg != "":
                try:
                    cmd = json.loads(msg)
                    top.configure(cmd)
                    pump()
                except Exception as e:
                    print('json?',msg)
                    sys.print_exception(e)

        # TODO messy code, the current Timers API is not really convenient
        Timers.now = pyb.millis()

        while Timers.remaining():
            if Timers.remaining() > pyb.millis() - Timers.now:
                break
            cb = Timers.elapse()
            if cb:
                cb()
                pump()

start()
