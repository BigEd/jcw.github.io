#!/usr/bin/env python3

from core import register, Gadget

class G_midiin(Gadget):
    'Capture midi-in messages.'

    nout = 1

    def __init__(self):
        super().__init__()
        try:
            import mido, time
            mido.set_backend("mido.backends.portmidi")
            port = mido.open_input()
            port.callback = self.midiEvent
        except:
            print('no MIDI support')

    def dispatch(self, inlet, msg):
        if inlet == 0:
            if self.enable and self.enable != 0:
                self.emit(0, msg)
        else:
            self.enable = msg

    def midiEvent(self, e):
        # see https://mido.readthedocs.io/en/latest/message_types.html
        if e.type == 'note_on':
            msg = ('note', e.channel, e.note, e.velocity)
        elif e.type == 'polytouch':
            msg = ('poly', e.channel, e.note, e.value)
        elif e.type == 'control_change':
            msg = ('ctl', e.channel, e.control, e.value)
        elif e.type == 'program_change':
            msg = ('pgm', e.channel, e.program)
        elif e.type == 'pitchwheel':
            msg = ('bend', e.channel, e.pitch)
        elif e.type == 'aftertouch':
            msg = ('touch', e.channel, e.value)
        else:
            print('midi event ignored:', e.type)
            return
        self.emit(0, msg)

class G_midiparse(Gadget):
    'Forward each type of midi message to its own outlet.'

    nin, nout= 1, 7

    def dispatch(self, inlet, msg):
        self.emit(6, msg[1])
        o = ['note','poly','ctl','pgm','touch','bend'].index(msg[0])
        self.emit(o, msg[2:] if o < 3 else msg[2])

register(globals())
