#!/usr/bin/env python3

from testing import *
from core import Circuit
import base, midi

def test_midiin():
    c = Circuit()
    result = capturePropagates(c)
    for msg in [
        # add gadgets
        ['g', "midiin",      {}],
        ['g', "print midi",  {}],
        ['g', "midiparse",   {}],
        ['g', "print note",  {}],
        ['g', "print poly",  {}],
        ['g', "print ctl",   {}],
        ['g', "print pgm",   {}],
        ['g', "print touch", {}],
        ['g', "print bend",  {}],
        ['g', "print chan",  {}],
        [0, 'w', 0, 1, 0],
        [0, 'w', 0, 2, 0],
        [2, 'w', 0, 3, 0],
        [2, 'w', 1, 4, 0],
        [2, 'w', 2, 5, 0],
        [2, 'w', 3, 6, 0],
        [2, 'w', 4, 7, 0],
        [2, 'w', 5, 8, 0],
        [2, 'w', 6, 9, 0],
    ]:
        c.configure(msg)
        c.pump()
    assert result == [
        ('G', 0, 'midiin',      {'i': 0, 'o': 1}),
        ('G', 1, 'print midi',  {'i': 1, 'o': 0}),
        ('G', 2, 'midiparse',   {'i': 1, 'o': 7}),
        ('G', 3, 'print note',  {'i': 1, 'o': 0}),
        ('G', 4, 'print poly',  {'i': 1, 'o': 0}),
        ('G', 5, 'print ctl',   {'i': 1, 'o': 0}),
        ('G', 6, 'print pgm',   {'i': 1, 'o': 0}),
        ('G', 7, 'print touch', {'i': 1, 'o': 0}),
        ('G', 8, 'print bend',  {'i': 1, 'o': 0}),
        ('G', 9, 'print chan',  {'i': 1, 'o': 0}),
        (0, 'W', 0, 1, 0),
        (0, 'W', 0, 2, 0),
        (2, 'W', 0, 3, 0),
        (2, 'W', 1, 4, 0),
        (2, 'W', 2, 5, 0),
        (2, 'W', 3, 6, 0),
        (2, 'W', 4, 7, 0),
        (2, 'W', 5, 8, 0),
        (2, 'W', 6, 9, 0)
    ]
    c.propagate = print

if __name__ == "__main__":
    test_midiin()

    import time
    t0 = time.time()
    while time.time() < t0 + 10: # wait 10s for real-time midi input
        Circuit.pump()
