#!/usr/bin/env python3

import asyncio, json, os, sys
from core import Circuit
import base, midi, timers

sys.path.append('.') # TODO looks like a hack, needed by plugins in lib/

# need to disable input buffering, see:
# https://stackoverflow.com/questions/2850893/reading-binary-data-from-stdin
sys.stdin = os.fdopen(sys.stdin.fileno(), 'rb', 0)

def sendReply(*args):
    print(json.dumps(args))

top = Circuit()
top.propagate = sendReply

loop = asyncio.get_event_loop()

timer = None

def keepTicking():
    global timer
    if timer:
        timer.cancel()
    while timers.pending:
        if timers.peek() > 1000 * loop.time():
            break
        timers.fire()
        top.pump()
    if timers.pending:
        timer = loop.call_at(timers.peek() * 0.001, keepTicking)
    else:
        timer = None

def reader():
    'Wait and feed incoming messages from the console to top level circuit.'

    msg = sys.stdin.readline().strip()
    if len(msg) == 0:
        sys.exit()

    timers.now = int(1000 * loop.time() + 0.5) # sync engine's notion of time

    try:
        cmd = json.loads(msg)
        top.configure(cmd)
        top.pump()
    except Exception as e:
        print('reader?', msg)
        sys.print_exception(e)

    keepTicking() # make sure that all timers will fire as needed

# this always triggers on first char, but then it will block until a newline
loop.add_reader(sys.stdin.fileno(), reader)

loop.run_forever()
