# Some utility code used during testing.

def capturePropagates(g):
    result = []
    g.propagate = lambda *args: result.append(args)
    return result
