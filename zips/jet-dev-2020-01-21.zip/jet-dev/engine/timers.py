# Timers manage any number of tiemouts with callbacks. This needs to work with
# polling, with asyncio, and in simulation. For both MicroPython and CPython3.

import heapq

tid = 0 # extra sequence number to prevent callback comparisons in lists
now = 0

pending = []
#heapq.heapify(pending)

def schedule(ms, cb):
    "Call a function at a specified time and return a cancelling function."
    global tid
    tid += 1
    t = [now + ms, tid, cb]
    heapq.heappush(pending, t)
    return lambda: cancel(t)

def peek():
    "Returns timestamp of first upcoming time (if any)."
    if pending:
        return pending[0][0]

def fire():
    "Call this when it's time to perform the next callback."
    global now
    now, _, cb = heapq.heappop(pending)
    if cb:
        return cb()

def cancel(t):
    "Cancel the timer, so it won't ever fire."
    t[2] = None

def process(sleepUntil):
    "Given a function which waits until arg, process all timers in the queue."
    while pending:
        sleepUntil(peek())
        fire()
