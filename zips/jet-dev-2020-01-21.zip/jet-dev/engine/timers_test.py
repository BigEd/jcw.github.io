#!/usr/bin/env micropython

import timers

vals = []
calls = []

def init():
    global vals, calls
    vals = []
    calls = []
    timers.now = 0

def called(when):
    timers.now = when
    calls.append(when)

def setVal(n):
    def setter():
        vals.append(n)
    return setter

def processAndCheck(expVals, expCalls, expNow):
    timers.process(called)
    assert vals == expVals
    assert calls == expCalls
    assert timers.now == expNow
    assert not timers.peek()

def test_never():
    init()
    timers.process(called)
    assert calls == []

def test_single():
    init()
    timers.schedule(10, setVal(1))
    assert timers.peek() == 10
    processAndCheck([1], [10], 10)

def test_ordered():
    init()
    timers.schedule(10, setVal(1))
    assert timers.peek() == 10
    timers.schedule(25, setVal(2))
    assert timers.peek() == 10
    processAndCheck([1,2], [10,25], 25)

def test_reversed():
    init()
    timers.schedule(25, setVal(1))
    assert timers.peek() == 25
    timers.schedule(10, setVal(2))
    assert timers.peek() == 10
    processAndCheck([2,1], [10,25], 25)

def test_same():
    init()
    timers.schedule(10, setVal(1))
    timers.schedule(10, setVal(2))
    timers.schedule(10, setVal(3))
    assert timers.peek() == 10
    processAndCheck([1,2,3], [10,10,10], 10)

def test_unsorted():
    init()
    timers.schedule(25, setVal(1))
    assert timers.peek() == 25
    timers.schedule(10, setVal(2))
    assert timers.peek() == 10
    timers.schedule(15, setVal(3))
    assert timers.peek() == 10
    processAndCheck([2,3,1], [10,15,25], 25)

if __name__ == '__main__':
    test_never()
    test_single()
    test_ordered()
    test_reversed()
    test_same()
    test_unsorted()
