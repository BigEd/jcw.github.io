import json, pyb, sys, uasyncio
from time import ticks_ms

from core import Circuit
import base, timers

sys.path.append('.') # TODO looks like a hack, needed by plugins in lib/

top = Circuit()
top.propagate = lambda *args: print(json.dumps(args))

task = None  # background task to process the timer chain
sched = None # when is the next timer scheduled to fire

async def ticker():
    'Used as task to process pending timers, as long as there are any.'

    global task, sched
    while timers.pending:
        now = ticks_ms()
        ms = timers.peek() - now
        if ms <= 0:
            try:
                timers.fire()
                top.pump()
            except Exception as e:
                print('ticker?', ms, now)
                sys.print_exception(e)
        else:
            sched = now + ms
            await uasyncio.sleep_ms(ms)
    task = None

def keepTicking():
    'Make sure there is a ticker task, may cancel existing one to preempt it.'

    global task, sched
    if timers.pending:
        if task and timers.peek() < sched:
            task.cancel()
            task = None
        if not task:
            task = uasyncio.create_task(ticker())

async def reader():
    'Wait and feed incoming messages from the console to top level circuit.'

    serial = pyb.repl_uart() or pyb.USB_VCP()
    stdin = uasyncio.StreamReader(serial)
    print('urun start')

    while True:
        msg = await stdin.readline()
        msg = msg.strip()
        if len(msg) == 0:
            break

        timers.now = ticks_ms() # sync engine's notion of time

        try:
            cmd = json.loads(msg)
            top.configure(cmd)
            top.pump()
        except Exception as e:
            print('reader?', msg)
            sys.print_exception(e)

        keepTicking() # make sure that all timers will fire as needed

uasyncio.run(reader())
