<svelte:head>
    <title>JET dev - JeeLabs</title>
</svelte:head>

<script>
    import { setContext } from 'svelte';
    setContext('sendMsg', onSendMsg)

    import Dashboard from './Dashboard.svelte';
    import Editor from './Editor.svelte';
    import Console from './Console.svelte';
    import Admin from './Admin.svelte';
    import Tabs from './Tabs.svelte';

    let ws, onReceive

    function connect() {
        ws = new WebSocket(`ws://${location.host}/live`)

        ws.onclose = e => {
            ws = null
            if (e.code != 1006)
                console.log(`WebSocket disconnected, code ${e.code}`)
            setTimeout(connect, 1000)
        }

        ws.onopen = e => {
            console.info("websocket connected")
        }

        ws.onmessage = e => {
            onReceive(JSON.parse(e.data))
        }
    }
    connect()

    let tabNum = 1;

    // TODO messy, should probably put this inside the ws.on... handlers
    function onSendMsg(...args) {
        if (ws)
            ws.send(JSON.stringify(args))
    }
</script>

<header><h1>JET dev</h1></header>

<Tabs {tabNum} names={['Dashboard','Editor','Console','Admin']}
on:tabChange={e => tabNum = e.detail} />
{#if tabNum === 0}
    <Dashboard/>
{:else if tabNum === 1}
    <Editor bind:onReceive />
{:else if tabNum === 2}
    <Console/>
{:else if tabNum === 3}
    <Admin/>
{/if}

<!--
<footer><p>See
<a href="https://git.jeelabs.org/jcw/jet">git.jeelabs.org/jcw/jet</a>
for details.</p></footer>
-->
