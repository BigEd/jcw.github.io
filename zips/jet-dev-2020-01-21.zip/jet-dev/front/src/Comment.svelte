<script>
    export let info
</script>

<text x={info.x} y={info.y} >{info.text}</text>

<style>
</style>
