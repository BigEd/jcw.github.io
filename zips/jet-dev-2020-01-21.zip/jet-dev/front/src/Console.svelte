<script>
    import { afterUpdate, onDestroy } from 'svelte'

    const rows = 25, cols = 80
    let inputElt, textarea, content = ''

    function addText(s) {
        let lines = (content + s).split('\n')
        if (lines.length > 100)
            lines = lines.slice(lines.length-100)
        content = lines.join('\n')
    }

    afterUpdate(() => {
        textarea.scrollTop = textarea.scrollHeight
    })

    let ws = null, cmd = 'help()', addr = '192.168.42.20', port = 8266

    function connect(e) {
        let proto = window.location.protocol.replace('http','ws')
        let url = `${proto}/${addr}:${port}/`
        ws = new WebSocket(url)
        ws.binaryType = 'arraybuffer'
        //console.log('ws', ws)

        ws.onopen = () => {
            inputElt.focus()
            addText(`\n<<< Connected to ${addr} >>>\n`)
        }

        ws.onmessage = e => {
            if (e.data instanceof ArrayBuffer) {
                let data = new Uint8Array(e.data)
                console.log('bin-data', data)
            } else
                addText(e.data)
        }

        ws.onclose = () => {
            ws = null
            addText('\n<<< Disconnected >>>')
        }

        ws.onerror = e => {
            alert(`Websocket error for ${url}`)
        }
    }

    function enterCmd(e) {
        //console.log('keyCode', e.keyCode, e)
        if (e.ctrlKey)
            switch (e.key) {
                case 'a': ws.send('\x01'); break; // raw repl
                case 'b': ws.send('\x02'); break; // normal repl
                case 'c': ws.send('\x03'); break; // interrupt
                case 'd': ws.send('\x04'); break; // soft reset
                case 'e': ws.send('\x05'); break; // paste mode
            }
        else if (e.key === 'Enter') {
            ws.send(cmd + '\r')
            cmd = ''
            return false
        }
    }

    onDestroy(() => {
        if (ws)
            ws.close()
    })

</script>

<textarea {rows} {cols} disabled bind:this={textarea} >{content}</textarea>
<div>
    {#if ws}
        <input type=text bind:value={cmd} size={cols+1}
                on:keydown={enterCmd} bind:this={inputElt} />
    {:else}
        <label>WebREPL address:
            <input type=text bind:value={addr} size=17 />
        </label>
        <label>Port:
            <input type=text bind:value={port} size=6 />
        </label>
        <button on:click={connect}>Connect</button>
    {/if}
</div>

<style>
    textarea {
        font-family: monospace;
        padding: 0 5px;
        background: #eee;
        word-break: break-all;
    }
    input {
        font-family: monospace;
        padding: 2px 8px 3px 5px;
        margin-right: 10px;
    }
</style>
