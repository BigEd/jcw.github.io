<script>
    let dense = false;
</script>

<p>
    <label><input type=checkbox bind:checked={dense}> Dense layout</label>
</p>

<main class:dense>
    {#each Array(30) as _, i}
        <div class=box style="grid-column-end: span {i%4+1};
                            grid-row-end: span {(i*7)%3+1};" >
            Item {i}
        </div>
    {/each}
</main>

<style>
    main {
        display: grid;
        grid-template-columns: repeat(auto-fill, 58px);
        grid-auto-rows: 58px;
        grid-gap: 2px;
    }
    .dense {
        grid-auto-flow: dense;
    }
    .box {
        background: #fdd;
        border: 1px solid grey;
        border-radius: 5px;
        padding: 3px;
    }
</style>
