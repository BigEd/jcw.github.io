<script>
    import { getContext } from 'svelte';
    const sendMsg = getContext('sendMsg');

    import Gadget from './Gadget.svelte';
    import Wire, { outletCoord, wirePath } from './Wire.svelte';

    let gadgets = []
    let wires = []

    let selection = new Set(), position = {x:0,y:0}, svg, marquee, dragWire

    function dragStart(evt) {
        position = getMousePos(evt);

        svg.addEventListener('mousemove', dragMove)
        svg.addEventListener('touchmove', dragMove)

        const gElt = evt.target.parentElement;
        if (gElt.classList.contains('draggable')) {
            const id = +gElt.id
            if (evt.target.nodeName == 'use' && evt.target.id[0] == 'o') {
                const outlet = +evt.target.id.slice(1)
                dragWire = newWire(gadgets[id], outlet)
                svg.appendChild(dragWire)
            } else {
                selection.add(id);
                gElt.parentElement.lastElementChild.after(gElt); // to front
            }
        } else {
            if (!evt.shiftKey)
                selection.clear()
            marquee = newMarquee(evt)
            svg.appendChild(marquee)
        }
    }

    function dragMove(evt) {
        const { x, y } = getMousePos(evt);
        const dx = x - position.x;
        const dy = y - position.y;
        position.x = x;
        position.y = y;

        if (dragWire)
            dragWire.adjustPath(evt)
        else if (marquee)
            marquee.adjustRect(dx, dy)
        else
            selection.forEach(id => {
                gadgets[id].x += dx
                gadgets[id].y += dy
            })
    }

    function dragEnd(evt) {
        svg.removeEventListener('mousemove', dragMove)
        svg.removeEventListener('touchmove', dragMove)

        if (dragWire) {
            const { x, y } = getMousePos(evt);
            const target = document.elementFromPoint(x, y)
            if (target.nodeName == 'use' && target.id[0] == 'i') {
                const gElt = target.parentElement;
                const inlet = +target.id.slice(1)
                const d = dragWire
                sendMsg(d.gadget.id, 'w', d.outlet, +gElt.id, inlet)
            }
            svg.removeChild(dragWire)
            dragWire = null
        } else if (marquee) {
            let m = marquee.getBBox()
            // TODO tedious: svg.getIntersectionList not available in Firefox
            for (let elt of document.getElementsByClassName('draggable')) {
                let e = elt.getBBox()
                let disjunct = e.x > m.x + m.width || e.x + e.width < m.x ||
                               e.y > m.y + m.height || e.y + e.height < m.y
                // TODO grrr, not in Firefox: if (svg.checkIntersection(elt, m))
                if (!disjunct)
                    selection.add(+elt.id)
            }
            svg.removeChild(marquee)
            marquee = null
        } else {
            selection.forEach(id => {
                const {x,y} = gadgets[id]
                sendMsg(id, 'u', {x, y})
            })
            selection.clear()
        }
    }

    function newSvgElt(type) {
        var e = document.createElementNS('http://www.w3.org/2000/svg', type)
        e.get = (k) => +e.getAttributeNS(null, k)
        e.set = (k,v) => e.setAttributeNS(null, k, v)
        return e
    }

    function newWire(g, n) {
        var w = newSvgElt('path')
        w.set('class', 'dragwire')

        w.gadget = g
        w.outlet = n

        w.adjustPath = (evt) => w.set('d', wirePath(...outletCoord(g, n),
                                                    evt.offsetX, evt.offsetY))
        return w
    }

    function newMarquee(evt) {
        var m = newSvgElt('rect')
        m.set('class', 'marquee')
        m.set('x', evt.offsetX)
        m.set('y', evt.offsetY)
        m.set('width', 0)
        m.set('height', 0)

        m.adjustRect = (dx, dy) => {
            // TODO don't use dx/dy, try to switch to offsetX/Y
            // FIXME this fails with negative widths or heights
            m.set('width', m.get('width') + dx)
            m.set('height', m.get('height') + dy)
        }

        return m
    }

    function getMousePos(evt) {
        if (evt.touches)
            evt = evt.touches[0];
        return { x: evt.clientX, y: evt.clientY };
    }

    export function onReceive(msg) {
        if (msg) {
            // TODO nesting
            if (msg[1] == 'B')
                gadgets[msg[0]].value = []
            else if (msg[1] == 'V')
                gadgets[msg[0]].value = msg[2]
            else if (msg[1] == 'P')
                console.log(msg[2].join(' '), msg[3])
            else if (msg[1] == 'W') {
                const w = msg.slice(0,1).concat(msg.slice(2))
                const s = w.toString() // TODO yuck, can't compare as arrays
                if (wires.some(v => v.toString() == s))
                    console.log("dup", s)
                else                    
                    wires = [...wires, w]
            } else if (msg[0] == 'G') {
                if (msg[1] == gadgets.length) {
                    const g = msg[3]
                    g.cmd = msg[2]
                    g.id = msg[1]
                    if (!g.x)
                        g.x = 250
                    if (!g.y)
                        g.y = 150
                    gadgets = [...gadgets, g]
                } else
                    console.log('dup', msg)
            } else
                console.log('ws?', msg)
        }
    }

    function keyUp(e) {
        if (e.keyCode === 13) {
            let cmd = e.srcElement.value.trim()
            e.srcElement.value = ''

            if (cmd != "") {
                // a single number creates a number gadget
                if (!isNaN(+cmd))
                    cmd = 'number ' + cmd

                const props = {}
                if (cmd[0] == '#') {
                    props.text = cmd.slice(1).trim()
                    cmd = '#'
                }

                sendMsg('g', cmd, props)
            }
        }
    }
</script>

<div>
    <label>Create:
        <input on:keyup={keyUp} size=40 placeholder="gadget args ..." />
    </label>
</div>

<svg width=100% height=300 bind:this={svg}
                           on:mousedown|preventDefault={dragStart}
                           on:mouseup={dragEnd} 
                           on:mouseleave={dragEnd}
                           on:touchstart|preventDefault={dragStart}
                           on:touchend={dragEnd} 
                           on:touchleave={dragEnd}
                           on:touchcancel={dragEnd} >
    <marker id=dot overflow=visible>
        <circle r=3 />
    </marker>
    <defs>
        <g id=inlet >
            <rect x=-5 y=-1 width=10 height=2 />
            <path d='M-10,1 A10,10 0 0 1 10,1' />
        </g>
        <g id=outlet >
            <rect x=-5 y=-1 width=10 height=2 />
            <path d='M-10,-1 A10,10 0 0 0 10,-1' />
        </g>
    </defs>
    {#each wires as [f,fo,t,ti] }
        <Wire fg={gadgets[f]} {fo} tg={gadgets[t]} {ti} />
    {/each}
    {#each gadgets as info (info.id)}
        <Gadget {info} />
    {/each}
</svg>

<h3>gadgets</h3>
{#each gadgets as g, i}
    {i}: {JSON.stringify(g)}<br/>
{/each}

<h3>wires</h3>
{#each wires as w, i}
    {i}: {JSON.stringify(w)}<br/>
{/each}

<style>
    svg { background: #f8f8f8; cursor: crosshair; }
    :global(.marquee) {
        stroke: red;
        stroke-dasharray: 10 5;
        fill: rgba(255,200,200,0.2);
    }
    :global(.dragwire) {
        stroke: red;
        stroke-dasharray: 4 2;
        fill: none;
    }
    path { fill: none; pointer-events: all; }
</style>
