<script>
    import { getContext } from 'svelte';
    const sendMsg = getContext('sendMsg');

    export let info
    $: cx = info.x
    $: cy = info.y

    $: if (info.value)
        setTimeout(() => { info.value = false }, 250)

    function onMouseDown(e) {
        sendMsg(info.id, 'd', 0, [])
    }
</script>

<circle {cx} {cy} r=10 />
<circle class=inner class:on={info.value} {cx} {cy} r=7
        on:mousedown|preventDefault|stopPropagation={onMouseDown} />

<style>
    circle { stroke: darkgrey; stroke-width: 2px; fill: white; }
    .inner { stroke: none; cursor: pointer; }
    .on { fill: black; }
</style>
