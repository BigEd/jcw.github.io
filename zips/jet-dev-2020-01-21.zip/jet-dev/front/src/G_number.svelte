<script>
    import { getContext } from 'svelte';
    const sendMsg = getContext('sendMsg');

    export let info
    $: x = info.x
    $: y = info.y

    info.value = +info.cmd.slice(6) || 0

    function onMouseDown(e) {
        e.target.focus() // TODO a hack, but it works reasonably well this way
    }

    function keyUp(e) {
        if (e.keyCode === 13)
            e.target.blur()
        else if (e.keyCode === 27)
            e.srcElement.value = info.value
    }

    function onBlur(e) {
        // note: don't use bind:value, send to engine first
        const value = e.srcElement.value
        sendMsg(info.id, 'd', 0, +value)
        // e.target.blur()  // this will stop re-sending on window focus loss
    }
</script>

<rect x={x-10} y={y-10} width=60 height=20 />
<foreignObject x={x-5} y={y-9} width=54 height=18 >
    <input type=number value={info.value}
           on:mousedown|stopPropagation={onMouseDown}
           on:keyup={keyUp} on:blur={onBlur} />
</foreignObject>

<style>
    rect { stroke: darkgrey; stroke-width: 2px; fill: white; }
    input { width: 100%; margin: 0; padding: 0; border: 0; }
</style>
