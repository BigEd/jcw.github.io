<script>
    import { getContext } from 'svelte';
    const sendMsg = getContext('sendMsg');

    export let info
    $: x = info.x
    $: y = info.y

    info.dyOut = 20
    info.value = +info.cmd.slice(6) || 0

    function onMouseDown(e) {
        e.target.focus() // TODO a hack, but it works reasonably well this way
    }

    function onMouseUp(e) {
        // note: don't use bind:value, send to engine first
        const value = e.srcElement.value
        sendMsg(info.id, 'd', 0, +value)
        e.target.blur()
    }
</script>

<rect x={x-10} y={y-10} width=110 height=30 />
<foreignObject x={x-3} y={y-9} width=104 height=28 >
    <input type=range min=0 max=100 value={info.value}
           on:mousedown|stopPropagation={onMouseDown}
           on:mouseup={onMouseUp} />
</foreignObject>

<style>
    rect { stroke: darkgrey; fill: white; }
    input { width: 95%; margin: 0; padding: 0; border: 0; }
</style>
