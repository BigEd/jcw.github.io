<script>
    import { getContext } from 'svelte';
    const sendMsg = getContext('sendMsg');

    export let info
    $: x = info.x
    $: y = info.y
    $: on = info.value

    function onMouseDown(e) {
        sendMsg(info.id, 'd', 0, [])
    }
</script>

<rect x={x-10} y={y-10} width=20 height=20 />
<circle cx={x} cy={y} r=7
        on:mousedown|preventDefault|stopPropagation={onMouseDown} />
<line class:on x1={x-8} y1={y-8} x2={x+8} y2={y+8} />
<line class:on x1={x+8} y1={y-8} x2={x-8} y2={y+8} />

<style>
    rect { stroke: darkgrey; stroke-width: 2px; fill: white; }
    circle { fill: white; cursor: pointer; }
    .on { stroke: black; }
    line { pointer-events: none; }
</style>
