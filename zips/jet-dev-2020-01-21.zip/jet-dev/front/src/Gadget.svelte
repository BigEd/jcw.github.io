<script>
    export let info
    import G_bang from './G_bang.svelte';
    import G_number from './G_number.svelte';
    import G_slider from './G_slider.svelte';
    import G_toggle from './G_toggle.svelte';
    import Generic from './Generic.svelte';
    import Comment from './Comment.svelte';

    info.dxIns = Array(info.i).fill(0)
    info.dyIn = -10
    info.dxOuts = Array(info.o).fill(0)
    info.dyOut = 10

    const types = {
        bang:   G_bang,
        number: G_number,
        slider: G_slider,
        toggle: G_toggle,
        '#':    Comment,
    }

    const name = info.cmd.match(/\S+/)
    const component = types[name && name[0]] || Generic
</script>

<g id={info.id} class=draggable >
    <svelte:component this={component} bind:info />
    {#each info.dxIns as dx, i}
        <use id=i{i} class=in href=#inlet
             x={info.x+dx} y={info.y+info.dyIn} >
            <title>inlet #{i}</title>
        </use>
    {/each}
    {#each info.dxOuts as dx, i}
        <use id=o{i} class=out href=#outlet
             x={info.x+dx} y={info.y+info.dyOut} >
            <title>outlet #{i}</title>
        </use>
    {/each}
</g>

<style>
    .draggable { cursor: move; }
    use:hover { fill: red; }
    .in:hover { cursor: default; }
    .out:hover { cursor: copy; }
</style>
