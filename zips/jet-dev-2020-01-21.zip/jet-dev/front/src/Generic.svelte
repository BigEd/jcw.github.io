<script>
    import { onMount } from 'svelte';
    export let info

    $: x = info.x;
    $: y = info.y;

    const minWidth = 20 * Math.max(info.i, info.o)

    let textElt, width = 0;

    function placeLets(vec) {
        const num = vec.length
        const xstep = (width - 10*num - 10) / Math.max(1, num-1) + 10
        for (let i = 0; i < num; i++)
            vec[i] = 10 + i * xstep
    }

    onMount(() => {
        if (textElt)
            width = textElt.getBBox().width + 10
        if (width < minWidth)
            width = minWidth
        placeLets(info.dxIns)
        placeLets(info.dxOuts)
    })
</script>

<rect x={x} y={y-10} {width} height=20 rx=6 />
<text x={x+5} y={y+5} bind:this={textElt} >{info.cmd}</text>

<style>
    rect { stroke: darkgrey; stroke-width: 2px; fill: white; }
    text { pointer-events: none; }
</style>
