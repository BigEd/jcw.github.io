<script>
  export let names, tabNum;

  import { createEventDispatcher } from 'svelte';
  let dispatch = createEventDispatcher();
</script>

<div class="tabs">
    {#each names as name, i}
        <button on:click={() => dispatch('tabChange', i)}>
            <div class:active={i == tabNum}>{name}</div>
        </button>
    {/each}
</div>

<style>
    .tabs {
        margin-bottom: 20px;
        border-bottom: 1px solid teal;
    }
    button {
        font-size: 120%;
        background: none;
        border: none;
        margin: 0;
        padding: 0 1rem 0 0;
        color: #ccc;
        cursor: pointer;
    }
    .active {
        padding-bottom: 3px;
        border-bottom: 3px solid teal;
        color: #333;
    }
</style>
