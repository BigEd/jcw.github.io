<script context="module">

    export function inletCoord(g, n) {
        return [ g.x + g.dxIns[n], g.y + g.dyIn ]
    }
    export function outletCoord(g, n) {
        return [ g.x + g.dxOuts[n], g.y + g.dyOut ]
    }
    export function wirePath(x1, y1, x2, y2) {
        return `M ${x1},${y1} C ${x1},${y1+25} ${x2},${y2-25} ${x2},${y2}`
    }
</script>

<script>
    export let fg, fo, tg, ti

    let d
    $: if (fg.dxOuts && tg.dxIns) // FIXME caused by wrong init order?
        d = wirePath(...outletCoord(fg, fo), ...inletCoord(tg, ti))
</script>

<path {d} />

<style>
    path { stroke: black; fill: none; marker: url(#dot); }
</style>
