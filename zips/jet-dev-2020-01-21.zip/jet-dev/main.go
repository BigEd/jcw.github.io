package main

import (
	"flag"
	"log"

	"./server"
)

func main() {
	flag.Parse()
	log.SetFlags(log.Ltime)

	server.Run()
}
