package server

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"time"

	"github.com/eclipse/paho.mqtt.golang"
	"github.com/gorilla/websocket"
	"github.com/tarm/serial"
)

const (
	listen = ":7489"
	prefix = "console/public"
	script = "run.py"
)

var (
	upgrader = websocket.Upgrader{}
	commands = make(chan string)
	replies  = make(chan string)
	clients  = make(chan *websocket.Conn)

	port  = flag.String("p", "", "serial port or mqtt broker")
	baud  = flag.Int("b", 115200, "baud rate")
	topic = flag.String("t", "jet/test", "mqtt topic")
)

func Run() {
	go func() {
		time.Sleep(2 * time.Second) // show this after other startup messages
		log.Println("web server at http://localhost" + listen)
	}()

	var engIn io.Writer
	var engOut io.Reader

	if *port == "" {
		log.Println("launching", script)
		engIn, engOut = launchEngine(script)
	} else if strings.Contains(*port, ":") {
		log.Println("connecting", *port, "topic", *topic)
		conn := mqttStreamer(*port, *topic)
		engIn = conn
		engOut = conn
	} else {
		log.Println("opening", *port)
		c := &serial.Config{Name: *port, Baud: *baud}
		tty, err := serial.OpenPort(c)
		check(err)
		engIn = tty
		engOut = tty
	}

	go func() {
		//defer in.Close()
		for msg := range commands {
			fmt.Println("C>E", msg)
			_, err := io.WriteString(engIn, msg+"\n")
			check(err)
		}
	}()

	go func() {
		scanner := bufio.NewScanner(engOut)
		for scanner.Scan() {
			msg := scanner.Text()
			if strings.HasPrefix(msg, "[") {
				replies <- msg
			} else {
				fmt.Println("e:", msg)
			}
		}
		check(scanner.Err())
	}()

	go func() {
		var listeners = make(map[string]*websocket.Conn)

		for {
			select {

			case c := <-clients:
				listeners[c.RemoteAddr().String()] = c

			case msg := <-replies:
				fmt.Println("E>C", msg)
				for addr, conn := range listeners {
					const wstm = websocket.TextMessage
					if conn.WriteMessage(wstm, []byte(msg)) != nil {
						delete(listeners, addr) // drop failing clients
					}
				}
			}
		}
	}()

	http.HandleFunc("/live", wsHandler)

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		log.Println("GET", r.URL.Path)
		http.ServeFile(w, r, prefix+r.URL.Path)
	})

	check(http.ListenAndServe(listen, nil))
}

func wsHandler(w http.ResponseWriter, r *http.Request) {
	c, err := upgrader.Upgrade(w, r, nil)
	check(err)
	defer c.Close()

	log.Println("ws connect", c.RemoteAddr())
	defer log.Println("ws disconnect", c.RemoteAddr())

	clients <- c

	for {
		msgType, msgData, err := c.ReadMessage()
		if err != nil {
			break
		}

		if msgType == websocket.TextMessage {
			msg := string(msgData)
			if strings.HasPrefix(msg, "[") {
				commands <- msg
			} else {
				fmt.Println("c:", msg)
			}
		} else {
			log.Printf("recv type %c ? %s", "0TB34567CIO"[msgType], msgData)
		}
	}
}

func launchEngine(name string) (io.WriteCloser, io.ReadCloser) {
	cmd := exec.Command("python3", "-u", name)
	cmd.Dir = "engine/"
	cmd.Stderr = os.Stderr

	stdIn, err := cmd.StdinPipe()
	check(err)
	stdOut, err := cmd.StdoutPipe()
	check(err)
	check(cmd.Start())

	return stdIn, stdOut
}

type MqttStream struct {
	incoming chan string
	client   mqtt.Client
	topic    string
}

func (ms MqttStream) Write(msg []byte) (int, error) {
	ms.client.Publish(ms.topic, 1, false, msg)
	return len(msg), nil
}

func (ms MqttStream) Read(buf []byte) (int, error) {
	msg := <-ms.incoming
	copy(buf, msg)
	return len(msg), nil
}

func mqttStreamer(port, topic string) io.ReadWriter {
	opts := mqtt.NewClientOptions().AddBroker(port)

	ms := MqttStream{
		incoming: make(chan string, 10),
		client:   mqtt.NewClient(opts),
		topic:    topic,
	}

	if t := ms.client.Connect(); t.Wait() {
		check(t.Error())
	}

	onReceive := func(client mqtt.Client, msg mqtt.Message) {
		ms.incoming <- string(msg.Payload()) + "\n"
	}

	if t := ms.client.Subscribe(topic+"/reply", 1, onReceive); t.Wait() {
		check(t.Error())
	}

	return ms
}

func check(err error) {
	if err != nil {
		log.Fatal(err)
		//panic(err)
	}
}
