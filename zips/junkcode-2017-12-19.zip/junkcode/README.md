Experimental area for tryouts, wild goose chases, dead ends, and so on.  
This repository uses git submodules. Run this command after a "git clone":

    git submodule update --init

For more practically useful code, see the [JeeLib][1] and [Embello][2] areas.

[1]: https://github.com/jcw/jeelib
[2]: https://github.com/jeelabs/embello
