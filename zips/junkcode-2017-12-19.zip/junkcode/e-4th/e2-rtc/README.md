Experimental bit-banged I2C driver in Mecrisp-Stellaris Forth.

This code runs on HyTiny (STM32F103), with an RTC connected as follows:

    SCL = PB6
    SDA = PB7

The "try" command resets the RTC on I2C address 0x68, and reports the
seconds readout in a loop. It exits when a key is pressed.

The driver code is in "x", it assumes "bd.txt" has been pre-loaded in flash.
