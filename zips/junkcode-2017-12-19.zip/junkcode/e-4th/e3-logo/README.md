Experimental bit-banged I2C + OLED driver in Mecrisp-Stellaris Forth.

This code runs on HyTiny (STM32F103), with an OLED connected as follows:

    SCL = PB6
    SDA = PB7

The "try" command initialises the OLED on I2C address 0x3C, clears the screen,
and then copies and displays the JeeLabs logo.

The driver code is in "x", it assumes "bd.txt" has been pre-loaded in flash.
