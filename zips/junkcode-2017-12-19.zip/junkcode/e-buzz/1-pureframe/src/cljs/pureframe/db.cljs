(ns pureframe.db)

(def default-db
  {:name "react/re-frame"})
