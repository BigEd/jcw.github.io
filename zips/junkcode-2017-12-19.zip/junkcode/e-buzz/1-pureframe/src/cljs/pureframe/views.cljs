(ns pureframe.views
  (:require [re-frame.core :as re-frame]))

(defn home-panel []
  (let [name (re-frame/subscribe [:name])]
    (fn []
      [:div.pure-g 
       [:div.pure-u-1-3 (str "Hello from " @name ".")]
       [:div.pure-u-1-3 (str "Hello from ClojureScript.")]
       [:div.pure-u-1-3 (str "Hello from Pure CSS.")]])))

(defn about-panel []
  (fn []
    [:div "This could be an About Page."]))

(defn test-panel []
  (fn []
    [:div "This is a Test Page."]))

(defmulti panels identity)
(defmethod panels :home-panel [] [home-panel])
(defmethod panels :about-panel [] [about-panel])
(defmethod panels :test-panel [] [test-panel])
(defmethod panels :default [] [:div])

;; TODO clean up this conversion of the PureCss menu to hiccup style templates
(defn custom-menu []
  [:div.custom-menu-wrapper
   [:div.pure-menu.custom-menu.custom-menu-top
    [:a.pure-menu-heading.custom-menu-brand {:href "#"} "Buzz"]
    [:a#toggle.custom-menu-toggle {:href "#"} [:s.bar] [:s.bar]]]
   [:div#tuckedMenu.pure-menu.pure-menu-horizontal.pure-menu-scrollable.custom-menu.custom-menu-bottom.custom-menu-tucked
    [:div.custom-menu-screen]
    [:ul.pure-menu-list
     [:li.pure-menu-item [:a.pure-menu-link {:href "#/"} "Home"]]
     [:li.pure-menu-item [:a.pure-menu-link {:href "#/about"} "About"]]
     [:li.pure-menu-item [:a.pure-menu-link {:href "#/test"} "Test"]]]]])

(defn main-panel []
  (let [active-panel (re-frame/subscribe [:active-panel])]
    (fn [] 
      [:div
       (custom-menu)
       [:div#content
        (panels @active-panel)]])))
