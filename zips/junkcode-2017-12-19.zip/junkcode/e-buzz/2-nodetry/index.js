goog.addDependency("base.js", ['goog'], []);
goog.addDependency("../cljs/core.js", ['cljs.core'], ['goog.string', 'goog.object', 'goog.string.StringBuffer', 'goog.array']);
goog.addDependency("../test/core_test.js", ['test.core_test'], ['cljs.core']);
goog.addDependency("../4F8F2B7.js", ['cljs.nodejs'], ['cljs.core']);
goog.addDependency("../nodetry/core.js", ['nodetry.core'], ['cljs.core', 'cljs.nodejs']);
goog.addDependency("../BCE03FE.js", ['cljs.nodejscli'], ['cljs.core', 'cljs.nodejs']);
