(defproject nodetry "0.1.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.7.0"]
                 [org.clojure/clojurescript "0.0-3308"]
                 [org.clojure/core.async "0.1.346.0-17112a-alpha"]]
  :profiles {:dev
             {:dependencies [[com.cemerick/piggieback "0.2.1"]
                             [org.clojure/tools.nrepl "0.2.10"]]
              :plugins [[lein-cljsbuild "1.0.6"]]
              :source-paths ["src" "dev"]
              :repl-options {:nrepl-middleware
                             [cemerick.piggieback/wrap-cljs-repl]}}}

  :hooks [leiningen.cljsbuild]

  :clean-targets [[:cljsbuild :builds 0 :compiler :output-to]
                  :target-path
                  :compile-path]

  :cljsbuild {:builds
              [{:id "dev"
                :source-paths ["src"]
                :compiler {:output-dir "out"
                           :output-to "index.js"
                           :optimizations :none
                           :source-map "src-maps"
                           :target :nodejs}}]
              :test-commands {"unit" ["node" "app_test.js"]}
              })
