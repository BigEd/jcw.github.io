(ns test.core-test
  (:require-macros [cljs.test :refer [deftest is testing run-tests]])
  #_(:require [nodetry.core]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))

(run-tests)
