# nodetry2

* see http://www.mase.io/code/clojure/node/2015/01/24/getting-started-with-clojurecript-and-node/
* and http://www.mase.io/code/clojure/node/2015/01/25/clojurescript-and-node-part-2-express/

Minimal use:

    lein cljsbuild once
    node out/nodetry2.js

FIXME: Write a one-line description of your library/project.

## Overview

FIXME: Write a paragraph about the library/project and highlight its goals.

## Setup

To get all the necessary node.js modules:

    lein npm install
    
For more info using the browser as a REPL environment, see
[this](https://github.com/clojure/clojurescript/wiki/The-REPL-and-Evaluation-Environments#browser-as-evaluation-environment).
    
Clean project specific out:

    lein clean
     
## License

Copyright © 2015 FIXME
