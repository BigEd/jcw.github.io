(defproject nodetry2 "0.1.0-SNAPSHOT"
  :description "FIXME: write this!"
  :url "http://example.com/FIXME"

  :dependencies [[org.clojure/clojure "1.7.0"]
                 [org.clojure/clojurescript "1.7.48"]]

  :npm {:dependencies [[source-map-support "0.2.8"]
                       [express "4.11.1"]]}

  :plugins [[lein-cljsbuild "1.0.6"]
            [lein-npm "0.6.1"]]

  :source-paths ["src" "target/classes"]

  :clean-targets ["out/nodetry2" "out/nodetry2.js"]

  :cljsbuild {
    :builds [{:id "server"
              :source-paths ["src"]
              :compiler {
                :main nodetry2.core
                :output-to "out/nodetry2.js"
                :output-dir "out"
                :optimizations :simple
                :target :nodejs
                :cache-analysis true
                :source-map "out/nodetry2.js.map"}}]})
