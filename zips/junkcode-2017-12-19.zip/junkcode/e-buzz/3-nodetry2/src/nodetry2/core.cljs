(ns nodetry2.core
  (:require [cljs.nodejs :as node]))

(node/enable-util-print!)
(println "[nodetry2]")
#_(.log js/console "hello")

(def express (node/require "express"))

(defn say-hello! [req res]
  (let [headers (js->clj (.-headers req) :keywordize-keys true)]
    (println "url:" (.-url req) "headers:" headers)
    (.send res "Hello world!")))

(defn -main []
  (let [app (express)]
    (.get app "/" say-hello!)
    (.listen app 3000 #(println "Server started on port 3000"))))

(set! *main-cli-fn* -main)
