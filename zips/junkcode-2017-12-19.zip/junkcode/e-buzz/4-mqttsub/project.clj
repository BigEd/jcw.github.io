(defproject mqttsub "0.1.0-SNAPSHOT"
  :description "FIXME: write this!"
  :url "http://example.com/FIXME"

  :dependencies [[org.clojure/clojure "1.7.0"]
                 [org.clojure/clojurescript "1.7.48"]]

  :npm {:dependencies [[source-map-support "0.2.8"]
                       [express "4.11.1"]]}

  :plugins [[lein-cljsbuild "1.0.6"]
            [lein-npm "0.6.1"]]

  :hooks [leiningen.cljsbuild]

  :source-paths ["src" "target/classes"]

  :test-paths ["test"]

  :clean-targets ["out/mqttsub" "out/mqttsub.js"]

  :cljsbuild {:builds [{:id "server"
                        :source-paths ["src"]
                        :compiler {:main mqttsub.core
                                   :output-to "out/mqttsub.js"
                                   :output-dir "out"
                                   :optimizations :simple
                                   :target :nodejs
                                   :cache-analysis true
                                   :source-map "out/mqttsub.js.map"}}]})
