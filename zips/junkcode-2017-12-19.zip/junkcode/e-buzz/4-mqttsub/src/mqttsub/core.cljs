(ns mqttsub.core
  (:require [cljs.nodejs :as node]))

(node/enable-util-print!)
(println "[mqttsub]")

(def express (node/require "express"))
(def mqtt (node/require "mqtt"))

(defn say-hello! [req res]
  (let [headers (js->clj (.-headers req) :keywordize-keys true)]
    (println "url:" (.-url req) "headers:" headers)
    (.send res "Hello world!")))

(defn start-server []
  (let [app (express)]
    (.get app "/" say-hello!)
    (.listen app 3000 #(println "Server started on port 3000"))))

(defn connect-to-mqtt []
  ; see https://github.com/mqttjs/MQTT.js/issues/252#issuecomment-74429723
  (let [client (.connect mqtt "mqtt://quadi.fritz.box"
                         #js {:protocolId "MQIsdp" :protocolVersion 3})]
    (.on client "connect" (fn []
                            (println "connected")
                            (.subscribe client "#")))
    (.on client "error" #(println "error:" %))
    (.on client "offline" #(println "offline"))
    (.on client "message" (fn [topic message]
                            (println topic message)))))

(defn -main []
  (connect-to-mqtt)
  (start-server))

(set! *main-cli-fn* -main)
