(ns framed.core)
