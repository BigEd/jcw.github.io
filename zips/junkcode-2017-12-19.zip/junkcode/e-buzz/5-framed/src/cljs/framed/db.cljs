(ns framed.db)

(def default-db
  {:name "re-frame"})
