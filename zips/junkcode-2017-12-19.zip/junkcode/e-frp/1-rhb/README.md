Based on https://github.com/gaearon/react-hot-boilerplate by Dan Abramov.
