Based on https://github.com/andreloureiro/cyclejs-starter by Andre Loureiro.
