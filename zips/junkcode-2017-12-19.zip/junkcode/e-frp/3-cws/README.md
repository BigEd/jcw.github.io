Based on https://github.com/killercup/cycle-webpack-starter by Pascal Hertleif.
