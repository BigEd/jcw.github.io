module.exports = [
  "@cycle/core",
  "@cycle/dom",
];
