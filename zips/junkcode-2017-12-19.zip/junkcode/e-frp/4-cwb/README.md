Based on https://github.com/michalvalasek/cycle-webpck-babel by Michal Valasek.
