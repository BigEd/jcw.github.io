Based on https://github.com/jackfranklin/jspm-es6-react-example by Jack Franklin.
