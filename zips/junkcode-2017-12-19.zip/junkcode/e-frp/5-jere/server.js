var express = require('express')
express()
  .use(function(req, res, next) {
    console.log('%s %s', req.method, req.url)
    next()
  })
  .use(express.static(__dirname))
  .listen(3000)
