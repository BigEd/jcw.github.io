import React from 'react'

class Reflow extends React.Component {

  constructor(){
    super();
    this.state = { temperature: "...", rate: 0 }
    this.primus = new Primus()
    this.primus.write(this.state.rate)
    this.primus.on('data', value => this.setState({ temperature: value }))
  }

  setRate(newRate) {
    console.log('rate', newRate)
    this.setState({ rate: newRate })
    this.primus.write(newRate)
  }

  render() {
    const buttons = [0,1,2,3,4,5].map(n => (
      <span key={n}>
        <button onClick={() => this.setRate(n)}>
          <h3>{n}</h3>
        </button>
        <span> </span>
      </span>
    ))

    return (
      <div>
        <h3>Reflow Control</h3>
        <h1>{this.state.temperature} °C</h1>
        <p>Current rate = {this.state.rate}</p>
        <p>New rate: {buttons}</p>
      </div>
    )
  }
}

React.render(<Reflow />, document.getElementById('app'))
