// adapted from the Primus "echo" example

var fs = require('fs')
var http = require('http')
var Primus = require('primus')
var serialport = require("serialport")

var tty = process.env.TTY || "- TTY env var not set?"

var serPort = new serialport.SerialPort(tty, {
    baudrate: 57600,
    parser: serialport.parsers.readline("\r\n")
})

serPort.on('error', function(err) {
  console.log(err)
  process.exit()
})

var server = http.createServer(function(req, res) {
  res.setHeader('Content-Type', 'text/html')
  var path = req.url
  if (path == '/')
      path += 'index.html'
  fs.createReadStream(__dirname + path).on('error', function() {}).pipe(res)
})

var netConn = new Primus(server)

netConn.on('connection', function(spark) {
  serPort.on("data", function(data) {
    console.log(spark.id, 'temp:', data)
    spark.write(data)
  })
  spark.on('data', function(data) {
    console.log(spark.id, 'rate:', data)
    serPort.write(data + '\n')
  })
})

server.listen(3000, function() {
  console.log('server started, http://localhost:3000')
})
