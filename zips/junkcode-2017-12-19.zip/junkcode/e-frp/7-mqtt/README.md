Based on https://github.com/jackfranklin/jspm-es6-react-example by Jack Franklin.

1. run `npm install jspm jspm-server -g` if needed

2. install dependencies:

        jspm install
        npm install

3. launch the server:

        npm start

4. open the app page in the browser: <http://localhost:3000>

5. to generate a bundled distribution:

        make dist
