// see http://www.eclipse.org/paho/clients/js/
// and https://gist.github.com/jcw/257b332abd80a7d049cf

import '../vendor/mqttws31'
import React from 'react'

class TryMqtt extends React.Component {

  constructor(){
    super();
    this.state = { lastMessage: null }

    let client = new Paho.MQTT.Client('localhost', 11883, "clienId");

    client.connect({ onSuccess: _ => {
      console.log("onConnect");
      //client.subscribe("$SYS/#");
      client.subscribe("/World");
      let msg = new Paho.MQTT.Message("Hello");
      msg.destinationName = "/World";
      client.send(msg); 
    } });

    client.onConnectionLost = resp => {
      console.log("onConnectionLost", resp.errorMessage);
    }

    client.onMessageArrived = msg => {
      let topic = msg.destinationName
      let payload = msg.payloadString
      console.log("onMessageArrived", topic, payload);
      this.setState({ lastMessage: `${topic} = ${payload}` })
    }
  }

  render() {
    return (
      <div>
        <h3>Try MQTT</h3>
        <p>Last message: {this.state.lastMessage}</p>
      </div>
    )
  }
}

React.render(<TryMqtt />, document.getElementById('app'))
