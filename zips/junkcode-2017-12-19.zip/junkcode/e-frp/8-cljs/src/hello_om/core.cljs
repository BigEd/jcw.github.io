(ns ^:figwheel-always hello-om.core
    (:require[om.core :as om :include-macros true]
              [om.dom :as dom :include-macros true]))

(enable-console-print!)

(println "Edits should show up in your developer console.")

;; define your app data so that it doesn't get over-written on reload

(defonce app-state (atom {:text "Hello world!"}))

(om/root
  (fn [data owner]
    (reify om/IRender
      (render [_]
        (dom/div nil
                 (dom/h1 nil (:text data))
                 (dom/svg #js {:width 100 :height 100}
                          (dom/rect #js {:x 10 :y 20 :width 30 :height 40})
                          (dom/rect #js {:x 0 :y 0 :width 99 :height 99
                                         :fill "none" :stroke "red"}))
                 (dom/p nil "hahaha")))))
  app-state
  {:target (. js/document (getElementById "app"))})


(defn on-js-reload []
  ;; optionally touch your app-state to force rerendering depending on
  ;; your application
  ;; (swap! app-state update-in [:__figwheel_counter] inc)
)

