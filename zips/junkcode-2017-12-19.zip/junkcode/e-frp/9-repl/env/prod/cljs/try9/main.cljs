(ns try9.main
  (:require [try9.core :as core]))

(core/main)
