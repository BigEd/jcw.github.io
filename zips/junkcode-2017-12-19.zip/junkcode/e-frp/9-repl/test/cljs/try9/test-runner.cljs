(ns try9.test-runner
  (:require
   [cljs.test :refer-macros [run-tests]]
   [try9.core-test]))

(enable-console-print!)

(defn runner []
  (if (cljs.test/successful?
       (run-tests
        'try9.core-test))
    0
    1))
