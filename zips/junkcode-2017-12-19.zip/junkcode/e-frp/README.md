Some experiments with Functional Reactive Programming.
