package main

import (
	"fmt"
	"os"
	"syscall"
)

const (
	dev      = "/dev/i2c-1"
	addr     = 0x68
	I2CSLAVE = 0x0703
)

func main() {
	file, err := os.OpenFile(dev, os.O_RDWR, os.ModeExclusive)
	if err != nil {
		panic(err)
	}
	syscall.Syscall(syscall.SYS_IOCTL, file.Fd(), I2CSLAVE, addr)
	file.Write([]byte{0})
	buf := make([]byte, 7)
	file.Read(buf)
	fmt.Printf("%02X\n", buf)
}
