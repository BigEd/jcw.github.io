Various explorations:

* **vm1/** - Simple `cmake` project
* **vm2/** - Minimal C code with `Makefile`
* **vm3/** - Engine + gadgets without `CppUTest`
* **vm4/** - Garbage-collected chunked memory
* **vm5/** - Try out port of technoblogy/ulisp-zero
* **vm6/** - Explore new gadget data structures
* **vm7/** - Load a gadget + wiring binary dump
* **vm8/** - Read-only structured data
* **vm9/** - Load back saved structured data
* **vmA/** - Start putting the pieces together
* **vmB/** - Try out some timer ideas
