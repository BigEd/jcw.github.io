Run this command before using `make`:

    cmake .
