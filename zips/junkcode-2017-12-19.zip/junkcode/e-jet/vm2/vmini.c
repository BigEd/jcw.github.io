#include <stdint.h>
#include <stdio.h>

typedef int Message;

typedef Message M;
typedef struct Gadget G;
typedef struct Circuit C;
typedef struct Recipe R;
typedef struct State S;

struct Gadget {
};

struct Circuit {
};

struct Recipe {
};

struct State {
};

int main () {
	puts("hello");
	return 0;
}
