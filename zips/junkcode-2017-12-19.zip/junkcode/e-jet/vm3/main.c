#include "engine.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

static void parseLine (char* buf) {
    for (int i = 0; ; ++i) {
        char* p = strtok(buf, " \t\n");
        buf = 0;
        if (p == 0)
            break;
        printf(" %d:%s", i, p);
    }
    printf("\n");
}

static void parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        return;
    }
    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0)
        parseLine(buf);
    fclose(fp);
}

int main (int argc, const char* argv[]) {
    Gadget* gp1 = LookupGadget("print", 0);
    Feed(gp1, 0, 10);
    for (int i = 1; i < argc; ++i)
        parseFile(argv[i]);
    return 0;
}
