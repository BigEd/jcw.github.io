// Simple chunked memory manager with mark/sweep garbage collection.
// Main code parses text files given as cmdline args as quick test.
// -jcw, 2017-12-01

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mem.h"

static Value parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }
    Value r = newChunk(T_OBJ, 0);
    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        Value v = parseLine(buf);
        pushValue(r.i, v);
        printf("%4d: ", v.i);
        showObject(v.i);
        printf("\n");
    }
    fclose(fp);
    return r;
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof chunks[0] == CHUNK_SIZE);
    assert(sizeof tags[0] == 2);
    assert(sizeof (Value) == 2);
    assert(T_OBJ == 0);

    sweepChunks(); // this inits the free chain, assuming tags are all-zero
    printf("chunks %db, free %d x %db = %db\n",
            (int) sizeof chunks, countFreeChunks(), CHUNK_SIZE, chunkSize(0));

    for (int i = 1; i < argc; ++i) {
        Value v = parseFile(argv[i]);
        int n = countFreeChunks();
        markChunk(v.i);
        sweepChunks();
        printf("free %d => %d\n", n, countFreeChunks());
    }
    return 0;
}
