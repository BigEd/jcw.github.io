// Build up a circuit from a textual description.
// -jcw, 2017-12-06

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHUNK_BITS   12
#define CHUNK_SIZE   (1 << CHUNK_BITS)
#define GADGET_BITS  10
#define GADGET_SIZE  (1 << GADGET_BITS)
#define HANDLER_BITS 8
#define HANDLER_SIZE (1 << HANDLER_BITS)
#define STATE_BITS   14
#define STATE_SIZE   (1 << STATE_BITS)
#define OUTLET_BITS  12
#define OUTLET_SIZE  (1 << OUTLET_BITS)
#define NETLIST_BITS 14
#define NETLIST_SIZE (1 << NETLIST_BITS)
#define INLET_BITS   5
#define INLET_SIZE   (1 << INLET_BITS)

//------------------------------------------------------------------------------

struct {
    uint16_t handler :HANDLER_BITS;
    uint16_t state   :STATE_BITS;
    uint16_t outlet  :OUTLET_BITS;
    uint16_t chunk   :CHUNK_BITS;
} gadgets [GADGET_SIZE];

typedef struct {
    uint16_t last   :1;
    uint16_t gadget :GADGET_BITS;
    uint16_t inlet  :INLET_BITS;
} Inlet;

typedef struct {
    uint16_t flag :1;
    uint16_t ref :NETLIST_BITS;
} NetRef;

union {
    NetRef net;
    Inlet  dir;
} outlets [OUTLET_SIZE];

int32_t states [STATE_SIZE];
Inlet netlists [NETLIST_SIZE];

uint16_t lastGadget, lastState, lastOutlet, lastNetlist;

//------------------------------------------------------------------------------

static int lookupHandler (const char* name) {
    return 1;
}

//------------------------------------------------------------------------------

static void parseGadget (int pos, const char* token) {
    switch (pos) {
        case 0:
            ++lastGadget;
            gadgets[lastGadget].handler = lookupHandler(token);
            gadgets[lastGadget].state = lastState + 1;
            gadgets[lastGadget].outlet = lastOutlet + 1;
            break;
        case 1:
            lastState += atoi(token);
            break;
    }
}

static void parseOutlet (int pos, const char* token) {
    if (pos == 0) {
        ++lastOutlet;
        outlets[lastOutlet].net.ref = lastNetlist + 1;
    }
    if (pos >= 0) {
        int gnum, inum = 1;
        if (sscanf(token, "%d:%d", &gnum, &inum) < 1)
            printf("can't parse netlist entry: %s\n", token);
        // TODO treat "-x.y" as shared netlist with previous gadget x, outlet y
        ++lastNetlist;
        netlists[lastNetlist].gadget = gnum;
        netlists[lastNetlist].inlet = inum;
    } else // called after all items have been parsed
        switch (lastNetlist + 1 - outlets[lastOutlet].net.ref) {
            case 0:
                outlets[lastOutlet].net.ref = 0; // empty netlist
                break;
            case 1:
                // optimisation: single netlist is folded into outlet itself
                outlets[lastOutlet].dir = netlists[lastNetlist--];
                outlets[lastOutlet].dir.last = 1;
                break;
            default:
                netlists[lastNetlist].last = 1;
                break;
        }
}

// note: buf is clobbered, strtok is not reentrant
static void parseLine (char* buf) {
    char parseType = *buf;
    for (int i = 0; ; ++i) {
        char* p = strtok(buf, " \t\r\n");
        if (p == 0)
            break;
        buf = 0;
        switch (parseType) {
            case '#': case '\n': break;
            case ' ': parseOutlet(i, p); break;
            default:  parseGadget(i, p); break;
        }
    }
    if (parseType == ' ')
        parseOutlet(-1, 0);
}

static void parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }
    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        if (*buf != ' ' && *buf != '#' && *buf != '\n')
            printf("%03d: %s", lastGadget + 1, buf);
        else
            printf("     %s", buf);
        parseLine(buf);
    }
    fclose(fp);
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof gadgets[0] == 8);
    assert(sizeof states[0] == 4);
    assert(sizeof outlets[0] == 2);
    assert(sizeof netlists[0] == 2);

    for (int i = 1; i < argc; ++i)
        parseFile(argv[i]);

    ++lastGadget;
    gadgets[lastGadget].state = lastState + 1;
    gadgets[lastGadget].outlet = lastOutlet + 1;
    ++lastOutlet;
    outlets[lastOutlet].net.ref = lastNetlist + 1;

    printf("last g %d, s %d, o %d, n %d\n",
            lastGadget, lastState, lastOutlet, lastNetlist);

    printf("Gadgets:\n");
    for (int i = 1; i <= lastGadget; ++i)
        printf("%3d: handler %d, state %d, outlet %d\n",
                i, gadgets[i].handler, gadgets[i].state, gadgets[i].outlet);

    printf("Outlets:\n");
    for (int i = 1; i <= lastOutlet; ++i) {
        assert(outlets[i].net.flag == outlets[i].dir.last);
        if (outlets[i].dir.last)
            printf("%3d: dir gadget %d, inlet %d\n",
                    i, outlets[i].dir.gadget, outlets[i].dir.inlet); 
        else
            printf("%3d: net ref %d\n", i, outlets[i].net.ref);
    }

    printf("Netlists:\n");
    for (int i = 1; i <= lastNetlist; ++i)
        printf("%3d: last %d, gadget %d, inlet %d\n",
                i, netlists[i].last, netlists[i].gadget, netlists[i].inlet); 

    FILE* fp = fopen("vmdump.bin", "wb");
    if (fp == 0) {
        perror("vmdump.bin");
        exit(1);
    }

    fputs("<jet> ", fp);
    fwrite(&lastGadget, sizeof lastGadget, 1, fp);
    fwrite(gadgets + 1, sizeof gadgets[0], lastGadget, fp);
    fwrite(&lastOutlet, sizeof lastOutlet, 1, fp);
    fwrite(outlets + 1, sizeof outlets[0], lastOutlet, fp);
    fwrite(&lastNetlist, sizeof lastNetlist, 1, fp);
    fwrite(netlists + 1, sizeof netlists[0], lastNetlist, fp);

    fclose(fp);
    return 0;
}
