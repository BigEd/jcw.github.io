// Load gadget and wiring info from binary dump file.
// -jcw, 2017-12-08

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHUNK_BITS   12
#define GADGET_BITS  10
#define HANDLER_BITS 8
#define STATE_BITS   14
#define OUTLET_BITS  12
#define NETLIST_BITS 14
#define INLET_BITS   5

//------------------------------------------------------------------------------

struct {
    uint16_t handler :HANDLER_BITS;
    uint16_t state   :STATE_BITS;
    uint16_t outlet  :OUTLET_BITS;
    uint16_t chunk   :CHUNK_BITS;
} const *gadgets;

typedef struct {
    uint16_t last   :1;
    uint16_t gadget :GADGET_BITS;
    uint16_t inlet  :INLET_BITS;
} Inlet;

typedef struct {
    uint16_t flag :1;
    uint16_t ref :NETLIST_BITS;
} NetRef;

union {
    NetRef net;
    Inlet  dir;
} const *outlets;

int32_t *states;
Inlet const *netlists;

uint16_t lastGadget, lastState, lastOutlet, lastNetlist;

//------------------------------------------------------------------------------

static void loadFile (const char* filename) {
    FILE *fp = fopen(filename, "rb");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }

    fseek(fp, 0, SEEK_END);
    int size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    void* buf = malloc(size);
    fread(buf, 1, size, fp);

    fclose(fp);

    gadgets = buf;
    lastGadget = ((const uint16_t*) buf)[3];
    outlets = (const void*) (gadgets+lastGadget+1);
    lastOutlet = *(const uint16_t*)(const void*) outlets;
    netlists = (const void*) (outlets+lastOutlet+1);
    lastNetlist = *(const uint16_t*)(const void*) netlists;
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof *gadgets == 8);
    assert(sizeof *states == 4);
    assert(sizeof *outlets == 2);
    assert(sizeof *netlists == 2);

    for (int i = 1; i < argc; ++i)
        loadFile(argv[i]);

    printf("last g %d, s %d, o %d, n %d\n",
            lastGadget, lastState, lastOutlet, lastNetlist);

    printf("Gadgets:\n");
    for (int i = 1; i <= lastGadget; ++i)
        printf("%3d: handler %d, state %d, outlet %d\n",
                i, gadgets[i].handler, gadgets[i].state, gadgets[i].outlet);

    printf("Outlets:\n");
    for (int i = 1; i <= lastOutlet; ++i) {
        assert(outlets[i].net.flag == outlets[i].dir.last);
        if (outlets[i].dir.last)
            printf("%3d: dir gadget %d, inlet %d\n",
                    i, outlets[i].dir.gadget, outlets[i].dir.inlet); 
        else
            printf("%3d: net ref %d\n", i, outlets[i].net.ref);
    }

    printf("Netlists:\n");
    for (int i = 1; i <= lastNetlist; ++i)
        printf("%3d: last %d, gadget %d, inlet %d\n",
                i, netlists[i].last, netlists[i].gadget, netlists[i].inlet); 

    return 0;
}
