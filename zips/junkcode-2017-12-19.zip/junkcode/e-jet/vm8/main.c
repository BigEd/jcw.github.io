// Read-only structured data, compatible with GC'd chunked memory.
// Use negative indices, no chunking needed as it's allocated all at once.
// -jcw, 2017-12-09

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mem.h"

static void dumpObject (int cnum);

//------------------------------------------------------------------------------

char    romStrs [1<<16]; // max 64 KB
Value   romObjs [1<<15]; // max 64 KB
int32_t romInts [1<<14]; // max 64 KB
double  romFlts [1<<14]; // max 128 KB

uint16_t romNextStr = 0, romNextObj = 0, romNextInt = 0, romNextFlt = 0;

struct {
    uint16_t type :3;
    uint16_t size :13;
    uint16_t indx;
} romTags [STORE_SIZE], *roTagsPtr = romTags + STORE_SIZE;

uint16_t romAlloc = STORE_SIZE;

static Value romValue (Value v) {
    if (v.f && v.i > 0) {
        assert(romAlloc > 0); // unlikely, but we ran out of descriptors
        int a = --romAlloc;
        romTags[a].type = TYPE(v.i);
        romTags[a].size = chunkSize(v.i);
        switch (TYPE(v.i)) {
            case T_OBJ:
                romTags[a].indx = romNextObj;
                int n = romTags[a].size >> 1;
                romNextObj += n;
                //printf("fz f %d i %d a %d t %d n %d\n",
                //        v.f, v.i, a, TYPE(v.i), n);
                for (int i = 0; i < n; ++i) {
                    Value* p = chunkOffset(v.i, i << 1);
                    assert(p != 0);
                    romObjs[i + romTags[a].indx] = romValue(*p);
                }
                break;
            case T_STR:
                romTags[a].indx = romNextStr;
                int cnum = v.i;
                do {
                    int n = NEXT(cnum);
                    if (n > CHUNK_SIZE)
                        n = CHUNK_SIZE;
                    strncpy(romStrs + romNextStr, chunks[cnum].m, n);
                    romNextStr += n;
                    cnum = NEXT(cnum);
                } while (cnum > CHUNK_SIZE);
                break;
            case T_INT:
                romTags[a].indx = romNextInt;
                romInts[romNextInt++] = chunks[v.i].l;
                break;
            case T_FLT:
                romTags[a].indx = romNextFlt;
                romFlts[romNextFlt++] = chunks[v.i].d;
                break;
        }
        //printf("f %d i %d => a %d\n", v.f, v.i, a - STORE_SIZE);
        v.i = a - STORE_SIZE;
    }
    return v;
}

//------------------------------------------------------------------------------

static void dumpString (int cnum) {
    assert(cnum < 0);
    printf("'%s'", romStrs + roTagsPtr[cnum].indx);
}

static void dumpValue (Value v) {
    if (v.f == 0)
        printf("%d", v.i);
    else {
        assert(v.i < 0);
        int off = roTagsPtr[v.i].indx;
        switch (roTagsPtr[v.i].type) {
            case T_OBJ: dumpObject(v.i);             break;
            case T_STR: dumpString(v.i);             break;
            case T_INT: printf("%d", romInts[off]);  break;
            case T_FLT: printf("%g",  romFlts[off]); break;
            default:    printf("?");                 break;
        }
    }
}

static void dumpObject (int cnum) {
    assert(cnum < 0);
    printf("[");
    int off = roTagsPtr[cnum].indx;
    int n = roTagsPtr[cnum].size >> 1;
    //printf("cnum %d off %d n %d\n", cnum, off, n);
    for (int i = 0; i < n; ++i) {
        if (i > 0)
            printf(" ");
        dumpValue(romObjs[i+off]);
    }
    printf("]");
}

//------------------------------------------------------------------------------

static Value parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }
    Value r = newChunk(T_OBJ, 0);
    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        printf("=== %s", buf);
        Value v = romValue(parseLine(buf));
        pushValue(r.i, v);
        printf("%4d: ", v.i);
        dumpObject(v.i);
        printf("\n");
    }
    fclose(fp);
    return r;
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof romTags[0] == 4);
    assert(sizeof romStrs[0] == 1);
    assert(sizeof romObjs[0] == 2);
    assert(sizeof romInts[0] == 4);
    assert(sizeof romFlts[0] == 8);

    sweepChunks(); // this inits the free chain, assuming tags are all-zero
    printf("chunks %db, free %d x %db = %db\n",
            (int) sizeof chunks, countFreeChunks(), CHUNK_SIZE, chunkSize(0));

    for (int i = 1; i < argc; ++i) {
        Value v = parseFile(argv[i]);
        int n = countFreeChunks();
        markChunk(v.i);
        sweepChunks();

        printf("free %d => %d\n", n, countFreeChunks());
        printf("ro t %d o %d s %d i %d f %d\n",
                STORE_SIZE - romAlloc,
                romNextObj, romNextStr, romNextInt, romNextFlt);

        printf("%d romTags\n", STORE_SIZE - romAlloc);
        for (int i = romAlloc; i < STORE_SIZE; ++i)
            printf("%4d: type %d size %d indx %d\n",
                    i - STORE_SIZE,
                    romTags[i].type, romTags[i].size, romTags[i].indx);

        printf("%d romStrs (bytes)\n", romNextStr);
        for (int i = 0; i < romNextStr; ++i)
            printf(" %02x", romStrs[i]);

        printf("\n%d romObjs\n", romNextObj);
        for (int i = 0; i < romNextObj; ++i)
            printf("%4d: i %d f %d\n", i, romObjs[i].i, romObjs[i].f);

        printf("%d romInts\n", romNextInt);
        for (int i = 0; i < romNextInt; ++i)
            printf("%4d: %d\n", i, romInts[i]);

        printf("%d romFlts\n", romNextFlt);
        for (int i = 0; i < romNextFlt; ++i)
            printf("%4d: %g\n", i, romFlts[i]);

        romNextStr += romNextStr & 1; // round up to multiple of 2 bytes
        romNextObj += romNextObj & 1; // round up to multiple of 4 bytes
        romNextInt += romNextInt & 1; // round up to multiple of 8 bytes
        uint16_t objBase = romNextStr / 2;
        uint16_t intBase = (objBase + romNextObj) / 2;
        uint16_t fltBase = (intBase + romNextInt) / 2;
        printf("base o %d i %d f %d\n", objBase, intBase, fltBase);

        for (int i = romAlloc; i < STORE_SIZE; ++i)
            switch (romTags[i].type) {
                case T_OBJ: romTags[i].indx += objBase; break;
                case T_INT: romTags[i].indx += intBase; break;
                case T_FLT: romTags[i].indx += fltBase; break;
            }

        uint16_t nTags = STORE_SIZE - romAlloc, nFull = fltBase + romNextFlt;

        FILE* fp = fopen("vmrom.bin", "wb");
        if (fp == 0) {
            perror("vmrom.bin");
            exit(1);
        }

        fwrite(&nTags, sizeof nTags, 1, fp);
        fwrite(&nFull, sizeof nFull, 1, fp);
        fwrite(romTags + romAlloc, sizeof romTags[0], nTags, fp);
        fwrite(romStrs, sizeof romStrs[0], romNextStr, fp);
        fwrite(romObjs, sizeof romObjs[0], romNextObj, fp);
        fwrite(romInts, sizeof romInts[0], romNextInt, fp);
        fwrite(romFlts, sizeof romFlts[0], romNextFlt, fp);

        fclose(fp);

        romNextObj = romNextStr = romNextInt = romNextFlt = 0;
        romAlloc = STORE_SIZE;
    }
    return 0;
}
