// Load structured data from binary dump file.
// -jcw, 2017-12-10

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mem.h"

static void dumpObject (int cnum);

//------------------------------------------------------------------------------

typedef struct {
    uint16_t type :3;
    uint16_t size :13;
    uint16_t indx;
} RomTag;

union {
    const RomTag*   tags;
    const char*     strs;
    const Value*    objs;
    const uint32_t* ints;
    const double*   flts;
} rom;

//------------------------------------------------------------------------------

static void loadFile (const char* filename) {
    FILE *fp = fopen(filename, "rb");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }

    fseek(fp, 0, SEEK_END);
    int size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    void* buf = malloc(size);
    fread(buf, 1, size, fp);

    fclose(fp);

    uint16_t offset = *(uint16_t*) buf;
    rom.tags = (RomTag*) buf + offset + 1;

    //for (int i = -offset; i < 0; ++i)
    //    printf("%4d: type %d size %d indx %d\n",
    //            i, rom.tags[i].type, rom.tags[i].size, rom.tags[i].indx);
}

//------------------------------------------------------------------------------

static void dumpString (int cnum) {
    assert(cnum < 0);
    printf("'%s'", rom.strs + rom.tags[cnum].indx);
}

static void dumpValue (Value v) {
    if (v.f == 0)
        printf("%d", v.i);
    else {
        assert(v.i < 0);
        int off = rom.tags[v.i].indx;
        switch (rom.tags[v.i].type) {
            case T_OBJ: dumpObject(v.i);              break;
            case T_STR: dumpString(v.i);              break;
            case T_INT: printf("%d", rom.ints[off]);  break;
            case T_FLT: printf("%g",  rom.flts[off]); break;
            default:    printf("?");                  break;
        }
    }
}

static void dumpObject (int cnum) {
    assert(cnum < 0);
    printf("[");
    int off = rom.tags[cnum].indx;
    int n = rom.tags[cnum].size >> 1;
    for (int i = 0; i < n; ++i) {
        if (i > 0)
            printf(" ");
        dumpValue(rom.objs[i+off]);
    }
    printf("]");
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    for (int i = 1; i < argc; ++i)
        loadFile(argv[i]);

    dumpObject(-1);  printf("\n");
    dumpObject(-6);  printf("\n");
    dumpObject(-11); printf("\n");
    dumpObject(-17); printf("\n");

    return 0;
}
