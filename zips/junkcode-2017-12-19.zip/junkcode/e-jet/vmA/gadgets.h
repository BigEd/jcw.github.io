// Basic gadget definitions.

//------------------------------------------------------------------------------

int initSetup (Config* cfg, Value ini) {
    cfg->outlets = 1;
    return 0;
}

int initHandler (Gadget* gdg, int inlet, Value msg) {
    printf("init < %d:%d\n", (int) (gdg - gadgets), inlet);
    emitValue(gdg, 0, msg);
    return 0;
}

int metroSetup (Config* cfg, Value ini) {
    cfg->inlets = 2;
    cfg->outlets = 1;
    cfg->stateLen = 1;
    return 0;
}

int metroHandler (Gadget* gdg, int inlet, Value msg) {
    printf("metro < %d:%d\n", (int) (gdg - gadgets), inlet);
    emitValue(gdg, 0, msg);
    return 0;
}

int passSetup (Config* cfg, Value ini) {
    cfg->inlets = 1;
    cfg->outlets = 1;
    return 0;
}

int passHandler (Gadget* gdg, int inlet, Value msg) {
    printf("pass < %d:%d\n", (int) (gdg - gadgets), inlet);
    emitValue(gdg, 0, msg);
    return 0;
}

int printSetup (Config* cfg, Value ini) {
    cfg->inlets = 1;
    return 0;
}

int printHandler (Gadget* gdg, int inlet, Value msg) {
    printf("print < %d:%d\n", (int) (gdg - gadgets), inlet);
    printf("print: ");
    showValue(msg);
    printf("\n");
    return 0;
}

const char* gadgetTypes [] = {
    "init",
    "metro",
    "pass",
    "print",
    0
};

int (*const gadgetSetups [])(Config*,Value) = {
    initSetup,
    metroSetup,
    passSetup,
    printSetup,
};

int (*const gadgetHandlers [])(Gadget*,int,Value) = {
    initHandler,
    metroHandler,
    passHandler,
    printHandler,
};
