// Build up a circuit from a textual description.
// -jcw, 2017-12-12

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mem.h"

//------------------------------------------------------------------------------

#define HANDLER_BITS 8
#define HANDLER_SIZE (1 << HANDLER_BITS)
#define STATE_BITS   14
#define STATE_SIZE   (1 << STATE_BITS)
#define OUTLET_BITS  12
#define OUTLET_SIZE  (1 << OUTLET_BITS)
#define GADGET_BITS  10
#define GADGET_SIZE  (1 << GADGET_BITS)
#define NETLIST_BITS 14
#define NETLIST_SIZE (1 << NETLIST_BITS)
#define IOLET_BITS   5
#define IOLET_SIZE   (1 << IOLET_BITS)

typedef struct {
    uint16_t handler :HANDLER_BITS;
    uint16_t state   :STATE_BITS;
    uint16_t outlet  :OUTLET_BITS;
    uint16_t chunk   :STORE_BITS;
} Gadget;

typedef struct {
    uint16_t last   :1;
    uint16_t gadget :GADGET_BITS;
    uint16_t iolet  :IOLET_BITS;
} Iolet;

typedef struct {
    uint16_t flag :1;
    uint16_t ref  :NETLIST_BITS;
} NetRef;

typedef union {
    NetRef net;
    Iolet  dir;
} Outlet;

typedef struct {
    int8_t /* version, flags, */ inlets, outlets;
    void* state;
    uint16_t stateLen;
    //Value myData;
} Config;

Gadget gadgets [GADGET_SIZE];
Outlet outlets [OUTLET_SIZE];
int32_t states [STATE_SIZE];
Iolet netlists [NETLIST_SIZE];

uint16_t nextGadget, nextState, nextOutlet, nextNetlist = 1;

const char* gadgetTypes [];
int (*const gadgetSetups [])(Config*,Value);
int (*const gadgetHandlers [])(Gadget*,int,Value);

//------------------------------------------------------------------------------

static int objSize (int cnum) {
    assert(TYPE(cnum) == T_OBJ);
    return chunkSize(cnum) >> 1;
}

static Value objAt (int cnum, int index) {
    assert(index < objSize(cnum));
    Value* p = chunkOffset(cnum, index << 1);
    assert(p != 0);
    return *p;
}

static const char* asStr (Value v) {
    assert(TYPE(v.i) == T_STR);
    return chunks[v.i].m;
}

static void sendTo (Gadget* gp, int inlet, Value msg) {
    printf(">>> %s %d:%d\n",
        gadgetTypes[gp->handler], (int) (gp - gadgets), inlet);
    gadgetHandlers[gp->handler](gp, inlet, msg);
}

static void emitValue (Gadget* gp, int outlet, Value msg) {
    Outlet* op = outlets + gp->outlet + outlet;
    if (op->dir.last)
        sendTo(gadgets + op->dir.gadget, op->dir.iolet, msg);
    else if (op->net.ref > 0) {
        Iolet* ip = netlists + op->net.ref;
        do
            sendTo(gadgets + ip->gadget, ip->iolet, msg);
        while (!(ip++)->last);
    }
}

static int lookupHandler (const char* name) {
    for (const char** p = gadgetTypes; *p != 0; ++p)
        if (strcmp(name, *p) == 0)
            return p - gadgetTypes;
    assert(0); // no such gadget
    return -1;
}

//------------------------------------------------------------------------------

#include "gadgets.h"

//------------------------------------------------------------------------------

static void defineGadget (Gadget* gp, Value v) {
    Value g = objAt(v.i, objSize(v.i) - 1);
    assert(g.f && objSize(g.i) > 0);
    const char* s = asStr(objAt(g.i, 0));
    assert(s != 0);

    int h = lookupHandler(s);
    gp->handler = h;
    gp->state = nextState;
    gp->outlet = nextOutlet;

    Config cfg;
    memset(&cfg, 0, sizeof cfg);
    cfg.state = states + nextState;

    gadgetSetups[h](&cfg, g);

    nextOutlet += cfg.outlets;
    nextState += (cfg.stateLen + 3) >> 2; // round to uint32_t sizes
}

typedef struct {
    Iolet from, to;
} Wire;

Wire wires [1000]; // FIXME arbitrary high bound, not checked
int nextWire;

static void addWire (int fo, int fp, int ti, int tp) {
    Wire* wp = wires + nextWire++;
    wp->from.gadget = fo;
    wp->from.iolet = fp;
    wp->to.gadget = ti;
    wp->to.iolet = tp;
}

static int wireCmp (const void* p, const void* q) {
    const Wire *a = p, *b = q;
    return a->from.gadget < b->from.gadget ||
           a->from.iolet < b->from.iolet ||
           a->to.gadget < b->to.gadget ||
           a->to.iolet < b->to.iolet ||
           a < b ? -1 : 1;
}

static void setupOutlet (int low, int high) {
    const Wire* wp = wires + low;
    //printf("OUT %d:%d low %d high %d\n",
    //        wp->from.gadget, wp->from.iolet, low, high);

    Gadget* gp = gadgets + wp->from.gadget;
    Outlet* op = outlets + gp->outlet + wp->from.iolet;
    switch (high - low) {
        case 0: break;
        case 1:
            op->dir = wp->to;
            op->dir.last = 1;
            break;
        default:
            op->net.ref = nextNetlist;
            for (int i = low; i < high; ++i)
                netlists[nextNetlist++] = wires[i].to;
            netlists[nextNetlist-1].last = 1;
            break;
    }
}

static void setupNetlists () {
    qsort(wires, nextWire, sizeof wires[0], wireCmp);

    int i = 0;
    while (i < nextWire) {
        int low = i;
        while (++i < nextWire)
            if (memcmp(&wires[low].from, &wires[i].from, sizeof (Iolet)) != 0)
                break;
        setupOutlet(low, i);
    }
}

static void parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }

    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        if (*buf == 'G') {
            printf("%3d: %s", nextGadget, buf);
            Value v = parseLine(buf + 1);
            // showObject(v.i); printf("\n");
            defineGadget(gadgets + nextGadget++, v);
        } else {
            printf("     %s", buf);
            if (*buf == 'W') {
                int fo, fp, ti, tp;
                int n = sscanf(buf + 1, "%d:%d %d:%d", &fo, &fp, &ti, &tp);
                assert(n == 4);
                addWire(fo, fp, ti, tp);
            }
        }
    }

    fclose(fp);
    setupNetlists();
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof gadgets[0] == 8);
    assert(sizeof states[0] == 4);
    assert(sizeof outlets[0] == 2);
    assert(sizeof wires[0] == 4);
    assert(sizeof netlists[0] == 2);

    sweepChunks(); // this inits the free chain, assuming tags are all-zero

    for (int i = 1; i < argc; ++i)
        parseFile(argv[i]);

    gadgets[nextGadget].state = nextState;
    gadgets[nextGadget++].outlet = nextOutlet;
    outlets[nextOutlet++].net.ref = nextNetlist;

    printf("\nlast g %d, s %d, o %d, n %d\n",
            nextGadget, nextState, nextOutlet, nextNetlist);

    printf("%d gadgets:\n", nextGadget);
    for (int i = 0; i < nextGadget; ++i)
        printf("%3d: handler %d, state %d, outlet %d\n",
                i, gadgets[i].handler, gadgets[i].state, gadgets[i].outlet);

    printf("%d wires:\n", nextWire);
    for (int i = 0; i < nextWire; ++i)
        printf("%3d: from %d:%d to %d:%d\n",
                i, wires[i].from.gadget, wires[i].from.iolet,
                wires[i].to.gadget, wires[i].to.iolet);

    printf("%d outlets:\n", nextOutlet);
    for (int i = 0; i < nextOutlet; ++i) {
        assert(outlets[i].net.flag == outlets[i].dir.last);
        if (outlets[i].dir.last)
            printf("%3d: dir gadget %d, inlet %d\n",
                    i, outlets[i].dir.gadget, outlets[i].dir.iolet); 
        else
            printf("%3d: net ref %d\n", i, outlets[i].net.ref);
    }

    printf("%d Netlists:\n", nextNetlist - 1);
    for (int i = 1; i < nextNetlist; ++i)
        printf("%3d: last %d, gadget %d, inlet %d\n",
                i, netlists[i].last, netlists[i].gadget, netlists[i].iolet); 

    printf("\nStarting up ...\n\n");
    static Value nil = { .f = 0, .i = 0 };
    for (int i = 0; i < nextGadget-1; ++i) {
        Gadget* gp = gadgets + i;
        if (gp->handler == 0) // it's an "init" gadget
            sendTo(gp, 0, nil);
    }

    return 0;
}
