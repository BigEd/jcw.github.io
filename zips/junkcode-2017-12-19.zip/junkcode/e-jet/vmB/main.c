// Implement a simple multi-timer mechanism.
// -jcw, 2017-12-15

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STATE_BITS   14
#define STATE_SIZE   (1 << STATE_BITS)
#define GADGET_BITS  10
#define GADGET_SIZE  (1 << GADGET_BITS)
#define IOLET_BITS   5
#define IOLET_SIZE   (1 << IOLET_BITS)

typedef struct {
    int16_t  i :15;
    uint16_t f :1;
} Value;

typedef struct {
    uint16_t ticks;
    Value    chain;
} Timer;

Timer timers [10];
Value firstTimer;

//------------------------------------------------------------------------------

#define TIMER_BASE(tp)   ((int) (tp - timers))   // FIXME temp hack

#define NEXT(chain) (&timers[(chain).i])

static void dumpTimers () {
    printf("\tTimers:");
    Value* curr = &firstTimer;
    for (;;) {
        Timer* next = NEXT(*curr);
        if (next == timers)
            break;
        printf(" #%d %d ms", TIMER_BASE(next), next->ticks);
        curr = &next->chain;
    }
    printf("\n");
}

static void unsetTimer (Timer* tp) {
    //printf("unset #%d %d ms\n", TIMER_BASE(tp), tp->ticks);

    Value* curr = &firstTimer;
    for (;;) {
        Timer* next = NEXT(*curr);
        if (next == tp)
            break;
        curr = &next->chain;
    }

    if (NEXT(tp->chain) != timers)
        NEXT(tp->chain)->ticks += tp->ticks;
    *curr = tp->chain;
    tp->chain.f = 0;

    assert(timers[0].ticks == 60001);
}

static void setTimer (Timer* tp, int ms) {
    //printf("set #%d %d ms\n", TIMER_BASE(tp), ms);
    if (tp->chain.f)
        unsetTimer(tp);

    Value* curr = &firstTimer;
    for (;;) {
        Timer* next = NEXT(*curr);
        if (next->ticks > ms) {
            if (next != timers)
                next->ticks -= ms;
            break;
        }
        ms -= next->ticks;
        curr = &next->chain;
    }

    tp->ticks = ms;
    tp->chain = *curr;
    curr->i = TIMER_BASE(tp);

    assert(timers[0].ticks == 60001);
}

static long now = 0;

static void fireTimer (Timer* tp) {
    printf("fired #%d @ %ld\n", TIMER_BASE(tp), now);
    tp->ticks = 0;
    unsetTimer(tp);
}

static void waitUntil (int ms) {
    while (NEXT(firstTimer)->ticks < ms) {
        now += NEXT(firstTimer)->ticks;
        ms -= NEXT(firstTimer)->ticks;
        fireTimer(NEXT(firstTimer));
    }
    now += ms;
}

static void parseFile (const char* filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == 0) {
        perror(filename);
        exit(1);;
    }

    char buf [100];
    while (fgets(buf, sizeof buf, fp) != 0) {
        printf(">>> %s", buf);
        int next, index, ms;
        int n = sscanf(buf, "%d %d %d", &next, &index, &ms);
        assert(n == 3);
        setTimer(&timers[index], ms);
        dumpTimers();
        waitUntil(next);
    }

    fclose(fp);
}

//------------------------------------------------------------------------------

int main (int argc, const char* argv[]) {
    assert(sizeof (Timer) == 4);

    timers[0].ticks = 60001; // always past any real timers
    firstTimer.f = 1;

    for (int i = 1; i < argc; ++i)
        parseFile(argv[i]);

    return 0;
}
