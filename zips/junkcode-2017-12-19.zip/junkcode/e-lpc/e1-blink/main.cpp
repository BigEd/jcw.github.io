// Blink the LED attached between PIO0_4 and VCC.

#include "LPC8xx.h"

// waste some time by doing nothing for a while
void delay (int count) {
    while (--count >= 0)
        __asm("nop\n");
}

int main () {
    // define PIO0_4 as an output pin
    LPC_GPIO_PORT->DIR0 |= 1 << 4;

    while (true) {
        // toggle the PIO0_4 pin
        LPC_GPIO_PORT->NOT0 = 1 << 4;
        // slow down so the blinking becomes visible
        delay(1000000);
    }
}
