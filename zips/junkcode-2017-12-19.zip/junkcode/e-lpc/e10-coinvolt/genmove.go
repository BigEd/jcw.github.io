// Package genmove generates servo motion commands from a textual description.
package main

import (
	"fmt"
	"regexp"
	"strconv"
)

const motions = `
50 lfi 25 t lfr 25 t 50 lfo 25 t lfr 25 t
50 rfi 25 t rfr 25 t 50 rfo 25 t rfr 25 t
50 ltu 25 t ltr 25 t 50 ltd 25 t ltr 25 t
50 rtu 25 t rtr 25 t 50 rtd 25 t rtr 25 t
50 t
`

const (
	RFOOT = iota
	RHIP
	LFOOT
	LHIP
)

func gen(part, step int) {
	fmt.Printf("LPC_SCT->MATCHREL[%d].U = %d;\n", part+1, (5*step+1500)*12)
}

func main() {
	arg := 0
	var err error
	for _, s := range regexp.MustCompile("[ \t\n]").Split(motions, -1) {
		switch s {
		case "lfr":
			gen(LHIP, 0)
		case "lfi":
			gen(LHIP, arg)
		case "lfo":
			gen(LHIP, -arg)

		case "rfr":
			gen(RHIP, 0)
		case "rfi":
			gen(RHIP, -arg)
		case "rfo":
			gen(RHIP, arg)

		case "ltr":
			gen(LFOOT, 0)
		case "ltd":
			gen(LFOOT, arg)
		case "ltu":
			gen(LFOOT, -arg)

		case "rtr":
			gen(RFOOT, 0)
		case "rtd":
			gen(RFOOT, -arg)
		case "rtu":
			gen(RFOOT, arg)

		case "t":
			fmt.Printf("delay(%d);\n", arg)

		case "":
			// ignore

		default:
			arg, err = strconv.Atoi(s)
			if err != nil {
				panic(err)
			}
		}
	}
}
