// Light up one of the LEDs in a bar, connected via charlieplexing.

#include "LPC8xx.h"

extern "C" void SysTick_Handler () {                                             
    // the only effect is to generate an interrupt, no work is done here         
}

void delay (int millis) {
    while (--millis >= 0)
        __WFI(); // wait for the next SysTick interrupt
}

// setup the analog(ue) comparator, using the ladder on + and pin PIO0_1 on -
void analogSetup () {
    LPC_SYSCON->PDRUNCFG &= ~(1<<15);               // power up comparator
    LPC_SYSCON->SYSAHBCLKCTRL |= (1<<18) | (1<<19); // ACMP & IOCON clocks
    LPC_SYSCON->PRESETCTRL &= ~(1<<12);             // reset comparator
    LPC_SYSCON->PRESETCTRL |= (1<<12);              // release comparator

    // CLKIN has to be disabled, this is the default on power up
    LPC_SWM->PINENABLE0 &= ~(1<<1); // enable ACMP_I2 on PIO0_1

    // connect bandgap to CMP-
    LPC_CMP->CTRL = (6<<11);
}

// measure the voltage on PIO0_1, returns a value from 0 to 32
// the steps will be roughly 0.1V apart, from 0 to 3.3V
int analogMeasure () {
    int i;
    for (i = 0; i < 32; ++i) {
        LPC_CMP->LAD = (i << 1) | 1;                // use ladder tap i
        for (int i = 0; i < 100; ++i) __ASM("");    // brief settling delay
        if (LPC_CMP->CTRL & (1<<21))                // if COMPSTAT bit is set
            break;                                  // ... we're done
    }
    return i;
}

const uint8_t bars [] = {
    0b000000,   // off
    0b010000,   // 1
    0b101111,   // 2
    0b101110,   // 3
    0b010001,   // 4
    0b001110,   // 5
    0b110001,   // 6
    0b001100,   // 7
    0b110011,   // 8
    0b001000,   // 9
    0b110111,   // 10
    0b000000,   // off
};

int main () {
    SysTick_Config(12000000/1000);      // 1000 Hz
    delay(1000);                        // keep reset active briefly

    analogSetup();

    LPC_SWM->PINENABLE0 = 0xFFFFFFFFUL; // everything is used as GPIO
    LPC_GPIO_PORT->DIR0 = 0b111111;     // PIO0_1..5 are all outputs

    while (true) {
#if 0
        for (int i = 0; i < sizeof bars; ++i) {
            //LPC_GPIO_PORT->PIN0 = i;
            LPC_GPIO_PORT->PIN0 = bars[i];
            delay(250);
        }
        delay(1000);
#else
        int vcc = (9 * 31) / analogMeasure();
        int bar = vcc/2 - 7;
        if (bar < 0 || bar >= sizeof bars)
            bar = 0;
        LPC_GPIO_PORT->PIN0 = bars[bar];
#endif
        delay(100);
    }
}
