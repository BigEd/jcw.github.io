// Blink the LED using the SCT in PWM mode.

#include "LPC8xx.h"

int main () {
    LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 8);  // enable the SCT
    LPC_SYSCON->PRESETCTRL |= ( 1<< 8);     // take it out of reset

    LPC_SWM->PINASSIGN6 = 0x04ffffFFUL;     // connect CTOUT_0 to PIO0_4

    LPC_SCT->CONFIG = 0x1;                  // UNIFY

    // toggle the output on half the system clock for a 1 Hz blink rate
    LPC_SCT->MATCH[0].U = LPC_SCT->MATCHREL[0].U = SystemCoreClock / 2;

    LPC_SCT->OUT[0].SET = 0x2;              // set on event 1
    LPC_SCT->OUT[0].CLR = 0x1;              // clear on event 0
    LPC_SCT->OUTPUT |= 0x1;                 // enable output 0

    LPC_SCT->EVENT[0].CTRL = 0x0000D000;
    LPC_SCT->EVENT[0].STATE = 0x1;
    LPC_SCT->EVENT[1].CTRL = 0x00005000;
    LPC_SCT->EVENT[1].STATE = 0x2;

    LPC_SCT->LIMIT_L = 0x3;                 // events 0 and 1 clear the counter

    LPC_SCT->CTRL_L &= ~(1 << 2);           // start the SCT

    while (true)
        ;
}
