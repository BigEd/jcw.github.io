// Blink the LED using the Self Wake-up Timer.

#include "LPC8xx.h"

extern "C" void WKT_IRQHandler () {
    LPC_WKT->CTRL = LPC_WKT->CTRL;  // clear the alarm interrupt
    LPC_WKT->COUNT = 5000;          // 10 KHz / 5000 -> 1 tick per 500 ms
    LPC_GPIO_PORT->NOT0 = 1 << 4;   // toggle the PIO0_4 pin
}

int main () {
    // define PIO0_4 as an output pin
    LPC_GPIO_PORT->DIR0 |= 1 << 4;

    LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 9);  // SYSCTL_CLOCK_WKT
    LPC_SYSCON->PRESETCTRL |= (1 << 9);     // RESET_WKT
    LPC_PMU->DPDCTRL |= (1 << 2);           // LPOSCEN
    LPC_WKT->CTRL = (1 << 0);               // WKT_CTRL_CLKSEL
    LPC_WKT->COUNT = 1;                     // start the counter

    NVIC_EnableIRQ(WKT_IRQn);

    while (true)
        ;
}
