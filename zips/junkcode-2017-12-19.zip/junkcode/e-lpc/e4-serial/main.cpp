// Send a text string to the serial port.

#include "LPC8xx.h"
#include "uart.h"

int main () {
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);

    for (const char* s = "Hello world!\r\n"; *s != 0; ++s)
        uart0SendChar(*s);
    
    while (true)
         ;
}
