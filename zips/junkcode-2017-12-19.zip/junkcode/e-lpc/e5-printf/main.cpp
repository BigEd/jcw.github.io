// Sending formatted text to the serial port using printf.

#include "LPC8xx.h"
#include "uart.h"
#include <stdio.h>

int main () {
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);

    printf("Device ID: 0x%08x\n", LPC_SYSCON->DEVICE_ID);
    printf("Clock speed: %d Hz\n", SystemCoreClock);
    
    while (true)
         ;
}
