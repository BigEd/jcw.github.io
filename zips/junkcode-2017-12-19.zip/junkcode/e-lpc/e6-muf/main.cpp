// Sending formatted text to the serial port using printf.

#include <stdio.h>
#include "muf.h"

#if !TEST
#include "LPC8xx.h"
#include "uart.h"
#endif

PrintGadget printG;
DoubleGadget doubleG;

int main () {
#if !TEST
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);
#endif

    printf(" Gadget %2d b\n", (int) sizeof (Gadget));
    printf("  Value %2d b\n", (int) sizeof (Value));
    printf("   Type %2d b\n", (int) sizeof (Value::Type));
    printf("  Inlet %2d b\n", (int) sizeof (Inlet));
    printf(" Outlet %2d b\n", (int) sizeof (Outlet));
    printf(" printG %2d b\n", (int) sizeof printG);
    printf("doubleG %2d b\n", (int) sizeof doubleG);
    printf("\n");

    doubleG.out >> printG.in;

    printG.in = 123;
    printG.in = "abc";
    printG.in = Value::nil;
    doubleG.in = 234;
}
