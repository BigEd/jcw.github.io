// Muf experiment.

#include <stdint.h>

class Inlet;
class Outlet;
class Value;

class Gadget {
protected:
    Gadget () {}

    void define (Inlet& in);
    void define (Outlet& out);

private:
    virtual void trigger (Inlet& inlet) = 0;
    void send(Outlet* outlet, const Value& v);

    typedef struct { const Outlet* from; Inlet* to; } Wire;

    static void addWire (const Outlet* from, Inlet* to) {
        wires[numWires].from = from;
        wires[numWires].to = to;
        ++numWires;
    }

    static Wire wires[];
    static int numWires;

    friend class Inlet;
    friend class Outlet;
};

Gadget::Wire Gadget::wires[25];
int Gadget::numWires;

class Value {
public:
    typedef enum { Nil, String, Int } Type;

    Value () : typ (Nil) {}
    Value (const char* v) : typ (String), value ((intptr_t) v) {}
    Value (int v) : typ (Int), value ((intptr_t) v) {}

    Type type () { return typ; }

    operator const char* () {
        return typ == String ? (const char*) value : "";
    }

    operator int () {
        return typ == Int ? value : 0;
    }

    void operator= (const Value& v) {
        value = v.value;
        typ = v.typ;
    }

    static Value nil;

private:
    Type typ;
    intptr_t value;
};

Value Value::nil;

class Inlet : public Value {
public:
    void operator= (const Value& v) {
        *(Value*) this = v;
        owner->trigger(*this);
    }

private:
    Gadget* owner;

    friend class Gadget;
};

class Outlet {
public:
    void operator= (const Value& v) { owner->send(this, v); }

    const Outlet& operator>> (Inlet& inlet) const {
        Gadget::addWire(this, &inlet);
        return *this;
    }

private:
    Gadget* owner;

    friend class Gadget;
};

void Gadget::define (Inlet& in) {
    in.owner = this;
}

void Gadget::define (Outlet& out) {
    out.owner = this;
}

void Gadget::send(class Outlet* outlet, const Value& v) {
    for (int i = 0; i < numWires; ++i)
        if (wires[i].from == outlet)
            *wires[i].to = v;
}

class PrintGadget : Gadget {
public:
    PrintGadget () { define(in); }

    virtual void trigger (Inlet& inlet) {
        printf("print: ");
        const char* s = "";
        switch (in.type()) {
            case Value::Nil:    s = "<nil>"; break;
            case Value::String: s = (const char*) in; break;
            case Value::Int:    printf("%d", (int) in); break;
        }
        printf("%s\n", s);
    }

    Inlet in;
};

class DoubleGadget : Gadget {
public:
    DoubleGadget () { define(in); define(out); }

    virtual void trigger (Inlet& inlet) {
        out = 2 * (int) in;
    }

    Inlet in;
    Outlet out;
};
