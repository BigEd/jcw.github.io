// Sending formatted text to the serial port using printf.

#include <stdio.h>
#include "muf.h"

#if !TEST
#include "LPC8xx.h"
#include "uart.h"
#endif

EventGadget eventG;
PrintGadget printG;
DoubleGadget doubleG;

Gadget* const Gadget::instances[] = {
    &eventG,
    &printG,
    &doubleG,
    0
};

uint8_t const Gadget::wiring[] = {
    // 0 eventG
    // 1 printG
    1, 1, 0, // 2.1 doubleG => printG 1.1
};

int main () {
#if !TEST
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);
#endif

    Gadget::init();

#if 1
    printf(" Gadget %2d b\n", (int) sizeof (Gadget));
    printf("  Value %2d b\n", (int) sizeof (Value));
    printf("   Type %2d b\n", (int) sizeof (Value::Type));
    printf("  Inlet %2d b\n", (int) sizeof (Inlet));
    printf(" Outlet %2d b\n", (int) sizeof (Outlet));
    printf(" eventG %2d b\n", (int) sizeof eventG);
    printf(" printG %2d b\n", (int) sizeof printG);
    printf("doubleG %2d b\n", (int) sizeof doubleG);
    printf("\n");
#endif

    printG.in = 123;
    printG.in = "abc";
    printG.in = Value::nil;
    doubleG.in = 234;
}
