// Muf experiment.

#include <stdint.h>

class Inlet;
class Outlet;
class Value;

class Gadget {
public:
    Inlet& inlet (int n);
    Outlet& outlet (int n);

    static void init ();

    static Gadget* const instances[];
    static uint8_t const wiring[];

protected:
    Gadget () {}

    virtual int numInlets () const = 0;
    virtual int numOutlets () const { return 0; }

private:
    virtual void trigger (int idx) = 0;
    void send(int woff, const Value& v);

    friend class Inlet;
    friend class Outlet;
};

class Value {
public:
    typedef enum { Nil, String, Int } Type;

    Value () : typ (Nil) {}
    Value (const char* v) : typ (String), value ((intptr_t) v) {}
    Value (int v) : typ (Int), value ((intptr_t) v) {}

    Type type () { return typ; }

    operator const char* () const {
        return typ == String ? (const char*) value : "";
    }

    operator int () const {
        return typ == Int ? value : 0;
    }

    void operator= (const Value& v) {
        typ = v.typ;
        value = v.value;
    }

    static Value nil;

protected:
    uint16_t gid;
    uint8_t idx;

private:
    Type typ :8;
    intptr_t value;

    friend class Gadget;
};

Value Value::nil;

class Inlet : public Value {
public:
    void operator= (const Value& v) {
        *(Value*) this = v;
        Gadget::instances[gid]->trigger(idx);
    }
};

class Outlet {
public:
    bool inUse () const { return Gadget::wiring[woff] != 0; }

    void operator= (const Value& v) { Gadget::instances[gid]->send(woff, v); }

private:
    uint16_t gid;
    uint16_t woff;

    friend class Gadget;
};

void Gadget::init () {
    uint16_t woff = 0;
    for (int gid = 0; instances[gid] != 0; ++gid) {
        Gadget* g = instances[gid];
        for (int i = 1; i <= g->numInlets(); ++i) {
            g->inlet(i).gid = gid;
            g->inlet(i).idx = i;
        }
        for (int o = 1; o <= g->numOutlets(); ++o) {
            g->outlet(o).gid = gid;
            g->outlet(o).woff = woff;
            while (Gadget::wiring[woff++] != 0)
                ;
        }
    }
}

Inlet& Gadget::inlet (int n) {
    return ((Inlet*) (this + 1))[n-1];
}

Outlet& Gadget::outlet (int n) {
    return ((Outlet*) &inlet(numInlets() + 1))[n-1];
}

void Gadget::send(int woff, const Value& v) {
    while (Gadget::wiring[woff] != 0) {
        Gadget* g = Gadget::instances[Gadget::wiring[woff++]];
        g->inlet(Gadget::wiring[woff++]) = v;
    }
}

class EventGadget : public Gadget {
public:
    virtual int numInlets () const { return 0; }

    virtual void trigger (int idx) {}
};

class PrintGadget : public Gadget {
public:
    virtual int numInlets () const { return 1; }

    virtual void trigger (int idx) {
        printf("print: ");
        const char* s = "";
        switch (in.type()) {
            case Value::Nil:    s = "<nil>"; break;
            case Value::String: s = (const char*) in; break;
            case Value::Int:    printf("%d", (int) in); break;
        }
        printf("%s\n", s);
    }

    Inlet in;
};

class DoubleGadget : public Gadget {
public:
    virtual int numInlets () const { return 1; }
    virtual int numOutlets () const { return 1; }

    virtual void trigger (int idx) {
        out = 2 * (int) in;
    }

    Inlet in;
    Outlet out;
};
