// experimental mug definition syntax
class Event_Mug : public Mug {
public:
 virtual void trigger (int idx) {
  switch (idx) {
  }
 }
    void Run () {
        while (true) {
            delay(1200000);
            bang = Value::nil;
        }
    }
 virtual int numInlets () { return 0;}
 virtual int numOutlets () { return 1;}
 Outlet bang;
};

class Print_Mug : public Mug {
public:
 virtual void trigger (int idx) {
  switch (idx) {
   case 1: {
    printf("print: ");
    const char* s = "";
    switch (in.type()) {
        case Value::Nil:    s = "<nil>"; break;
        case Value::String: s = (const char*) in; break;
        case Value::Int:    printf("%d", (int) in); break;
    }
    printf("%s\n", s);
   }
  }
 }
 virtual int numInlets () { return 1;}
 virtual int numOutlets () { return 0;}
 Inlet in;
};

class Double_Mug : public Mug {
public:
 virtual void trigger (int idx) {
  switch (idx) {
   case 1: {
    out = 2 * (int) in;
   }
  }
 }
 virtual int numInlets () { return 1;}
 virtual int numOutlets () { return 1;}
 Inlet in;
 Outlet out;
};

class PinOut_Mug : public Mug {
public:
 virtual void trigger (int idx) {
  switch (idx) {
   case 1: {
    int b = 1 << pin;
    if (set.type() != Value::Int)
        LPC_GPIO_PORT->NOT0 = b;
    else if (set)
        LPC_GPIO_PORT->SET0 = b;
    else
        LPC_GPIO_PORT->CLR0 = b;
    break;
   }
   case 2: {
    LPC_GPIO_PORT->DIR0 |= 1 << pin;
// vim: set ft=cpp :
   }
  }
 }
 virtual int numInlets () { return 2;}
 virtual int numOutlets () { return 0;}
 Inlet set, pin;
};

