// Blink two LEDs at a differrent rate using mugs.

#include <stdio.h>
#include "../../t-base/mug/mugs.h"

#include "LPC8xx.h"
#include "uart.h"

class PinOutMug : public Mug {
public:
    virtual int numInlets () const { return 2; }

    virtual void trigger (int idx) {
        int b = 1 << pin;
        switch (idx) {
            case 1:
                if (set.type() != Value::Int)
                    LPC_GPIO_PORT->NOT0 = b;
                else if (set)
                    LPC_GPIO_PORT->SET0 = b;
                else
                    LPC_GPIO_PORT->CLR0 = b;
                break;
            case 2:
                LPC_GPIO_PORT->DIR0 |= b;
                break;
        }
    }

    Inlet set, pin;
};

// mugs used in this example
EventMug eventG;
MetroMug metro1, metro2, metro3;
PinOutMug pinOut1, pinOut2, pinOut3;

// list of all the mugs, to define their index
Mug* const Mug::instances[] = {
    &eventG,
    &metro1,
    &metro2,
    &metro3,
    &pinOut1,
    &pinOut2,
    &pinOut3,
    0
};

// wire connections, one set for each outlet
uint8_t const Mug::wiring[] = {
    // 0 eventG 1
    4, 1, 0, // 1 metro1
    5, 1, 0, // 2 metro2
    6, 1, 0, // 3 metro3
    // 4 pinOut1
    // 5 pinOut2
    // 6 pinOut2
};

// pre-defined values, sent to inlets at init time
Mug::Preset const Mug::presets[] = {
#if 0 // proto-LPC812
    { 1, 1, Value::Int, 500 }, // metro1.ms
    { 4, 2, Value::Int, 7 }, // pinOut1.pin
    { 2, 1, Value::Int, 700 }, // metro2.ms
    { 5, 2, Value::Int, 13 }, // pinOut2.pin
#endif
#if 1 // EA-LPC824
    { 1, 1, Value::Int, 500 }, // metro1.ms
    { 4, 2, Value::Int, 12 }, // pinOut1.pin
    { 2, 1, Value::Int, 700 }, // metro2.ms
    { 5, 2, Value::Int, 16 }, // pinOut2.pin
    { 3, 1, Value::Int, 900 }, // metro2.ms
    { 6, 2, Value::Int, 27 }, // pinOut2.pin
#endif
    { 0, 0, Value::Nil, 0 }
};

int main () {
#if 0
    // set up the UART on pins 0 and 4 (or 18 and 7), running at 115200 baud
    //LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    LPC_SWM->PINASSIGN0 = 0xFFFF1207UL;
    uart0Init(115200);

    printf("    Mug %2d b\n", (int) sizeof (Mug));
    printf("  Value %2d b\n", (int) sizeof (Value));
    printf("   Type %2d b\n", (int) sizeof (Value::Type));
    printf("  Inlet %2d b\n", (int) sizeof (Inlet));
    printf(" Outlet %2d b\n", (int) sizeof (Outlet));
    printf(" eventG %2d b\n", (int) sizeof eventG);
    printf(" metro1 %2d b\n", (int) sizeof metro1);
    printf("pinOut1 %2d b\n", (int) sizeof pinOut1);
    printf("\n");
#endif

    Mug::init();
    eventG.Run();
}
