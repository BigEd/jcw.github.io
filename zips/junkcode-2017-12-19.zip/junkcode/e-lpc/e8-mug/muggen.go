package main

import (
	"fmt"
	"io/ioutil"
	"strings"
)

func main() {
	data, _ := ioutil.ReadFile("defs.mug")
	currdef := ""
	ins := []string{}
	outs := []string{}
	inIdx := 0
	outIdx := 0
	closed := false

	closer := func() {
		if len(currdef) > 0 {
			if !closed {
				fmt.Println("   }\n  }\n }")
			}
			fmt.Printf(" virtual int numInlets () { return %d;}\n", inIdx)
			fmt.Printf(" virtual int numOutlets () { return %d;}\n", outIdx)
			if inIdx > 0 {
				fmt.Printf(" Inlet %s;\n", strings.Join(ins, ", "))
			}
			if outIdx > 0 {
				fmt.Printf(" Outlet %s;\n", strings.Join(outs, ", "))
			}
			fmt.Printf("};\n\n")
		}
	}

	for pos, line := range strings.Split(string(data), "\n") {
		if len(strings.TrimSpace(line)) == 0 {
			continue
		}
		switch {
		case strings.HasPrefix(line, "MUGTYPE "):
			closer()
			currdef = line[8:]
			ins = nil
			outs = nil
			inIdx = 0
			outIdx = 0
			closed = false
			fmt.Printf("class %s_Mug : public Mug {\npublic:\n"+
				" virtual void trigger (int idx) {\n"+
				"  switch (idx) {\n",
				currdef)
		case strings.HasPrefix(line, "INLET "):
			ins = append(ins, line[6:])
			if inIdx > 0 {
				fmt.Println("    break;\n   }")
			}
			inIdx++
			fmt.Printf("   case %d: {\n", inIdx)
		case strings.HasPrefix(line, "OUTLET "):
			outs = append(outs, line[7:])
			outIdx++
		case strings.HasPrefix(line, "EXTRA"):
			fmt.Println("  }\n }")
			closed = true
		default:
			_ = pos //fmt.Println("#line", pos+1)
			fmt.Println(line)
		}
	}
	closer()
}
