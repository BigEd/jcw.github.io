// Generate up to 4 independent servo motion control pulses in hardware.
// See http://jeelabs.org/2014/12/10/dips-into-the-lpc810/

#include "LPC8xx.h"

#define TEST        1   // 1 for single-channel test setup, 0 for quad-channel

#if TEST
#define POS2US      10  // us per position unit
#define CYCLE_MS    10  // cycle time for servo pulsing
#else
#define POS2US      5   // us per position unit
#define CYCLE_MS    20  // cycle time for servo pulsing
#endif

#define SCT_MHZ     12  // SCT clock ticks per microsecond

extern "C" void SysTick_Handler () {
    // the only effect is to generate an interrupt, no work is done here
}

void delay (uint32_t steps) {
    while (steps-- > 0)
        __WFI();
}

void pwmSetup (int usInit, int usCycle) {
    LPC_SYSCON->SYSAHBCLKCTRL |= (1<<8);    // enable the SCT
    LPC_SCT->CONFIG = (1<<0);               // unify

    LPC_SCT->MATCH[0].U = LPC_SCT->MATCHREL[0].U = usCycle * SCT_MHZ;
    for (int i = 1; i < 5; ++i)
        LPC_SCT->MATCH[i].U = LPC_SCT->MATCHREL[i].U = usInit * SCT_MHZ;

    for (int i = 0; i < 5; ++i) {
        LPC_SCT->EVENT[i].CTRL = (i<<0) | (1<<12);
        LPC_SCT->EVENT[i].STATE = (1<<0);
    }

    for (int i = 0; i < 4; ++i) {
        LPC_SCT->OUT[i].SET = (1<<0);
        LPC_SCT->OUT[i].CLR = (1<<(i+1));
    }

    LPC_SCT->LIMIT_L = (1<<0);              // event 0 clears the counter
    LPC_SCT->CTRL_L &= ~(1<<2);             // start the SCT
}

void pwmChannel (int chan, int us) {
    LPC_SCT->MATCHREL[chan+1].U = us * SCT_MHZ;
}

typedef struct {
    uint8_t time;       // in steps of 20 ms
    int8_t targets[4];  // RFOOT, RHIP, LFOOT, LHIP
} Motion;

const Motion motions [] = {
//#include "motions.h"
    { 25, {  0,  0,  0,  0 } },
    { 25, {  0,  0,  0,  0 } },

    { 25, { 50,  0,  0,  0 } },
    { 25, {  0,  0,  0,  0 } },
    { 25, {-50,  0,  0,  0 } },
    { 25, {  0,  0,  0,  0 } },

    { 25, {  0, 50,  0,  0 } },
    { 25, {  0,  0,  0,  0 } },
    { 25, {  0,-50,  0,  0 } },
    { 25, {  0,  0,  0,  0 } },

    { 25, {  0,  0, 50,  0 } },
    { 25, {  0,  0,  0,  0 } },
    { 25, {  0,  0,-50,  0 } },
    { 25, {  0,  0,  0,  0 } },

    { 25, {  0,  0,  0, 50 } },
    { 25, {  0,  0,  0,  0 } },
    { 25, {  0,  0,  0,-50 } },
    { 25, {  0,  0,  0,  0 } },

    { 0 }
};

int main () {
    for (int i = 0; i < 3000000; ++i) __ASM(""); // allow early reset to work

    LPC_SWM->PINENABLE0 |= (3<<2) | (1<<6); // disable SWD and RESET

#if TEST
    LPC_SWM->PINASSIGN7 = 0xFFFF01FF;       // connect CTOUT_2 to PIO0_1, pin 5
#else
    LPC_SWM->PINASSIGN6 = 0x02FFFFFF;       // connect CTOUT_0 to PIO0_2
    LPC_SWM->PINASSIGN7 = 0xFF000403;       // cto1 -> 3, cto2 -> 4, cto3 -> 0
#endif

    pwmSetup(1500, 1000 * CYCLE_MS);        // use SCT for servo PWM pulse gen
    SysTick_Config(12000000/1000*CYCLE_MS); // in sync with SCT timing

    Motion last = { 0, { 0, 0, 0, 0 } };    // keep track of last known state

    for (int step = 0; ; ++step) {          // take the next step
        if (motions[step].time == 0)        // if there is none left...
            step = 0;                       // ... loop back to beginning
        int n = motions[step].time * 20 / CYCLE_MS; // number of steps to take

        for (int t = 1; t <= n; ++t) {      // for each steo
            for (int i = 0; i < 4; ++i) {       // for each channel
                int usFrom = POS2US * last.targets[i];        // last known
                int usTo = POS2US * motions[step].targets[i]; // desired

                // calculate the fractional position to take at each step
                int pos = usFrom + ((usTo - usFrom) * t) / n;

                // set SCT accordingly, for use in next PWM cycle
                pwmChannel(i, 1500 + pos);
            }
            __WFI();                            // wait for next cycle time
        }

        last = motions[step];               // step taken, use as new rest state
    }
}
