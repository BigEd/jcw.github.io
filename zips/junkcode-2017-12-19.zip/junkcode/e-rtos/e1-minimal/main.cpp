// Minimal code, using Chibios 3.x as build environment, but not calling it.
// This serves only to verify that the basic build mechanism is working.

// #include "hal.h"

int main () {
    // halInit();
    // chSysInit();

    return 0;
}
