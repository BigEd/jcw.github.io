// The inevitable blink demo, using ChibiOS 3.x as build environment.
// Blinks the green LED on the Nucleo F103RB board.

#include "hal.h"

int main () {
    halInit();
    chSysInit();

    while (true) {
        palTogglePad(GPIOA, GPIOA_LED_GREEN);
        chThdSleepMilliseconds(500);
    }

    return 0;
}
