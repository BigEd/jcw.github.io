// ChibiOS configuration

#define CH_CFG_ST_RESOLUTION                32
#define CH_CFG_ST_FREQUENCY                 1000
#define CH_CFG_ST_TIMEDELTA                 0

#define CH_CFG_TIME_QUANTUM                 0
#define CH_CFG_MEMCORE_SIZE                 0

#define CH_CFG_USE_EVENTS                   TRUE
#define CH_CFG_USE_MESSAGES                 TRUE

// Microcontroller configuration

#define STM32F103_MCUCONF

#define STM32_NO_INIT                       FALSE
#define STM32_HSI_ENABLED                   TRUE
#define STM32_LSI_ENABLED                   FALSE
#define STM32_HSE_ENABLED                   FALSE
#define STM32_LSE_ENABLED                   FALSE
#define STM32_SW                            STM32_SW_PLL
#define STM32_PLLSRC                        STM32_PLLSRC_HSI
#define STM32_PLLXTPRE                      STM32_PLLXTPRE_DIV1
#define STM32_PLLMUL_VALUE                  16
#define STM32_HPRE                          STM32_HPRE_DIV1
#define STM32_PPRE1                         STM32_PPRE1_DIV2
#define STM32_PPRE2                         STM32_PPRE2_DIV2
#define STM32_ADCPRE                        STM32_ADCPRE_DIV4
#define STM32_USB_CLOCK_REQUIRED            FALSE
#define STM32_USBPRE                        STM32_USBPRE_DIV1P5
#define STM32_MCOSEL                        STM32_MCOSEL_NOCLOCK
#define STM32_RTCSEL                        STM32_RTCSEL_NOCLOCK
#define STM32_PVD_ENABLE                    FALSE
#define STM32_PLS                           STM32_PLS_LEV0

#define STM32_SERIAL_USE_USART2             TRUE
#define STM32_SERIAL_USART2_PRIORITY        12

// Hardware abstraction layer configuration

#define HAL_USE_PAL                         TRUE
                                            
#define HAL_USE_SERIAL                      TRUE
#define SERIAL_DEFAULT_BITRATE              115200
#define SERIAL_BUFFERS_SIZE                 16
