// Blinking with some serial test output on USART 2 in a separate thread.
// On the Nucleo F103RB, this will coome out of the USB virtual serial port.

#include "hal.h"
#include "chprintf.h"

static void printf (const char* fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	chvprintf((BaseSequentialStream*) &SD2, fmt, ap);
	va_end(ap);
}

static THD_WORKING_AREA(waPrinter, 64);
static THD_FUNCTION(Printer, /*arg*/) {
    printf("clock = %d Hz - ", STM32_SYSCLK);
    for (int count = 1; count <= 10; ++count) {
        printf("%d ", count);
        chThdSleepMilliseconds(1000);
    }
    printf("bye!\r\n");
    return 0;
}

int main () {
    halInit();
    chSysInit();

    sdStart(&SD2, NULL);
    printf("\r\n[e3-printf]\r\n");

    chThdCreateStatic(waPrinter, sizeof waPrinter, NORMALPRIO, Printer, 0);

    while (true) {
        palTogglePad(GPIOA, GPIOA_LED_GREEN);
        chThdSleepMilliseconds(500);
    }

    return 0;
}
