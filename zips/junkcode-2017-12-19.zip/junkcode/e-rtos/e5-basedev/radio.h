// new driver code, exposes a minimal public API

class RF69 : SpiDevice {
public:
    static void init (int freq, uint8_t group, uint8_t id);
    static void sleep ();
    
    static int receive (void* ptr, int len);
    static void send (uint8_t header, const void* ptr, int len);
    
    static uint8_t rssi;
    static int16_t afc;

private:
    static uint8_t readReg (uint8_t addr);
    static void writeReg (uint8_t addr, uint8_t value);
    static void setMode (uint8_t newMode);
    static void setFrequency (uint32_t freq);
};

uint8_t RF69::rssi;
int16_t RF69::afc;

// driver implementation

static volatile uint8_t mode;
static uint8_t myId;

enum {
    REG_FIFO          = 0x00,
    REG_OPMODE        = 0x01,
    REG_FRFMSB        = 0x07,
    REG_FEIMSB        = 0x21,
    REG_FEILSB        = 0x22,
    REG_RSSIVALUE     = 0x24,
    REG_IRQFLAGS1     = 0x27,
    REG_IRQFLAGS2     = 0x28,
    REG_SYNCVALUE1    = 0x2F,
    REG_SYNCVALUE2    = 0x30,
    
    MODE_SLEEP        = 0<<2,
    MODE_TRANSMIT     = 3<<2,
    MODE_RECEIVE      = 4<<2,

    IRQ1_MODEREADY    = 1<<7,
    IRQ1_RXREADY      = 1<<6,

    IRQ2_FIFONOTEMPTY = 1<<6,
    IRQ2_PACKETSENT   = 1<<3,
    IRQ2_PAYLOADREADY = 1<<2,
};

uint8_t RF69::readReg (uint8_t addr) {
    return spiRegister(addr, 0);
}

void RF69::writeReg (uint8_t addr, uint8_t value) {
    spiRegister(addr | 0x80, value);
}

void RF69::setMode (uint8_t newMode) {
    mode = newMode;
    writeReg(REG_OPMODE, (readReg(REG_OPMODE) & 0xE3) | newMode);
    while ((readReg(REG_IRQFLAGS1) & IRQ1_MODEREADY) == 0)
        ;
}

void RF69::setFrequency (uint32_t freq) {
    // Frequency steps are in units of (32,000,000 >> 19) = 61.03515625 Hz
    // use multiples of 64 to avoid multi-precision arithmetic, i.e. 3906.25 Hz
    // due to this, the lower 6 bits of the calculated factor will always be 0
    // this is still 4 ppm, i.e. well below the radio's 32 MHz crystal accuracy
    // 868.0 MHz = 0xD90000, 868.3 MHz = 0xD91300, 915.0 MHz = 0xE4C000  
    uint32_t frf = ((freq << 2) / (32000000L >> 11)) << 6;
    writeReg(REG_FRFMSB, frf >> 16);
    writeReg(REG_FRFMSB+1, frf >> 8);
    writeReg(REG_FRFMSB+2, frf);
}

static const uint8_t configRegs [] = {
    0x01, 0x00, // OpMode = sleep
    0x02, 0x00, // DataModul = packet mode, fsk
    0x03, 0x02, // BitRateMsb, data rate = 49,261 khz
    0x04, 0x40, //0x8A, // BitRateLsb, divider = 32 MHz / 650
    0x05, 0x03, //0x05, // FdevMsb = 90 KHz
    0x06, 0x33, //0xC3, // FdevLsb = 90 KHz
    //0x07, 0xD9, // // FrfMsb, freq = 868.000 MHz
    //0x08, 0x00, // // FrfMib, divider = 14221312
    //0x09, 0x00, // // FrfLsb, step = 61.03515625
    //0x0B, 0x40, //0x20, // AfcCtrl, afclowbetaon
    0x19, 0x42, // RxBw ...
    0x1A, 0x91, //...
    0x1E, 0x0C, // AfcAutoclearOn, AfcAutoOn
    0x25, 0x40, //0x80, // DioMapping1 = SyncAddress (Rx)
    0x29, 0xC4, // // RssiThresh ...
    0x2E, 0x88, // SyncConfig = sync on, sync size = 2
    0x2F, 0x2D, // SyncValue1 = 0x2D
    //0x30, 0x64, // 0x30, 0x05, // SyncValue2 = 0x05
    0x37, 0x90, //0x00, // PacketConfig1 = fixed, no crc, filt off
    0x38, 0x42, //0x00, // PayloadLength = 0, unlimited
    0x3C, 0x8F, // FifoTresh, not empty, level 15
    0x3D, 0x12, //0x10, // PacketConfig2, interpkt = 1, autorxrestart off
    0x6F, 0x30, // TestDagc ...
    0
};

void RF69::init (int freq, uint8_t group, uint8_t id) {
    spiConfig();
    do
        writeReg(REG_SYNCVALUE1, 0xAA);
    while (readReg(REG_SYNCVALUE1) != 0xAA);
    do
        writeReg(REG_SYNCVALUE1, 0x55);
    while (readReg(REG_SYNCVALUE1) != 0x55);

    for (const uint8_t* p = configRegs; ; p += 2) {
        uint8_t cmd = p[0];
        if (cmd == 0)
            break;
        writeReg(cmd, p[1]);
    }

    setFrequency(freq);
    writeReg(REG_SYNCVALUE2, group);
    myId = id;
}

void RF69::sleep () {
    setMode(MODE_SLEEP);
}

int RF69::receive (void* ptr, int len) {
    switch (mode) {
    case MODE_RECEIVE:
        if (readReg(REG_IRQFLAGS2) & IRQ2_PAYLOADREADY) {
            rssi = readReg(REG_RSSIVALUE);
            // use the FEI value, since the AFC reg has already been cleared
            afc = (readReg(REG_FEIMSB) << 8) + readReg(REG_FEILSB);
            
            spiEnable();
            spiTransfer(REG_FIFO);
            int count = spiTransfer(0);
            for (int i = 0; i < count; ++i) {
                uint8_t v = spiTransfer(0);
                if (i < len)
                    ((uint8_t*) ptr)[i] = v;
            }
            spiDisable();

            return count;
        }
        break;
    case MODE_TRANSMIT:
        break;
    default:
        setMode(MODE_RECEIVE);
    }
    return -1;
}

void RF69::send (uint8_t header, const void* ptr, int len) {
    // while the mode is MODE_TRANSMIT, receive polling will not interfere
    setMode(MODE_TRANSMIT);

    spiEnable();
    spiTransfer(REG_FIFO | 0x80);
    spiTransfer(len + 2);
    spiTransfer(header);
    spiTransfer(myId);
    for (int i = 0; i < len; ++i)
        spiTransfer(((const uint8_t*) ptr)[i]);
    spiDisable();

    while ((readReg(REG_IRQFLAGS2) & IRQ2_PACKETSENT) == 0)
        chThdYield();

    setMode(MODE_RECEIVE);
}
