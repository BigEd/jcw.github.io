class SpiDevice {
public:
    void spiConfig () {
        palSetPadMode(GPIOA, 5, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // SCK
        palSetPadMode(GPIOA, 6, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MISO
        palSetPadMode(GPIOA, 7, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MOSI
        palSetPadMode(GPIOB, 6, PAL_MODE_OUTPUT_PUSHPULL);            // SSEL
        palSetPad(GPIOB, 6);

        static const SPIConfig spicfg = {
            NULL, GPIOB, 6, SPI_CR1_BR_0
        };
        spiStart(&SPID1, &spicfg);
    }

    void spiEnable () {
        spiSelect(&SPID1);
    }

    void spiDisable () {
        spiUnselect(&SPID1);
    }

    uint8_t spiTransfer (uint8_t out) {
        return spiPolledExchange(&SPID1, out);
    }

    uint8_t spiRegister (uint8_t cmd, uint8_t val) {
        spiEnable();
        spiTransfer(cmd);
        uint8_t in = spiTransfer(val);
        spiDisable();
        return in;
    }
};
