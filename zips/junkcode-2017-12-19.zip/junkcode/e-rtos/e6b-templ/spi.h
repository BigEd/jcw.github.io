class SpiDevice {
public:
    void init () {
        palSetPadMode(GPIOA, 5, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // SCK
        palSetPadMode(GPIOA, 6, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MISO
        palSetPadMode(GPIOA, 7, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MOSI
        palSetPadMode(GPIOB, 6, PAL_MODE_OUTPUT_PUSHPULL);            // SSEL
        palSetPad(GPIOB, 6);

        static const SPIConfig spicfg = {
            NULL, GPIOB, 6, SPI_CR1_BR_0
        };
        spiStart(&SPID1, &spicfg);
    }

    void enable () {
        spiSelect(&SPID1);
    }

    void disable () {
        spiUnselect(&SPID1);
    }

    uint8_t transfer (uint8_t out) {
        return spiPolledExchange(&SPID1, out);
    }

    uint8_t rwReg (uint8_t cmd, uint8_t val) {
        enable();
        transfer(cmd);
        uint8_t in = transfer(val);
        disable();
        return in;
    }
};
