// A first test for RFM69 native-mode packet reception under Chibios,
//
// The radio is connected to SPI1, i.e. pins 10..13 on the Nuclei F103RB board.
// Interrupts are not used.

#include "hal.h"
#include "chprintf.h"

BaseSequentialStream *serial = (BaseSequentialStream*) &SD2;

#include "spi.h"
#include "radio.h"

uint8_t rxBuf[66];

static THD_WORKING_AREA(waRadio, 128);
static THD_FUNCTION(Radio, /*arg*/) {
    while (true) {
        int len = RF69::receive(rxBuf, sizeof rxBuf);
        if (len >= 0) {
            chprintf(serial, "OK ");
            for (int i = 0; i < len; ++i)
                chprintf(serial, "%02x", rxBuf[i]);
            chprintf(serial, " (%d%s%d)\n",
                        RF69::rssi, RF69::afc < 0 ? "" : "+", RF69::afc);
        }
        chThdSleepMilliseconds(1);
    }
    return 0;
}

int main () {
    halInit();
    chSysInit();

    sdStart(&SD2, NULL);
    chprintf(serial, "\n[e7-namesp]\n");

    RF69::init(868000000, 100, 1);
    chThdCreateStatic(waRadio, sizeof waRadio, NORMALPRIO, Radio, 0);

    while (true) {
        chThdSleepMilliseconds(3000);
        chprintf(serial, " -> send 10b\n");
        RF69::send(0, "0123456789", 10);
    }

    return 0;
}
