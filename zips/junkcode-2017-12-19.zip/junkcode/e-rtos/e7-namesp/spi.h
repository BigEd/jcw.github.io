namespace RF69_SPI {

    static const SPIConfig config = {
        NULL, GPIOB, 6, SPI_CR1_BR_0
    };

    static void init () {
        palSetPadMode(GPIOA, 5, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // SCK
        palSetPadMode(GPIOA, 6, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MISO
        palSetPadMode(GPIOA, 7, PAL_MODE_STM32_ALTERNATE_PUSHPULL);   // MOSI
        palSetPadMode(GPIOB, 6, PAL_MODE_OUTPUT_PUSHPULL);            // SSEL
        palSetPad(GPIOB, 6);

        spiStart(&SPID1, &config);
    }

    static void enable () {
        spiSelect(&SPID1);
    }

    static void disable () {
        spiUnselect(&SPID1);
    }

    static uint8_t transfer (uint8_t out) {
        return spiPolledExchange(&SPID1, out);
    }

    static uint8_t rwReg (uint8_t cmd, uint8_t val) {
        enable();
        transfer(cmd);
        uint8_t in = transfer(val);
        disable();
        return in;
    }
}
