// A first test for RFM69 native-mode packet reception under Chibios,
//
// The radio is connected to SPI1, i.e. pins 10..13 on the Nuclei F103RB board.
// Interrupts are not used.

#include "hal.h"
#include "chprintf.h"

BaseSequentialStream *serial = (BaseSequentialStream*) &SD2;

#define RF69_SPI_GPIO   GPIOB
#define RF69_SPI_PAD    6
#define RF69_SPI_DEV    SPID1

#include "spi.h"
#include "radio.h"

#undef RF69_SPI_GPIO
#undef RF69_SPI_PAD
#undef RF69_SPI_DEV

#define RF69_SPI_GPIO   GPIOB
#define RF69_SPI_PAD    7
#define RF69_SPI_DEV    SPID1

#define RF69_SPI RF69_SPIx
#define RF69 RF69x

#include "spi.h"
#include "radio.h"

#undef RF69_SPI
#undef RF69

uint8_t rxBuf[66];

static THD_WORKING_AREA(waRadio, 128);
static THD_FUNCTION(Radio, /*arg*/) {
    while (true) {
        int len = RF69::receive(rxBuf, sizeof rxBuf);
        if (len >= 0) {
            chprintf(serial, "OK ");
            for (int i = 0; i < len; ++i)
                chprintf(serial, "%02x", rxBuf[i]);
            chprintf(serial, " (%d%s%d)\n",
                        RF69::rssi, RF69::afc < 0 ? "" : "+", RF69::afc);
        }
        chThdYield();
    }
    return 0;
}

static THD_WORKING_AREA(waRadiox, 128);
static THD_FUNCTION(Radiox, /*arg*/) {
    while (true) {
        int len = RF69x::receive(rxBuf, sizeof rxBuf);
        if (len >= 0) {
            chprintf(serial, "OKx ");
            for (int i = 0; i < len; ++i)
                chprintf(serial, "%02x", rxBuf[i]);
            chprintf(serial, " (%d%s%d)\n",
                        RF69x::rssi, RF69x::afc < 0 ? "" : "+", RF69x::afc);
        }
        chThdYield();
    }
    return 0;
}

int main () {
    halInit();
    chSysInit();

    sdStart(&SD2, NULL);
    chprintf(serial, "\n[e8-dual]\n");

    RF69::init(868000000, 100, 1);
    RF69x::init(868000000, 99, 2);
    chThdCreateStatic(waRadio, sizeof waRadio, NORMALPRIO, Radio, 0);
    chThdCreateStatic(waRadio, sizeof waRadiox, NORMALPRIO, Radiox, 0);

    while (true) {
        chThdSleepMilliseconds(3000);
        chprintf(serial, " -> send 10b\n");
        RF69::send(0, "0123456789", 10);
        RF69x::send(0, "9876543210", 10);
    }

    return 0;
}
