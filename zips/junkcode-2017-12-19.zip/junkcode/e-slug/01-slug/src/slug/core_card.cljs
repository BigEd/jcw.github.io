(ns slug.core-card
  (:require-macros [devcards.core :as dc])
  (:require [slug.doodle]))

(dc/start-devcard-ui!)
