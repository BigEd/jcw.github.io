(ns example.example-test
  (:require [clojure.test :refer :all]))

(deftest example-passing-test
  (is (= 1 1)))
