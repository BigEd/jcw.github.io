# 06-boot

Set up a reagent app via [Boot](http://boot-clj.com) and
[Tenzing](https://github.com/martinklepsch/tenzing), using `boot -d boot/new new
-t tenzing -n your-app -a +reagent`.

Run in development mode using:

    boot dev

The application will be served at <http://localhost:3000>.
