(ns app.db)

(def default-db
  {:name "re-frame"})
