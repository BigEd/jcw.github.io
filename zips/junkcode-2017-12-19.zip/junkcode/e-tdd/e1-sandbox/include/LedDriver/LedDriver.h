#pragma once

void LedDriver_Create (void);
void LedDriver_Destroy (void);
