#include "LedDriver.h"
#include <stdlib.h>
#include <memory.h>

void LedDriver_Create(void)
{
}

void LedDriver_Destroy(void)
{
}
