#include "CppUTest/CommandLineTestRunner.h"

int main (int ac, char** av) {
    return RUN_ALL_TESTS(ac, av);
}
