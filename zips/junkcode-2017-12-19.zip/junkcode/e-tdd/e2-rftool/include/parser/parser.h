#pragma once

typedef struct { const char* name; void (*func)(); } ParserCmd;

void ParserCreate (const ParserCmd* cmds);
 int ParserDepth ();
void ParserPush (int value);
 int ParserPop ();
void ParserAdd (char ch);
void ParserString (const char* text);
