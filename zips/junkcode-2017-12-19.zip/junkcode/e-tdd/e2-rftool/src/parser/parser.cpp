#include "parser.h"

static int depth, width;
static int stack[5];    // TODO check for overflow
static char token[10];  // TODO check for overflow
static const ParserCmd* cmdList;

void ParserCreate (const ParserCmd* cmds) {
    cmdList = cmds;
    depth = width = 0;
}

int ParserDepth () {
    return depth;
}

void ParserPush (int value) {
    stack[depth++] = value;
}

int ParserPop () {
    return depth > 0 ? stack[--depth] : 0;
}

void ParserAdd (char ch) {
    if (ch > ' ')
        token[width++] = ch;
    else if (width > 0) {
        token[width] = 0;
        width = 0;
        char* end;
        long value;
        if (token[0] == '$')
            value = strtol(token + 1, &end, 16);
        else
            value = strtol(token, &end, 10);
        if (end > token)
            ParserPush((int) value);
        else
            for (const ParserCmd* p = cmdList; p->name != 0; ++p)
                if (strcmp(p->name, token) == 0)
                    p->func();
    }
}

void ParserString (const char* text) {
    while (*text != 0)
        ParserAdd(*text++);
}
