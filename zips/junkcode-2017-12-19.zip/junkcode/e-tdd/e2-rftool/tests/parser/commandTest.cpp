#include "parser.h"

#include "CppUTest/TestHarness.h"

const int UNSET = 0x12345678;

static int oneCalls, twoCalls, threeResult;

static void oneFunc () { ++oneCalls; }
static void twoFunc () { ++twoCalls; }
static void threeFunc () { threeResult = ParserPop(); }
static void fourFunc () { ParserPush(321); }

const ParserCmd cmds[] = {
    { "one", &oneFunc },
    { "two", &twoFunc },
    { "three", &threeFunc },
    { "four", &fourFunc },
    { 0, 0 }
};

TEST_GROUP(Commands)
{
    void setup() {
        ParserCreate(cmds);
        oneCalls = twoCalls = 0;
        threeResult = UNSET;
    }
};

TEST(Commands, CallOne)
{
    CHECK_EQUAL(0, oneCalls);
    CHECK_EQUAL(0, twoCalls);
    ParserString("one ");
    CHECK_EQUAL(1, oneCalls);
    CHECK_EQUAL(0, twoCalls);
    CHECK_EQUAL(0, ParserDepth());
}

TEST(Commands, CallOneAndTwo)
{
    CHECK_EQUAL(0, oneCalls);
    CHECK_EQUAL(0, twoCalls);
    ParserString("11 one 22 two 33 one ");
    CHECK_EQUAL(2, oneCalls);
    CHECK_EQUAL(1, twoCalls);
    CHECK_EQUAL(3, ParserDepth());
    CHECK_EQUAL(33, ParserPop());
    CHECK_EQUAL(22, ParserPop());
    CHECK_EQUAL(11, ParserPop());
}

TEST(Commands, CallThree)
{
    CHECK_EQUAL(UNSET, threeResult);
    ParserString("11 22 three 33 ");
    CHECK_EQUAL(22, threeResult);
    CHECK_EQUAL(2, ParserDepth());
    CHECK_EQUAL(33, ParserPop());
    CHECK_EQUAL(11, ParserPop());
}

TEST(Commands, CallFour)
{
    ParserString("99 four 88 ");
    CHECK_EQUAL(3, ParserDepth());
    CHECK_EQUAL(88, ParserPop());
    CHECK_EQUAL(321, ParserPop());
    CHECK_EQUAL(99, ParserPop());
}
