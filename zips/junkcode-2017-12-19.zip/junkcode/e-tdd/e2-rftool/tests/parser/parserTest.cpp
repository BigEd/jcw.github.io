#include "parser.h"

#include "CppUTest/TestHarness.h"

TEST_GROUP(Parser)
{
    void setup() {
        ParserCreate(0);
    }
};

TEST(Parser, Create)
{
    CHECK_EQUAL(0, ParserDepth());
}

TEST(Parser, Push)
{
    ParserPush(987);
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(987, ParserPop());
}

TEST(Parser, Pop)
{
    ParserPush(876);
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(876, ParserPop());
    CHECK_EQUAL(0, ParserDepth());
}

TEST(Parser, PopTooMuch)
{
    CHECK_EQUAL(0, ParserPop());
    CHECK_EQUAL(0, ParserDepth());
}

TEST(Parser, AddChars)
{
    ParserAdd('5');
    ParserAdd('6');
    CHECK_EQUAL(0, ParserDepth());
    ParserAdd(' ');
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(56, ParserPop());
}

TEST(Parser, Nothing)
{
    ParserString("");
    CHECK_EQUAL(0, ParserDepth());
}

TEST(Parser, Value)
{
    ParserString("123 ");
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(123, ParserPop());
}

TEST(Parser, Partial)
{
    ParserString("12");
    ParserString("34 ");
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(1234, ParserPop());
}

TEST(Parser, TwoValues)
{
    ParserString("123 456 ");
    CHECK_EQUAL(2, ParserDepth());
    CHECK_EQUAL(456, ParserPop());
    CHECK_EQUAL(123, ParserPop());
}

TEST(Parser, WithWhitespace)
{
    ParserString(" 111 \t 222 \n 333 ");
    CHECK_EQUAL(3, ParserDepth());
    CHECK_EQUAL(333, ParserPop());
    CHECK_EQUAL(222, ParserPop());
    CHECK_EQUAL(111, ParserPop());
}

TEST(Parser, Hex)
{
    ParserString("$01aBc2 ");
    CHECK_EQUAL(1, ParserDepth());
    CHECK_EQUAL(0x1ABC2, ParserPop());
}
