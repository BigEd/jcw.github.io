// Blink the LED attached between PIO0_4 and VCC.

#include "LPC8xx.h"

int main () {
    // define PIO0_4 as an output pin
    LPC_GPIO_PORT->DIR0 |= 1 << 4;

    while (true) {
        // do a million times nothing to waste time
        for (int i = 0; i < 1000000; ++i)
            __asm("nop\n");
        // toggle the PIO0_4 pin
        LPC_GPIO_PORT->NOT0 = 1 << 4;
    }
}
