// Forthy, host side interface -jcw, 2014
package main

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/chimera/rs232"
)

const (
	SERIAL_PORT = "/dev/tty.usbserial-A8009L2N"
	// SERIAL_PORT = "/dev/tty.usbserial-A600dWcB"

	FLASH_BASE = 0x800
	FLASH_SIZE = 2048
	RAM_SIZE   = 512
	NOW_SIZE   = 100
)

var (
	target      *connection
	sendChannel chan []byte
	hostStack   []int
	words       = make(map[string]int)
	defName     string
	defValue    int
	nowCode     []byte
	ramCode     []byte
	ramFill     int
	flashCode   []byte
	toFlash     bool
	codePtr     = &nowCode
	input       = os.Stdin
	quitChan    = make(chan bool)
)

func main() {
	fmt.Println("Connecting to", SERIAL_PORT)
	target = connect(SERIAL_PORT)

	toFlash = true
	include("flash.f")
	fwords := len(words)
	toFlash = false
	include("ram.f")

	id := target.Identify()
	fmt.Printf("Forthy: %d ops, %d flash (%db), %d ram (%db), device %X.%X\n",
		OP_END, fwords, len(flashCode), len(words)-fwords, len(ramCode),
		id>>4, id&0xF)

	fmt.Print("Uploading pages ")
	for _ = range target.Program(FLASH_BASE, flashCode) {
		fmt.Print("+")
	}
	fmt.Println(" done")

	close(quitChan) // TODO hack to stop the programmer's line scanning
	// resetTarget(false) // don't enter the boot loader

	talkToTarget()

	parseUntilEof()
}

func (c *connection) ReadReply(count int) []byte {
	var buf = [256]byte{}
	n, err := io.ReadAtLeast(c, buf[:count], count)
	check(err)
	if n != count {
		panic(fmt.Errorf("expected %d bytes, got %d", count, n))
	}
	if true {
		fmt.Printf("(got %x)\n", buf[:n])
	}
	return buf[:n]
}

func include(name string) {
	savedIn := input
	defer func() { input = savedIn }()

	var err error
	input, err = os.Open(name)
	check(err)
	defer input.Close()

	parseUntilEof()
}

func parseUntilEof() {
	for {
		s := word()
		if s == "" {
			if input == os.Stdin {
				fmt.Println()
			}
			break
		}

		if f, ok := immediates[s]; ok {
			f()
		} else if w, ok := words[s]; ok {
			w -= codePos() + 2
			comma(uint8(w>>8), uint8(w))
		} else if op, ok := opcodes[s]; ok {
			comma(op)
		} else if v, err := strconv.ParseInt(s, 0, 33); err == nil {
			// using 33 iso 32 bits to accept unsigned ints up to 2^32-1
			literal(int(v))
		} else {
			fmt.Printf("%s ? ", s)
			// TODO clear nowCode and flush pending input
		}
	}
}

func word() (s string) {
	_, err := fmt.Fscan(input, &s)
	if err != nil {
		s = ""
	}
	if sendChannel != nil {
		sendChannel <- nil
	}
	return
}

func talkToTarget() {
	sendChannel = make(chan []byte)

	// report all received text on stdout
	go func() {
		for data := range target.bytes {
			fmt.Print(string(data))
		}
	}()

	// send code to target, once nothing new comes in for 100 ms
	go func() {
		timer := time.NewTimer(0)
		for {
			select {
			case <-sendChannel:
				timer.Reset(100 * time.Millisecond)
			case <-timer.C:
				flushCode()
			}
		}
	}()

	resetTarget(false) // don't enter the boot loader
}

func resetTarget(isp bool) {
	target.SetRTS(isp)
	target.SetDTR(true)
	time.Sleep(time.Millisecond)
	target.SetDTR(false)
}

var codeGuard sync.Mutex

func flushCode() {
	codeGuard.Lock()
	defer codeGuard.Unlock()

	if codePtr == &nowCode && len(nowCode) > 0 {
		for len(ramCode) > ramFill {
			cdef := ramCode[ramFill:]
			if len(cdef) > 50 {
				cdef = cdef[:50] // send in sizeable chunks
			}
			copyToRam(cdef)
			ramFill += len(cdef)
		}

		sendCode(nowCode)
		nowCode = nil
	}
}

func sendCode(data []byte) {
	// time.Sleep(10 * time.Millisecond) // TODO hack to avoid waiting for OK
	var check uint8
	for _, b := range data {
		check ^= b
	}
	target.Write([]byte{'p', byte(len(data) + 1)})
	target.Write(data)
	target.Write([]byte{check})
}

func copyToRam(data []byte) {
	var copyCmd []byte
	codePtr = &copyCmd
	defer func() { codePtr = &nowCode }()

	comma(OP_LITS, uint8(len(data)))
	copyCmd = append(copyCmd, data...)
	literal(ramFill)
	comma(OP_COPYSTR)
	sendCode(copyCmd)
}

func codePos() int {
	pos := len(*codePtr)
	if codePtr == &nowCode {
		pos += RAM_SIZE - NOW_SIZE
	} else if codePtr != &ramCode {
		pos -= FLASH_SIZE
	}
	return pos
}

func comma(ops ...uint8) {
	*codePtr = append(*codePtr, ops...)
}

func literal(v int) {
	if -128 <= v && v <= 127 {
		comma(OP_LIT1, uint8(v))
	} else {
		comma(OP_LIT4, uint8(v), uint8(v>>8), uint8(v>>16), uint8(v>>24))
	}
}

func check(err error) {
	if err != nil {
		panic(err)
	}
}

var immediates = map[string]func(){
	"if":     doIf,
	"then":   doThen,
	"else":   doElse,
	"begin":  doBegin,
	"again":  doAgain,
	"until":  doUntil,
	"while":  doWhile,
	"repeat": doRepeat,
	":":      doColon,
	";":      doSemicolon,
	"words":  doWords,
	"\\":     func() { skipInputTo('\n') },
	"(":      func() { skipInputTo(')') },
}

const (
	OP_EXIT = iota
	OP_TEST
	OP_DUP
	OP_DROP
	OP_RPOP
	OP_RPUSH
	OP_LIT1
	OP_LIT4
	OP_NEG
	OP_NOT
	OP_ADD
	OP_SUB
	OP_MUL
	OP_DIV
	OP_AND
	OP_OR
	OP_XOR
	OP_LSHIFT
	OP_RSHIFT
	OP_0LT
	OP_0EQ
	OP_OVER
	OP_SWAP
	OP_NIP
	OP_TUCK
	OP_PICK
	OP_PRC
	OP_PRU
	OP_PRN
	OP_RDB
	OP_LITS
	OP_AT
	OP_BANG
	OP_CAT
	OP_CBANG
	OP_COPYSTR
	OP_0BRANCH
	OP_BRANCH
	OP_DECIMAL
	OP_HEX
	OP_END
)

var opcodes = map[string]uint8{
	"!":       OP_BANG,
	"*":       OP_MUL,
	"+":       OP_ADD,
	"-":       OP_SUB,
	".":       OP_PRN,
	"/":       OP_DIV,
	"0<":      OP_0LT,
	"0=":      OP_0EQ,
	"<<":      OP_LSHIFT,
	">>":      OP_RSHIFT,
	">r":      OP_RPUSH,
	"@":       OP_AT,
	"and":     OP_AND,
	"c!":      OP_CBANG,
	"c.":      OP_PRC,
	"c@":      OP_CAT,
	"decimal": OP_DECIMAL,
	"drop":    OP_DROP,
	"dup":     OP_DUP,
	"exit":    OP_EXIT,
	"hex":     OP_HEX,
	"key":     OP_RDB,
	"negate":  OP_NEG,
	"nip":     OP_NIP,
	"not":     OP_NOT,
	"or":      OP_OR,
	"over":    OP_OVER,
	"pick":    OP_PICK,
	"r>":      OP_RPOP,
	"swap":    OP_SWAP,
	"tuck":    OP_TUCK,
	"u.":      OP_PRU,
	"xor":     OP_XOR,
}

func push(v int) {
	hostStack = append(hostStack, v)
}

func pop() int {
	n := len(hostStack) - 1
	v := hostStack[n]
	hostStack = hostStack[:n]
	return v
}

func swap() {
	n := len(hostStack) - 1
	hostStack[n], hostStack[n-1] = hostStack[n-1], hostStack[n]
}

func doBegin() {
	push(codePos())
}

func doAgain() {
	comma(OP_BRANCH)
	comma(uint8(pop() - codePos() - 1))
}

func doUntil() {
	comma(OP_0BRANCH)
	comma(uint8(pop() - codePos() - 1))
}

func doWhile() {
	doIf()
	swap()
}

func doRepeat() {
	doAgain()
	doThen()
}

func doIf() {
	comma(OP_0BRANCH)
	doBegin()
	comma(0)
}

func doThen() {
	offset := pop()
	(*codePtr)[offset] = byte(codePos() - offset - 1)
}

func doElse() {
	comma(OP_BRANCH)
	doBegin()
	comma(0)
	swap()
	doThen()
}

func doColon() {
	name := word()
	if _, ok := words[name]; ok {
		fmt.Println("redefined:", name)
	}
	if toFlash {
		codePtr = &flashCode
	} else {
		codePtr = &ramCode
	}
	defName = name
	defValue = codePos()
}

func doSemicolon() {
	if defName != "" {
		words[defName] = defValue
		comma(OP_EXIT)
		codePtr = &nowCode
		defName = ""
	} else {
		fmt.Println("';' ignored")
	}
}

func doWords() {
	fmt.Print("FLASH:")
	for k, v := range words {
		if v < 0 {
			fmt.Print(" ", k)
		}
	}
	fmt.Println()
	fmt.Print("RAM:")
	for k, v := range words {
		if v >= 0 {
			fmt.Print(" ", k)
		}
	}
	fmt.Println()
}

func skipInputTo(ch byte) {
	var b [1]byte
	for {
		_, err := io.ReadFull(input, b[:1])
		if err != nil || b[0] == ch || b[0] == '\n' {
			break
		}
	}
}

func saveHex(name string, data []byte) {
	fd, err := os.Create(name)
	check(err)
	defer fd.Close()

	for i := 0; i < len(data); i += 16 {
		chunk := data[i:]
		if len(chunk) > 32 {
			chunk = chunk[:32]
		}
		addr := FLASH_BASE + i
		sum := len(chunk) + (addr >> 8) + addr
		for _, b := range chunk {
			sum += int(b)
		}
		sum = -sum & 0xFF
		fmt.Fprintf(fd, ":%02X%04X00%02X%02X\n", len(chunk), addr, chunk, sum)
	}
}

func connect(port string) *connection {
	opt := rs232.Options{BitRate: 115200, DataBits: 8, StopBits: 1}
	target, err := rs232.Open(port, opt)
	check(err)

	ch := make(chan []byte)

	go func() {
		var buf [100]byte
		for {
			n, err := target.Read(buf[:])
			if err != nil {
				break
			}
			ch <- buf[:n]
		}
	}()

	pr, pw := io.Pipe()

	go func() {
		for {
			select {
			case data := <-ch:
				pw.Write(data)
			case <-quitChan:
				pw.Close() // this will stop the scanner, yeay!
				return
			}
		}
	}()

	ln := make(chan string)

	go func() {
		scanner := bufio.NewScanner(pr)
		for scanner.Scan() {
			ln <- scanner.Text()
		}
	}()

	return &connection{target, ln, ch}
}

type connection struct {
	*rs232.Port
	lines chan string
	bytes chan []byte
}

func (c *connection) SendAndWait(cmd string, expectList ...string) {
	c.Write([]byte(cmd + "\r\n"))
	for _, expect := range expectList {
		select {
		case reply := <-c.lines:
			if reply != expect {
				log.Panicln(reply, expect, cmd)
			}
		case <-time.After(250 * time.Millisecond):
			panic("timeout!")
		}
	}
}

func (c *connection) Identify() int {
	// TODO: this is the wrong place, needs to move higher up
	// defer func() {
	//     if e, ok := recover().(error); ok {
	//         err = e
	//     }
	// }()

	c.SetRTS(true) // keep RTS on for ISP mode
	c.SetDTR(true) // pulse DTR to reset
	c.SetDTR(false)
	c.SetRTS(false)

	c.SendAndWait("?", "Synchronized")
	c.SendAndWait("Synchronized", "Synchronized", "OK")
	c.SendAndWait("12000", "12000", "OK")
	c.SendAndWait("A 0", "A 0", "0")

	c.SendAndWait("J", "0")
	id, err := strconv.Atoi(<-c.lines)
	check(err)

	return id
}

func (c *connection) Program(startAddress int, data []byte) chan int {
	const sectorSize = 1024
	const pageSize = 64

	for len(data)%pageSize != 0 {
		data = append(data, 0xFF)
	}
	firstPage := startAddress / pageSize
	lastPage := firstPage + len(data)/pageSize - 1

	for len(data)%sectorSize != 0 {
		data = append(data, 0xFF)
	}
	firstSector := startAddress / sectorSize
	lastSector := firstSector + len(data)/sectorSize - 1

	c.SendAndWait("U 23130", "0") // unlock for programming

	// erase entire range, as 1024-byte sectors
	c.SendAndWait(fmt.Sprint("P ", firstSector, lastSector), "0") // prepare
	c.SendAndWait(fmt.Sprint("E ", firstSector, lastSector), "0") // erase

	r := make(chan int)
	go func() {
		defer close(r)
		// program in 64-byte pages (sectors won't fit in the LPC810's RAM)
		for page := firstPage; page <= lastPage; page++ {
			const RAM_ADDR = 0x10000300
			// write one page of data to RAM
			offset := (page - firstPage) * pageSize
			c.SendAndWait(fmt.Sprint("W ", RAM_ADDR, pageSize), "0")
			c.Write(data[offset : offset+pageSize])
			// prepare and copy the data to flash memory
			sector := (page * pageSize) / sectorSize
			c.SendAndWait(fmt.Sprint("P ", sector, sector), "0")
			destAddr := page * pageSize
			c.SendAndWait(fmt.Sprint("C ", destAddr, RAM_ADDR, pageSize), "0")
			r <- (page - firstPage) + 1
		}
	}()
	return r
}
