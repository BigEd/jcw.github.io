// Forthy, a tethered Forth-like interpreter -jcw, 2014

#include "LPC8xx.h"
#include "uart.h"

#define RAM_SIZE    512 // must be even, low 255 bytes can be set from packet
#define CMD_SIZE    100 // the top of RAM is used for incoming commands
#define STACK_SIZE  64  // max 256, dpix and rpix must fit in a uint8_t
#define STACK_BASE  1   // entries below this are used for system variables

#define FLASH_BASE  ((const uint8_t*) 0x0800) // start of flash-based code
#define FLASH_SIZE  0x0800

uint8_t ram [RAM_SIZE];
int32_t stacks [STACK_SIZE];

#define base *((uint8_t*) stacks + 0)   // number base
#define mode *((uint8_t*) stacks + 1)   // interpreter mode
#define rpix *((uint8_t*) stacks + 2)   // return stack index
#define dpix *((uint8_t*) stacks + 3)   // data stack index

static uint8_t rdb () {
    while (true) {
        int ch = uart0RecvChar();
        if (ch >= 0)
            return ch;
    }
}

static void prc (char c) {
    if (c == '\n')
        uart0SendChar('\r');
    uart0SendChar(c);
}

static void pru (uint32_t i) {
    if (i >= base)
        pru(i / base);
    int n = i % base + '0';
    if (n > '9')
        n += 7;
    prc(n);
}

static void prn (int i) {
    if (i < 0) {
        i = -i;
        prc('-');
    }
    pru(i);
    prc(' ');
}

static void initVars () {
    base = 10;
    mode = 0;
    rpix = STACK_SIZE - 1;
    dpix = STACK_BASE;
}

static void copyStr (const uint8_t* pc, int dest) {
    int num = pc[-1];
    while (--num >= 0)
        ram[dest++] = *pc++;
}

static void run () {
    const uint8_t *pc = ram + RAM_SIZE - CMD_SIZE;
    int32_t *dp = stacks + dpix;
    int32_t *rp = stacks + rpix + 1;
    int32_t top = *dp, x;
    while (true) {
        uint8_t op = *pc++;
        switch (op) {
            case 0: // return
                if (rp >= stacks + STACK_SIZE) {
                    *dp = top;
                    dpix = dp - stacks;
                    rpix = rp - stacks - 1;
                    return; // will drop back to listen mode
                }
                pc = (uint8_t*) *rp++;
                break;
            case 1: // report pc, dp, and rp to the serial port
                prn(pc - ram); prn(dp - stacks); prn(rp - stacks); break;
            case 2: *dp++ = top; break; // dup
            case 3: top = *--dp; break; // drop
            case 4: *dp++ = top; top = *rp++; break; // r>
            case 5: *--rp = top; top = *--dp; break; // >r
            case 6: *dp++ = top; top = (int8_t) *pc++; break; // lit1
            case 7: // lit4
                *dp++ = top;
                top = pc[0] | (pc[1] << 8) | (pc[2] << 16) | (pc[3] << 24);
                pc += 4;
                break;
            case 8: top = - top; break; // negate
            case 9: top = ~ top; break; // not
            case 10: top += *--dp; break; // +
            case 11: top -= *--dp; break; // -
            case 12: top *= *--dp; break; // *
            case 13: top /= *--dp; break; // /
            case 14: top &= *--dp; break; // and
            case 15: top |= *--dp; break; // or
            case 16: top ^= *--dp; break; // xor
            case 17: top <<= *--dp; break; // <<
            case 18: top >>= *--dp; break; // >>
            case 19: top >>= 31; break; // 0<
            case 20: top = top ? 0 : ~0; break; // 0=
            case 21: *dp++ = top; top = dp[-2]; break; // over
            case 22: x = top; top = dp[-1]; dp[-1] = x; break; // swap
            case 23: --dp; break; // nip
            case 24: *dp = dp[-1]; dp[-1] = top; ++dp; break; // tuck
            case 25: top = dp[-1-top]; break; // pick
            case 26: prc(top); top = *--dp; break; // prc
            case 27: pru(top); top = *--dp; break; // pru
            case 28: prn(top); top = *--dp; break; // prn
            case 29: *dp++ = top; top = rdb(); break; // rdb
            case 30: // lits
                *dp++ = top; x = *pc++; top = (int32_t) pc; pc += x; break;
            case 31: top = *(const int32_t*) (top & ~3); break; // @
            case 32: *(int32_t*) (top & ~3) = *--dp; top = *--dp; break; // !
            case 33: top = *(const uint8_t*) top; break; // c@
            case 34: *(uint8_t*) top = *--dp; top = *--dp; break; // c!
            case 35: // copy counted string
                copyStr((uint8_t*) *--dp, top); top = *--dp; break;
            case 36: // 0branch
                x = (int8_t) *pc++; if (top == 0) pc += x; top = *--dp; break;
            case 37: x = (int8_t) *pc++; pc += x; break; // branch
            case 38: base = 10; break; // decimal
            case 39: base = 16; break; // hex
            
            default: { // not a primitive op, so we'll call it as compiled word
                x = ((op << 8) | *pc++) - 65536; // always a negative offset
                *--rp = (int32_t) pc;
                pc += x;
                // TODO hack to calculate the proper flash address
                if (pc < ram && (const uint8_t*) *rp >= ram)
                    pc += FLASH_BASE + FLASH_SIZE - ram;
            }
        }
    }
}

static bool readPacket () {
    int num = rdb(), check = 0;
    uint8_t* cmd = ram + RAM_SIZE - CMD_SIZE;
    for (int i = 0; i < num; ++i) {
        cmd[i] = rdb();
        check ^= cmd[i];
    }
    cmd[num-1] = 0; // replace checksum with return opcode
    return check == 0;
}

int main () {
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);

    initVars();
    while (true) {
        prc('O'); prc('K'); prc(' ');
        char c = rdb();
        if (c == 'p' && readPacket())
            run();
        else {
            prn(c); prc('?'); prc('\n');
        }
    }
}
