// Filling flash memory with some simple float operations.

#include "LPC8xx.h"
#include "uart.h"

static void prc (char c) {
    if (c == '\n')
        uart0SendChar('\r');
    uart0SendChar(c);
}

static void pru (uint32_t i) {
    if (i >= 10)
        pru(i / 10);
    int n = i % 10 + '0';
    if (n > '9')
        n += 7;
    prc(n);
}

static void prf (double d, int w, int p) {
    w -= p;
    if (p > 0)
        w -= 1;
    pru((int) d);
    d -= (int) d;
    if (p > 0) {
        prc('.');
        while (--p >= 0) {
            d *= 10;
            if (p == 0)
                d += 0.5;
            pru((int) d % 10);
        }
    }
}

int main () {
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);

    prf(123.45, 9, 3); prc('\n');
    prf(123.45, 9, 2); prc('\n');
    prf(123.45, 9, 1); prc('\n');
    prf(123.45, 9, 0); prc('\n');

    while (true)
        __asm("nop\n");
}
