// Blink the LED attached between LED and VCC.

#include "LPC8xx.h"

#define LED 7 // 13

// waste some time by doing nothing for a while
void delay (int count) {
    while (--count >= 0)
        __asm("nop\n");
}

int main () {
    // define LED as an output pin
    LPC_GPIO_PORT->DIR0 |= 1 << LED;

    while (true) {
        // toggle the LED pin
        LPC_GPIO_PORT->NOT0 = 1 << LED;
        // slow down so the blinking becomes visible
        delay(1000000);
    }
}
