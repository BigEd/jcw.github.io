// Blink an LED and receive RF69 packets using mugs.

#include <stdio.h>
#include "../../t-base/mug/mugs.h"

#include "LPC8xx.h"
#include "uart.h"

#include "spi.h"
#include "../../t-radio/rf69/radio.h"

uint8_t rxBuf[66];

class RadioMug : public Mug {
public:
    virtual int numInlets () const { return 0; }
    virtual int numOutlets () const { return 1; }

    virtual void trigger (int idx) {
        timeout(1000);

        printf("check\n");
        int len = RF69::receive(rxBuf, sizeof rxBuf);
        if (len >= 0) {
            printf("OK ");
            for (int i = 0; i < len; ++i)
                printf("%02x", rxBuf[i]);
            printf(" (%d%s%d)\n",
                        RF69::rssi, RF69::afc < 0 ? "" : "+", RF69::afc);
        }
    }

    Outlet packet;
};

// mugs used in this example
EventMug eventG;
RadioMug radioG;

// list of all the mugs, to define their index
Mug* const Mug::instances[] = {
    &eventG,
    &radioG,
    0
};

// wire connections, one set for each outlet
uint8_t const Mug::wiring[] = {
    // 0 eventG 1
    0, // 1 radioG
};

// pre-defined values, sent to inlets at init time
Mug::Preset const Mug::presets[] = {
    { 1, 0, Value::Nil, 0 }, // radioG fake timeout, to start things up
    { 0, 0, Value::Nil, 0 }
};

int main () {
    // set up the UART on pins 0 and 4, running at 115200 baud
    LPC_SWM->PINASSIGN0 = 0xFFFF0004UL;
    uart0Init(115200);

    printf("\n[e4-rfmug]\n");
    
    // sck 6, miso 11, mosi 9, ssel 8, irq 8
    // sck 12, miso 15, mosi 14, ssel 13, irq 8
    /* Pin Assign 8 bit Configuration */
    /* SPI0_SCK */
    LPC_SWM->PINASSIGN3 = 0x06FFFFFFUL; 
    /* SPI0_MOSI */
    /* SPI0_MISO */
    /* SPI0_SSEL */
    LPC_SWM->PINASSIGN4 = 0xFF080B09UL;

    RF69::init(8683, 42, 1);
    RF69::encrypt("mysecret");
    RF69::txPower(0); // minimal

#if 0
    printf("    Mug %2d b\n", (int) sizeof (Mug));
    printf("  Value %2d b\n", (int) sizeof (Value));
    printf("   Type %2d b\n", (int) sizeof (Value::Type));
    printf("  Inlet %2d b\n", (int) sizeof (Inlet));
    printf(" Outlet %2d b\n", (int) sizeof (Outlet));
    printf(" eventG %2d b\n", (int) sizeof eventG);
    printf(" metroG %2d b\n", (int) sizeof metroG);
    printf("pinOutG %2d b\n", (int) sizeof pinOutG);
    printf("\n");
#endif

    Mug::init();
    eventG.Run();
}
