# greddy

> Initially generated with `lein new figwheel greddy -- --om`  
> Adapted to render a small SVG scene -jcw

Experiments with graph editing.

## Overview

An exploration into graph editing, SVG, ClojureScript, Om, and Figwheel.

## Setup

> First, install [leiningen](http://leiningen.org), which uses Java.
> (on Mac OSX, use: `brew install leiningen`)

To get an interactive development environment run:

    lein figwheel

and open your browser at [localhost:3449](http://localhost:3449/).
This will auto compile and send all changes to the browser without the
need to reload. After the compilation process is complete, you will
get a Browser Connected REPL. An easy way to try it is:

    (js/alert "Am I connected?")

and you should see an alert in the browser window.

To clean all compiled files:

    lein clean

To create a production build run:

    lein cljsbuild once min

And open your browser in `resources/public/index.html`. You will not
get live reloading, nor a REPL. 

## License

Copyright © 2015 Jean-Claude Wippler
Distributed under the MIT Public License.
