;ns ^:figwheel-always greddy.core
(ns greddy.core
    (:require [sablono.core :as sab :refer-macros [html]]
              [om.core :as om :include-macros true]
              [greddy.util :as gu]))

(enable-console-print!)
;(println "------------------------------------------------------------------")
(println (gu/check))

(defonce app-state (atom {:title "Hello world!" :xpos 20 :ypos 30}))

(defn main [app owner] 
  (reify
    om/IWillMount
    (will-mount [_]
      (let [id (js/setInterval #(om/transact! app :xpos inc) 1000)]
        (om/set-state! owner :timerId id)))
    om/IWillUnmount
    (will-unmount [_]
      (js/clearInterval (om/get-state owner :timerId)))
    om/IRender
    (render [_]
      (html
        [:div
         [:h3 (:title app)]
         [:svg {:width "100%" :height 200}
          [:rect {:width "100%" :height "100%"
                  :fill "white" :stroke "green"}]
          [:rect {:x (:xpos app) :y (:ypos app) :width 100 :height 70
                  :onClick (fn [e] (om/transact! app :ypos #(+ % 5)))
                  :style {:cursor "move"}}]
          [:rect {:x 30 :y (- (:ypos app) 10) :width 50 :height 90 :fill "red"
                  :onClick (fn [e]
                             (println (.-target.y.baseVal.value e))
                             (println (. e -target.y.baseVal.value)))
                  :style {:cursor "move"}}]
          ]
         [:p "x: " (:xpos app) " y: " (:ypos app) " - click on the box!"]] ))))

(om/root main app-state {:target (. js/document (getElementById "app"))})

(defn on-js-reload []
  ;; optionally touch your app-state to force rerendering depending on
  ;; your application
  ;; (swap! app-state update-in [:__figwheel_counter] inc)
)
