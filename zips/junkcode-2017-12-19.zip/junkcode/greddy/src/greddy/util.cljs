(ns greddy.util
  (:require
    [cljs.core.async :as async :refer [<! >! chan close! put! alts! timeout]])
  (:require-macros [cljs.core.async.macros :refer (go go-loop)]))

(enable-console-print!)
(defn check [] "ok")

; reload won't clean up the running go code, so they'll add up ...
#_(go
    (while true 
      (<! (timeout 3000))
      (println "3s")))

(def metro 
  {:name "metro"
   :ins  [500] 
   :outs [:bang]})

(defn metro-handler [{:keys [out]}]
  (go 
    (while true 
      (<! (timeout 500))
      (out 0 :bang))))

(def log {:name "log"})

(defn log-handler [{:keys [events]}]
  (go 
    (while true 
      (let [msg (<! events)]
        (println "log:" msg)))))

(def my-circuit
  {:gadgets [metro log log]
   :wires #{[0 0 1 0] [0 0 2 0]}
   :inputs []
   :outputs []})

(def native-env {:metro metro-handler 
                 :log   log-handler})

(println "my-circuit" my-circuit)

(defn wiring-channels
  "Construct the channels used as wiring between gadgets"
  [wires]
  (reduce (fn [acc wire]
            (let [c (gensym)
                  [from-gadget from-output to-gadget to-input] wire 
                  outs (get-in acc [from-gadget :outs from-output])
                  ins (get-in acc [to-gadget :ins to-input])]
              (-> acc 
                  (assoc-in [from-gadget :outs from-output] (conj outs c))
                  (assoc-in [to-gadget :ins to-input] (conj ins c)))))
          {}
          wires))

#_(def xx 
    {0 {:ins [c1, c2, c3]
        :outs [c1, c3]}
     1 {:ins [c2, c3]
        :outs []}})

(def wiring (wiring-channels (:wires my-circuit)))
(println "wiring" wiring)

(defn instantiate
  "Instantiate one gadget or circuit"
  [{:keys [ins outs] :as gadget}]
  #_(println "INST:" ins outs gadget)
  (assoc gadget :ins ins :outs ins))

(defn circuit-instance
  "Construct an actual circuit instance from its definition"
  [{:keys [gadgets inputs outputs]} env]
  {:name (str (gensym "circ"))
   :gadgets (map instantiate gadgets)})

(def circ (circuit-instance my-circuit native-env))
(println "circ" circ)

(defn connect-wires
  "Connect the wires between the gadgets"
  [circ wires]
  circ)
