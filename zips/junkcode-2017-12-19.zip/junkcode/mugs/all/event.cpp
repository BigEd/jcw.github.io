#include "event.h"

void EventMug::Run () {
    while (true) {
        int n = 2400 * nextTimer();
        while (--n >= 0)
            __asm("");
    }
}
