#include <mug.h>

class EventMug : public Mug {
public:
    virtual void trigger (int) {}

    virtual int numInlets () const { return 0; }
    virtual int numOutlets () const { return 0; }

    void Run ();
};
