#include <mugs.h>

EventMug eventG;
PrintMug printG;
FeedMug feedG;

Net Net::nets [3];

Mug* const Mug::instances[] = {
    &eventG,
    &printG,
    &feedG,
    0
};

uint8_t const Net::wiring[] = {
    0,
    1, 1, 0, 2, 1, 0,
    0
};

Mug::Preset const Mug::presets[] = {
    { 0, 0, 0 }
};

int main () {
    Mug::init();
    feedG = "hello";
    return 0;
}
