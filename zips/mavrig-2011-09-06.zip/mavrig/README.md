Mavrig was an experimental micro application framework for Tcl.

*Shelved, see <http://equi4.com/mavrig.org/>*
