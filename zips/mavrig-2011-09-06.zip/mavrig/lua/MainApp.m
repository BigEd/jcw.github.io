//
//  MainApp.m
//  wapp
//
//  Created by Jean-Claude Wippler on 18/02/2008.
//  Copyright Equi 4 Software 2008. All rights reserved.
//

#import "MainApp.h"

LUA_API int luaopen_vq_core (lua_State *L);

@implementation MainApp

// convert an Obj-C object to a value pushed on the Lua stack
static void objToLua (lua_State *L, id anObj)
{
    if (anObj == nil || [anObj isKindOfClass: [WebUndefined class]])
        lua_pushnil(L);
    else if ([anObj isKindOfClass: [NSNumber class]])
        lua_pushnumber(L, [anObj doubleValue]);
    else if ([anObj isKindOfClass: [NSString class]])
        lua_pushstring(L, [anObj UTF8String]);
    else if ([anObj isKindOfClass: [NSArray class]]) {
        lua_createtable(L, 0, [anObj count]);
        int i = 0;
        for (id elt in anObj) {
            objToLua(L, elt);
            lua_rawseti(L, -2, ++i);
        }
    } else if ([anObj isKindOfClass: [NSDictionary class]]) {
        lua_newtable(L);
        for (id elt in [anObj keyEnumerator]) {
            objToLua(L, elt);
            objToLua(L, [anObj objectForKey: elt]);
            lua_rawset(L, -3);
        }
    } else
        lua_pushlightuserdata(L, anObj);
}

// convert the top of the Lua stack to an Obj-C object
static id luaToObj (lua_State *L)
{
    switch (lua_type(L, -1)) {
        case LUA_TNIL:
            return [NSNull null];
        case LUA_TNUMBER:
            return [NSNumber numberWithDouble: lua_tonumber(L, -1)];
        case LUA_TSTRING:
            return [NSString stringWithUTF8String: lua_tostring(L, -1)];
        case LUA_TTABLE: {
            // TODO: always ued as list for now, try to detect hashes as well?
            int i, n = lua_objlen(L, -1);
            NSMutableArray* anArray = [NSMutableArray arrayWithCapacity: n];
            for (i = 0; i < n; ++i) {
                lua_rawgeti(L, -1, i+1);
                [anArray addObject: luaToObj(L)];
                lua_pop(L, 1);
            }
            return anArray;
        }
        case LUA_TLIGHTUSERDATA:
            return lua_touserdata(L, -1);
    }
    NSLog(@"LTO? %d", lua_type(L, -1));
    return nil;
}

// function wapp.atPos (obj,num)
static int atPos_Lua (lua_State *L)
{
    id anObj = lua_touserdata(L, 1);
    int idx = luaL_checkinteger(L, 2);
    objToLua(L, [anObj webScriptValueAtIndex: idx]);
    return 1;
}

// function wapp.atKey (obj,str)
static int atKey_Lua (lua_State *L)
{
    id anObj = lua_touserdata(L, 1);
    id key = luaToObj(L);
    objToLua(L, [anObj valueForKey: key]);
    return 1;
}

// function wapp.showHtml (text)
static int showHtml_Lua (lua_State *L)
{
    size_t      len;
    void*       ptr = (void*) lua_tolstring(L, 1, &len);
    WebFrame* frame = lua_touserdata(L, lua_upvalueindex(1));
    NSURL*     base = lua_touserdata(L, lua_upvalueindex(2));
    NSData*    data = [NSData dataWithBytesNoCopy: ptr
                                           length: len
                                     freeWhenDone: NO];
    
    [frame loadData: data MIMEType: @"text/html" textEncodingName: @"utf-8"
            baseURL: base];
    return 0;
}

// function wapp.javaScript (script)
static int javaScript_Lua (lua_State *L)
{
    size_t       len;
    void*        ptr = (void*) lua_tolstring(L, 1, &len);
    WebView*    view = lua_touserdata(L, lua_upvalueindex(1));
    NSString* script = [[NSString alloc] initWithBytesNoCopy: ptr
                                                      length: len
                                                    encoding: NSUTF8StringEncoding
                                                freeWhenDone: NO];
    
    objToLua(L, [view stringByEvaluatingJavaScriptFromString: script]);
    return 1;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    L = luaL_newstate();
    luaL_openlibs(L);

    lua_getglobal(L, "package");                // p
    lua_getfield(L, -1, "loaded");              // p l
    lua_pushcfunction(L, luaopen_vq_core);      // p l f
    lua_call(L, 0, 1);                          // p l m
    lua_setfield(L, -2, "vq.core");             // p l
    lua_pop(L, 2);                              // <>

    NSBundle* main = [NSBundle mainBundle];
    NSString* path = [[main resourcePath] stringByAppendingString: @"/"];
    baseUrl = [[NSURL fileURLWithPath: path] retain];

    lua_newtable(L); // wapp
    
    objToLua(L, path);
    lua_setfield(L, -2, "path");

    lua_pushcfunction(L, atPos_Lua);
    lua_setfield(L, -2, "atPos");
    
    lua_pushcfunction(L, atKey_Lua);
    lua_setfield(L, -2, "atKey");
    
    lua_pushlightuserdata(L, [webview mainFrame]);
    lua_pushlightuserdata(L, baseUrl);
    lua_pushcclosure(L, showHtml_Lua, 2);
    lua_setfield(L, -2, "showHtml");
    
    lua_pushlightuserdata(L, webview);
    lua_pushcclosure(L, javaScript_Lua, 1);
    lua_setfield(L, -2, "javaScript");
    
    lua_setglobal(L, "wapp");

    [[webview windowScriptObject] setValue:self forKey:@"wapp"];
    
    NSString* script = [path stringByAppendingString: @"init.lua"];
    if (luaL_dofile(L, [script UTF8String])) {
        NSLog(@"ADFL error: %s", lua_tostring(L, -1));
        lua_pop(L, 1);
    }
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApp
{
    return YES;
}

- (void)applicationWillTerminate:(NSNotification *)aNotification
{
    lua_close(L);
}

- (id)invokeUndefinedMethodFromWebScript:(NSString *)name withArguments:(NSArray *)args
{
    // TODO: try to optimize later, this does two string interns + hash lookups
    lua_getglobal(L, "wapp");
    lua_getfield(L, -1, [name UTF8String]);
    for (id elt in args)
        objToLua(L, elt);
    if (lua_pcall(L, [args count], 1, 0)) {
        NSLog(@"IUMFWS? %s", lua_tostring(L, -1));
        lua_pop(L, 1);
        return nil;
    }
    id result = luaToObj(L);
    lua_pop(L, 2);
    return result;
}

@end

@implementation MainApp (WebResourceLoadDelegate)

// called when internal urls are requested, e.g. images

- (NSURLRequest *)webView:(WebView *) sender 
                 resource:(id) identifier 
          willSendRequest:(NSURLRequest *) request 
         redirectResponse:(NSURLResponse *) redirectResponse
           fromDataSource:(WebDataSource *) dataSource
{
    //NSString *path = [[request URL] relativePath];
    //NSLog(@"WRLD %@", path);
    return request;
}

@end
