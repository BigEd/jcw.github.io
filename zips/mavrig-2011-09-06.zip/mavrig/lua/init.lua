--
--  init.lua
--  wapp
--
--  Created by Jean-Claude Wippler on 22/02/2008.
--  Copyright Equi 4 Software 2008. All rights reserved.
--

module('wapp', package.seeall)

package.path = path..'Code/?.lua'
package.cpath = ''

loadfile(path .. 'Code/vq.lua')()

function showPage (tail)
  local f = assert(io.open(path..'Html/'..tail))
  local text = f:read('*a')
  f:close()
  showHtml(text)
end

print('JS:', javaScript('1+2'))

function twice (n)
  return 2*n
end

function demotable ()
  return vq({meta='A,B:I,C';'a',1,'b','aa',22,'cc','aaa',333,'ddd'}):html()
end

function showdict (t)
  print(t)
  table.foreach(t, print)
end

showPage 'index.html'
