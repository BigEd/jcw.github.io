#!/usr/bin/env tclkit85
# custom startup file for the Mavrig website
# jcw, 2008-05-05

cd [file dir [info script]]

# use timestamped logging
proc tclLog {msg} { Log: {$msg} }

# load Rig and other modules next to it (just server.tcl in this app)
source Rig.tcl

# stop a previous instance if it is still running
catch {
	#TODO: do this gracefully via a signal file for a less disruptive approach
	set pid [Rig readfile pid.txt]
	if {$pid ne ""} {
		exec kill $pid
		Log: {process $pid killed}
	}
}

# write current process id to file
Rig writefile pid.txt [pid]

# only use a few specific modules in this app, no auto-loading
Rig loader Httpd  ./contrib/jcw/0.x/Httpd.tcl
Rig loader Render ./contrib/jcw/0.x/Render.tcl
Rig loader Web    ./contrib/jcw/0.x/Web.tcl
Rig loader Wikify ./contrib/jcw/0.x/Wikify.tcl

# the main application logic
Rig notify main.Init $argv
Rig notify main.Run
if {![info exists Rig::exit]} { vwait Rig::exit }
Rig notify main.Done $Rig::exit
exit $Rig::exit
