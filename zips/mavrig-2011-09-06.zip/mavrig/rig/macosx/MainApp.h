//
//  MainApp.h
//  wapp
//
//  Created by Jean-Claude Wippler on 18/02/2008.
//  Copyright Equi 4 Software 2008. All rights reserved.
//

@interface MainApp : NSObject {
    IBOutlet WebView *webview;
    NSURL *baseUrl;
}

@end
