//
//  MainApp.m
//  wapp
//
//  Created by Jean-Claude Wippler on 18/02/2008.
//  Copyright Equi 4 Software 2008. All rights reserved.
//

#import "MainApp.h"

@implementation MainApp

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSBundle* main = [NSBundle mainBundle];
    NSString* path = [[main resourcePath] stringByAppendingString: @"/"];
    baseUrl = [[NSURL fileURLWithPath: path] retain];

    [[webview windowScriptObject] setValue:self forKey:@"wapp"];
    
	WebFrame* frame = [webview mainFrame];
    NSData*    data = [NSData dataWithContentsOfFile: @"/Users/jcw/w/wapp/main.m"];
    
    [frame loadData: data MIMEType: @"text/plain" textEncodingName: @"utf-8"
            baseURL: baseUrl];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApp
{
    return YES;
}

- (void)applicationWillTerminate:(NSNotification *)aNotification
{
}

- (id)invokeUndefinedMethodFromWebScript:(NSString *)name withArguments:(NSArray *)args
{
    return nil;
}

@end

@implementation MainApp (WebResourceLoadDelegate)

// called when internal urls are requested, e.g. images

- (NSURLRequest *)webView:(WebView *) sender 
                 resource:(id) identifier 
          willSendRequest:(NSURLRequest *) request 
         redirectResponse:(NSURLResponse *) redirectResponse
           fromDataSource:(WebDataSource *) dataSource
{
    //NSString *path = [[request URL] relativePath];
    //NSLog(@"WRLD %@", path);
    return request;
}

@end
