% REQ H Content-Type text/javascript
% Web sendfile [REQ] [Rig home]/site/j/jquery-1.2.3.pack.js
