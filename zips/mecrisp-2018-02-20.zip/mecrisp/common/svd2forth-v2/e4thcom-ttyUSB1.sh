#!/bin/sh
e4thcom -t mecrisp -d ttyUSB1 -b B115200	| tee e4thcom.log
