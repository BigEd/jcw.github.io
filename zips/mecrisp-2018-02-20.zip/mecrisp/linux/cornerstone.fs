
\ As the Linux target works on RAM memory, cornerstone doesn't need to take care of page borders.

: cornerstone ( Name ) ( -- ) <builds does> eraseflashfrom ;
