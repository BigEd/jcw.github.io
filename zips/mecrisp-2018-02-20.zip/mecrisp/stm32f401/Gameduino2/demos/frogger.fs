base @
hex

: frogger-data ( -- )

05000000 GD.c 01000000 GD.c 0801c100 GD.c 0721c100 GD.c 05000001 GD.c
0100e000 GD.c 08002010 GD.c 07004010 GD.c 05000002 GD.c 0101a800 GD.c
08001008 GD.c 07201008 GD.c 05000003 GD.c 0101a840 GD.c 08006030 GD.c
07186030 GD.c 05000004 GD.c 0101b140 GD.c 08001008 GD.c 07080208 GD.c
0101b140 GD.c ffffff2b GD.c 00000004 GD.c 0001b540 GD.c ffffff22 GD.c
00000000 GD.c 9ded9c78 GD.c 47238fcf GD.c 6bdbc715 GD.c 096484d8 GD.c
642bf110 GD.c 09090de2 GD.c b21afc84 GD.c 9961f2b0 GD.c 400fe241 GD.c
2c5607fc GD.c 24021eed GD.c 1120870a GD.c 13fe42d9 GD.c 71007f96 GD.c
3f8905ca GD.c 73466c82 GD.c e61c0d83 GD.c b997b162 GD.c 1eee2b44 GD.c
7eaeae99 GD.c bd55ef5d GD.c ed7b6eaa GD.c fbf7bbb1 GD.c 577719e9 GD.c
f5d557bd GD.c db5555ea GD.c af7772e5 GD.c 99d9cf57 GD.c ce5fc81f GD.c
e6ca220a GD.c 42a857c5 GD.c ae2941e5 GD.c 6e1962d4 GD.c 7d88b39d GD.c
2972cf3d GD.c 16d6a5f7 GD.c b3e41077 GD.c a2aadb13 GD.c f69ac0c9 GD.c
b23dfb05 GD.c 3f6cacef GD.c ed55f6f5 GD.c ed73a44c GD.c 4d4a6451 GD.c
80ef92b9 GD.c 669ffaf5 GD.c 9f8bd53d GD.c 597dae8f GD.c 4c67dbc4 GD.c
c93ed639 GD.c 9c1db281 GD.c c2da459d GD.c 838da0a5 GD.c 1c92ee89 GD.c
40e8cf3f GD.c e9a673e6 GD.c 00000003 GD.c 00000000 GD.c 5862a000 GD.c
87ff2bd0 GD.c fb92bede GD.c 9be8b6fb GD.c c521f3ff GD.c bdcb9f9c GD.c
fa6da292 GD.c 88a152bd GD.c 9f7b85eb GD.c 95ebead6 GD.c cb49d413 GD.c
a2a17bf4 GD.c 7a48514b GD.c b7ddb2a5 GD.c 9e28df4f GD.c fb3d47e7 GD.c
ab2afb42 GD.c f49b5930 GD.c e7e7248b GD.c 97a37cbd GD.c eed95f62 GD.c
e9d6e935 GD.c c2ed7217 GD.c 486a2e71 GD.c afa75bec GD.c 9921c828 GD.c
a5da675f GD.c c2aa1b6f GD.c 58585dd0 GD.c df4eb57d GD.c f66b9ee8 GD.c
6d190cf3 GD.c 5fb54fd4 GD.c 36d37aed GD.c 94ff64fd GD.c ea569bd7 GD.c
b9e7fac7 GD.c a36ce976 GD.c abbf66be GD.c ae96f126 GD.c 7d74fa65 GD.c
6f67ed0c GD.c d578f816 GD.c f5f4fd46 GD.c b69abfd1 GD.c 3fd63f4b GD.c
437137ab GD.c 4eb56639 GD.c 7b3fd23f GD.c e0a7c7e5 GD.c f4bb54f3 GD.c
0a3837cb GD.c 736406d4 GD.c b0fe9f68 GD.c b4fa7fbe GD.c 587edf48 GD.c
1f77ecd2 GD.c aae7e4a9 GD.c 9d9be996 GD.c 1514f98e GD.c 9b6aae7c GD.c
0000003e GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c
00000000 GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c
00000000 GD.c 59b20db0 GD.c bfcccd96 GD.c 0b5d65dd GD.c d47708cf GD.c
7abf70b1 GD.c 09dd8761 GD.c f2fde7f7 GD.c 28761d85 GD.c ddfaebbc GD.c
e732d87a GD.c 8b856e81 GD.c 6675b983 GD.c 8365c307 GD.c 5aedecad GD.c
9ea7d678 GD.c 1970d1d8 GD.c 7763ba27 GD.c 9ce465c2 GD.c 9858ee8c GD.c
a295993c GD.c d68b85ae GD.c d76c1bca GD.c 59c7e4c2 GD.c b8e2c367 GD.c
7d3ee17b GD.c 8f8ac89c GD.c 030b1d17 GD.c 00000000 GD.c 00000000 GD.c
00000000 GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c 00000000 GD.c
00000000 GD.c 00000000 GD.c 00000000 GD.c 11d80000 GD.c 4ebf767b GD.c
d573ffdc GD.c 097abf70 GD.c 85d68aee GD.c b7efa6f0 GD.c 5de16fb9 GD.c
c3d6efd7 GD.c 5fba3d96 GD.c c5c3a6e7 GD.c afdcfec1 GD.c 7ee1d373 GD.c
db33fdcd GD.c a9f59e1e GD.c 5c347627 GD.c d8ee89c6 GD.c b919709d GD.c
dcebf72f GD.c b93c9874 GD.c dcebf72f GD.c ad68b874 GD.c 2d76c1bc GD.c
759c7e4c GD.c bb8e2c36 GD.c d5efee17 GD.c 1d373afd GD.c c1e1ad06 GD.c
2ebb0783 GD.c 3e1956c2 GD.c 08baee18 GD.c d86864db GD.c c8b62175 GD.c
5afb0170 GD.c aee06e4d GD.c 865ed08b GD.c 16cb223b GD.c 1cded505 GD.c
7adc2c66 GD.c d535acfb GD.c 70b8dade GD.c 6fb3ddb1 GD.c b7d898f1 GD.c
4fb9e6c1 GD.c ac8b65f6 GD.c b2cbfed3 GD.c ddd7da4e GD.c 8cfb73f1 GD.c
4662a6ee GD.c be686d77 GD.c 2f9ddd1c GD.c e71e4be7 GD.c 2b0b07b4 GD.c
2c1ddd1d GD.c c84d1cfc GD.c 1b72b0a4 GD.c 6467cff2 GD.c 71e585b4 GD.c
ac12a767 GD.c 2a52372a GD.c e5e52681 GD.c dbe74b0b GD.c a7e7da13 GD.c
71876b88 GD.c 4197f4e9 GD.c 5a5b1eda GD.c 86ad7fe7 GD.c 7b75ffb8 GD.c
76dbf5e3 GD.c cd18cbff GD.c 31a75e3e GD.c b8f8dadf GD.c dbe4ebe7 GD.c
5cffeb43 GD.c bf7ff5aa GD.c 3ffaa77d GD.c 43ff9cc9 GD.c b5fe532b GD.c
eb5c9de9 GD.c 5affd29f GD.c 63ade4ff GD.c 86e7fadf GD.c 66db5459 GD.c
cf8339c2 GD.c 987829e4 GD.c 566f96fb GD.c cf83428b GD.c cc8ee6cc GD.c
05b349a6 GD.c d791affb GD.c 5f2e9fe7 GD.c 5136fb33 GD.c 6cff497f GD.c
a1e4c593 GD.c c9c8a7fb GD.c e4a5b343 GD.c 82fa98ee GD.c bba339eb GD.c
97997d2c GD.c 177a64db GD.c 5cd9d36f GD.c 5895a6b8 GD.c 4ebe9e99 GD.c
aebfca9e GD.c f1f6757c GD.c e51ca1da GD.c 3bb975f9 GD.c 57705b7f GD.c
c6247b46 GD.c 3dab85c0 GD.c b4b92ebf GD.c 63b17c81 GD.c 3abe56b9 GD.c
d9fad4fb GD.c 1fefad4c GD.c efbf3adc GD.c dba8fd84 GD.c e9fabaf2 GD.c
f9d3f30a GD.c f0b90ca9 GD.c a0b83664 GD.c c86584cd GD.c 73332749 GD.c
3327b5cc GD.c 3a9f9f23 GD.c 2134d3a9 GD.c 797d7e9e GD.c e563fcb3 GD.c
beafb3ab GD.c aacc767e GD.c 78d635ef GD.c 1a7e12ef GD.c fee9c772 GD.c
ba125743 GD.c 2babf2a6 GD.c b38b9d1f GD.c 790d342d GD.c f5e5f57d GD.c
dfe937f9 GD.c f1b6fb29 GD.c cb801a5e GD.c 262c1264 GD.c 5c6631e1 GD.c
1b1a7b34 GD.c 9ed39c79 GD.c 19a95a9f GD.c ed1cfd6f GD.c 1b724f38 GD.c
46e7cff2 GD.c 25771a55 GD.c 6cd6647c GD.c b1bb93a8 GD.c ae9dcb5d GD.c
086d7408 GD.c 9870e9a5 GD.c 8c3b5c5f GD.c 0cbfa74b GD.c d2d8f6d2 GD.c
356bff3a GD.c dbaffdc4 GD.c b6dfaf1b GD.c 68c65ffb GD.c 8d3af1f6 GD.c
6dde96f9 GD.c f97ad2e8 GD.c 3ffad0f6 GD.c dffd6a97 GD.c fea9df6f GD.c
399bdfcf GD.c bfca491d GD.c ad373bfe GD.c 6bff4a7f GD.c 8eb793fd GD.c
009feb7d GD.c 00000000 GD.c c0000000 GD.c a8ae13a3 GD.c 12b431e1 GD.c
a09dacc2 GD.c 75721335 GD.c b0bc7144 GD.c c2eeb352 GD.c 69d691cf GD.c
82342b54 GD.c 1935f233 GD.c 74011e45 GD.c 636ab776 GD.c 5691b935 GD.c
bca45425 GD.c 7ce9617c GD.c fcfb427b GD.c 30ed7114 GD.c 32fe9d2e GD.c
6b43db48 GD.c 5affc875 GD.c ebff710d GD.c b7ebc6f6 GD.c 3197feed GD.c
2e440afa GD.c f147cad7 GD.c c9d7cf71 GD.c ffd687b7 GD.c ffeb54b9 GD.c
f54efb7e GD.c 8b26b97f GD.c ff292474 GD.c ae4ef4da GD.c 7fe94ff5 GD.c
d6f27fad GD.c 13fd6fb1 GD.c 00000000 GD.c 00000000 GD.c 2ddff420 GD.c
7cf8d285 GD.c f9d4c914 GD.c 3fbf911d GD.c 76fda1db GD.c 3fcbcfca GD.c
09339cbb GD.c 648617cf GD.c 588a78ea GD.c cea4a40d GD.c 9d3498ca GD.c
ea7d3eb6 GD.c 437cfefc GD.c e62a067a GD.c 352347e3 GD.c 3f3754bf GD.c
17fcf768 GD.c 7c0e7e75 GD.c ed4b477e GD.c df5ffdcb GD.c bb952dc9 GD.c
7f926f2f GD.c ec4d7caa GD.c 760f9bab GD.c 399abbb1 GD.c 93523de2 GD.c
b49a63c5 GD.c cf8b8a08 GD.c 6419da7c GD.c a7ac7b3b GD.c 6d0eb54f GD.c
c6be587e GD.c 37f975e4 GD.c ccfd5f2f GD.c 69b62c6e GD.c d3fcc78d GD.c
57db758c GD.c fe6eff73 GD.c 1898fafc GD.c 7363291b GD.c 6af971fb GD.c
6b2937f9 GD.c 0017eabb GD.c 00000000 GD.c 51f8f000 GD.c afe37f37 GD.c
9b67f25f GD.c 5239f5c2 GD.c b5dcff23 GD.c e7c516c8 GD.c 7e1f62af GD.c
5f729372 GD.c 92bfafea GD.c 4daef21a GD.c 9ce6dca1 GD.c f05a2198 GD.c
2cea41d5 GD.c fdca42c0 GD.c 8de7b3fa GD.c abab50ad GD.c 52e67f1f GD.c
8fd5819f GD.c 7eb71d1f GD.c c97ecf93 GD.c 53d5c8d2 GD.c fa9202dc GD.c
5836e1fe GD.c 5ff5b2af GD.c 26b4c3c2 GD.c 5affad90 GD.c dcf20f70 GD.c
dfe016b5 GD.c 016fcbb3 GD.c 0fa5efa1 GD.c 3e85df7d GD.c f6bce4d6 GD.c
0f48fd64 GD.c 28769cd3 GD.c 43c8e7f5 GD.c 66866c8f GD.c c6da4dad GD.c
bab5e8e7 GD.c 9f7036e1 GD.c b33723f0 GD.c 1dc0ebca GD.c deb5dabb GD.c
ab2beb17 GD.c 82634216 GD.c 58e51f6c GD.c eface421 GD.c 0b54f279 GD.c
deeb93a8 GD.c 2527ed97 GD.c 35eb52a7 GD.c 7a0d8e18 GD.c d3fcd20b GD.c
0000bfcc GD.c 00000000 GD.c e5c00000 GD.c fcb77751 GD.c cfbaae3c GD.c
dc777aa5 GD.c c504d885 GD.c 2dfd3fdd GD.c 4b3f3792 GD.c b7bf3d2c GD.c
693f3bb7 GD.c 8e7b5269 GD.c 6aa0aef2 GD.c b7f6d3f9 GD.c 4ffde49d GD.c
eb1dfb83 GD.c 3cd0d04f GD.c bffa88c3 GD.c eabb63b8 GD.c 44aa7a7f GD.c
fa61ffda GD.c cb6ffdd5 GD.c cbeffcef GD.c d74fecea GD.c f7e03b5f GD.c
7def0dc3 GD.c 4baaef6d GD.c b1dde1c7 GD.c 3a7fe1b7 GD.c f7febaef GD.c
aebf5fef GD.c 5fd89bff GD.c 4efb7f57 GD.c 54bec4ba GD.c 0d4fe6d7 GD.c
f2905bd0 GD.c 1a45015c GD.c bb929e7b GD.c 43dc73cf GD.c bad01ef6 GD.c
a7b3f115 GD.c db8619bd GD.c ea4b5fe7 GD.c 9e8ff6ae GD.c d2ebdcb7 GD.c
7c85c350 GD.c dfcf54ef GD.c 11ae5260 GD.c 8fae418e GD.c b37f3f36 GD.c
6d866ff2 GD.c 00003fd6 GD.c 00000000 GD.c d75b419b GD.c 916eafe6 GD.c
bf92b9bf GD.c dcaddabf GD.c da15c95f GD.c bfe8d202 GD.c 5dfb8ee9 GD.c
525cb91e GD.c 6193df72 GD.c 96b971de GD.c abe23f0b GD.c a75ff4f5 GD.c
a7d8a683 GD.c 709fc4a7 GD.c 645e9512 GD.c c7b72417 GD.c f4f8bcbe GD.c
a34f524e GD.c c17fdcfc GD.c c92cef37 GD.c dfce0df4 GD.c 1a66bac0 GD.c
7cfd20db GD.c d1b9ff6a GD.c d6c2f84a GD.c 5283354f GD.c ab7e6584 GD.c
4a45c0cc GD.c 835ec178 GD.c baf3b9d2 GD.c 39ba68a7 GD.c cc4cc99f GD.c
32fccdf0 GD.c b4bf72f9 GD.c b1da27c6 GD.c 5b8da0d4 GD.c b659cec2 GD.c
76e7272b GD.c 474ee4c7 GD.c 9cd61ee6 GD.c e0e5761e GD.c 58a61635 GD.c
bfc2ffc9 GD.c bb7fe797 GD.c cbeffcc5 GD.c 1493ff43 GD.c d11a67fe GD.c
a694aad1 GD.c d0d1f435 GD.c afbe2793 GD.c a69ff0ba GD.c efebb3ee GD.c
5fce6aba GD.c 41b09ed8 GD.c 70b6535c GD.c bd0d1afe GD.c b4916d37 GD.c
f6c917a5 GD.c d194c950 GD.c b237caa8 GD.c af96203a GD.c 5e4d7da8 GD.c
d8968ea5 GD.c b1b2c3c9 GD.c 934c03f7 GD.c b7245de9 GD.c 9787fd86 GD.c
a581b3dd GD.c a8e435d6 GD.c 01ede97a GD.c d8000000 GD.c b17c9f0a GD.c
ec629caa GD.c aa2f93fe GD.c dd8509f0 GD.c 87933146 GD.c 3e3cae2e GD.c
55292971 GD.c 237fe5a8 GD.c fe78e94f GD.c d3c2f3e1 GD.c 33dafa84 GD.c
a3cd57c7 GD.c d71af01d GD.c 4ccf9c8e GD.c 66b8bbfd GD.c f39ff71b GD.c
a27b1e53 GD.c c5c937c5 GD.c 2f3c2b4b GD.c 4d89cfda GD.c 5e4bdbe5 GD.c
55bb73a2 GD.c db96362b GD.c 2af2214d GD.c 2e7b4fcf GD.c ad7feebd GD.c
53feb214 GD.c 3124b21a GD.c 9ceedea9 GD.c e3c15fcc GD.c 4b5f546a GD.c
2650f245 GD.c 53935c6b GD.c 9d8978ea GD.c f49b2c3c GD.c bd3a692e GD.c
aba94b74 GD.c d7d72e2f GD.c 0f7e690f GD.c bdf9cf6b GD.c 8ebe7d8d GD.c
57ad0794 GD.c 92e1fb78 GD.c b6aa7f94 GD.c 3101c6ce GD.c af1d583e GD.c
c67ef377 GD.c bffc2dfa GD.c cc6bea41 GD.c 369e2a7a GD.c 1e850e3e GD.c
06d95292 GD.c ecf294f4 GD.c fe6bcf31 GD.c 1cb42390 GD.c 91ad9ba9 GD.c
bf57b50d GD.c fd4a3fce GD.c 4a6e23fa GD.c e387971a GD.c 2eba9fac GD.c
f427d767 GD.c 294a985e GD.c db8ca1e5 GD.c 1304472e GD.c af71ffb2 GD.c
77569c52 GD.c e30d5f7e GD.c 297072ea GD.c 52c77962 GD.c 00000001 GD.c
e0caac00 GD.c 3f3a7e62 GD.c cc8d498d GD.c 9369696e GD.c 9fe7523c GD.c
9a664e9f GD.c 1cf54906 GD.c 459e548c GD.c cc29654a GD.c 9d46ac19 GD.c
3c75b135 GD.c 56da4794 GD.c 49b012dd GD.c 791d5aea GD.c d70be62a GD.c
fc3cfc12 GD.c d0f32216 GD.c bf6b865a GD.c 2fdf9f8f GD.c 7ad0f46f GD.c
dd5cd9bf GD.c eb141a87 GD.c a4d3479f GD.c c66d523c GD.c 3695d4e9 GD.c
249b0726 GD.c ab78efde GD.c 3f4274d0 GD.c f75f71c9 GD.c c2cf1361 GD.c
9d639bf7 GD.c a8fc85d1 GD.c 0a612e8d GD.c 36c24ed9 GD.c 56f12520 GD.c
fe8e78f1 GD.c 423523bb GD.c 435f23db GD.c 4c7a487a GD.c cb65b31b GD.c
f5229588 GD.c 682bb16e GD.c 32687ddf GD.c cddd866d GD.c b4f36b3a GD.c
9d7b1cfa GD.c fa86cddc GD.c 17dffbb9 GD.c 61c03369 GD.c 276d84f9 GD.c
27bf37c5 GD.c e293fec2 GD.c 05b122fb GD.c 86c653b5 GD.c 3ce276f2 GD.c
fbdf79ad GD.c a6d1bdc6 GD.c a73d02b5 GD.c 5aaf79a6 GD.c ce8f3b06 GD.c
ae3625fd GD.c 6996c55b GD.c dfcf6d42 GD.c ffbff75d GD.c 41f4841d GD.c
ee875df8 GD.c ef397aa9 GD.c e39f9ad9 GD.c 72757a72 GD.c baf26deb GD.c
fa477efc GD.c 229f294d GD.c 1ef9f617 GD.c 010c560f GD.c 5fb45db0 GD.c
e335b8e7 GD.c b9534583 GD.c ff2425fb GD.c eb93a445 GD.c 3c9cdf67 GD.c
726adb2c GD.c b677725e GD.c 7aff2bcb GD.c 1159ff72 GD.c fd6eb3ab GD.c
cbcffdc5 GD.c bb7f95ac GD.c 34f958f2 GD.c 69f6627b GD.c 9bac37ed GD.c
2aacfd74 GD.c 59aeebf7 GD.c 8567b5f9 GD.c d626deac GD.c bb4fd1b1 GD.c
976ffe2f GD.c abb9f43c GD.c 2ff566cf GD.c 78febe7d GD.c c036d9b0 GD.c
c31e90cb GD.c ab397b42 GD.c 7cb28f8f GD.c 95bffbcd GD.c 7d7edaaf GD.c
754cad7d GD.c 681b78e1 GD.c da8fff5a GD.c 63bcb406 GD.c af929675 GD.c
bd6dffe3 GD.c ae475807 GD.c bfbeddd7 GD.c 8f7cd187 GD.c 00004ffb GD.c
80000000 GD.c c1ecc304 GD.c 3afe41e2 GD.c 5986185c GD.c 6ab3ec56 GD.c
6182343f GD.c 69b52f2e GD.c 23bcd97f GD.c 49fed1a9 GD.c 50fb4248 GD.c
76fda227 GD.c adfd4d1c GD.c 1bfaa114 GD.c d7f57c69 GD.c 3fea90eb GD.c
bfab87ae GD.c fea704d6 GD.c fdbf8d23 GD.c 4c5e67e5 GD.c 8d43ffa5 GD.c
3f3ff2e5 GD.c fea43195 GD.c 4f32caaa GD.c 95464370 GD.c e4a8affa GD.c
bf7fcbfa GD.c faaca223 GD.c 22cb3acb GD.c 2b88a1c1 GD.c 59d25ff4 GD.c
f36f04da GD.c fdfea338 GD.c c132cb08 GD.c d7323c5b GD.c 92c2317f GD.c
22c9bc12 GD.c 11ebfd73 GD.c f9f97f48 GD.c d7322e9b GD.c de1f101f GD.c
d2affce3 GD.c a37bde5f GD.c 5ff5c9d2 GD.c 632dee20 GD.c e93afe7c GD.c
13cffae4 GD.c 97f5469f GD.c ea56bf9f GD.c 23dffae4 GD.c 4fcbfa12 GD.c
fd5c9d4b GD.c bfa52239 GD.c c9d5b5fc GD.c f12efff3 GD.c fdfa848f GD.c
ffd72752 GD.c bfd0910e GD.c 93a94aff GD.c 889b7feb GD.c 01ffdfeb GD.c
dffae4e9 GD.c dffb7e22 GD.c 5ebffa88 GD.c fd7274ae GD.c ea70466f GD.c
5cc8b92f GD.c 9508d9ff GD.c d22c8bfa GD.c 87437fe8 GD.c 38b3afd4 GD.c
5d7d9fa3 GD.c 73ffaac7 GD.c fe8ae3c0 GD.c 529d35f2 GD.c 0ed9c45d GD.c
a14a8cf9 GD.c 2a8882fe GD.c 5557fbfb GD.c 8c81fa8c GD.c 9ae501a2 GD.c
bcfeae46 GD.c abc6a98c GD.c f8529fa7 GD.c 939f9feb GD.c 01bb4f11 GD.c
d4afa9f1 GD.c 701f14f3 GD.c 0e47ac9f GD.c 91d44fe8 GD.c e34d5c79 GD.c
97d967ab GD.c 79ea8453 GD.c 50c52f82 GD.c 3afa73d5 GD.c 95c36d11 GD.c
95c93d2b GD.c 836d092b GD.c c10f0a51 GD.c 2f3533fe GD.c 54153fcb GD.c
af079b33 GD.c 77e3c78e GD.c 076bb20e GD.c 671e87a6 GD.c 0627e347 GD.c
66983eb7 GD.c 0daf57c7 GD.c eca3e3fa GD.c dbcdc199 GD.c 4f39bcd3 GD.c
09be9346 GD.c 93470e0f GD.c 8e9fbe71 GD.c e3335eaf GD.c 3f77adfb GD.c
5fabf5bc GD.c c6e9e51e GD.c b7abfdc7 GD.c c1dc2ed6 GD.c 3a78f1cd GD.c
e679671e GD.c dc1b2fe6 GD.c 37468d18 GD.c b7c7d906 GD.c feddf2f3 GD.c
3c3e3b38 GD.c 3c3c3a3c GD.c d1a3a6ce GD.c d7649724 GD.c c677470f GD.c
e367ae37 GD.c 3b38d922 GD.c 5fcb66be GD.c 7cbcf834 GD.c f9bfdbe3 GD.c
bbbfc7c3 GD.c 3d25be53 GD.c 4d1fc6ce GD.c 7ae5efa7 GD.c 71ffdfe3 GD.c
b19dfefa GD.c d8d8ef29 GD.c 9c6c9f91 GD.c df845867 GD.c 1373fdbf GD.c
ddd263be GD.c 323a3dba GD.c 43971cf9 GD.c cfd4b8d7 GD.c 3a3a3e5f GD.c
bfdf3278 GD.c 7cde9d37 GD.c a3a13329 GD.c 8dd9c68f GD.c 8c0ecf1b GD.c
6789f4de GD.c 4c1f860e GD.c c7aee037 GD.c f5030683 GD.c 98033156 GD.c
fcb27ff9 GD.c 7bdfc5ff GD.c 5f01ffd9 GD.c 008877b9 GD.c
;

decimal
0        constant BACKGROUND_HANDLE
224      constant BACKGROUND_WIDTH
256      constant BACKGROUND_HEIGHT
1        constant BACKGROUND_CELLS
1        constant SPRITES_HANDLE
16       constant SPRITES_WIDTH
16       constant SPRITES_HEIGHT
100      constant SPRITES_CELLS
2        constant LIFE_HANDLE
8        constant LIFE_WIDTH
8        constant LIFE_HEIGHT
1        constant LIFE_CELLS
3        constant ARROW_HANDLE
48       constant ARROW_WIDTH
48       constant ARROW_HEIGHT
1        constant ARROW_CELLS
4        constant FONT_HANDLE
8        constant FONT_WIDTH
8        constant FONT_HEIGHT
128      constant FONT_CELLS
112084   constant ASSETS_END
base !

1 constant CONTROL_LEFT
2 constant CONTROL_RIGHT
4 constant CONTROL_UP
8 constant CONTROL_DOWN


: draw_score ( x y n -- )
    >r
    swap 8 * swap 8 *
    FONT_HANDLE 5 r>
    GD.cmd_number
;

\ Game variables
0 variable t
0 variable prevt
0 variable frogx          \ screen position
0 variable frogy          \ screen position
0 variable leaping        \ 0 means not leaping, 1-8 animates the leap
0 variable frogdir        \ while leaping, which direction is the leap?
0 variable frogface       \ which way is the frog facing, in furmans for CMD_ROTATE
0 variable dying          \ 0 means not dying, 1-64 animation counter
0 variable score 
0 variable hiscore        0 hiscore !
0 variable lives

5 buffer: done

create homes 
24 72 16 lshift or h, 
120 168 16 lshift or h, 
216 h,

0 variable time

: frog_start
  120 frogx !
  232 frogy !
  0 leaping !
  0 frogdir !
  0 frogface !
  0 dying !
  120 7 lshift time !
;

: erase ( caddr u -- ) 0 fill ;

: level_start
    done 5 erase
;
 
: game_start
  4 lives !
  0 score !
  0 t ! 
;

: game_setup
  game_start
  level_start
  frog_start
;

: sprite  ( x y anim -- )
    >r
    swap 16 - 255 and swap 8 - 255 and
    over 224 > if
        r> GD.Cell
        swap 256 - 16 * swap 16 *
        GD.Vertex2f
    else
        SPRITES_HANDLE r> GD.Vertex2ii
    then
;

: r1  ( x y -- x' y ) \ move 16 pixels right, a sprite's width
    swap 16 + swap
;

: turtleanim
    t @ 5 rshift 3 mod 50 +
;

: turtle3  ( x y -- )
    turtleanim >r
    2dup r@ sprite
    r1 2dup r@ sprite
    r1 r> sprite
;

: turtle2  ( x y -- )
    turtleanim >r
    2dup r@ sprite
    swap 16 + swap r> sprite
;

: log1  ( x y -- )
    2dup            86 sprite
    r1 2dup         87 sprite
    r1              88 sprite
;

: log ( length x y -- )
    2dup 86 sprite r1
    rot 0 do
        2dup 87 sprite r1
    loop
    88 sprite
;

: riverat  ( y tt -- )
    swap case
        120 of negate endof
        104 of endof
        88  of 5 4 */ endof
        72  of negate 2/ endof
        56  of 2/ endof
    endcase
;

: F16 ( x1 -- x2 )
    16 lshift
inline 1-foldable ;

: rotate_around ( x y a -- )
    >r
    swap F16 swap F16
    GD.cmd_loadidentity
    2dup GD.cmd_translate
    r> GD.cmd_rotate
    swap negate swap negate GD.cmd_translate
    GD.cmd_setmatrix
;

: GD.touch
    GD.inputs.x -32768 <>
;

: letter  ( x spr -- x' ) \ one letter of "F R O G G E R"
    >r
    dup 50 SPRITES_HANDLE r> GD.Vertex2ii
    24 +
;

: game_over
    60 0 do
        GD.Clear
        \ Draw "F R O G G E R" using the sprites 90-94
        GD.BITMAPS GD.Begin
        160
        90 letter   \ F
        91 letter   \ R
        92 letter   \ O
        93 letter   \ G
        93 letter   \ G
        94 letter   \ E
        91 letter   \ R
        drop
        240 136 FONT_HANDLE GD.OPT_CENTER s" GAME OVER" GD.cmd_text
        i 59 = if
            240 200 FONT_HANDLE GD.OPT_CENTER s" PRESS TO PLAY" GD.cmd_text
        then

        GD.swap
    loop
    begin GD.getinputs GD.touch until
    begin GD.getinputs GD.touch 0= until
;

: padx ( i - x )
    3 - 48 * 480 +
;

: pady ( i -- y )
    3 - 48 * 272 +
;

: pads
    CONTROL_RIGHT GD.Tag
    2 padx 1 pady ARROW_HANDLE 0 GD.Vertex2ii

    24 24 $4000 3 * rotate_around
    CONTROL_UP GD.Tag
    1 padx 0 pady ARROW_HANDLE 0 GD.Vertex2ii

    24 24 $4000 2 * rotate_around
    CONTROL_LEFT GD.Tag
    0 padx 1 pady ARROW_HANDLE 0 GD.Vertex2ii

    24 24 $4000 1 * rotate_around
    CONTROL_DOWN GD.Tag
    1 padx 2 pady ARROW_HANDLE 0 GD.Vertex2ii
;

create frog_anim
    2 c, 1 c, 0 c, 0 c, 2 c,
create die_anim
    31 c, 32 c, 33 c, 30 c,

: drawfrog \ draw the frog himself, or his death animation
    frogx @ frogy @
    dying @ 0= if
        leaping @ 2/ frog_anim + c@
    else
        dying @ 16 / die_anim + c@
    then
    sprite
;

: touching
    GD.inputs.ptag 2 =
;

: die
    1 dying !
;

: gameloop
    GD.getinputs
    GD.Clear
    1 GD.Tag
    SPRITES_HANDLE GD.BitmapHandle
    GD.SaveContext
    224 256 GD.ScissorSize
    GD.BITMAPS GD.Begin
    0 0 BACKGROUND_HANDLE 0 GD.Vertex2ii

    frogx @ 8 - GD.REG_TAG_X GD.!
    frogy @     GD.REG_TAG_Y GD.!

    2 GD.Tag
    GD.GREATER 0 GD.AlphaFunc  \ on road, don't tag transparent pixels

    \ Completed homes
    5 0 do
        done i + c@ if
            homes i + c@ 40 63 sprite
        then
    loop

    \ Yellow cars
    t @ negate        216 3 sprite
    t @ negate 128 +  216 3 sprite

    \ Dozers
    t @               200 4 sprite
    t @ 50 +          200 4 sprite
    t @ 150 +         200 4 sprite

    \ Purple cars
    t @ negate        184 7 sprite
    t @ negate 75 +   184 7 sprite
    t @ negate 150 +  184 7 sprite

    \ Green and white racecars
    t @ 2*            168 8 sprite

    \ Trucks
    t @ negate 2/
    dup             152 5 sprite
    dup 16 +        152 6 sprite
    dup 100 +       152 5 sprite
        116 +       152 6 sprite

    GD.ALWAYS 0 GD.AlphaFunc   \ on river, tag transparent pixels

    \ Turtles
    256 0 do
        120 t @ riverat i + 120 turtle3
    64 +loop

    \ Short logs
    240 0 do
        1 104 t @ riverat i + 104 log
    80 +loop

    \ Long logs
    256 0 do
        5 88 t @ riverat i + 88 log
    128 +loop

    \ Turtles again, but slower
    250 0 do
        72 t @ riverat i + 72 turtle2
    50 +loop

    \ Top logs
    210 0 do
        2 56 t @ riverat i + 56 log
    70 +loop

    0 GD.TagMask
    drawfrog

    t @ prevt !
    1 t +!

    time @ 1- 0 max dup time !  \ lose time, die if zero
    0= if
        die
    then

    GD.SaveContext
    72 248 GD.ScissorXY
    120 time @ 7 rshift - 8 GD.ScissorSize
    GD.Clear
    GD.RestoreContext

    1 GD.TagMask

    GD.touch GD.inputs.tag and >r
    r@ 0<>
    dying @ 0= and
    leaping @ 0= and if
        r@ frogdir !
        1 leaping !
        10 score +!
    else
        leaping @ 0<> if
            leaping @ 9 < if
                frogdir @ case
                CONTROL_LEFT    of -2 frogx endof
                CONTROL_RIGHT   of  2 frogx endof
                CONTROL_UP      of -2 frogy endof
                CONTROL_DOWN    of  2 frogy endof
                endcase
                +!
                0 frogface !
                1 leaping +!
            else
                0 leaping !
            then
        then
    then
    r> drop

    GD.RestoreContext
    GD.SaveContext
    GD.BITMAPS GD.Begin
  
    pads

    GD.RestoreContext

    255 85 0 GD.ColorRGB
    3 1 score @ draw_score
    11 1 hiscore @ draw_score

    255 255 255 GD.ColorRGB
    lives @ 0 ?do
        i 8 * 240 LIFE_HANDLE 0 GD.Vertex2ii
    loop

    \ GD.inputs.x GD.inputs.y 31 0 s" @" GD.cmd_text
    GD.swap

    dying @ if
        1 dying +!
        dying @ 64 = if
            cr ." ---- DIE ----"
            -1 lives +!
            lives @ 0= time @ 0= or if
                game_over
                game_start
                level_start
            then
            frog_start
        then
    else
        frogx @ 8 224 within 0= if
            die
        else
            \ GD.inputs.ptag cr .
            frogy @ 128 > if \ road section
                touching if
                    die cr ." splat"
                then
            else
                frogy @ 40 > if \ river section
                    leaping @ 0= if
                        touching if
                            \ move frog according to lane speed
                            frogy @ t @ riverat
                            frogy @ prevt @ riverat
                            - frogx +!
                        else
                            die cr ." splash"
                        then
                    then
                else
                then
            then
        then
    then
;

: frogger
    GD.init
    frogger-data
    GD.calibrate

    game_setup
    1 done c!
    begin
        gameloop
    again
;
