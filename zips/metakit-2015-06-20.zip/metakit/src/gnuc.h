// gnuc.h --
// $Id$
// This is part of Metakit, the homepage is http://www.equi4.com/metakit.html

/** @file
 * Configuration header for GNU C++
 */

#define q4_GNUC 1

#if !defined (q4_BOOL)
#define q4_BOOL 1
#endif
