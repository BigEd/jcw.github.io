#include <jee.h>

UartDev< PinD<1>, PinD<0> > console;  // pin info is ignored on avr + esp

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinB<1> led;  // Port B bit 1 is "digital pin 9" on ATmega328

constexpr int MHZ = 16;

int main () {
    enableSysTick();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    for (int i = 0; i < 3; ++i) {
        uint32_t t0 = micros();
        for (int i = 0; i < 100; ++i)
            for (int j = 0; j < 10000; ++j)
                __asm("");
        uint32_t t1 = micros() - t0;
        Serial.print("t = ");
        Serial.print(t1);
        Serial.print(" ps, f = ");
        Serial.print(1000000000L / t1);
        Serial.print(" kHz, ");
        Serial.print(t1 / (1000000L / MHZ));
        Serial.print(".");
        Serial.print((t1 / (10000000L / MHZ)) % 10L);
        Serial.print(" cycles/loop\n");
    }

    led.mode(Pinmode::out);

    while (true) {
        printf("%d\n", ticks);
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400);
    }
}
