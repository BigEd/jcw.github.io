#include "stm32f103xb.h"

static void delay (int count) {
    for (int i = 0; i < count; i++)
        __asm(""); // this prevents being optimised away
}

int main () {
    RCC->APB2ENR |= 1<<4; // enable GPIOC clock

    // set up PC13 as output: open drain, 2 MHz
    GPIOC->CRH |= 0b0110 << 20;

    for (;;) {
        GPIOC->BRR = 1 << 13;
        delay(250000);
        GPIOC->BSRR = 1 << 13;
        delay(1000000);
    }
}
