#include <Arduino.h>

#define LED 2

void setup() {
  pinMode(LED, OUTPUT);
  Serial.begin(115200);
  delay(200);
}

void loop() {
  digitalWrite(LED, 1);
  delay(500);
  digitalWrite(LED, 0);
  delay(500);

  Serial.write("Hello!\n");
  delay(1000);
}
