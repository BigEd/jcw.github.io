#include <Arduino.h>

void setup() {
    pinMode(PA5, OUTPUT);
}

void loop() {
    digitalWrite(PA5, HIGH);
    delay(100);
    digitalWrite(PA5, LOW);
    delay(400);
}
