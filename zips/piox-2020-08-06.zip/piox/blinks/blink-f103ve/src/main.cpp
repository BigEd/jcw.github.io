#include <Arduino.h>

#define LED PB9

void setup() {
    Serial.begin();
    delay(3000);
    Serial.println("hello");
    pinMode(LED, OUTPUT);
}

void loop() {
    static int i = 0;
    Serial.println(++i);

    digitalWrite(LED, 0);
    delay(100);
    digitalWrite(LED, 1);
    delay(400);
}
