#include <mbed.h>

int main() {

    // put your setup code here, to run once:

    while(1) {
        // put your main code here, to run repeatedly:
    }
}
