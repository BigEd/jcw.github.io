#include <mbed.h>

Serial console (PA_9, PA_10, 115200);
DigitalOut led (PA_6);


int main() {
    int i = 0;
    while (1) {
        console.printf("hello %d\n", ++i);
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400);
    }
}
