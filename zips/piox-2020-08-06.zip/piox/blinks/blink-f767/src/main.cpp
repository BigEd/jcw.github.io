#include <mbed.h>

DigitalOut led (PB_0);
Serial console (USBTX, USBRX, 115200);

int main() {
    int i = 0;
    while (1) {
        console.printf("hello %d\n", ++i);

        led = 1;
        wait(0.1);
        led = 0;
        wait(0.4);
    }
}
