#include <mbed.h>

// Serial console (USBTX, USBRX);
DigitalOut led (PB_10);

int main () {
    while (1) {
        // console.printf("hello\n");
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400); 
    }
}
