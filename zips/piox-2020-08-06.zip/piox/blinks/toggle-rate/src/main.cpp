#if ARDUINO
    #include <Arduino.h>
#elif LIBOPEN
    #include <libopencm3/stm32/rcc.h>
    #include <libopencm3/stm32/gpio.h>
#elif MBED
    #include <mbed.h>
#elif RAW
    #include <raw.h>
#endif

#if 0
    static void delayLoop (int count) {
        for (int i = 0; i < count; ++i)
            __asm("");
    }
#else
    #define delayLoop(x)
#endif

#if ARDUINO
    const int led = PC0;
#elif MBED
    DigitalOut led (PC_0);
#elif RAW
    PinC<0> led;
#endif

void setup () {
#if ARDUINO
    pinMode(led, OUTPUT);
#elif LIBOPEN
    rcc_clock_setup_in_hse_8mhz_out_72mhz();
    rcc_periph_clock_enable(RCC_GPIOC);
    gpio_set_mode(GPIOC, GPIO_MODE_OUTPUT_50_MHZ,
                    GPIO_CNF_OUTPUT_PUSHPULL, GPIO0);
#elif RAW
    rcc_clock_setup_in_hse_8mhz_out_72mhz();
    led.mode(Pinmode::out);
#endif
}

void loop () {
#if ARDUINO
    digitalWrite(PC0, 0); delayLoop(1000000);
    digitalWrite(PC0, 1); delayLoop(4000000);
    digitalWrite(PC0, 0); delayLoop(1000000);
    digitalWrite(PC0, 1); delayLoop(4000000);
    digitalWrite(PC0, 0); delayLoop(1000000);
    digitalWrite(PC0, 1); delayLoop(4000000);
    digitalWrite(PC0, 0); delayLoop(1000000);
    digitalWrite(PC0, 1); delayLoop(4000000);
#elif LIBOPEN
    gpio_clear(GPIOC, GPIO0); delayLoop(1000000);
    gpio_set  (GPIOC, GPIO0); delayLoop(4000000);
    gpio_clear(GPIOC, GPIO0); delayLoop(1000000);
    gpio_set  (GPIOC, GPIO0); delayLoop(4000000);
    gpio_clear(GPIOC, GPIO0); delayLoop(1000000);
    gpio_set  (GPIOC, GPIO0); delayLoop(4000000);
    gpio_clear(GPIOC, GPIO0); delayLoop(1000000);
    gpio_set  (GPIOC, GPIO0); delayLoop(4000000);
#elif MBED || RAW
    led = 0; delayLoop(1000000);
    led = 1; delayLoop(4000000);
    led = 0; delayLoop(1000000);
    led = 1; delayLoop(4000000);
    led = 0; delayLoop(1000000);
    led = 1; delayLoop(4000000);
    led = 0; delayLoop(1000000);
    led = 1; delayLoop(4000000);
#endif
}

#if !ARDUINO
int main () {
    setup();
    while (true)
        loop();
}
#endif
