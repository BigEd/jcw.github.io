#include <verilated.h>
#include <verilated_vcd_c.h>
#include "Vtop.h"

vluint64_t simTime;

// double sc_time_stamp () { return simTime; }

int main (int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    Vtop dut;
    Verilated::traceEverOn(true);
    VerilatedVcdC tfp;
    dut.trace(&tfp, 99);

    if (true) tfp.open("data.vcd");

    for (simTime = 0; simTime < 100 && !Verilated::gotFinish(); ++simTime) {
        dut.CLK = 1;
        dut.eval();
        tfp.dump(simTime*10); // positive clock edge
        dut.CLK = 0;
        dut.eval();
        tfp.dump(simTime*10+5); // negative clock edge
        dut.eval();
        tfp.dump(simTime*10+8); // async combinational changes
        tfp.flush();
    }

    tfp.dump(simTime*10); // final positive clock edge
    tfp.close();
    return 0;
}
