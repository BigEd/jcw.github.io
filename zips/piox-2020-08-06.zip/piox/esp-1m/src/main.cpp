#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>
#include <FS.h>

ESP8266WebServer server (80);
ESP8266HTTPUpdateServer updater;

char const* setupWiFi () {
#if 1  // choose between access point and client station mode
    Serial.println("\nsetting up access point");
    WiFi.mode(WIFI_AP);
    IPAddress myIP (192, 168, 1, 1);
    WiFi.softAPConfig(myIP, myIP, IPAddress(255, 255, 255, 0));
    WiFi.softAP("esptest", "test");
    static String s = myIP.toString();
#else
    WiFi.mode(WIFI_STA);
    #include "../../ssidpass.h"
    Serial.printf("connecting to '%s' ", ssid);
    WiFi.begin(ssid, pass);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println(" ok.");
    static String s = WiFi.localIP().toString();
#endif
    return s.c_str();
}

void setup() {
    Serial.begin(115200);

    char const* s = setupWiFi();

    server.on("/hello", []() {
        server.send(200, "text/html", "<h1>Hello!</h1>");
    });

    if (SPIFFS.begin()) {
        Serial.println("SPIFFS mounted");
        server.serveStatic("/", SPIFFS, "/");
        // TODO needs newer version? can use index.htm for now
        //server.setDefaultFile("index.html");
    }

    updater.setup(&server);
    server.begin();

    Serial.printf("HTTP server started at http://%s/\n", s);
}

void loop() {
    server.handleClient();
}
