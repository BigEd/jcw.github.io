#include "Arduino.h"
//#include "ESP8266WiFi.h"
#include "i2s.h"

int16_t buf [128];
 
void setup() {
    //system_update_cpu_freq(160);

    i2s_begin();
    //i2s_set_rate(2500000);
    i2s_set_rate(250000);

    memset(buf, 0x55, sizeof buf);
}

void loop() {
#if 0
    i2s_write_sample(0x55555555);
#else
    i2s_write_buffer_mono_nb(buf, sizeof buf / 2);
#endif
}
