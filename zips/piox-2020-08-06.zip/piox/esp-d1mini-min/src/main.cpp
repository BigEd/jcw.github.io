#include <Arduino.h>

constexpr int MHZ = 80;

void setup () {
    Serial.begin(115200);
    Serial.println("Booting");

    for (int i = 0; i < 3; ++i) {
        uint32_t t0 = micros();
        for (int i = 0; i < 1000000; ++i) __asm("");
        uint32_t t1 = micros() - t0;
        Serial.printf("t = %d ps, f = %d kHz, %d.%d cycles/loop\n",
                        t1, 1000000000 / t1,
                        t1 / (1000000 / MHZ), (t1 / (10000000 / MHZ)) % 10);
    }
}

void loop () {
}
