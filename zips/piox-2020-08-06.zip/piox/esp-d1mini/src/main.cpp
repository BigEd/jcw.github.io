#include <ArduinoOTA.h>
#include <ESP8266WebServer.h>
#include <FS.h>

#include "../../ssidpass.h"

ESP8266WebServer server (80);

void setupWiFi () {
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);

    while (WiFi.waitForConnectResult() != WL_CONNECTED) {
        Serial.println("Connection Failed! Rebooting...");
        delay(5000);
        ESP.restart();
    }

    Serial.printf("Connected as %s\n", WiFi.localIP().toString().c_str());
}

void setupOTA () {
    // Port defaults to 8266
    //  ArduinoOTA.setPort(8266);
    // Hostname defaults to esp8266-[ChipID]
    //  ArduinoOTA.setHostname("myesp8266");
    // No authentication by default
    //  ArduinoOTA.setPassword("admin");
    // Password can be set with it's md5 value as well
    // MD5(admin) = 21232f297a57a5a743894a0e4a801fc3
    //  ArduinoOTA.setPasswordHash("21232f297a57a5a743894a0e4a801fc3");

    ArduinoOTA.onStart([]() {
        Serial.printf("Start updating %s\n",
            ArduinoOTA.getCommand() == U_FLASH ? "sketch" : "filesystem");
        SPIFFS.end();
    });

    ArduinoOTA.onProgress([](unsigned progress, unsigned total) {
        int percent = (progress * 100 ) / total;
        if (percent % 10 == 0)
            Serial.printf("\r  %u%% ", percent);
    });

    ArduinoOTA.onEnd([]() {
        Serial.printf("\nDone\n");
    });

    ArduinoOTA.onError([](ota_error_t error) {
        char const* msg = "";
        switch (error) {
            case OTA_AUTH_ERROR:    msg = "Auth";    break;
            case OTA_BEGIN_ERROR:   msg = "Begin";   break;
            case OTA_CONNECT_ERROR: msg = "Connect"; break;
            case OTA_RECEIVE_ERROR: msg = "Receive"; break;
            case OTA_END_ERROR:     msg = "End";     break;
        }
        Serial.printf("Error %u: %s Failed\n", error, msg);
    });

    ArduinoOTA.begin();
}

void setupSPIFFS () {
    if (SPIFFS.begin())
        server.serveStatic("/", SPIFFS, "/");
    else
        Serial.println("SPIFFS Failed!");
}

void setup () {
    Serial.begin(115200);
    Serial.println("Booting");

    server.on("/heap", []() {
        server.send(200, "text/plain", String(ESP.getFreeHeap()));
    });

    setupSPIFFS();
    setupWiFi();
    setupOTA();
    server.begin();
}

void loop () {
    ArduinoOTA.handle();
    server.handleClient();
}
