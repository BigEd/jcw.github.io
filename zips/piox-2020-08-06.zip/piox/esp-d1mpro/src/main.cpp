#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>

#include "../../ssidpass.h"

ESP8266WebServer server (80);
ESP8266HTTPUpdateServer updater;

void setupWiFi () {
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);

    Serial.printf("connecting to '%s' ", ssid);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println(" ok.");

    //myIP = WiFi.localIP();
}

void setup() {
    Serial.begin(115200);
    Serial.println("\nin main");

    setupWiFi();

    server.on("/", []() {
        server.send(200, "text/html", "<h1>Hello 5!</h1>");
    });

    updater.setup(&server);
    server.begin();

    String s = WiFi.localIP().toString();
    Serial.printf("HTTP server started at http://%s/\n", s.c_str());
    Serial.printf("       to update, open http://%s/update\n", s.c_str());
}

void loop() {
    server.handleClient();
}
