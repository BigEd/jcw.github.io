#include <Arduino.h>

void setup() {
    Serial.begin(115200);
    Serial.printf("\nhello\n");
    pinMode(22, OUTPUT);
}

void loop() {
    Serial.printf("%d\n", millis());

    digitalWrite(22, 0);
    delay(100);
    digitalWrite(22, 1);
    delay(400);
}
