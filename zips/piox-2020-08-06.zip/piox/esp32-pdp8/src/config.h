#define CONFIG_OLED 1

#define CONFIG_SDA_PIN  "4"
#define CONFIG_SCL_PIN  "15"
#define CONFIG_RST_PIN  "16"
#define CONFIG_SC_CS    "5"

#define CONFIG_WIFI_SSID     "..."
#define CONFIG_WIFI_PASSWORD "..."

#define CONFIG_TIMEZONE "CET-1:00:CEST-2:00:00,M3.5.0,M10.5.0"
