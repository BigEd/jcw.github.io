#include <Arduino.h>

constexpr int LED = 21; // reusing wrover board def

void setup() {
    Serial.begin(115200);
    pinMode(LED, OUTPUT);

    constexpr int chan = 0;
    ledcSetup(chan, 40000000, 1);
    ledcWrite(chan, 1);
    ledcAttachPin(15, chan);
}

void loop() {
    Serial.printf("%lu\n", millis());

    digitalWrite(LED, 1);
    delay(100);
    digitalWrite(LED, 0);
    delay(400);
}
