#include <Arduino.h>

#define LED 16

void setup() {
    Serial.begin(115200);
    Serial.println("Booting");

    pinMode(LED, OUTPUT);
}

void loop() {
    digitalWrite(LED, 0);
    delay(10);
    digitalWrite(LED, 1);
    delay(990);
    Serial.printf("%d\n", millis());
}
