#include <Arduino.h>

/*
   Example animated analogue meters using a ILI9341 TFT LCD screen

   Needs Font 2 (also Font 4 if using large scale label)

   Make sure all the display driver and pin comnenctions are correct by
   editting the User_Setup.h file in the TFT_eSPI library folder.

#########################################################################
###### DON'T FORGET TO UPDATE THE User_Setup.h FILE IN THE LIBRARY ######
#########################################################################
*/

#include <TFT_eSPI.h> // Hardware-specific library
#include <SPI.h>

TFT_eSPI tft = TFT_eSPI();       // Invoke custom library

setup_t user; // The library defines the type "setup_t" as a struct
// Calling tft.getSetup(user) populates it with the settings

static int8_t getPinName(int8_t pin)
{
    // For ESP32 pin labels on boards use the GPIO number
    return pin;
}

void showConfig (void) {

    tft.getSetup(user); //

    Serial.printf("\n");

    Serial.print ("TFT_eSPI ver = " + user.version + "\n");
    Serial.printf("Processor    = ESP%i\n", user.esp, HEX);
    Serial.printf("Frequency    = %i MHz\n", ESP.getCpuFreqMHz());
    Serial.printf("Transactions = %s \n",   (user.trans  ==  1) ? "Yes" : "No");
    Serial.printf("Interface    = %s \n",   (user.serial ==  1) ? "SPI" : "Parallel");
    if (user.tft_driver != 0xE9D) // For ePaper displays the size is defined in the sketch
    {
        Serial.printf("Display driver = "); Serial.println(user.tft_driver, HEX); // Hexadecimal code
        Serial.printf("Display width  = %i \n",   user.tft_width);  // Rotation 0 width and height
        Serial.printf("Display height = %i \n\n", user.tft_height);
    }
    else if (user.tft_driver == 0xE9D) Serial.printf("Display driver = ePaper\n\n");

    if (user.r0_x_offset  != 0)  Serial.printf("R0 x offset = %i \n",   user.r0_x_offset); // Offsets, not all used yet
    if (user.r0_y_offset  != 0)  Serial.printf("R0 y offset = %i \n",   user.r0_y_offset);
    if (user.r1_x_offset  != 0)  Serial.printf("R1 x offset = %i \n",   user.r1_x_offset);
    if (user.r1_y_offset  != 0)  Serial.printf("R1 y offset = %i \n",   user.r1_y_offset);
    if (user.r2_x_offset  != 0)  Serial.printf("R2 x offset = %i \n",   user.r2_x_offset);
    if (user.r2_y_offset  != 0)  Serial.printf("R2 y offset = %i \n",   user.r2_y_offset);
    if (user.r3_x_offset  != 0)  Serial.printf("R3 x offset = %i \n",   user.r3_x_offset);
    if (user.r3_y_offset  != 0)  Serial.printf("R3 y offset = %i \n\n", user.r3_y_offset);

    if (user.pin_tft_mosi != -1) Serial.printf("MOSI    = D%i (GPIO %i)\n",   getPinName(user.pin_tft_mosi), user.pin_tft_mosi);
    if (user.pin_tft_miso != -1) Serial.printf("MISO    = D%i (GPIO %i)\n",   getPinName(user.pin_tft_miso), user.pin_tft_miso);
    if (user.pin_tft_clk  != -1) Serial.printf("SCK     = D%i (GPIO %i)\n",   getPinName(user.pin_tft_clk), user.pin_tft_clk);

    if (user.pin_tft_cs   != -1) Serial.printf("TFT_CS   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_cs), user.pin_tft_cs);
    if (user.pin_tft_dc   != -1) Serial.printf("TFT_DC   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_dc), user.pin_tft_dc);
    if (user.pin_tft_rst  != -1) Serial.printf("TFT_RST  = D%i (GPIO %i)\n\n", getPinName(user.pin_tft_rst), user.pin_tft_rst);

    if (user.pin_tch_cs   != -1) Serial.printf("TOUCH_CS = D%i (GPIO %i)\n\n", getPinName(user.pin_tch_cs), user.pin_tch_cs);

    if (user.pin_tft_wr   != -1) Serial.printf("TFT_WR   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_wr), user.pin_tft_wr);
    if (user.pin_tft_rd   != -1) Serial.printf("TFT_RD   = D%i (GPIO %i)\n\n", getPinName(user.pin_tft_rd), user.pin_tft_rd);

    if (user.pin_tft_d0   != -1) Serial.printf("TFT_D0   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d0), user.pin_tft_d0);
    if (user.pin_tft_d1   != -1) Serial.printf("TFT_D1   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d1), user.pin_tft_d1);
    if (user.pin_tft_d2   != -1) Serial.printf("TFT_D2   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d2), user.pin_tft_d2);
    if (user.pin_tft_d3   != -1) Serial.printf("TFT_D3   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d3), user.pin_tft_d3);
    if (user.pin_tft_d4   != -1) Serial.printf("TFT_D4   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d4), user.pin_tft_d4);
    if (user.pin_tft_d5   != -1) Serial.printf("TFT_D5   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d5), user.pin_tft_d5);
    if (user.pin_tft_d6   != -1) Serial.printf("TFT_D6   = D%i (GPIO %i)\n",   getPinName(user.pin_tft_d6), user.pin_tft_d6);
    if (user.pin_tft_d7   != -1) Serial.printf("TFT_D7   = D%i (GPIO %i)\n\n", getPinName(user.pin_tft_d7), user.pin_tft_d7);

    uint16_t fonts = tft.fontsLoaded();
    if (fonts & (1 << 1))        Serial.printf("Font GLCD   loaded\n");
    if (fonts & (1 << 2))        Serial.printf("Font 2      loaded\n");
    if (fonts & (1 << 4))        Serial.printf("Font 4      loaded\n");
    if (fonts & (1 << 6))        Serial.printf("Font 6      loaded\n");
    if (fonts & (1 << 7))        Serial.printf("Font 7      loaded\n");
    if (fonts & (1 << 9))        Serial.printf("Font 8N     loaded\n");
    else
        if (fonts & (1 << 8))        Serial.printf("Font 8      loaded\n");
    if (fonts & (1 << 15))       Serial.printf("Smooth font enabled\n");
    Serial.printf("\n");

    if (user.serial==1)          Serial.printf("Display SPI frequency = %2.1f MHz \n", user.tft_spi_freq/10.0);
    if (user.pin_tch_cs != -1)   Serial.printf("Touch SPI frequency   = %2.1f MHz \n", user.tch_spi_freq/10.0);

    Serial.printf("\n");
}

// pick one!

//#include "analog.h"
//#include "smooth.h"
//#include "utftdemo.h"
//#include "3dcube.h"
//#include "sprite.h"
//#include "mandelbrot.h"
//#include "yinyang.h"
#include "gtest.h"
