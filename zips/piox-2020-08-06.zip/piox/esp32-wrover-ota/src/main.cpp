#include <WiFi.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <ArduinoOTA.h>

#include "../../ssidpass.h"

#define LED_RED     0
#define LED_GREEN   2
#define LED_BLUE    4
#define BACKLIGHT   5

#define PSRAM_BASE  0x3F800000

constexpr int MHZ = 240;

void setup() {
    Serial.begin(115200);
    Serial.println("Booting");

    pinMode(LED_RED  , OUTPUT);
    pinMode(LED_GREEN, OUTPUT);
    pinMode(LED_BLUE , OUTPUT);

    pinMode(BACKLIGHT, OUTPUT);
    digitalWrite(BACKLIGHT, 0);

    for (int i = 0; i < 3; ++i) {
        uint32_t t0 = micros();
        for (int i = 0; i < 1000000; ++i) __asm("");
        uint32_t t1 = micros() - t0;
        Serial.printf("t = %d ps, f = %d kHz, %d.%d cycles/loop\n",
                        t1, 1000000000 / t1,
                        t1 / (1000000 / MHZ), (t1 / (10000000 / MHZ)) % 10);
    }

    esp_chip_info_t chip_info;
    esp_chip_info(&chip_info);
    char const* bt = chip_info.features & CHIP_FEATURE_BT ? "/BT" : "";
    char const* ble = chip_info.features & CHIP_FEATURE_BLE ? "/BLE" : "";
    Serial.printf("ESP32: %d CPU cores, WiFi%s%s, rev %d, %d MB%s flash\n",
            chip_info.cores, bt, ble, chip_info.revision,
            spi_flash_get_chip_size() / (1024 * 1024),
            chip_info.features & CHIP_FEATURE_EMB_FLASH ? "" : " external");

    Serial.printf("heap = %d\n", ESP.getFreeHeap());
#if 0
    void* p1 = ps_malloc(4*1024*1024-100);
    void* p2 = ps_malloc(10);
    Serial.printf("%x %x\n", p1, p2);
    uint32_t* psram = (uint32_t*) p1;
#else
    // skip first bytes, else it corrupts the heap and OTA fails later on
    uint32_t* psram = (uint32_t*) PSRAM_BASE + 40;
#endif
    Serial.println(*psram);
    *psram = 1234567890;
    Serial.println(*psram);
    ++*psram;
    Serial.println(*psram);

    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);
    while (WiFi.waitForConnectResult() != WL_CONNECTED) {
        Serial.println("Connection Failed! Rebooting...");
        delay(5000);
        ESP.restart();
    }

    Serial.println("Ready");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());

    // Port defaults to 3232
    // ArduinoOTA.setPort(3232);

    // Hostname defaults to esp3232-[MAC]
    // ArduinoOTA.setHostname("myesp32");

    // No authentication by default
    // ArduinoOTA.setPassword("admin");

    // Password can be set with it's md5 value as well
    // MD5(admin) = 21232f297a57a5a743894a0e4a801fc3
    // ArduinoOTA.setPasswordHash("21232f297a57a5a743894a0e4a801fc3");

    ArduinoOTA.onStart([]() {
        String type;
        if (ArduinoOTA.getCommand() == U_FLASH)
        type = "sketch";
        else // U_SPIFFS
        type = "filesystem";

        // NOTE: if updating SPIFFS this would be the place to
        //          unmount SPIFFS using SPIFFS.end()
        Serial.println("Start updating " + type);
    }).onEnd([]() {
        Serial.println("\nEnd");
    }).onProgress([](unsigned int progress, unsigned int total) {
        Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
    }).onError([](ota_error_t error) {
        Serial.printf("Error[%u]: ", error);
        switch (error) {
            case OTA_AUTH_ERROR:    Serial.println("Auth Failed"); break;
            case OTA_BEGIN_ERROR:   Serial.println("Begin Failed"); break;
            case OTA_CONNECT_ERROR: Serial.println("Connect Failed"); break;
            case OTA_RECEIVE_ERROR: Serial.println("Receive Failed"); break;
            case OTA_END_ERROR:     Serial.println("End Failed"); break;
        }
    });

    ArduinoOTA.begin();
}

void loop() {
    ArduinoOTA.handle();

    digitalWrite(LED_RED  , 1);
    digitalWrite(LED_GREEN, 1);
    digitalWrite(LED_BLUE , 1);
    delay(100);
    digitalWrite(LED_RED  , 0);
    digitalWrite(LED_GREEN, 0);
    digitalWrite(LED_BLUE , 0);
    delay(400);
}
