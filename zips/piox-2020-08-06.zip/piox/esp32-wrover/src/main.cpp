#include <Arduino.h>

#define LED_RED     0
#define LED_GREEN   2
#define LED_BLUE    4
#define BACKLIGHT   5

#define printf Serial.printf

void setup() {
    Serial.begin(115200);

    pinMode(LED_RED  , OUTPUT); digitalWrite(LED_RED  , 0);
    pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, 0);
    pinMode(LED_BLUE , OUTPUT); digitalWrite(LED_BLUE , 0);

    //pinMode(BACKLIGHT, OUTPUT);
    //digitalWrite(BACKLIGHT, 0);
}

void loop() {
    printf("%d\n", millis());

    digitalWrite(LED_RED, 1);
    delay(10);
    digitalWrite(LED_RED, 0);
    delay(490);

    digitalWrite(LED_GREEN, 1);
    delay(10);
    digitalWrite(LED_GREEN, 0);
    delay(490);

    digitalWrite(LED_BLUE, 1);
    delay(10);
    digitalWrite(LED_BLUE, 0);
    delay(990);
}
