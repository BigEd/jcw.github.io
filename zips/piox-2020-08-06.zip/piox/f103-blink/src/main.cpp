#include <jee.h>

UartDev< PinA<9>, PinA<10> > console;

int printf (const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinC<13> led;

int main () {
    //fullSpeedClock();
    enableSysTick();
    console.init();
    printf("abc\n");
    led.mode(Pinmode::out);

    while (true) {
        led.toggle();
        wait_ms(500);
        printf("hello %d\n", ticks);
    }
}
