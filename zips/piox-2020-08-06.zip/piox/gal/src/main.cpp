// GAL programmer
//
// see http://www.armory.com/~rstevew/Public/Pgmrs/GAL/
// and http://www.armory.com/~rstevew/Public/Pgmrs/GAL/algo.htm
// and http://www.armory.com/~rstevew/Public/Pgmrs/GAL/program.htm
// and http://www.armory.com/~rstevew/Public/Pgmrs/GAL/_F_pal_gal.html

#include <Arduino.h>

#define tty Serial

#define LED PB10

// ZIF socket pin allocations

#define Z01 PC0
#define Z02 PA5   // VPP DAC
#define Z03 PC2
#define Z04 PC4
#define Z05 PC3
#define Z06 PC5
#define Z07 PB11  // VCC
#define Z08 PB8
#define Z09 PB9
#define Z10 PC1   // GND
#define Z11 PA0
#define Z12 PA2   // GND
#define Z13 PA1
#define Z14 PA3
#define Z15 PD0
#define Z16 PA8
#define Z17 PC11
#define Z18 PC9
#define Z19 PC7
#define Z20 PB15
#define Z21 PB13  // GND
#define Z22 PD1
#define Z23 PC12
#define Z24 PC10
#define Z25 PC8
#define Z26 PC6
#define Z27 PB14
#define Z28 PB12  // VCC

#define Z02_VPP PA4  // ADC
#define Z07_VCC PB4
#define Z10_GND PB0
#define Z12_GND PB1
#define Z21_GND PB5
#define Z28_VCC PD2

static void delayMicros (int us) {
    for (int n = 0; n < 100 * us; ++n) __asm("");  // FIXME
}

static void setDAC (int v) {
    // TODO
}

static int readADC () {
    // TODO
    return 0;
}

static void setVpp (int vpp) {
    setDAC(100 * vpp); // FIXME
    tty.print("Vpp ");
    tty.print(vpp);
    tty.print(", adc ");
    tty.print(readADC());
    tty.println();
}

// pin I/O shorthand
static int  pi (int pin) { return digitalRead(pin); }
static void pd (int pin) { pinMode(pin, INPUT_PULLDOWN); }
static void pu (int pin) { pinMode(pin, INPUT_PULLUP); }
static void p0 (int pin) { digitalWrite(pin, LOW); pinMode(pin, OUTPUT); }
static void p1 (int pin) { digitalWrite(pin, HIGH); pinMode(pin, OUTPUT); }

#if 0
static void print8bin (uint8_t v) {
    for (int i = 0; i < 8; ++i)
        tty.print((v >> i) & 1);  // printed in b0..b7 order
}
#endif

static void powerDown () {
    setVpp(0);  // Z02 is high-voltage, not tied to any GPIO pin
    pu(Z07_VCC); pu(Z28_VCC);               // all VCCs disabled
    pd(Z10_GND); pu(Z12_GND); pu(Z21_GND);  // all GNDs disabled
    // all other pins are set to weak pull-downs
    pd(Z01); pd(Z03); pd(Z04); pd(Z05); pd(Z06); pd(Z07); pd(Z08); pd(Z09);
    pd(Z10); pd(Z11); pd(Z12); pd(Z13); pd(Z14); pd(Z15); pd(Z16); pd(Z17);
    pd(Z18); pd(Z19); pd(Z20); pd(Z21); pd(Z22); pd(Z23); pd(Z24); pd(Z25);
    pd(Z26); pd(Z27); pd(Z28);
}

// ---------- ControlPins & GalBase --------------------------------------------

struct ControlPins {
    int vccPin, gndPin;
    int stbPin, sclkPin, sdinPin, sdoutPin;
    int r0pin, r1pin, r2pin, r3pin, r4pin, r5pin;
};

struct GalBase : ControlPins {
    int vccPin, gndPin, stbPin, sclkPin, sdinPin, sdoutPin;
    uint8_t row [16];  // up to 128 bits per transfer

    GalBase (const ControlPins& config)
        : ControlPins (config) {}

    void printRowBin (int bits) {
        for (int i = 0; i < bits; ++i) {
            if (i % 10 == 0)
                tty.print(' ');
            tty.print((row[i/8] >> (i%8)) & 1, BIN);
        }
        tty.println();
    }

    void powerOn (int vpp) {
        powerDown();
        pu(stbPin);              // pull strobe pin up
        p1(gndPin); p0(vccPin);  // apply 5V power
        setVpp(vpp);
    }

    void readMode () {
        powerOn(120);  // set Vpp to 12.0V
    }

    void setRA (int ra) {
        (ra & 0x01 ? p1 : p0)(r0pin);
        (ra & 0x02 ? p1 : p0)(r1pin);
        (ra & 0x04 ? p1 : p0)(r2pin);
        (ra & 0x08 ? p1 : p0)(r3pin);
        (ra & 0x10 ? p1 : p0)(r4pin);
        (ra & 0x20 ? p1 : p0)(r5pin);
    }

    void readRow (int ra, int count) {
        setRA(ra);
        p0(stbPin); delayMicros(10); p1(stbPin);
        memset(row, 0, sizeof row);
        for (int i = 0; i < count; ++i) {
            row[i/8] |= pi(sdinPin) << (i%8);
            p1(sclkPin); delayMicros(10); p0(sclkPin);
        }
    }
};

// ---------- GAL 16V8 ---------------------------------------------------------

const struct ControlPins Pins16V8 = {
    .vccPin = Z28_VCC, .gndPin = Z10_GND,
    .stbPin = Z19, .sclkPin = Z08, .sdinPin = Z09, .sdoutPin = Z20,
    .r0pin = Z26, .r1pin = Z03, .r2pin = Z04,
    .r3pin = Z05, .r4pin = Z06, .r5pin = Z07,
};

struct Gal16V8 : GalBase {
    Gal16V8 () : GalBase (Pins16V8) {}

    void readPES () {
        readRow(58, 64);
    }

    void readUES () {
        readRow(32, 64);
    }
};

// ---------- GAL 20V8 ---------------------------------------------------------

const struct ControlPins Pins20V8 = {
    .vccPin = Z28_VCC, .gndPin = Z12_GND,
    .stbPin = Z17, .sclkPin = Z10, .sdinPin = Z11, .sdoutPin = Z19,
    .r0pin = Z25, .r1pin = Z03, .r2pin = Z04,
    .r3pin = Z05, .r4pin = Z08, .r5pin = Z09,
};

struct Gal20V8 : GalBase {
    Gal20V8 () : GalBase (Pins20V8) {}

    void readPES () {
        readRow(58, 64);
    }

    void readUES () {
        readRow(40, 64);
    }
};

// ---------- GAL 22V10 --------------------------------------------------------

const struct ControlPins Pins22V10 = {
    .vccPin = Z28_VCC, .gndPin = Z12_GND,
    .stbPin = Z18, .sclkPin = Z10, .sdinPin = Z11, .sdoutPin = Z18,
    .r0pin = Z04, .r1pin = Z05, .r2pin = Z06,
    .r3pin = Z07, .r4pin = Z08, .r5pin = Z09,
};

struct Gal22V10 : GalBase {
    Gal22V10 () : GalBase (Pins22V10) {}

    void readPES () {
        // TODO readRow(58, 64);
    }

    void readUES () {
        // TODO readRow(32, 64);
    }
};

// ---------- GAL 26V12 --------------------------------------------------------

const struct ControlPins Pins26V12 = {
    .vccPin = Z07_VCC, .gndPin = Z21_GND,
    .stbPin = Z14, .sclkPin = Z12, .sdinPin = Z13, .sdoutPin = Z15,
    .r0pin = Z04, .r1pin = Z05, .r2pin = Z06,
    .r3pin = Z09, .r4pin = Z10, .r5pin = Z11,
};

struct Gal26V12 : GalBase {
    Gal26V12 () : GalBase (Pins26V12) {}

    void readPES () {
        // TODO readRow(58, 64);
    }

    void readUES () {
        // TODO readRow(32, 64);
    }
};

// ---------- Main -------------------------------------------------------------

void setup() {
    tty.begin(115200);
    delay(3000);  // delay so PlatformIO connection to USB will show greeting
    tty.println("GAL programmer v0.1");

    pinMode(LED, OUTPUT);

    Gal16V8 gal;
    gal.readMode();

    tty.print("Set Vcc to 5V and Vpp to 12V, then hit <enter> ... ");
    while (tty.read() != '\r')
        ;
    tty.println();

    tty.print("PES:");
    gal.readPES();
    gal.printRowBin(64);

    tty.print("UES:");
    gal.readUES();
    gal.printRowBin(64);

    tty.print("Turn off Vpp and Vcc, then hit <enter> ... ");
    while (tty.read() != '\r')
        ;
    tty.println();

    powerDown();
    tty.println("Done.");
}

void loop() { p0(LED); delay(100); p1(LED); delay(900); }
