#include <Arduino.h>
#include <SPI.h>

#define J_ARDUINO 1

#ifdef __AVR__

#define USBRX   0
#define USBTX   1
#define PA_4    4
#define PC_13   13

#else // __AVR__

#define USBRX   D0
#define USBTX   D1
#define PA_4    PA4
#define PA_11   PA11
#define PB_3    PB3
#define PB_4    PB4
#define PB_5    PB5
#define PB_6    PB6
#define PC_13   PC13

#endif // __AVR__

typedef int PinName;

template<PinName P>
struct JDigitalOut {
    JDigitalOut () {
        pinMode(P, OUTPUT);
    }
    JDigitalOut (int value) {
        digitalWrite(P, value);
        pinMode(P, OUTPUT);
    }
    JDigitalOut& operator= (int value) {
        digitalWrite(P, value);
        return *this;
    }
    operator int () const {
        return digitalRead(P);
    }
};

template< int N>
struct SpiGpio {
  static void master () {
    digitalWrite(N, 1);
    pinMode(N, OUTPUT);
    SPI.begin();
  }

  static uint8_t rwReg (uint8_t cmd, uint8_t val) {
    digitalWrite(N, 0);
    SPI.transfer(cmd);
    uint8_t in = SPI.transfer(val);
    digitalWrite(N, 1);
    return in;
  }
};

typedef SpiGpio<PA_4> JSPI1;
//typedef SpiGpio<PB_6> JSPI1;

struct JSerial {
    JSerial (int tx, int rx, long baud =115200) {
        Serial.begin(baud);
    }
    static void printf(const char* fmt, ...) {
        Serial.print(fmt);
    }
};

void wait_ms (int ms) {
    return delay(ms);
}
