#include <mbed.h>

template<PinName P>
struct JDigitalOut : DigitalOut {
    JDigitalOut ()
        : DigitalOut (P) {}
    JDigitalOut (int value)
        : DigitalOut (P, value) {}
    JDigitalOut& operator= (int value) {
        *(DigitalOut*)this = value;
        return *this;
    }
};

template< PinName MO, PinName MI, PinName CK, PinName SS >
class SpiGpio {
public:
    static void master () {
        nss = 1;
        spi.format(8);
        spi.frequency(2000000);
    }

    static void enable () {
        nss = 0;
    }

    static void disable () {
        nss = 1;
    }

    static uint8_t transfer (uint8_t val) {
        return spi.write(val);
    }

    static uint8_t rwReg (uint8_t cmd, uint8_t val) {
        enable();
        transfer(cmd);
        uint8_t r = transfer(val);
        disable();
        return r;
    }

    static DigitalOut nss;
    static SPI spi;
};

template< PinName MO, PinName MI, PinName CK, PinName SS >
DigitalOut SpiGpio<MO,MI,CK,SS>::nss (SS);

template< PinName MO, PinName MI, PinName CK, PinName SS >
SPI SpiGpio<MO,MI,CK,SS>::spi (MO, MI, CK);

//typedef SpiGpio<PB_5,PB_4,PB_3,PA_11> JSPI1;
typedef SpiGpio<PA_7,PA_6,PA_5,PB_6> JSPI1;

typedef Serial JSerial;

extern void setup ();
extern void loop ();

int main () {
    setup();
    for (;;)
        loop();
}
