#include "jee.h"
#include "rf69.h"

RF69<JSPI1> rf;

JSerial console (USBTX, USBRX, 115200);
//#include "USBSerial.h"
//USBSerial console;

void setup() {
    wait_ms(3000);
    console.printf("hello\n");
    rf.init(1, 6, 8686);
}

void loop() {
    char rxBuf [64];
    int bytes = rf.receive(rxBuf, sizeof rxBuf);
    if (bytes >= 0) {
        console.printf("RF69 #%d: ", bytes);
        for (int i = 0; i < bytes; ++i)
            console.printf("%02x", rxBuf[i]);
        console.printf("\n");
    }
}
