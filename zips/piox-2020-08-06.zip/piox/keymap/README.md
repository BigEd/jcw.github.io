Show incoming keys received on USB.  
Compiled for Blue Pill.  
Useful to figure out what function keys etc actually send in Miniterm.

-jcw, 2018-03-10
