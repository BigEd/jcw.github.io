#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  delay(3000); Serial.println("hello");
}

void loop() {
  int c = Serial.read();
  if (c > 0) {
    if ('!' <= c && c <= '~')
      Serial.write(c);
    else {
      if (c < 16)
        Serial.print('0');
      Serial.print(c, HEX);
    }
    Serial.print(' ');
  }
}
