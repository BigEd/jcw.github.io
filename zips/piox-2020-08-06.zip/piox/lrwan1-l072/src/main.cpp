#include <mbed.h>

DigitalOut led (PA_0);

int main () {
    while (1) {
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);
    }

    return 0;
}
