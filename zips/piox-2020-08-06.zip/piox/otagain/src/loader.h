// Boot loader, using radio driver w/ JeeBoot protocol.

#include <string.h>

// RfDriver is used by BootLogic to talk to the radio.
class RfDriver {
public:
    static int requestOnce (const void* inp, unsigned inLen, BootReply* rp) {
        // send out the request over RF
        D(("request # %d\n", inLen));
        rf.send(0xC0, inp, inLen);

        // wait a limited time for a reply to come back
        int len;
        for (int i = 0; i < 100000; ++i) {
            len = rf.receive(rp, sizeof (BootReply));
            if (len > 2)
                D(("l %d f %d o %d d %d", len, rp->flags, rp->orig, rp->dest));
            // only accept packets with special flags and coming from server
            if (len > 2 && rp->flags == 3 && rp->orig != 0 && rp->dest == 0)
                break;
            len = 0;
        }
        rf.sleep();

        D(("  got # %d\n", len));
        // D( for (int i = 0; i < len; ++i) )
        // D(     printf("%02x", ((const uint8_t*) rp)[i]); )
        // D(("\n"));
        return len - 2;
    }

    static int request (const void* inp, unsigned inLen, BootReply* rp) {
        for (int retry = 0; retry < 10; ++retry) {
            // send request and wait for a response
            int len = requestOnce(inp, inLen, rp);
            if (len > 0)
                return len;
            // add an exponential back-off delay
            // TODO go to sleep
            int n = 1 << (retry + 20);
            for (int i = 0; i < n; ++i) __asm("");
        }
        return -1;
    }
};

// RfDispatch is called by BootLogic when it wants to save to flash.
bool RfDispatch (int pos, const uint8_t* buf, int len) {
    D(("dispatch @ %d # %d\n", pos, len));

    // last call needs to flush what remains in pageBuf
    if (buf == 0 && pageFill > 0)
        len = PAGE_SIZE - pageFill;

    while (len > 0) {
        int count = len;
        if (pageFill + count > PAGE_SIZE)
            count = PAGE_SIZE - pageFill;

        if (buf) {
            D(("copying %db @ %d\n", count, pageFill));
            memcpy((uint8_t*) pageBuf + pageFill, buf, count);
            buf += count;
        } else {
            D(("clearing %db @ %d\n", count, pageFill));
            memset((uint8_t*) pageBuf + pageFill, 0xFF, count);
        }

        pageFill += count;
        if (pageFill >= PAGE_SIZE) {
            int pageNum = pos / PAGE_SIZE;
            D(("FLASH page %d pos %d\n", pageNum, pos));
#if 0
            if (pageNum == 0) {
                // swap reset vector so boot loader gets control back
                pageBuf[6] = pageBuf[1];
                pageBuf[1] = ((const int*) LOAD_ADDR)[1];
                // fix the vector table checksum to get past ROM boot check
                int sum = 0;
                for (int i = 0; i < 7; ++i)
                    sum -= pageBuf[i];
                pageBuf[7] = sum;
            }
#endif
            // TODO Flash64::erase(pageNum, 1);
            D(("erase %d\n", pageNum));
            // TODO Flash64::save(pageNum, pageBuf);
            D(("save %d @ %x\n", pageNum, pageBuf));
            pageFill = 0;
        }

        pos += count;
        len -= count;
    }

    return true;
}

typedef bool (*BootLogicDispatch)(int, const uint8_t*, int);

template< typename DRIVER, BootLogicDispatch DISPATCH >
class BootLogic {
    DRIVER driver;

public:
    BootReply reply;

    bool identify (uint16_t type, const uint8_t* hwid =0) {
        HelloRequest req;
        req.type = type & 0xFFF;
        req.bootRev = BOOT_REVISION;

        memset(req.hwId, 0, sizeof req.hwId);
        if (hwid != 0)
            memcpy(req.hwId, hwid, sizeof req.hwId);

        int n = driver.request(&req, sizeof req, &reply);
        return n == sizeof reply.h;
    }

    int fetchOne (uint16_t swid, uint16_t index) {
        FetchRequest req;
        req.swId = swid;
        req.swIndex = index;

        return driver.request(&req, sizeof req, &reply) - 2;
    }

    bool fetchAll (uint16_t swid) {
        int pos = 0;
        uint16_t index = 0;
        for (;;) {
            int len = fetchOne(swid, index);
            if (len <= 0)
                break;
            bool ok = DISPATCH(pos, reply.f.data, len);
            if (!ok)
                return false;
            pos += len;
            ++index;
        }
        return DISPATCH(pos, 0, 0);
    }
};
