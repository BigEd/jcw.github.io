#include <jee.h>
#include <jee/spi-rf69.h>

UartDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

#define RF_DEBUG 1     // set to 1 to include serial printf debugging, else 0

#if RF_DEBUG
#define D(x) printf x
#else
#define D(x)
#endif

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
RF69< decltype(spi) > rf;

const int PAGE_SIZE = 1024, LOAD_ADDR = 0xC000;
int pageFill, pageBuf [PAGE_SIZE/sizeof(int)];

#include "packets.h"
#include "util.h"
#include "loader.h"

// the bootLogic object encapsulates the entire... boot logic
BootLogic<RfDriver,RfDispatch> bootLogic;

void bootLoader () {
    D(("rf inited %x\n", (unsigned) pageBuf));

    // get the 12-byte h/w id, see STM32 docs - TODO this is F103-specific!
    auto result = (const uint8_t*) 0x1FFFF7E8;

    // let's get in touch with the boot server first
    D(("> identify\n"));
    while (bootLogic.identify(99, result)) {
        auto swid = bootLogic.reply.h.swId;
        auto size = bootLogic.reply.h.swSize;
        auto crc = bootLogic.reply.h.swCrc;
        D(("  swid %u size %u crc %x\n", swid, size, crc));

#if 0
        // if current code matches size and crc, we're done
        // unfortunately, we have to "fake-unpatch" low mem to calculate it
        memcpy(pageBuf, 0x0000, PAGE_SIZE);
        pageBuf[1] = pageBuf[6];
        // this assumes entry 6 and 7 are zero in the original code file!
        pageBuf[6] = pageBuf[7] = 0;

        // calculate checksum over 64 bytes of RAM, rest from flash memory
        uint16_t myCrc = Util::calculateCrc(CRC_INIT, pageBuf, PAGE_SIZE);
        myCrc = Util::calculateCrc(myCrc, (void*) PAGE_SIZE, size - PAGE_SIZE);

        D(("  myCrc %x\n", myCrc));
        if (crc == myCrc)
            break;

        // nope, we need to download the latest firmware
#endif
        D(("> fetchAll %u\n", swid));
        bootLogic.fetchAll(swid);

        break; // FIXME see above
    }

    D(("JUMP"));
    console.putc('!');
    console.putc('\n');
    // D( for (int i = 0; i < 100000; ++i) __ASM(""); ) // let serial finish
    // D( LPC_SWM->PINASSIGN[0] = 0xFFFFFFFF; );        // disable serial pin

    // finally, prepare to jump to user code:
    //  * reset dispatch vector base
    //  * reset stack
    //  * jump to (alternate!) reset vector entry
    // see http://markdingst.blogspot.nl/
    //  2012/06/make-own-bootloader-for-arm-cortex-m3.html
#if 0
    __ASM("ldr     r0, =0x0000\n"
          "ldr     r1, =0xE000ED08\n"
          "str     r0, [r1]\n"
          "ldr     r1, [r0]\n"
          "mov     sp, r1\n"
          "ldr     r0, [r0, #24]\n"
          "bx      r0\n");
#endif
}

// TODO from is probably meaningless
void respondToHello (int8_t from, const HelloRequest* req) {
    D(("Hello Req: f %d t %d b %d h %d\n",
        from, req->type, req->bootRev, req->hwId));
    HelloReply r { 99, BOOT_REVISION, 3, 120, 4 };
    rf.send(0xC0, &r, sizeof r);
};

void respondToFetch (int8_t from, const FetchRequest* req) {
    D(("Fetch Req: f %d i %d x %d\n", from, req->swId, req->swIndex));
    FetchReply r;
    r.swIdXor = req->swId ^ req->swIndex;
    if (req->swIndex < 2) {
        memset(r.data, req->swId, sizeof r.data);
        rf.send(0xC0, &r, sizeof r);
    } else
        rf.send(0xC0, &r, 2);
}

void bootServer () {
    while(1) {
        uint8_t rxBuf [64];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);
        if (rxLen < 0)
            continue;

        D(("recv %db afc %d rssi %d lna %d:", rxLen, rf.afc, rf.rssi, rf.lna));
        for (int i = 0; i < rxLen; ++i)
            D((" %02x", rxBuf[i]));
        D(("\n"));

        uint8_t from = rxBuf[1] & 0x3F;
        switch (rxLen-2) {
            case sizeof (HelloRequest):
                respondToHello(from, (const HelloRequest*) (rxBuf + 2));
                break;
            case sizeof (FetchRequest):
                respondToFetch(from, (const FetchRequest*) (rxBuf + 2));
                break;
        }
    }
}

int main() {
    D(("\n"));
#if CENTRAL
    D(("[1] CENTRAL\n"));
    int me = 1; // him = 2;
#else
    D(("[2] REMOTE\n"));
    int me = 2; // him = 1;
#endif
    spi.init();
    rf.init(me, 55, 869525);
    // rf.encrypt("mysecret");
    rf.txPower(0);
    rf.sleep();

    // dump all RFM69 registers
    for (int i = 0; i < 0x60; i += 16) {
        D(("%02x:", i));
        for (int j = 0; j < 16; ++j)
            D((" %02x", rf.readReg(i+j)));
        D(("\n"));
    }

#if CENTRAL
    bootServer();
#else
    bootLoader();
#endif
}
