#include <mbed.h>
#include "spi.h"
#include "rf69.h"

Serial console (PA_2, PA_15, 115200);
RF69<SpiDev1> rf;
uint8_t rxBuf [64];

int main() {
    rf.init(1, 6, 8686);
    console.printf("hello\n");
    int i = 0;
    while (1) {
        int len = rf.receive(rxBuf, sizeof rxBuf);
        if (len >= 0) {
            console.printf("%d: %d bytes\n", ++i, len);
        }
    }
}
