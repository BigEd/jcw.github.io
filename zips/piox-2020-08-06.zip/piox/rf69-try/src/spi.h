#include <mbed.h>

template< PinName MO, PinName MI, PinName CK, PinName SS >
class SpiDev {
public:
    static void master () {
        nss = 1;
        spi.format(8);
        spi.frequency(8000000);
    }

    static void enable () {
        nss = 0;
    }

    static void disable () {
        nss = 1;
    }

    static uint8_t transfer (uint8_t val) {
        return spi.write(val);
    }

    static uint8_t rwReg (uint8_t cmd, uint8_t val) {
        enable();
        transfer(cmd);
        uint8_t r = transfer(val);
        disable();
        return r;
    }

    static DigitalOut nss;
    static SPI spi;
};

template< PinName MO, PinName MI, PinName CK, PinName SS >
DigitalOut SpiDev<MO,MI,CK,SS>::nss (SS);

template< PinName MO, PinName MI, PinName CK, PinName SS >
SPI SpiDev<MO,MI,CK,SS>::spi (MO, MI, CK);

typedef SpiDev<PB_5,PB_4,PB_3,PA_11> SpiDev1;
