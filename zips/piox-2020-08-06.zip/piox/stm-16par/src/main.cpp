// ILI9325 LCD (HY28A-LCDA) demo, connected to Blue Pill via 16-bit parallel
//
// This implements a simple serial display, taking input from USB.

#include <Arduino.h>
#include <jee.h>
#include <jee/text-font.h>

PinA<8> rst;
PinB<7> csa;
PinC<13> led;

#if 1
#include <jee/dio-ili9325.h>
ILI9325< PinB<1>, PinB<0>, PinB<6> > lcd;
#else
#include <jee/spi-ili9325.h>
SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4>, 1 > spi;
ILI9325< decltype(spi) > lcd;
#endif

TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;

UartBufDev< PinA<9>, PinA<10> > uart;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    fullSpeedClock();
    uart.init();

    PinA<12> usbEna;
    usbEna.mode(Pinmode::out);
    usbEna = 0;
    wait_ms(2);
    usbEna = 1;

    Serial.begin();

    rst.mode(Pinmode::out); rst = 0;
    csa.mode(Pinmode::out); csa = 0;
    led.mode(Pinmode::out); led = 1;
    rst = 1; wait_ms(10);

    lcd.init();
    // lcd.write(0x01, 0);  // fix scan line dir of HY28A-LCDA (default 0x0100)
    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    for (char c = '0'; c <= '9'; ++c)
        uart.putc(c);
    uart.putc('\n');

    while (true) {
        printf("%d\n", ticks);
        wait_ms(500);
    }

    while (true) {
        if (Serial.available()) {
            char c = Serial.read();
            uart.putc(c);
            text.fg = 0xFFFF;
            console.putc(c);
        }
        if (uart.readable()) {
            char c = uart.getc();
            Serial.write(c);
            text.fg = 0x07E0;
            console.putc(c);
        }
    }
}
