// Try to run an 8080 emulator.

#include <jee.h>
#include <string.h>

#define index indx

#include "i8080.h"
#include "i8080_hal.h"
#include "i8080_hal_c.h"
#include "i8080_c.h"
#include "cputest_com.h"
#include "test_com.h"
#include "8080pre_com.h"
#include "8080ex1_com.h"

#if 0
UartBufDev< PinA<9>, PinA<10> > console;
#else
UsbDev< PinA<12> > console;
#endif

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

static void execute_test (uint8_t const* comdata, size_t comlen) {
    if (comlen + 500 > sizeof memory) {
        printf("skipped, %d bytes won't fit\n", comlen);
        return;
    }

    uint8_t* mem = i8080_hal_memory();
    memset(mem, 0, 0x4000);
    memcpy(mem + 0x0100, comdata, comlen);

    mem[5] = 0xC9;  // Inject RET at 0x0005 to handle "CALL 5".
    i8080_init();
    i8080_jump(0x100);

    while (true) {
        int pc = i8080_pc();
        if (mem[pc] == 0x76) {
            printf("\nHLT at %04x\n", pc);
            return;
        }
        if (pc == 0x0005) {
            switch (i8080_regs_c()) {
                case 2:
                    console.putc((char)i8080_regs_e());
                    break;
                case 9:
                    for (int i = i8080_regs_de(); mem[i] != '$'; i += 1)
                        console.putc(mem[i]);
                    break;
            }
        }
        i8080_instruction();
        if (i8080_pc() == 0) {
            printf("\nJump to 0000 from %04x\n", pc);
            return;
        }
    }
}

int main () {
    //console.init();
    //fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    printf("1: %d ms\n", ticks);
    execute_test(CPUTEST_COM, sizeof CPUTEST_COM);
    printf("2: %d ms\n", ticks);
    execute_test(TEST_COM, sizeof TEST_COM);
    printf("3: %d ms\n", ticks);
    execute_test(__8080PRE_COM, sizeof __8080PRE_COM);
    printf("4: %d ms\n", ticks);
    execute_test(__8080EX1_COM, sizeof __8080EX1_COM);
    printf("5: %d ms\n", ticks);
    return 0;
}
