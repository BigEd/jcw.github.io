// Demo of a Blue Pill with ILI9341 LCD display connected via SPI.

#include <jee.h>
#include <jee/spi-ili9341.h>
#include <jee/text-font.h>

SpiHw< PinB<5>, PinB<4>, PinB<3>, PinB<0> > spi;
ILI9341< decltype(spi), PinB<6> > lcd;
PinA<15> light;  // LCD backlight
PinB<7> reset;   // LCD hard reset

TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    fullSpeedClock(); // 72Mhz

    light.mode(Pinmode::out);
    reset.mode(Pinmode::out);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25; // disable JTAG, keep SWD enabled

    // the following is needed to use h/w SPI1 with pins B5..B3 iso A7..A5
    MMIO32(afio + 0x04) |= (1<<0);  // SPI1_REMAP in AFIO's MAPR

    spi.init();
    reset = 1;
    wait_ms(10); // data sheet says to wait 5ms
    lcd.init();

    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    light = 1; // turn backlighting on

    while (true) {
      printf("%d\n", ticks);
      wait_ms(500);
    }
}
