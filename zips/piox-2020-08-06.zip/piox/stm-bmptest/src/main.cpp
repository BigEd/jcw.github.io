#include <jee.h>

UartDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

// PinD<3> led;

int main() {
    enableSysTick();
    // led.mode(Pinmode::out);
    while (1) {
        printf("%d\n", ticks);
        // led.toggle();
        wait_ms(500);
    }
}
