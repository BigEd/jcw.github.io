// Data capture setup for RF69, using a 16 MB SPI flash chip.

#include <jee.h>
#include <jee/spi-rf69.h>
#include <jee/spi-flash.h>

UartBufDev< PinA<9>, PinA<10>, 500 > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiHw< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spiA;
RF69< decltype(spiA) > rf;

SpiHw< PinB<15>, PinB<14>, PinB<13>, PinB<12> > spiB;
SpiFlash< decltype(spiB) > mem;

PinC<13> led;

static void radioScanner () {
    rf.init(63, 42, 8683);    // node 63, group 42, 868.3 MHz
    rf.writeReg(0x29, 0xFF);  // minimal RSSI threshold
    rf.writeReg(0x2E, 0xB8);  // sync size 7+1
    rf.writeReg(0x58, 0x29);  // high sensitivity mode
    rf.writeReg(0x19, 0x4C);  // reduced Rx bandwidth
    // rf.writeReg(0x03, 0x02);  // bit rate

    rf.setMode(rf.MODE_RECEIVE);

    constexpr int NFS = 256;  // number of frequency steps
    constexpr int SPS = 16;   // samples per frequency step
    constexpr int us = 0;     // microsecond delay between rssi samples

    // 868.3 MHz = 0xD91300, with 80 steps per pixel, a sweep can cover
    // 256*80*61.03515625 = 1.25 Mz, i.e. 625 kHz towards both sides
    constexpr uint32_t middle = 0xD91300;  // 0xE4C000 for 915.0 MHz
    constexpr uint32_t step = 80;
    uint32_t first = middle - NFS/2 * step;

    static uint8_t buf [SPS*NFS];
    printf("NFS %d x SPS %d = %d\n", NFS, SPS, sizeof buf);

    while (true) {
        int max = 0;
        uint8_t* p = buf;
        uint32_t start = ticks;

        for (int x = 0; x < NFS; ++x) {
            // step to a new frequency
            uint32_t freq = first + x * step;
            rf.writeReg(rf.REG_FRFMSB,   freq >> 16);
            rf.writeReg(rf.REG_FRFMSB+1, freq >> 8);
            rf.writeReg(rf.REG_FRFMSB+2, freq);

            SysTick<72000000> now;
            for (int i = 0; i < SPS; ++i) {
                if (us > 2)
                    now.wait_us(us-2);
                uint8_t v = ~rf.readReg(rf.REG_RSSIVALUE);
                if (v > max && x > 50) // don't use first 50 readings
                    max = v;
                *p++ = v;
            }
        }

        if (max >= 120) {
            printf("%d ms\n", ticks - start);
            break;
        }
    }

    uint32_t stop = ticks;
    for (int i = 0; i < sizeof buf; ++i)
        printf(" %d", buf[i]);
    wait_ms(100);
    printf("\n");
}

static void radioListener () {
    rf.init(63, 6, 8686);     // node 63, group 6, 868.6 MHz
    rf.writeReg(0x29, 0xE4);  // lower RSSI threshold
    // rf.writeReg(0x58, 0x29);  // high sensitivity mode

    while (true) {
        uint8_t rxBuf [66];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            led.toggle();

            printf("RF69 r%d l%d a%d %d>%d ",
                    rf.rssi, rf.lna, rf.afc, rxBuf[1] & 0x3F, rxBuf[0] & 0x3F);
            for (int i = 0; i < rxLen; ++i)
                printf("%02x", rxBuf[i]);
            printf("\n");
        }
    }
}

int main() {
    fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    // (PB3/PB4 are tied to DIO pins of the RFM69 module)
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    spiA.init();
    spiB.init();

    // SPE, BR=2, MSTR, CPOL (clk/2, i.e. 18 MHz)
    MMIO32(spiB.cr1) = (1<<6) | (0<<3) | (1<<2) | (0<<1);

    mem.init();
    printf("id %06x, %dK\n", mem.devId(), mem.size());

    static uint8_t buf [256];
    uint32_t start = ticks;
    for (int i = 0; i < 1000; ++i)
        mem.read256(i, buf);
    printf("read 256 %d us\n", ticks - start);

    start = ticks;
    for (int i = 0; i < 10; ++i)
        mem.erase(16 * i);
    printf("erase 4k %d ms\n", (ticks - start) / 10);

    start = ticks;
    for (int i = 0; i < 100; ++i)
        mem.write256(i, buf);
    printf("write 256 %d us\n", (ticks - start) * 10);

#if 0
    start = ticks;
    mem.wipe();
    printf("wipe all %d ms\n", ticks - start);
#endif

    // radioScanner();
    radioListener();
}
