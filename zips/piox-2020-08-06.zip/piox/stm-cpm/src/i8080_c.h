// Intel 8080 (KR580VM80A) microprocessor core model
//
// Copyright (C) 2012 Alexander Demin <alexander@demin.ws>
//
// Optimized for Arduino by reducing memory usage by Rick Companje (2016)
//
// Credits
//
// Viacheslav Slavinsky, Vector-06C FPGA Replica
// http://code.google.com/p/vector06cc/
//
// Dmitry Tselikov, Bashrikia-2M and Radio-86RK on Altera DE1
// http://bashkiria-2m.narod.ru/fpga.html
//
// Ian Bartholomew, 8080/8085 CPU Exerciser
// http://www.idb.me.uk/sunhillow/8080.html
//
// Frank Cringle, The original exerciser for the Z80.
//
// Thanks to zx.pk.ru and nedopc.org/forum communities.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

#include "i8080.h"
#include "i8080_hal.h"

#define RD_BYTE(addr) i8080_hal_memory_read_byte(addr)
#define RD_WORD(addr) i8080_hal_memory_read_word(addr)

#define WR_BYTE(addr, value) i8080_hal_memory_write_byte(addr, value)
#define WR_WORD(addr, value) i8080_hal_memory_write_word(addr, value)

typedef union {
    struct { uint8_t l, h; };
    uint16_t w;
} reg_pair;

struct i8080 {
    struct {
        uint8_t carry_flag;
        uint8_t unused1;
        uint8_t parity_flag;
        uint8_t unused3;
        uint8_t half_carry_flag;
        uint8_t unused5;
        uint8_t zero_flag;
        uint8_t sign_flag;
    };
    reg_pair af, bc, de, hl;
    reg_pair sp, pc;
    uint16_t iff;
};

#define AF              cpu.af.w
#define BC              cpu.bc.w
#define DE              cpu.de.w
#define HL              cpu.hl.w
#define SP              cpu.sp.w
#define PC              cpu.pc.w
#define A               cpu.af.h
#define F               cpu.af.l
#define B               cpu.bc.h
#define C               cpu.bc.l
#define D               cpu.de.h
#define E               cpu.de.l
#define H               cpu.hl.h
#define L               cpu.hl.l
#define HSP             cpu.sp.h
#define LSP             cpu.sp.l
#define HPC             cpu.pc.h
#define LPC             cpu.pc.l
#define IFF             cpu.iff

#define F_CARRY         0x01
#define F_UN1           0x02
#define F_PARITY        0x04
#define F_UN3           0x08
#define F_HCARRY        0x10
#define F_UN5           0x20
#define F_ZERO          0x40
#define F_NEG           0x80

#define C_FLAG          cpu.carry_flag
#define P_FLAG          cpu.parity_flag
#define H_FLAG          cpu.half_carry_flag
#define Z_FLAG          cpu.zero_flag
#define S_FLAG          cpu.sign_flag
#define UN1_FLAG        cpu.unused1
#define UN3_FLAG        cpu.unused3
#define UN5_FLAG        cpu.unused5

#define SET(flag)       (flag = 1)
#define CLR(flag)       (flag = 0)
#define TST(flag)       (flag)
#define CPL(flag)       (flag = !flag)

static struct i8080 cpu;

static uint8_t const half_carry_table[] = { 0, 0, 1, 0, 1, 0, 1, 1 };
static uint8_t const sub_half_carry_table[] = { 1, 0, 0, 0, 1, 1, 1, 0 };

static void POP (uint16_t& reg) { reg = RD_WORD(SP); SP += 2; }
static void PUSH (uint16_t reg) { SP -= 2; WR_WORD(SP, reg); }
//static void RET () { POP(PC); }
//static void STC () { SET(C_FLAG); }
//static void CMC () { CPL(C_FLAG); }

static int i8080_getParity (int val) {
    val ^= val >> 4;
    val &= 0xf;
    return !((0x6996 >> val) & 1);
}

static void INR (uint8_t& reg) {
    ++reg;
    S_FLAG = (reg & 0x80) != 0;
    Z_FLAG = reg == 0;
    H_FLAG = (reg & 0x0f) == 0;
    P_FLAG = i8080_getParity(reg);
}

static void DCR (uint8_t& reg) {
    --reg;
    S_FLAG = (reg & 0x80) != 0;
    Z_FLAG = reg == 0;
    H_FLAG = (reg & 0x0f) != 0x0f;
    P_FLAG = i8080_getParity(reg);
}

static void ADD (uint8_t val) {
    uint16_t work16 = (uint16_t)A + val;
    int index = ((A & 0x08) >> 1) |
                ((val & 0x08) >> 2) |
                ((work16 & 0x08) >> 3);
    A = work16 & 0xff;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    H_FLAG = half_carry_table[index];
    P_FLAG = i8080_getParity(A);
    C_FLAG = (work16 & 0x0100) != 0;
}

static void ADC (uint8_t val) {
    uint16_t work16 = (uint16_t)A + val + C_FLAG;
    int index = ((A & 0x08) >> 1) |
                ((val & 0x08) >> 2) |
                ((work16 & 0x08) >> 3);
    A = work16 & 0xff;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    H_FLAG = half_carry_table[index];
    P_FLAG = i8080_getParity(A);
    C_FLAG = (work16 & 0x0100) != 0;
}

static void SUB (uint8_t val) {
    uint16_t work16 = (uint16_t)A - val;
    int index = ((A & 0x08) >> 1) |
                ((val & 0x08) >> 2) |
                ((work16 & 0x08) >> 3);
    A = work16 & 0xff;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    H_FLAG = sub_half_carry_table[index];
    P_FLAG = i8080_getParity(A);
    C_FLAG = (work16 & 0x0100) != 0;
}

static void SBB (uint8_t val) {
    uint16_t work16 = (uint16_t)A - val - C_FLAG;
    int index = ((A & 0x08) >> 1) |
                ((val & 0x08) >> 2) |
                ((work16 & 0x08) >> 3);
    A = work16 & 0xff;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    H_FLAG = sub_half_carry_table[index];
    P_FLAG = i8080_getParity(A);
    C_FLAG = (work16 & 0x0100) != 0;
}

static void CMP (uint8_t val) {
    uint16_t work16 = (uint16_t)A - val;
    int index = ((A & 0x08) >> 1) |
                ((val & 0x08) >> 2) |
                ((work16 & 0x08) >> 3);
    S_FLAG = (work16 & 0x80) != 0;
    Z_FLAG = (work16 & 0xff) == 0;
    H_FLAG = sub_half_carry_table[index];
    C_FLAG = (work16 & 0x0100) != 0;
    P_FLAG = i8080_getParity(work16 & 0xff);
}

static void ANA (uint8_t val) {
    H_FLAG = ((A | val) & 0x08) != 0;
    A &= val;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    P_FLAG = i8080_getParity(A);
    CLR(C_FLAG);
}

static void XRA (uint8_t val) {
    A ^= val;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    CLR(H_FLAG);
    P_FLAG = i8080_getParity(A);
    CLR(C_FLAG);
}

static void ORA (uint8_t val) {
    A |= val;
    S_FLAG = (A & 0x80) != 0;
    Z_FLAG = A == 0;
    CLR(H_FLAG);
    P_FLAG = i8080_getParity(A);
    CLR(C_FLAG);
}

static void DAD (uint16_t reg) {
    uint32_t work32 = (uint32_t)HL + reg;
    HL = work32;
    C_FLAG = (work32 & 0x10000L) != 0;
}

static void CALL () {
    PUSH(PC + 2);
    PC = RD_WORD(PC);
}

static void RST (uint16_t addr) {
    PUSH(PC);
    PC = (addr);
}

#define DEST(x) ((x >> 3) & 7)
#define SOURCE(x) (x & 7)
#define CONDITION(x) ((x >> 3) & 7)
#define VECTOR(x) ((x >> 3) & 7)
#define RP(x) ((x >> 4) & 3)

static uint8_t M;
static uint8_t* const REG[] = { &B, &C, &D, &E, &H, &L, &M, &A };
static uint16_t* const PAIR[] = { &BC, &DE, &HL, &SP };

static void i8080_init(void) {
    C_FLAG = 0;
    S_FLAG = 0;
    Z_FLAG = 0;
    H_FLAG = 0;
    P_FLAG = 0;
    UN1_FLAG = 1;
    UN3_FLAG = 0;
    UN5_FLAG = 0;

    PC = 0xF800;
}

static void i8080_store_flags(void) {
    if (S_FLAG) F |= F_NEG;      else F &= ~F_NEG;
    if (Z_FLAG) F |= F_ZERO;     else F &= ~F_ZERO;
    if (H_FLAG) F |= F_HCARRY;   else F &= ~F_HCARRY;
    if (P_FLAG) F |= F_PARITY;   else F &= ~F_PARITY;
    if (C_FLAG) F |= F_CARRY;    else F &= ~F_CARRY;
    F |= F_UN1;    // UN1_FLAG is always 1.
    F &= ~F_UN3;   // UN3_FLAG is always 0.
    F &= ~F_UN5;   // UN5_FLAG is always 0.
}

static void i8080_retrieve_flags(void) {
    S_FLAG = F & F_NEG      ? 1 : 0;
    Z_FLAG = F & F_ZERO     ? 1 : 0;
    H_FLAG = F & F_HCARRY   ? 1 : 0;
    P_FLAG = F & F_PARITY   ? 1 : 0;
    C_FLAG = F & F_CARRY    ? 1 : 0;
}

static uint8_t i8080_checkCondition(uint8_t c) {
  switch (c) {
    case 0: return !Z_FLAG;
    case 1: return Z_FLAG;
    case 2: return !C_FLAG;
    case 3: return C_FLAG;
    case 4: return !P_FLAG;
    case 5: return P_FLAG;
    case 6: return !S_FLAG;
    case 7: return S_FLAG;
  }
  return 0;
}

static void i8080_execute(int opcode) {
    uint16_t work16;
    uint8_t work8;
    uint8_t carry, add;

    switch (opcode) {
        case 0x00:            /* nop */
        // Undocumented NOP.
        case 0x08:            /* nop */
        case 0x10:            /* nop */
        case 0x18:            /* nop */
        case 0x20:            /* nop */
        case 0x28:            /* nop */
        case 0x30:            /* nop */
        case 0x38:            /* nop */
            return;

        case 0x07:            /* rlc */
            C_FLAG = ((A & 0x80) != 0);
            A = (A << 1) | C_FLAG;
            return;

        case 0x0F:            /* rrc */
            C_FLAG = A & 0x01;
            A = (A >> 1) | (C_FLAG << 7);
            return;

        case 0x17:            /* ral */
            work8 = (uint8_t)C_FLAG;
            C_FLAG = ((A & 0x80) != 0);
            A = (A << 1) | work8;
            return;

        case 0x1F:             /* rar */
            work8 = (uint8_t)C_FLAG;
            C_FLAG = A & 0x01;
            A = (A >> 1) | (work8 << 7);
            return;

        case 0x21:             /* lxi h, data16 */
            HL = RD_WORD(PC);
            PC += 2;
            break;

        case 0x22:            /* shld addr */
            WR_WORD(RD_WORD(PC), HL);
            PC += 2;
            return;

        case 0x27:            /* daa */
            carry = (uint8_t)C_FLAG;
            add = 0;
            if (H_FLAG || (A & 0x0f) > 9) {
                add = 0x06;
            }
            if (C_FLAG || (A >> 4) > 9 || ((A >> 4) >= 9 && (A & 0x0f) > 9)) {
                add |= 0x60;
                carry = 1;
            }
            ADD(add);
            P_FLAG = i8080_getParity(A);
            C_FLAG = carry;
            return;

        case 0x2A:            /* ldhl addr */
            HL = RD_WORD(RD_WORD(PC));
            PC += 2;
            return;

        case 0x2F:            /* cma */
            A ^= 0xff;
            return;

        case 0x32:            /* sta addr */
            WR_BYTE(RD_WORD(PC), A);
            PC += 2;
            return;

        case 0x34:            /* inr m */
            work8 = RD_BYTE(HL);
            INR(work8);
            WR_BYTE(HL, work8);
            return;

        case 0x35:            /* dcr m */
            work8 = RD_BYTE(HL);
            DCR(work8);
            WR_BYTE(HL, work8);
            return;

        case 0x36:            /* mvi m, data8 */
            WR_BYTE(HL, RD_BYTE(PC++));
            return;

        case 0x37:            /* stc */
            SET(C_FLAG);
            return;

        case 0x3A:            /* lda addr */
            A = RD_BYTE(RD_WORD(PC));
            PC += 2;
            return;

        case 0x3F:            /* cmc */
            CPL(C_FLAG);
            return;

        case 0x76:            /* hlt */
            PC--;
            return;

        case 0x86:            /* add m */
            work8 = RD_BYTE(HL);
            ADD(work8);
            return;

        case 0x8E:            /* adc m */
            work8 = RD_BYTE(HL);
            ADC(work8);
            return;

        case 0x96:            /* sub m */
            work8 = RD_BYTE(HL);
            SUB(work8);
            return;

        case 0x9E:            /* sbb m */
            work8 = RD_BYTE(HL);
            SBB(work8);
            return;

        case 0xA6:            /* ana m */
            work8 = RD_BYTE(HL);
            ANA(work8);
            return;

        case 0xAE:            /* xra m */
            work8 = RD_BYTE(HL);
            XRA(work8);
            return;

        case 0xB6:            /* ora m */
            work8 = RD_BYTE(HL);
            ORA(work8);
            return;

        case 0xBE:            /* cmp m */
            work8 = RD_BYTE(HL);
            CMP(work8);
            return;

        case 0xC3:            /* jmp addr */
        case 0xCB:            /* jmp addr, undocumented */
            PC = RD_WORD(PC);
            return;

        case 0xC6:            /* adi data8 */
            work8 = RD_BYTE(PC++);
            ADD(work8);
            return;

        case 0xC9:            /* ret */
        case 0xD9:            /* ret, undocumented */
            POP(PC);
            return;

        case 0xCD:            /* call addr */
        case 0xDD:            /* call, undocumented */
        case 0xED:
        case 0xFD:
            CALL();
            return;

        case 0xCE:            /* aci data8 */
            work8 = RD_BYTE(PC++);
            ADC(work8);
            return;

        case 0xD3:            /* out port8 */
            i8080_hal_io_output(RD_BYTE(PC++), A);
            return;

        case 0xD6:            /* sui data8 */
            work8 = RD_BYTE(PC++);
            SUB(work8);
            return;

        case 0xDB:            /* in port8 */
            A = i8080_hal_io_input(RD_BYTE(PC++));
            return;

        case 0xDE:            /* sbi data8 */
            work8 = RD_BYTE(PC++);
            SBB(work8);
            return;

        case 0xE3:            /* xthl */
            work16 = RD_WORD(SP);
            WR_WORD(SP, HL);
            HL = work16;
            return;

        case 0xE6:            /* ani data8 */
            work8 = RD_BYTE(PC++);
            ANA(work8);
            return;

        case 0xE9:            /* pchl */
            PC = HL;
            return;

        case 0xEB:            /* xchg */
            work16 = DE;
            DE = HL;
            HL = work16;
            return;

        case 0xEE:            /* xri data8 */
            work8 = RD_BYTE(PC++);
            XRA(work8);
            return;

        case 0xF1:            /* pop psw */
            POP(AF);
            i8080_retrieve_flags();
            return;

        case 0xF3:            /* di */
            IFF = 0;
            i8080_hal_iff(IFF);
            return;

        case 0xF5:            /* push psw */
            i8080_store_flags();
            PUSH(AF);
            return;

        case 0xF6:            /* ori data8 */
            work8 = RD_BYTE(PC++);
            ORA(work8);
            return;

        case 0xF9:            /* sphl */
            SP = HL;
            return;

        case 0xFB:            /* ei */
            IFF = 1;
            i8080_hal_iff(IFF);
            return;

        case 0xFE:            /* cpi data8 */
            work8 = RD_BYTE(PC++);
            CMP(work8);
            return;

    }

    // cmp,ora,xra,ana,sbb,sub,adc,add
    switch (opcode & 0b11111000) {
        // cmp s  ZSPCA   Compare register with A
        case 0b10111000: CMP(*REG[SOURCE(opcode)]); return;
        // ora s  ZSPCA   OR  register with A
        case 0b10110000: ORA(*REG[SOURCE(opcode)]); return;
        // xra s  ZSPCA   ExclusiveOR register with A
        case 0b10101000: XRA(*REG[SOURCE(opcode)]); return;
        // ana s  ZSCPA   AND register with A
        case 0b10100000: ANA(*REG[SOURCE(opcode)]); return;
        // sbb s  ZSCPA   Subtract register from A with borrow
        case 0b10011000: SBB(*REG[SOURCE(opcode)]); return;
        // sub s  ZSCPA   Subtract register from A
        case 0b10010000: SUB(*REG[SOURCE(opcode)]); return;
        // adc s  ZSCPA   Add register to A with carry
        case 0b10001000: ADC(*REG[SOURCE(opcode)]); return;
        // add s  ZSPCA   Add register to A
        case 0b10000000: ADD(*REG[SOURCE(opcode)]); return;
    }

    // rst,cccc,jccc,rccc,mvi,dcr,inr
    switch (opcode & 0b11000111) {
        // rst n - Restart (n*8)
        case 0b11000111:
            RST(DEST(opcode)*8);
            return;
        // cccc a    lb hb    -       Conditional subroutine call
        case 0b11000100:
            if (i8080_checkCondition(CONDITION(opcode)))
                CALL();
            else
                PC+=2;
            return;
        // jccc a    lb hb    -       Conditional jump
        case 0b11000010:
            if (i8080_checkCondition(CONDITION(opcode)))
                PC = RD_WORD(PC);
            else
                PC+=2;
            return;
        // rccc -       Conditional return 0 from subroutine
        case 0b11000000:
            if (i8080_checkCondition(CONDITION(opcode)))
                POP(PC);
            return;
        // mvi d,#   db - Move immediate to register
        case 0b00000110:
            *REG[DEST(opcode)] = RD_BYTE(PC++);
            return;
        // dcr d   ZSPA    Decrement register
        case 0b00000101:
            DCR(*REG[DEST(opcode)]);
            return;
        // inr d   ZSPA    Increment register
        case 0b00000100:
            INR(*REG[DEST(opcode)]);
            return;
    }

    // push,pop,dcx,ldax,dad,inx,stax,lxi
    switch (opcode & 0b11001111) {
        // push rp   *2       -       Push register pair on the stack
        case 0b11000101: PUSH(*PAIR[RP(opcode)]); return;
        // pop rp    *2       *2      Pop  register pair from the stack
        case 0b11000001: POP(*PAIR[RP(opcode)]); return;
        // dcx rp -       Decrement register pair
        case 0b00001011: (*PAIR[RP(opcode)])--; return;
        // ldax rp   *1       -       Load indirect through BC or DE
        case 0b00001010: A = RD_BYTE(*PAIR[RP(opcode)]); return;
        // dad rp             C       Add register pair to HL (16 bit add)
        case 0b00001001: DAD(*PAIR[RP(opcode)]); return;
        // inx rp             -       Increment register pair
        case 0b00000011: (*PAIR[RP(opcode)])++; return;
        // stax rp   *1       -       Store indirect through BC or DE
        case 0b00000010: WR_BYTE(*PAIR[RP(opcode)],A); return;
        // lxi rp,#  lb hb    -       Load register pair immediate
        case 0b00000001: *PAIR[RP(opcode)] = RD_WORD(PC); PC+=2; return;
    }

    // mov d,s - Move register to register
    if ((opcode & 0b11000000) == 0b01000000) { 
        if (DEST(opcode)==6)
            WR_BYTE(HL,*REG[SOURCE(opcode)]);
        else if (SOURCE(opcode)==6)
            *REG[DEST(opcode)] = RD_BYTE(HL);
        else
            *REG[DEST(opcode)] = *REG[SOURCE(opcode)]; 
        return;
    }
}

static int i8080_instruction(void) {
    i8080_execute(RD_BYTE(PC++));
    return 1;
}

void i8080_jump(int addr) { PC = addr & 0xffff; }
int i8080_pc(void) { return PC; }
int i8080_regs_bc(void) { return BC; }
int i8080_regs_de(void) { return DE; }
int i8080_regs_hl(void) { return HL; }
int i8080_regs_sp(void) { return SP; }
int i8080_regs_a(void) { return A; }
int i8080_regs_b(void) { return B; }
int i8080_regs_c(void) { return C; }
int i8080_regs_d(void) { return D; }
int i8080_regs_e(void) { return E; }
int i8080_regs_h(void) { return H; }
int i8080_regs_l(void) { return L; }
