// Try to run CP/M on an 8080 emulator.

#include <jee.h>
#include <jee/text-ihex.h>
#include <string.h>

#define index indx
#define putchar console.putc

#include "i8080.h"
#include "i8080_hal.h"
#include "i8080_hal_c.h"
//#include "i8080_c.h"
#include "i8080_c_orig.h"

static bool showBiosCalls, showDiskIO, showReads, showWrites, showFlushes;

#if 0
UartBufDev< PinA<9>, PinA<10>, 10, 50 > console;
#else
UsbDev< PinA<12> > console;
#endif

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

#if 0
PinC<13> led;  // F103RE "red mini" board with two tanatalum caps
#else
PinB<9> led;   // F103VE "circle" board with µSD socket on the bottom
#endif

template< int PSZ >
struct FlashPages {
    constexpr static uint32_t pageSize = PSZ;

    static void copyFrom (uint32_t offset, void* ptr, int len) {
        memcpy(ptr, (uint8_t*) offset, len);
    }

    static void copyTo (uint32_t offset, void const* ptr, int len) {
        uint8_t* to = (uint8_t*) offset;
        for (int i = 0; i < len; i += 2) {
            if ((offset + i) % PSZ == 0)
                mem.erasePage(to + i);
            mem.write16(to + i, *(uint16_t*) ((uint32_t) ptr + i));
        }
    }

    static Flash mem;
};

template< int PSZ >
Flash FlashPages<PSZ>::mem;

template< typename MEM >
struct WriteCache {
    WriteCache () { pageInBuf = ~0; }

    void read (uint32_t pos, void* ptr, int len) {
        if (showReads)
            printf("\nREAD pos %d len %d\n", pos, len);

        while (len > 0) {
            uint32_t pageNum = pos / MEM::pageSize;
            uint32_t limit = (pageNum+1) * MEM::pageSize;

            uint32_t n = len;
            if (n > limit - pos)
                n = limit - pos;

            if (pageNum == pageInBuf)
                memcpy(ptr, buffer + pos % MEM::pageSize, n);
            else
                MEM::copyFrom(pos, ptr, n);

            pos += n;
            len -= n;
            ptr = (uint8_t*) ptr + n;
        }
    }

    void write (uint32_t pos, void const* ptr, int len) {
        if (showWrites)
            printf("\nWRITE pos %d len %d\n", pos, len);

        while (len > 0) {
            uint32_t pageNum = pos / MEM::pageSize;
            uint32_t limit = (pageNum+1) * MEM::pageSize;

            uint32_t n = len;
            if (n > limit - pos)
                n = limit - pos;

            if (pageNum != pageInBuf) {
                flush();
                MEM::copyFrom(pageNum * MEM::pageSize, buffer, MEM::pageSize);
                pageInBuf = pageNum;
            }

            // TODO: this should refuse to *change addresses before __etext
            //  note that writing to a page with __etext *in* it is acceptable
            memcpy(buffer + pos % MEM::pageSize, ptr, n);

            pos += n;
            len -= n;
            ptr = (const uint8_t*) ptr + n;
        }
    }

    void flush () {
        if (pageInBuf != (uint16_t) ~0) {
            uint32_t pos = pageInBuf * MEM::pageSize;

            if (showFlushes)
                printf("\nFLUSH pos %d len %d\n", pos, MEM::pageSize);

            MEM::copyTo(pos, buffer, MEM::pageSize);
            pageInBuf = ~0;
        }
    }

    uint16_t pageInBuf;
    uint8_t buffer [MEM::pageSize];
};

FlashPages<2048> flash;
WriteCache< decltype(flash) > disk;

constexpr uint16_t cpm_sz  = 0x1600;
constexpr uint16_t bios_sz = 0x0200;

constexpr uint16_t memsize = sizeof memory;
constexpr uint16_t biosadr = memsize - bios_sz;
constexpr uint16_t ccpadr  = biosadr - cpm_sz;

constexpr uint32_t diskoff = 0x2E00;
constexpr uint32_t bootoff = diskoff + 0x0380;

static void bios (int req) {
    if (showBiosCalls && req > 4)
        printf("\nBIOS #%d A %02x BC %04x DE %04x HL %04x\n",
                req, A, BC, DE, HL);

    constexpr uint16_t iobyte  = 0x0003;
    constexpr uint16_t usrdrv  = 0x0003;
    constexpr uint16_t tpaddr  = 0x0080;

    static uint8_t sekdsk, sektrk, seksec;
    static uint16_t dmaadr;
    uint32_t seek;

    switch (req) {
	case  0:  // boot     ;  0 Initialize
            printf("\r\n\n%dk CP/M vers 2.2\r\n", (biosadr+0x0600) >> 10);
            i8080_hal_memory_write_byte(iobyte, 0);
            i8080_hal_memory_write_byte(usrdrv, 0);
            disk.read(bootoff + cpm_sz, i8080_hal_memory() + biosadr, bios_sz);
            i8080_hal_memory_write_byte(usrdrv, 0);
            // fall through
        case  1:  // wboot    ;  1 Warm boot
            disk.read(bootoff, i8080_hal_memory() + ccpadr, cpm_sz);
            disk.flush();
            // set up low mem and finish by jumping to the command processor
            i8080_hal_memory_write_byte(0x0000, 0xC3);
            i8080_hal_memory_write_word(0x0001, biosadr+3);
            i8080_hal_memory_write_byte(0x0005, 0xC3);
            i8080_hal_memory_write_word(0x0006, ccpadr+0x0800+6);
            dmaadr = tpaddr;
            C = i8080_hal_memory_read_byte(usrdrv);
            i8080_jump(ccpadr);
            break;

        // console I/O
	case  2:  // conist   ;  2 Console status
            A = console.readable() ? 0xFF : 0x00;
            break;
	case  3:  // conin    ;  3 Console input
            A = console.getc();
            break;
	case  4:  // conout   ;  4 Console OUTput
            console.putc(C);
            break;

        // disk I/O
	case  8:  // home     ;  8 Home disk
            sektrk = 0;
            break;
	case  9:  // seldsk   ;  9 Select disk
            if (C < 2) {
                sekdsk = C;
                HL = biosadr + 17*3 + 16*C;  // DPT address
            } else
                HL = 0;
            break;
	case 10:  // settrk   ; 10 Select track
            sektrk = C;
            break;
	case 11:  // setsec   ; 11 Select sector
            seksec = C;
            break;
	case 12:  // setdma   ; 12 Set DMA ADDress
            dmaadr = BC;
            break;
	case 13:  // read     ; 13 Read 128 bytes
	case 14:  // write    ; 14 Write 128 bytes
            seek = ((sekdsk * 77 + sektrk) * 26 + (seksec-1)) * 128;
            if (showDiskIO)
                printf("\nDISK %s addr %04x seek %d = %d/%d/%d\n",
                        req == 13 ? "read" : "write", dmaadr, seek,
                        sekdsk, sektrk, seksec);
            if (req == 13)
                disk.read(diskoff + seek, i8080_hal_memory() + dmaadr, 128);
            else
                disk.write(diskoff + seek, i8080_hal_memory() + dmaadr, 128);
            A = 0;
            break;
	case 16:  // sectrn   ; 16 Sector translate
            HL = i8080_hal_memory_read_byte(DE + C);
//printf("sectrn %04x %d -> %d\n", DE, C, L);
            break;

        // stubs
	case  7:  // reader   ;  7 Reader input
            A = 0x1A;
            break;
        default:
            // TODO report this?
            // fall through
	case  5:  // list     ;  5 List OUTput
	case  6:  // punch    ;  6 punch OUTput
	case 15:  // listst   ; 15 List status
            A = 0;
            break;
    }
}

static bool saveHex () {
    IntelHex<32> hex;
    hex.init();
    uint32_t base = 0;

    printf(" Intel HEX ");
    while (!hex.parse(console.getc())) ;
    if (hex.check == 0) {
        printf("[%d] #%d @ $%08x ", hex.type, hex.len, base + hex.addr);
        switch (hex.type) {
            case 0:  // data
                disk.write(diskoff + base + hex.addr, hex.data, hex.len);
                break;
            case 1:  // eof
                return true;
            case 2:  // ext seg addr
                base = (hex.data[0]<<12) | (hex.data[1]<<4);
                break;
            case 4:  // ext addr
                base = (hex.data[0]<<24) | (hex.data[1]<<16);
                break;
            default: // other
                printf("[%d] #%d (ignored) ", hex.type, hex.len);
                break;
        }
    } else
        printf("?");

    return false;
}

static void listen () {
    printf("\ng=go, :=hex, or show b)ios d)isk r)ead w)rite f)lush");
    while (true) {
        printf("\n> ");
        int c = console.getc();
        if (c == '\r' || c == '\n')
            continue;
        console.putc(c);

        switch (c) {
            case 'g': return;

            case ':': if (saveHex()) return; else break;

            case 'b': showBiosCalls = true; break;
            case 'd': showDiskIO = true; break;
            case 'r': showReads = true; break;
            case 'w': showWrites = true; break;
            case 'f': showFlushes = true; break;
            default:  printf("?"); break;
        }
    }
}

int main () {
    //console.init();
    //fullSpeedClock();
    //printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
    led.mode(Pinmode::out); led = 1;

    while (true) {
        i8080_init();

        led = 0;  // on
        listen();
        led = 1;  // off

        printf("\nBOOT %04x @ %08x => CCP %04x, BDOS %04x, BIOS %04x-%04x.",
            memsize-ccpadr, bootoff, ccpadr, ccpadr+0x0800, biosadr, memsize-1);

        // TODO it would be cleaner to jump to emulated rom as first step
        bios(0);  // cold boot

        while (true) {
            int pc = i8080_pc();
            if (memory[pc] == 0x76) {
                if (pc < biosadr) {
                    printf("\nHLT at %04x\n", pc);
                    break;
                }
                uint8_t req = memory[pc+1];
                i8080_jump(pc+2);
                bios(req);
            } else {
                //static int i = 0; if (++i > 1000) return 1;
                //printf("PC %04x = %02x\n", pc, memory[pc]);
                i8080_instruction();
            }
        }
    }
}
