#include <jee.h>

PinA<1> led;
PinA<2> dcfIn;
PinA<8> dcfOut;

UartBufDev< PinA<9>, PinA<10>, 1000 > console;
SysTick<72000000> tick;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

void dcfPlot (bool edges) {
    static int last;
    for (int i = 0; i < 100; ++i) {
        int n = 0;
        for (int j = 0; j < 10; ++j) {
            if (!edges)
                last = 1;
            if (dcfIn != last) {
                last = !last;
                ++n;
            }
            dcfOut = !last;
            wait_ms(1);
        }
        console.putc(n ? '@' + n : '.');
    }
    console.putc('\n');
}

void pulseTimes () {
    uint32_t tickLast = ~0;
    uint32_t usLast = tick.micros();
    int pinLast = dcfIn;
    int lineLast = 0;
    printf("\n0 ");
    while (true) {
        if (ticks != tickLast) {
            tickLast = ticks;
            if (tickLast % 1000 == 0) {
                uint32_t us = tick.micros();
                int diff = (us - usLast + 25) / 50;
                printf("\n%d ", 2 * diff + lineLast);
                lineLast ^= 1;
            }
        }
        if (dcfIn != pinLast) {
            uint32_t us = tick.micros();
            int diff = (us - usLast + 25) / 50;
            printf("%d ", 2 * diff + pinLast);
            usLast = us;
            pinLast = !pinLast;
        }
    }
}

void pulseBuckets () {
    constexpr int B = 4;  // bucket size in ms
    constexpr int N = 1000/B;
    uint8_t buckets [N];
    for (int i = 0; i < N; ++i)
        buckets[i] = 0;
    for (int c = 0; c < 10; ++c) {
        printf("%d %d\n", c, tick.micros());
        int count = 0;
        for (int t = 0; t < 1000; ++t) {
            wait_ms(1);
            int s = !dcfIn;
            dcfOut = s;
            count += s;
            if (t % B == B-1) {
                if (count >= B/2) {
                    for (int o = 0; o <= 100; ++o)
                        ++buckets[((t - o + 1000) / B) % N];
                    for (int o = 900; o <= 1000; ++o)
                        --buckets[((t - o + 1000) / B) % N];
                } else {
                    for (int o = 0; o <= 100; ++o)
                        --buckets[((t - o + 1000) / B) % N];
                    for (int o = 900; o <= 1000; ++o)
                        ++buckets[((t - o + 1000) / B) % N];
                }
                count = 0;
            }
        }
    }
    for (int i = 0; i < N; ++i)
        //printf(" %d", buckets[i]);
        console.putc('0' + buckets[i] / 30);
    printf("\n");
}

int main () {
    fullSpeedClock();
    console.init();
    console.baud(115200, 72000000);
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);
    dcfIn.mode(Pinmode::in_pullup);
    dcfOut.mode(Pinmode::out);

#if 0
    //pulseTimes();
    while (true) pulseBuckets();
#else
    while (true) {
        led.toggle();
        dcfPlot(true);
    }
#endif
}
