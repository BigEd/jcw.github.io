#include <jee.h>
#include <jee/util-dcf77.h>
#include <jee/dio-pcd8544.h>
#include <jee/text-font.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

DCF77 radio;
PinA<2> dcfPin;
PinC<13> led;

PCD8544< PinB<9>,PinB<8>,PinB<7>,PinB<6>,PinB<5> > lcd; // CLK DIN DC CE RST
Font5x7< decltype(lcd) > screen;

int screenf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(screen.putc, fmt, ap); va_end(ap);
    return 0;
}

char const* const weekDays [] = { "Mon","Tue","Wed","Thu","Fri","Sat","Sun" };

int main () {
    console.init();
    enableSysTick();
    ticks = 60 * 60 * 1000; // 1h (in ms), indicates no valid clock

    dcfPin.mode(Pinmode::in_pullup);
    led.mode(Pinmode::out);

    lcd.init();
    lcd.clear();

    uint32_t dcfPollCycle = 0;
    uint32_t minuteCycle = 0;

    while (true) {
        led = dcfPin; // both GPIOs use inverted logic

        if (dcfPollCycle != ticks / radio.period) {
            dcfPollCycle = ticks / radio.period;

            // on correct decoding, reset ticks to between 0:00 and 0:59 in ms
            // ... minus 1s because this runs at the :59 mark before!
            if (radio.process(!dcfPin) && radio.decode()) // inverted logic
                ticks = (60 * radio.mm - 1) * 1000;
        }

        if (minuteCycle != ticks / 60000) {
            minuteCycle = ticks / 60000;
            if (minuteCycle < 60) { // after 1h it's a lost sync
                // adjust the actual minute, in case it was not received
                radio.mm = minuteCycle;

                //screenf("%02d-%02d-%02d %02d:%02d",
                //        radio.yr, radio.mo, radio.dy, radio.hh, radio.mm);
                printf(" 20%02d-%02d-%02d %02d:%02d %s %s\n",
                        radio.yr, radio.mo, radio.dy, radio.hh, radio.mm,
                        weekDays[radio.dow-1], radio.dst ? "CEST" : "CET");
            }
        }
    }
}
