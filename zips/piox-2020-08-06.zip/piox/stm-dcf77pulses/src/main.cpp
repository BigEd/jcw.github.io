#include <jee.h>

UartBufDev< PinA<9>, PinA<10> > console;
PinA<2> dcfIn;

int main () {
    console.init();
    enableSysTick();

    dcfIn.mode(Pinmode::in_pullup);

    uint32_t lastTime = 0;
    uint32_t signal = 0;
    uint32_t count = 0;

    while (true) {
        if (lastTime != ticks / 45) {
            lastTime = ticks / 45;

            signal <<= 1;
            signal |= !dcfIn; // inverted logic

            constexpr uint32_t pulseMask = 0b0011100001;
            constexpr uint32_t pulseBits = 0b0001100000;
            constexpr uint32_t pulseData = 0b0000001000;

            if ((signal & pulseMask) == pulseBits) {
                if (count++ % 59 == 0)
                    console.putc('\n');

                bool decodedBit = (signal & pulseData) != 0;
                console.putc(decodedBit ? '-' : '_');
            }
        }
    }
}
