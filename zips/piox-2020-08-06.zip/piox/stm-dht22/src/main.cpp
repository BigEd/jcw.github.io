#include <jee.h>
#include <jee/dio-dht22.h>

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

DHT22< PinA<10>, 8000000 > dht22;

int main () {
    console.init();
	enableSysTick();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

	dht22.init();

    while (true) {
		int16_t temp, humi;
		if (dht22.read(temp, humi))
			printf("%d %d\n", temp, humi);
		wait_ms(500);
	}
}
