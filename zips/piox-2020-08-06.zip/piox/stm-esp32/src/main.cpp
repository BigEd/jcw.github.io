#include <jee.h>

UartDev< PinD<1>, PinD<0> > console;  // pin info is ignored on avr + esp

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinD<22> led;  // 'D' is a no-op on ESP32, this is simply "digital pin 22"

int main () {
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    enableSysTick();

    led.mode(Pinmode::out);

    while (true) {
        printf("%d\n", ticks);
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400);
    }
}
