// see [1] https://jeelabs.org/ref/STM32F4-RM0090.pdf

#include <jee.h>
#include <jee/spi-flash.h>

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > fSpi;
SpiFlash< decltype(fSpi) > emem;

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinC<2> led;

constexpr int MHZ = 168;
SysTick<1000000*MHZ> now;

int main () {
    fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);

    fSpi.init();
    emem.init();

    printf("emem %x, %d kB\n", emem.devId(), emem.size());

    for (int i = 0; i < 3; ++i) {
        uint32_t t0 = now.micros();
        for (int i = 0; i < 1000000; ++i) __asm("");
        uint32_t t1 = now.micros() - t0;
        printf("t = %d ps, f = %d kHz, %d.%d cycles/loop\n",
                t1, 1000000000 / t1,
                t1 / (1000000 / MHZ), (t1 / (10000000 / MHZ)) % 10);
    }

    while (true) {
        printf("hello %d\n", ticks);
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);
    }
}
