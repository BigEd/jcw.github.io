// see [1] https://jeelabs.org/ref/STM32F4-RM0090.pdf

#include <jee.h>
#include <jee/mem-ili9341.h>

ILI9341< 0x60000000, 0x60080000 > lcd;

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

static void initFsmcLcd () {
    MMIO32(Periph::rcc + 0x38) |= (1<<0);  // enable FSMC [1] p.245

    Port<'D'>::modeMap(0b1110011110110011, Pinmode::alt_out);
    Port<'E'>::modeMap(0b1111111110000000, Pinmode::alt_out);

    constexpr uint32_t bcr1 = Periph::fsmc;
    //constexpr uint32_t btr1 = bcr1 + 0x04;
    MMIO32(bcr1) = (1<<20) | (1<<12) | (1<<7) | (1<<4);
    //MMIO32(btr1) = (1<<8) | (1<<4);
    MMIO32(bcr1) |= (1<<0);
}

PinA<6> led;

int main () {
    console.init();
    console.baud(115200, fullSpeedClock()/2);
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);

    initFsmcLcd();
    lcd.init();
    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    while (true) {
        printf("hello %d\n", ticks);
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400);
    }
}
