#include <jee.h>
#include <jee/spi-fram.h>

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinB<6> > spi;
Fram< decltype(spi) > fram;

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    console.init();
    printf("\n");

    fram.init();
    printf("%08x", fram.devId());

    uint8_t buf [5];

    fram.write(0, (uint8_t const*) "abc", 4);
    fram.read(0, buf, 5);
    ++buf[4];
    fram.write(4, buf+4, 1);

    for (int i = 0; i < sizeof buf; ++i)
        printf(" %02x", buf[i]);
    printf("\n");

    while (true) {}
}
