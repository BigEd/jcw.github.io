// R61505U LCD demo using FSMC, as available on the HY-MiniSTM32V board

#include <jee.h>
#include <jee/text-font.h>
#include <jee/spi-sdcard.h>
#include <jee/mem-r61505u.h>

PinA<0> ain;
PinB<0> led0;
PinB<1> led1;
PinC<13> keya;
PinB<2> keyb;
PinB<5> tftbl;
PinB<7> usben;

SpiGpio< PinD<2>, PinC<8>, PinC<12>, PinC<11> > spi;
SdCard< decltype(spi) > sd;

template< typename LCD >
struct DmaFill : LCD {
    // dma2 chan5
    constexpr static uint32_t dma   = 0x40020400;
    constexpr static uint32_t isr   = dma + 0x00;
    constexpr static uint32_t ifcr  = dma + 0x04;
    constexpr static uint32_t ccr   = dma + 0x58;
    constexpr static uint32_t cndtr = dma + 0x5C;
    constexpr static uint32_t cpar  = dma + 0x60;
    constexpr static uint32_t cmar  = dma + 0x64;

    static void fill (int x, int y, int w, int h, uint16_t rgb) {
        LCD::bounds(x+w-1, y+h-1);
        LCD::pixel(x, y, rgb);

        MMIO32(Periph::rcc + 0x14) |= (1<<1);  // enable dma2 [1] p.111

        MMIO32(cmar) = (uint32_t) &rgb;
        MMIO32(cpar) = 0x60020000;
        // FIXME this fails when w * h exceeds 65535 words (320 x 240 = 76800)
        MMIO32(cndtr) = w * h - 1;
        MMIO32(ccr) = (1<<14) | (1<<10) | (1<<8) | (1<<4);  // [1] pp.285
        MMIO32(ccr) |= (1<<0);  // enable
        // TODO it's NOT faster than a loop, probably due to bus contention?
        //  in other words: the next while loop slows down the DMA accesses
        while ((MMIO32(isr) & (1<<17)) == 0) ;  // wait for completion
        MMIO32(ifcr) = (1<<17);  // clear
        MMIO32(ccr) = 0;  // done
    }

    static void clear () {
        //fill(0, 0, LCD::width, LCD::height, 0xF800);
        fill(0, 0, LCD::width, LCD::height/2, 0xF800);
        fill(0, LCD::height/2, LCD::width, LCD::height/2, 0x07E0);
        //LCD::fill(0, 0, LCD::width, LCD::height, 0xF800);
    }
};

R61505U< 0x60000000, 0x60020000 > lcd;
//DmaFill< R61505U< 0x60000000, 0x60020000 > > lcd;
TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

UartBufDev< PinA<9>, PinA<10>, 500 > uart;

int debugf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(uart.putc, fmt, ap); va_end(ap);
    return 0;
}

static void initFsmcLcd () {
    MMIO32(Periph::rcc + 0x14) |= (1<<8);  // enable FSMC

    Port<'D'>::modeMap(0b1100111110110011, Pinmode::alt_out);
    Port<'E'>::modeMap(0b1111111110000000, Pinmode::alt_out);

    constexpr uint32_t bcr1 = 0xA0000000;
    constexpr uint32_t btr1 = 0xA0000004;
    MMIO32(bcr1) = (1<<12) | (1<<7) | (1<<4);
    MMIO32(btr1) = (1<<8);
    MMIO32(bcr1) |= (1<<0);
}

ADC<1> adc;

int main () {
    fullSpeedClock();
    uart.init();
    debugf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    adc.init();

    led0.mode(Pinmode::out);
    led1.mode(Pinmode::out);
    // tftbl.mode(Pinmode::out); tftbl = 1;

    initFsmcLcd();
    lcd.init();

    SysTick<72000000> now;
    uint32_t start = now.micros();
    lcd.clear();
    debugf("%d µs\n", now.micros() - start);

    spi.init();
    if (sd.init())
        debugf("sdhc %d\n", sd.sdhc);

    //int y = 0;

    while (true) {
#if 0
        if (uart.readable()) {
            char c = uart.getc();
            console.putc(c);
        }
#endif
#if 0
        uint32_t sum = 0;
        uint32_t start = ticks;
        for (int i = 0; i < 1000000; ++i)
            sum += adc.read(17);
        printf("%d, %d ns\n", sum, ticks - start);
        wait_ms(500);
#endif
#if 0
        constexpr int N = 10000;
        int sum = 0;
        for (int i = 0; i < N; ++i)
            sum += adc.read(ain);
        int n = (sum * lcd.width) / (N * 4095);

        lcd.fill(0, y, lcd.width, 1, 0);
        lcd.pixel(n, y, 0xFFFF);

        if (++y >= lcd.height)
            y = 0;
        lcd.vscroll(y);
#endif
    }
}
