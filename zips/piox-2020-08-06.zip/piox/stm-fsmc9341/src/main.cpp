#include <jee.h>
#include <jee/text-font.h>
#include <jee/mem-ili9341.h>

UartDev< PinA<9>, PinA<10> > uart;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(uart.putc, fmt, ap); va_end(ap);
    return 0;
}

ILI9341< 0x6C000000, 0x6C000800 > lcd;
TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;

static void initFsmcPins () {
    MMIO32(Periph::rcc + 0x14) |= (1<<8);  // enable FSMC

    Port<'D'>::modeMap(0b1111111100110011, Pinmode::alt_out);
    Port<'E'>::modeMap(0b1111111110000011, Pinmode::alt_out);
    Port<'F'>::modeMap(0b1111000000111111, Pinmode::alt_out);
    Port<'G'>::modeMap(0b0001010000111111, Pinmode::alt_out);
}

static void initFsmcLcd () {
    constexpr uint32_t bcr4 = 0xA0000018;
    constexpr uint32_t btr4 = 0xA000001C;

    MMIO32(bcr4) = (1<<12) | (1<<7) | (1<<4);
    MMIO32(btr4) = (1<<8) | (0<<0);
    MMIO32(bcr4) |= (1<<0);
}

PinD<3> led;

int main() {
    fullSpeedClock();
    led.mode(Pinmode::out);

    PinB<0> light;
    light.mode(Pinmode::out);
    light = 1;

    PinC<5> reset;
    reset.mode(Pinmode::out);
    reset = 0;
    wait_ms(10);
    reset = 1;
    wait_ms(10);

    initFsmcPins();
    initFsmcLcd();

    lcd.init();
    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    for (int x = 0; x < lcd.width; ++x) {
        lcd.pixel(x, 0, 0x00FF);
        lcd.pixel(x, lcd.height-1, 0xFF00);
    }

    while (1) {
        printf("%d\n", ticks);
        led.toggle();
        wait_ms(500);
    }
}
