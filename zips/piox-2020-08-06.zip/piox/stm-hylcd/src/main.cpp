#include <jee.h>
#include <jee/spi-ili9163.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiHw< PinA<7>, NoPin, PinA<5>, PinA<4> > spi;
ILI9163< decltype(spi), PinA<8> > lcd;

PinA<15> reset;
PinA<6> backlight;

int main () {
    console.init();
    console.baud(115200, fullSpeedClock());
    //enableSysTick();
    wait_ms(100);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25; // disable JTAG, keep SWD enabled

    spi.init();
    // switch to div-2, i.e. 18 MHz for SPI1
    MMIO32(spi.cr1) = (1<<6) | (0<<3) | (1<<2) | (0<<1);  // [1] p.742

    reset.mode(Pinmode::out);
    reset = 0;
    wait_ms(2);
    reset = 1;
    wait_ms(10);

    lcd.init();

    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    wait_ms(150); // avoids brief power-up flicker
    backlight.mode(Pinmode::out);
    backlight = 1;

    lcd.fill(0, 0, 90, 60, 0xF000);

    lcd.bounds();
    for (int i = 0; i < 60; ++i)
        lcd.pixel(i, 2*i, 0xFFE0);

    while (true) {}
}
