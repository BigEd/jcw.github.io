#include <jee.h>

UartDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

constexpr int MHZ = 8;
SysTick<1000000*MHZ> now;

int main () {
    console.init();
    //console.baud(115200, fullSpeedClock());
    enableSysTick();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    for (int i = 0; i < 3; ++i) {
        uint32_t t0 = now.micros();
        for (int i = 0; i < 1000000; ++i) __asm("");
        uint32_t t1 = now.micros() - t0;
        printf("t = %d ps, f = %d kHz, %d.%d cycles/loop\n",
                t1, 1000000000 / t1,
                t1 / (1000000 / MHZ), (t1 / (10000000 / MHZ)) % 10);
    }

    while (true) ;
}
