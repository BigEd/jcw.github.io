#include <jee.h>
#include <jee/spi-rf69.h>
#include <jee/i2c-ssd1306.h>
#include <jee/text-font.h>
#include <jee/spi-sdcard.h>

PinA<1> led;

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spiA;
RF69< decltype(spiA) > rf;

SpiGpio< PinB<5>, PinB<4>, PinB<3>, PinA<15> > spiB;
SdCard< decltype(spiB) > sd;

I2cBus< PinB<7>, PinB<6>, 5 > bus;
SSD1306< decltype(bus) > oled;

#if 0
Font5x7< decltype(oled) > console;
#else
UartBufDev< PinA<9>, PinA<10> > console;
#endif

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

template< typename T >
struct Fat16 {
    Fat16 () {
        T::read512(0, buf);                       // find boot sector
        base = *(uint32_t*) (buf+0x1C6);          // base for everything

        T::read512(base, buf);                    // location of boot rec
        spc = buf[0x0D];                          // sectors per cluster
        uint16_t rsec = *(uint16_t*) (buf+0x0E);  // reserved sectors
        uint8_t nfc = buf[0x10];                  // number of FAT copies
        uint16_t spf = *(uint16_t*) (buf+0x16);   // sectors per fat
        rdir = nfc * spf + rsec + base;           // location of root dir
        rmax = *(uint16_t*) (buf+0x11);           // max root entries
        data = (rmax >> 4) + rdir;                // start of data area

      //printf("base %d spc %d rsec %d nfc %d spf %d rdir %d rmax %d data %d\n",
      //  base, spc, rsec, nfc, spf, rdir, rmax, data);
    }

    uint32_t base;      // base sector for everything
    uint32_t rdir;      // location of root dir
    uint32_t data;      // start sector of data area
    uint16_t rmax;      // max root entries
    uint8_t spc;        // sectors per cluster

    uint8_t buf [512];  // buffer space for one sector
};

int main () {
    fullSpeedClock();
    // enableSysTick();
    led.mode(Pinmode::out);

    wait_ms(10);
    oled.init();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    oled.clear();

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    spiB.init();
    if (sd.init()) {
        printf("sdhc %d\n", sd.sdhc);

        Fat16< decltype(sd) > fat;

        printf("base %d spc %d rdir %d rmax %d data %d\n",
            fat.base, fat.spc, fat.rdir, fat.rmax, fat.data);

        for (int i = 0; i < 5; ++i) {
            printf("%3d:", i);
            sd.read512(fat.rdir+i, fat.buf);
            for (int j = 0; j < 20; ++j)
                printf(" %02x", fat.buf[j]);
            printf("\n");
        }

        uint32_t start = ticks;
        for (int i = 0; i < 100; ++i)
            sd.read512(i, fat.buf);
        printf("read512 %d us\n", (ticks - start) * 10);

        start = ticks;
        for (int i = 0; i < 100; ++i)
            sd.write512(1, fat.buf);
        printf("write512 %d us\n", (ticks - start) * 10);
    }

    spiA.init();
    rf.init(63, 6, 8686);     // node 63, group 6, 868.6 MHz
    rf.writeReg(0x29, 0xE4);  // lower RSSI threshold
    // rf.writeReg(0x58, 0x29);  // high sensitivity mode

    while (true) {
        uint8_t rxBuf [66];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            led = 0;

            printf("RF69 r%d l%d a%d %d>%d ",
                    rf.rssi, rf.lna, rf.afc, rxBuf[1] & 0x3F, rxBuf[0] & 0x3F);
            for (int i = 0; i < rxLen; ++i)
                printf("%02x", rxBuf[i]);
            printf("\n");

            led = 1;
        }
    }
}
