#include <jee.h>
#include <jee/spi-rf69.h>
#include <jee/i2c-ssd1306.h>
#include <jee/text-font.h>

UartDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

I2cBus< PinB<7>, PinB<6> > bus;
SSD1306< decltype(bus) > oled;
Font5x7< decltype(oled) > display;

int showf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(display.putc, fmt, ap); va_end(ap);
    return 0;
}

UartBufDev< PinA<2>, PinA<3> > uart2;

SpiGpio< PinB<5>, PinB<4>, PinB<3>, PinA<15> > spi;
RF69< decltype(spi) > rf;

PinA<0> led1;
PinA<1> led2;
//PinA<2> led3;
//PinA<3> led4;
PinA<4> led5;
PinA<5> led6;
PinA<8> led;

int main() {
    const uint32_t hz = fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    Port<'A'>::modeMap(0b0000000100110011, Pinmode::out);
    led = 1;

    spi.init();
    rf.init(1, 6, 8686);

    uart2.init();
    uart2.baud(115200, hz);

    oled.init();
    oled.clear();

    uint8_t rfBuf [64];

    while (true) {
        led1 = (ticks / 500) & 1;

        int rfLen = rf.receive(rfBuf, sizeof rfBuf);
        if (rfLen >= 0) {
            led = 0;
            printf(" RF69 %04x%02x%02x%02x ",
                    (uint16_t) rf.afc, rf.rssi, rf.lna, rfLen);
            for (int i = 0; i < rfLen; ++i)
                printf("%02x", rfBuf[i]);
            printf("\n");
            showf("%d %d\n", ticks, rfLen);
            uart2.putc('!');
            led2.toggle();
            led = 1;
        }

        if (uart2.readable()) {
            printf("<%02x>", uart2.getc());
            led5.toggle();
        }

        static uint32_t last = 0;
        if (last != ticks/1000) {
            last = ticks/1000;
            uart2.putc('a' + last%26);
            led6.toggle();
        }
    }
}
