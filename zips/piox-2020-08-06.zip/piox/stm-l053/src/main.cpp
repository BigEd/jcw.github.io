#include <jee.h>
#include <jee/spi-rf69.h>

UartDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinB<6> > spi;
RF69< decltype(spi) > rf;

int main () {
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    spi.init();
    rf.init(1, 6, 8686);  // node 1, group 6, 868.6 MHz

#if 0
    PinA<5> led;
    led.mode(Pinmode::out);
    while (true) {
        led.toggle();
        for (int i = 0; i < 1000000; ++i)
            __asm("");
    }
#endif

    while (true) {
        uint8_t rxBuf [64];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            printf("RF69 #%d: ", rxLen);
            for (int i = 0; i < rxLen; ++i)
                printf("%02x", rxBuf[i]);
            printf("\n");
        }
    }
}
