#include <jee.h>
#include <jee/dio-pcd8544.h>
#include <jee/text-font.h>

//UartBufDev< PinA<2>, PinA<15> > console;

PinB<3> led;
PinB<4> light;

PCD8544< PinA<0>, PinA<1>, PinA<3>, PinA<4>, PinA<5> > lcd;
Font5x7< decltype(lcd) > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main() {
    enableSysTick();
    led.mode(Pinmode::out);

    light.mode(Pinmode::out);
    lcd.init();
    lcd.clear();

    while (1) {
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);

        printf("%d ", ticks);
    }
}
