// Data logger for the Zelkova project, for use on a Blue Pill w/ SPI flash.
// for h/w details, see [1] https://jeelabs.org/ref/STM32F1-RM0008.pdf

#include <jee.h>
#include <jee/parse-cmd.h>
#include <jee/spi-flash.h>
#include <jee/util-date.h>
#include <string.h>

constexpr int version = 1;  // i.e. 0.1

UartBufDev< PinA<9>, PinA<10> > console;

int printf (const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

RTC rtc;
SysTick<defaultHz> tick;

// Small utility functions -----------------------------------------------------

static uint32_t chipId () {
    return MMIO32(0x1FFFF7E8) ^ MMIO32(0x1FFFF7EC) ^ MMIO32(0x1FFFF7F0);
}

// Data logging ----------------------------------------------------------------

enum { F_PAST };  // flag bits

struct Reading {
    // 0
    int32_t rtc;                    // seconds since power-up
    // 4
    uint8_t version :6;             // firmware version
    uint8_t type :2;                // reading type, see union below
    uint8_t flags;                  // status flags
    uint16_t events;                // events since previous entry
    // 8
    union {
        uint32_t _ [6];
        struct {                    // type 1: sensor reading
            // 8
            uint8_t vUsb;           // USB voltage Vx10
            uint8_t vSun;           // solar voltage Vx10
            uint16_t mvBat;         // LiPo voltage Vx1000
            // 12
            struct {                // soil sensors:
                int16_t temp;       //  temperature Cx10
                int16_t capa;       //  capacitance 0..1023
            } soil [3];
            // 24
            int16_t aTemp;          // ambient temperature Cx10
            uint16_t aHumi;         // ambient humidity RHx10
            // 28
            int16_t iTemp;          // internal temperature Cx10
            uint16_t cycles;        // reset cycle count
            // 32
        } sensors;
        struct {                    // type 2: configuration
            // 8
            uint32_t sec1970;       // date set, timestamp
            // 12
            uint16_t yr;            // date set, year
            uint8_t mo;             // date set, month
            uint8_t dy;             // date set, day
            uint8_t hh;             // date set, hour
            uint8_t mm;             // date set, minute
            uint8_t ss;             // date set, second
            // 23
            uint8_t soilVers [3];   // soil sensor version x10
            // 26
            uint16_t flashFill;     // flash fill pointer, bytes
            uint32_t sdcardFill;    // sd card fill pointer, bytes
            // 32
        } config;
        struct {                    // type 3: message
            // 8
            char text [24];         // message text
            // 32
        } message;
    };
    // 32

    Reading () { memset(this, 0, sizeof *this); }
};

struct Logger {
    SpiHw< PinB<15>, PinB<14>, PinB<13>, PinB<12> > spi;
    SpiFlash< decltype(spi) > emem;
    Flash imem;

    static Reading rBuf;
    static uint8_t msgFill;

    // internal flash for storing an index starting at 60K, far above the code
    int32_t const* const flashBase = (int32_t const*) 0x0F000;

    // the index stores "slot numbers" into spi data flash, one per month
    // a slot is an index to a Reading, i.e. byte offset / sizeof (Reading)
    // Jan 2018 is the first entry, Feb 2018 the 2nd, etc - room for 20 years
    const int numEntries = 256;  // 256x4b = 1k, i.e. this uses one flash page

    void init () {
        spi.init();
        MMIO32(spi.cr1) &= ~(7<<3);  // max speed, i.e. 4 MHz, [1] p.743
        emem.init();
    }

    void eraseAll () {
        imem.erasePage(flashBase);
        emem.wipe();
        init();  // re-init
    }

    int slotIndex (int yr, int mo) {
        return 12*(yr-2018) + (mo-1);
    }

    Reading const& reading (int slot) {
        emem.read(slot * sizeof rBuf, &rBuf, (int) sizeof rBuf);
        return rBuf;
    }

    static void msgPutc (int c) {
        if (msgFill < sizeof rBuf.message.text)
            rBuf.message.text[msgFill++] = c;
    }

    void addMessage (const char* fmt, ...) {
        msgFill = 0;

        va_list ap;
        va_start(ap, fmt);
        veprintf(msgPutc, fmt, ap);
        va_end(ap);

        while (msgFill < sizeof rBuf.message.text)
            msgPutc(0);
        rBuf.message.text[msgFill-1] = 0;

        Reading r = rBuf;
        r.type = 3;
        addReading(r);
    }

    void addReading (Reading& r) {
        r.rtc = rtc;          // fill in the timestamp for this reading
        r.version = version;  // and tag with current s/w version

        DateTime now (r.rtc);
        int yr = now.year();
        int mo = now.month();
        int nowIdx = slotIndex(yr, mo);

        // due to optimisation, total time to add will be under 6 ms @ 8 MHz
        int next = nextSlot();

        // if the last entry is not for the same month, add missing entries
        if (next > 0) {
            DateTime then (reading(next-1).rtc);
            int thenIdx = slotIndex(then.year(), then.month());
            while (thenIdx < nowIdx)
                imem.write32(flashBase + thenIdx++, next);

            // note: *NEVER* store readings marked older than the last one
            // in this case, store an incorrect timestamp, 
            // but at some point, the real time will catch up again
            if (r.rtc < then.get()) {
                r.flags |= 1<<F_PAST;    // flag trying to log in the past
                r.rtc = then.get() + 1;  // advance time by one second instead
            }
        }

        if (flashBase[nowIdx] < 0)
            imem.write32(flashBase + nowIdx, next);

        emem.write(next * sizeof r, &r, (int) sizeof r);
    }

    int nextSlot () {
        // go through all the stored offsets to find the first unused one
        int slot = -1;
        for (int i = 0; i < numEntries; ++i)
            if (flashBase[i] > slot)
                slot = flashBase[i] - 1;

        // starting from this slot, find the first unused entry in spi flash

        // to speed up the linear scan, each of which has to read some data
        // from spi flash, start with some quick look-aheads using bisection
        // note: this assumes there are at least 256K unused at end of flash
        for (int i = 8192; i > 0; i >>= 1)
            if (reading(slot+i).rtc >= 0)
                slot += i;

        // finish off by single-stepping to the very first unused slot
        while (reading(++slot).rtc >= 0) ;

        return slot;
    }

    void listAll () {
        int next = nextSlot();
        if (next == 0) {
            printf("no data\n");
            return;
        }

        int months = 0;

        for (int i = 0; i < numEntries-1; ++i)
            if (flashBase[i] >= 0) {
                int32_t first = flashBase[i];
                int32_t limit = flashBase[i+1];
                if (limit < 0)
                    limit = next;
                if (first < limit) {
                    int yr = 2018 + i/12;
                    int mo = 1 + i%12;
                    printf("  %4d-%02d: %d entries\n", yr, mo, limit-first);
                    ++months;
                }
            }

        DateTime then (reading(next-1).rtc);
        printf("%d months, last entry: %04d-%02d-%02d %02d:%02d:%02d\n",
                months, then.year(), then.month(), then.day(),
                        then.hour(), then.minute(), then.second());
    }

    bool dumpMonth (int yr, int mo) {
        int slot = slotIndex(yr, mo);

        int32_t first = flashBase[slot];
        int32_t limit = flashBase[slot+1];
        if (limit < 0)
            limit = nextSlot();
        if (first < 0 || first >= limit)
            return false;

        printf("%d entries:\n\n", limit-first);

        printf("date,time,version,type,flags,info\n");
        for (int slot = first; slot < limit; ++slot) {
            Reading const& r = reading(slot);
            DateTime dt (r.rtc);
            printf("%04d%02d%02d,%02d%02d%02d,%d,%d,%d,",
                    dt.year(), dt.month(), dt.day(),
                    dt.hour(), dt.minute(), dt.second(),
                    r.version, r.type, r.flags);
            switch (r.type) {
                case 3:
                    printf("\"%s\"", r.message.text);
                    break;
            }
            printf("\n");
        }

        return true;
    }

} logger;

Reading Logger::rBuf;
uint8_t Logger::msgFill;

// Command handlers ------------------------------------------------------------

bool echo;

static bool hCmd (int argc, int*);  // forward

static bool dCmd (int argc, int* argv) {
    DateTime now (rtc);

    int yr = argc > 1 ? argv[0] : now.year();
    int mo = argc > 0 ? argv[argc-1] : now.month();
    if (yr < 2018 || yr >= 2038 || mo < 1 || mo > 12) {
        //printf("year must be 2018..2037, month must be 1..12\n");
        printf("date is not in range [2018 01] to [2037 12]\n");
        return false;
    }

    return logger.dumpMonth(yr, mo);
}

static bool eCmd (int argc, int* argv) {
    echo = argc == 0 ? !echo : *argv != 0;
    return true;
}

static bool lCmd (int argc, int*) {
    logger.listAll();
    return true;
}

static bool tCmd (int argc, int*) {
    DateTime dt (rtc);
    printf("%04d-%02d-%02d %02d:%02d:%02d rtc %d\n",
            dt.year(), dt.month(), dt.day(),
            dt.hour(), dt.minute(), dt.second(),
            dt.get());
    return true;
}

static bool vCmd (int argc, int*) {
    printf("Zelkova BP v%d.%d cpu %08x spi %06x\n",
            version/10, version%10, chipId(), logger.emem.devId());
    return true;
}

static bool ACmd (int argc, int* argv) {
    DateTime dt (rtc);
    int yr = dt.year(), mo = dt.month(), dy = dt.day();
    if (argc == 2) {
        yr = *argv / 10000;
        mo = (*argv / 100) % 100;
        dy = *argv % 100;
        ++argv;
    }
    int hh = *argv / 10000,
        mm = (*argv / 100) % 100,
        ss = *argv % 100;
    DateTime newdt (yr, mo, dy, hh, mm, ss);
    rtc = newdt.get();
    wait_ms(2);
    return tCmd(0, 0);  // display the new date
}

static bool WCmd (int argc, int* argv) {
    if (*argv != 54321)
        return false;
    printf("Erasing flash, this may take up to a minute ... ");
    logger.eraseAll();
    printf("done.\n");
    return true;
}

static bool ZCmd (int argc, int* argv) {
    if (*argv != 123)
        return false;
    printf("Forcing reset ... ");
    Iwdg dog (0);   // this will timeout very soon
    while (true) ;  // ... and then force a reset
}

struct {
    uint8_t min, max;
    char cmd;
    bool (*fun)(int,int*);
    char const* desc;
} const cmdTab [] = {
    0, 2, 'd', dCmd, "        ?yyyy mm? d : dump one month of saved data",
    0, 1, 'e', eCmd, "              ?f? e : enable/disable/toggle echo",
    0, 9, 'h', hCmd, "                  h : show this help text",
    0, 0, 'l', lCmd, "                  l : show a list of saved readings",
    0, 0, 't', tCmd, "                  t : display current date and time",
    0, 0, 'v', vCmd, "                  v : display version and chip ID",
    1, 2, 'A', ACmd, "?yyyymmdd? hhmmss A : adjust current date/time",
    1, 1, 'W', WCmd, "            54321 W : wipe entire data flash",
    1, 1, 'Z', ZCmd, "              123 Z : full reset and server shutdown",
    0, 0, 0, 0, 0
};

static bool hCmd (int argc, int*) {
    for (auto p = cmdTab; p->fun != 0; ++p)
        printf("  %s\n", p->desc);
    return true;
}

struct {
    bool prompt;
    Command cmd;

    void init () {
        vCmd(0, 0);
        tCmd(0, 0);
        printf("Type 'h' for a list of commands.\n");
        echo = true;
        prompt = true;
    }

    // process incoming commands without blocking
    void poll () {
        if (prompt)
            printf(echo ? "> " : "<+>\n");
        prompt = false;

        if (!console.readable())
            return; // nothing to do

        int c = console.getc();
        if (c == '\n')
            prompt = true;
        else if (c < ' ')
            c = ' ';
        if (echo)
            console.putc(c);

        int in = cmd.parse(c);

        bool (*f)(int,int*) = 0;
        for (auto p = cmdTab; p->fun != 0; ++p)
            if (p->cmd == in) {
                if (p->min <= cmd.argc && cmd.argc <= p->max)
                    f = p->fun;
                else
                    printf(" (arg count?)\n  %s\n", p->desc);
                in = 0;
                break;
            }
        
        if (f != 0) {
            if (echo)
                printf("\n");
            prompt = f(cmd.argc, cmd.args);
            return;
        }

        switch (in) {
            case 0:
                break; // incomplete
            default:
                printf(" ?");
                // fall through
            case '?':
                for (int i = 0; i < cmd.argc; ++i)
                    printf(" %d", cmd.args[i]);
                printf("\n");
                prompt = in == '?';
                break;
        }
    }

} cmdLine;

// Main app setup and loop -----------------------------------------------------

int main () {
    console.init();
    enableSysTick();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    // ensure that the RTC hardware is running, or restart it if not
    // use RTC_DIVL, since that changes 32768x/sec when the RTC is running
    constexpr static uint32_t divl = Periph::rtc + 0x14;
    uint16_t start = MMIO16(divl);
    wait_ms(2);
    if (MMIO16(divl) == start) {
        printf("RTC init\n");
        rtc.init();
    }

    // adjust the RTC if its date and time is older than this code's build
    // very convenient during development and sets a sensible lower limit
    DateTime minDate (__DATE__, __TIME__);
    if (rtc < minDate.get())
        rtc = minDate.get();

    logger.init();
    cmdLine.init();

    logger.addMessage("haha %d", ticks);

    for (;;)
        cmdLine.poll();
}
