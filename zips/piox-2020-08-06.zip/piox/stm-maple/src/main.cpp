#include <Arduino.h>

#define MMIO32(x) (*(volatile uint32_t*) (x))

void setup() {
    pinMode(PA1, OUTPUT);
    Serial.begin();

return;
    for (int i = 0; i < 10; ++i)
        loop();

    // constexpr uint32_t rcc = 0x40021000;
    // MMIO32(rcc + 0x04) = 0;     // revert to HSI @ 8 MHz, no PLL
    // MMIO32(rcc + 0x00) = 0x81;  // turn off HSE and PLL, power-up value

    constexpr uint32_t usb = 0x40005C00;
    MMIO32(usb + 0x40) |= (1<<1);  // set USB PWDN

    constexpr uint32_t pwr = 0x40007000;
    MMIO32(pwr) |= (1<<1) | (1<<0);  // set PDDS and LPDS

    constexpr uint32_t scr = 0xE000ED10;
    MMIO32(scr) |= (1<<2);  // set SLEEPDEEP

    __asm("cpsid i");
    __asm("wfi");
}

void loop() {
    Serial.println(123);
    digitalWrite(PA1, 1);
    for (int i = 0; i < 100; ++i)
        __asm("wfi");
    digitalWrite(PA1, 0);
    for (int i = 0; i < 900; ++i)
        __asm("wfi");
}
