#include <Arduino.h>
#include <jee.h>
#include <jee/spi-sdcard.h>
#include <jee/dio-pcd8544.h>
#include <jee/text-font.h>

//#define ticks millis()
//#define wait_ms delay

class UsbSerial {
public:
    UsbSerial () { Serial.begin(); }

    static bool writable () { return Serial.availableForWrite(); }
    static void putc (int c) { Serial.write((char) c); }
    static bool readable () { return Serial.available(); }
    static int getc () { return Serial.read(); }
};

#if 0
UsbSerial console;
#elif 0
Font5x7< decltype(lcd) > console;
#else
UartDev< PinA<9>, NoPin > console;
#endif

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinB<8> gnd;
// PinA<8> light;
PinA<5> vcc;
SlowPin < PinA<6>, 100 > ck;

PCD8544< decltype(ck), PinA<7>, PinA<4>, PinB<7>, PinA<10> > lcd;
SpiGpio< PinB<15>, PinB<14>, PinB<13>, PinD<2> > spi;

PinA<1> ledY;       // "1" to turn on yellow LED
// PinA<5> ledG;       // "1" to turn on green LED
PinC<11> usbPower;  // "1" when USB power is present
PinB<0> batAdc;     // analog input, 1/4th Vbat
PinB<1> batGnd;     // must be "0" to measure Vbat

RTC now;

Iwdg dog (6);  // approx 26s

static void powerDown () {
    printf("power down\n");
    wait_ms(2);  // let console output finish

    MMIO32(Periph::rcc + 0x04) = 0;     // revert to HSI @ 8 MHz, no PLL
    MMIO32(Periph::rcc + 0x00) = 0x81;  // turn off HSE and PLL, power-up value
    MMIO32(Periph::usb + 0x40) |= 1<<1;  // set USB PWDN
    MMIO32(Periph::pwr) |= 1<<1 | 1<<0;  // set PDDS and LPDS

    constexpr uint32_t scr = 0xE000ED10;
    MMIO32(scr) |= 1<<2;  // set SLEEPDEEP

    __asm("cpsid i");
    __asm("wfi");
}

// TODO what a mess ...
SdCard< decltype(spi) > sd;
FatFS< decltype(sd), 3 > fat;
FileMap< decltype(fat), 2 > firmware (fat);
FileMap< decltype(fat), 500 > datafile (fat);

void setup() {
    enableSysTick(72000000/1000);
    console.baud(115200, 72000000);  // usart1: 115200 baud @ 72 MHz
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    batGnd.mode(Pinmode::out);  // set this to 0 asap
    // ledG.mode(Pinmode::out);
    ledY.mode(Pinmode::out);

    // ensure that the RTC is running, even when not initialised
    int start = now;
    for (int i = 0; i < 1100; ++i)
        if (now == start)
            wait_ms(1);
        else // yep, it's running
            break;
    if (now == start) {
        printf("RTC init\n");
        now.init();
    }

    // use a 6s watchdog timeout during the first 20s after power-up
    // this forces the min 2x retries needed to pick up the SD card (why???)
    // as soon as it has been detected, the watchdog is set to 26s again
    if (now < 20) {
        printf("%d: short watchdog\n", (int) now);
        dog.reload(0x200);
    }

    // set up the LCD, it's also powered from some GPIO pins
    gnd.mode(Pinmode::out);
    // light.mode(Pinmode::out);
    vcc.mode(Pinmode::out);
    vcc = 1;
    wait_ms(500);
    lcd.init(0x40);

    int vBat = (analogRead(PB0) * 3300 * 4) / 4095;
    printf("%d: usb %d, %d mV\n", (int) now, (int) usbPower, vBat);

    printf("%d: spi init %d\n", (int) now, ticks);
    spi.init();
    if (sd.init()) {
        printf("sdhc %d\n", sd.sdhc);
        dog.reload(0xFFF);  // revert to 26s watchdog timeout

        fat.init();

        printf("base %d spc %d rdir %d rmax %d data %d clim %d\n\n",
            fat.base, fat.spc, fat.rdir, fat.rmax, fat.data, fat.clim);

        sd.read512(fat.rdir, fat.buf);
        //fat.dumpHex(32);
        for (int i = 0; i < 512; i += 32) {
            int length = *(int32_t*) (fat.buf+i+28);
            if (length >= 0 && '!' < fat.buf[i] && fat.buf[i] <= '~') {
                uint8_t attr = fat.buf[i+11];
                printf("   %s\t", attr & 8 ? "vol:" : attr & 16 ? "dir:" : "");
                for (int j = 0; j < 11; ++j) {
                    int c = fat.buf[i+j];
                    if (c != ' ') {
                        if (j == 8 && (attr & 0x08) == 0)
                            printf(".");
                        printf("%c", c);
                    }
                }
                printf(" (%db)\n", length);
            }
        }
        printf("\n");

        if (firmware.open("FIRMWAREBIN") > 0)
            printf("  f/w ok\n");
        if (datafile.open("ZELKOVA DAT") > 0)
            printf("  dat ok\n");
        printf("\n");

        SysTick<72000000> tick;
#if 1
        uint32_t t = now;
        while (t == now) ;  // wait for second counter to change
        t = now;
        uint32_t s = tick.micros();
        while (t == now) ;  // wait for the next second
        printf("rtc %d us\n", tick.micros() - s);
#endif
        uint32_t start = tick.micros();
        sd.read512(1, fat.buf);
        printf("read512 %d us\n", tick.micros() - start);

        start = tick.micros();
        sd.write512(1, fat.buf);
        printf("write512 %d us\n", tick.micros() - start);

        //sd.read512(fat.base + fat.rsec, fat.buf);
        //fat.dumpHex(48);
        //sd.read512(fat.base, fat.buf);
        //fat.dumpHex(48);
    }
    printf("%d: sd done %d\n", (int) now, ticks);

    dog.reset();
    powerDown();
}

void loop() {
    // ledG.toggle();

    int vBat = (analogRead(PB0) * 3300 * 4) / 4095;
    printf("%03d %d %d\n", ticks % 1000, (int) now, vBat);

    ledY = 1;
    wait_ms(100);
    ledY = 0;
    wait_ms(400);
}
