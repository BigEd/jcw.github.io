# SD card to LCD display

A quick experiment to display a picture on a 320x240 LCD, connected over SPI.

With some tweaking, and driving both the SD card and the LCD buses through the
F103's SPI hardware, timings are: ≈ 150 µs for clear, ≈ 420 µs for
load+display.

The image was created by resizing a JPEG to 320x240 and applying the following
ImageMagick command + tweaks to extract a raw 320x240x2-byte RGB565 file, ready
to be sent to the LCD:

```
$ convert example.jpg -resize 320x240 +flip -strip \
    -define bmp:subtype=RGB565 bmp2:- | tail -c 153600 >image.raw
```

It needs to be saved as `IMAGE.RAW` on the SD card.

**OOPS** - This image conversion is not correct, it's flipped left to right.

## Front side

![](hw-front.jpg)

## Back side

![](hw-back.jpg)
