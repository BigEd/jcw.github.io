// Demo of a Blue Pill with ILI9341 LCD display connected via SPI.
// This example reads a 320x240 image off an SD card and displays it on the LCD.

#include <jee.h>
#include <jee/spi-ili9341.h>
#include <jee/spi-sdcard.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiHw< PinB<15>, PinB<14>, PinB<13>, PinB<12> > spi2;
SdCard< decltype(spi2) > sd;
FatFS< decltype(sd) > fat;

SpiHw< PinB<5>, PinB<4>, PinB<3>, PinB<0> > spi1;
ILI9341< decltype(spi1), PinB<6> > lcd;
PinA<15> light;  // LCD backlight
PinB<7> reset;   // LCD hard reset
PinC<13> led;

int main () {
    console.init();
    enableSysTick();
    led.mode(Pinmode::out);

    wait_ms(500);
    printf("\nsd card: ");
    spi2.init();
    if (sd.init())
        printf("detected, hd=%d\n", sd.sdhc);

    wait_ms(10);
    console.baud(115200, fullSpeedClock());
    // switch to div-2, i.e. 9 MHz for SPI2
    MMIO32(spi2.cr1) = (1<<6) | (0<<3) | (1<<2) | (0<<1);  // [1] p.742

    light.mode(Pinmode::out);
    reset.mode(Pinmode::out);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25; // disable JTAG, keep SWD enabled

    // the following is needed to use h/w SPI1 with pins B5..B3 iso A7..A5
    MMIO32(afio + 0x04) |= (1<<0);  // SPI1_REMAP in AFIO's MAPR

    spi1.init();
    // switch to div-2, i.e. 18 MHz for SPI1
    MMIO32(spi1.cr1) = (1<<6) | (0<<3) | (1<<2) | (0<<1);  // [1] p.742
    reset = 1;
    wait_ms(10); // data sheet says to wait 5ms
    lcd.init();

    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    light = 1; // turn backlighting on

    // the proper "raw" image file format can be generated with ImageMagick:
    //      convert example.jpg -resize 320x240 +flip -strip \
    //          -define bmp:subtype=RGB565 bmp2:- | tail -c 153600 >0-rgb.bmp
    // TODO fix the horizontal image reversal, it's mirrored right now ...

    fat.init();
    FileMap< decltype(fat), 49 > file (fat);
    int len = file.open("IMAGE   RAW");
    printf("<%d>\n", len);

    while (true) {
        uint32_t t1 = ticks;
        lcd.clear();
        t1 = ticks - t1;
        wait_ms(1000);

        uint32_t t2 = ticks;

        lcd.bounds();
        lcd.pixel(0, 0, 0); // FIXME this leads to off-by-one pixel placement
        spi1.enable();

        uint16_t buf [256];
        for (int pos = 0; pos < len; pos += 512) {
            if (!file.ioSect(false, pos/512, buf))
                printf("? fat map error at %d\n", pos);
            for (int j = 0; j < 256; j++) {
                lcd.out16(buf[j]);
            }
        }

        spi1.disable();
        printf("%d ms clear + %d ms load/display\n", t1, ticks - t2);

        wait_ms(1000);
    }
}
