#include <jee.h>
#include <jee/spi-flash.h>
#include <jee/spi-sdcard.h>
#include <jee/mem-r61509v.h>
#include <jee/text-font.h>

UartDev< PinA<9>, PinA<10> > uart;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(uart.putc, fmt, ap); va_end(ap);
    return 0;
}

R61509V< 0x6C000000, 0x6C000800 > lcd;
TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;

// the micro SD socket can be connected either via SDIO or via SPI2
#if 1
SpiGpio< PinD<2>, PinC<8>, PinC<12>, PinC<11> > spi;
#else
SpiGpio< PinB<15>, PinB<14>, PinB<13>, PinG<14> > spi;
#endif
SdCard< decltype(spi) > sd;

// definition of I2C bus and some code to detect devices on it

I2cBus< PinB<11>, PinB<10>, 5 > bus;

template< typename T >
void detectI2c (T bus) {
    for (int i = 0; i < 128; i += 16) {
        printf("%02x:", i);
        for (int j = 0; j < 16; ++j) {
            int addr = i + j;
            if (0x08 <= addr && addr <= 0x77) {
                bool ack = bus.start(addr<<1);
                bus.stop();
                printf(ack ? " %02x" : " --", addr);
            } else
                printf("   ");
        }
        printf("\n");
    }
}

// SRAM access via FSMC

uint16_t volatile* const sram = (uint16_t*) 0x68000000;

static void initFsmcPins () {
    MMIO32(Periph::rcc + 0x14) |= (1<<8);  // enable FSMC

    Port<'D'>::modeMap(0b1111111100110011, Pinmode::alt_out);
    Port<'E'>::modeMap(0b1111111110000011, Pinmode::alt_out);
    Port<'F'>::modeMap(0b1111000000111111, Pinmode::alt_out);
    Port<'G'>::modeMap(0b0001010000111111, Pinmode::alt_out);
}

static void initFsmcSram () {
    constexpr uint32_t bcr3 = 0xA0000010;
    constexpr uint32_t btr3 = 0xA0000014;

    MMIO32(bcr3) = (1<<12) | (1<<7) | (1<<4);
    MMIO32(btr3) = (2<<8) | (1<<0);
    MMIO32(bcr3) |= 1;
}

static void initFsmcLcd () {
    constexpr uint32_t bcr4 = 0xA0000018;
    constexpr uint32_t btr4 = 0xA000001C;

    MMIO32(bcr4) = (1<<12) | (1<<7) | (1<<4);
    MMIO32(btr4) = (1<<8) | (0<<0);
    MMIO32(bcr4) |= (1<<0);
}

void myMain () {
    fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    detectI2c(bus);

    initFsmcPins();
    initFsmcSram();
    initFsmcLcd();
    printf("fsmc inited\n");

    sram[0] = 1;
    sram[1] = 22;
    sram[2] = 333;

    printf("read: %d %d %d\n", sram[0], sram[1], sram[2]);

    lcd.init();
    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);

    spi.init();
    if (sd.init())
        printf("sdhc %d\n", sd.sdhc);

    while (true) {
        if (uart.readable()) {
            char c = uart.getc();
            console.putc(c);
        }
    }
}
