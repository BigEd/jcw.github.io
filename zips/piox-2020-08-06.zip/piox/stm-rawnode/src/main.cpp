#include <jee.h>
#include <jee/spi-rf69.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
RF69< decltype(spi) > rf;

PinC<13> led;

int main () {
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);
    spi.init();
    rf.init(1, 6, 8686);  // node 1, group 6, 868.6 MHz

    while (true) {
        uint8_t rxBuf [66];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            led.toggle();

            printf("RF69 #%d: ", rxLen);
            for (int i = 0; i < rxLen; ++i)
                printf("%02x", rxBuf[i]);
            printf("\n");
        }
    }
}
