#include <jee.h>
#include <jee/i2c-sht2x.h>

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

template< typename T >
void detectI2c (T bus) {
    for (int i = 0; i < 128; i += 16) {
        printf("%02x:", i);
        for (int j = 0; j < 16; ++j) {
            int addr = i + j;
            if (0x08 <= addr && addr <= 0x77) {
                bool ack = bus.start(addr<<1);
                bus.stop();
                printf(ack ? " %02x" : " --", addr);
            } else
                printf("   ");
        }
        printf("\n");
    }
}

I2cBus< PinB<9>, PinB<8> > bus;
SHT2x< decltype(bus) > sht2x;

int main () {
    console.init();
	enableSysTick();
    wait_ms(1000);
    printf("=====\n");

    detectI2c(bus);
	sht2x.init();

	printf("%d %d\n", sht2x.temp100(), sht2x.humidity10());

    while (true) {}
}
