// Demo of a Blue Pill with ILI9341 LCD display connected via SPI.

#include <jee.h>
#include <jee/dio-dht22.h>
#include <jee/dio-pcd8544.h>
#include <jee/spi-sdcard.h>
#include <jee/text-font.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PCD8544< SlowPin<PinB<10>,5>, PinB<1>, PinB<0>, PinA<3>, PinA<2> > lcd;
Font5x7< decltype(lcd) > display;
PinB<11> light;

void showf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(display.putc, fmt, ap); va_end(ap);
}

PinC<13> led;

I2cBus< PinB<7>, PinB<6>, 50 > bus;
constexpr int soilAddr = 0x20 << 1;

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
SdCard< decltype(spi) > sd;

template< typename T >
void detectI2c (T bus) {
    for (int i = 0; i < 128; i += 16) {
        printf("%02x:", i);
        for (int j = 0; j < 16; ++j) {
            int addr = i + j;
            if (0x08 <= addr && addr <= 0x77) {
                bool ack = bus.start(addr<<1);
                bus.stop();
                printf(ack ? " %02x" : " --", addr);
            } else
                printf("   ");
        }
        printf("\n");
    }
}

struct Soil {
    static void write (uint8_t reg) {
        bus.start(soilAddr);
        bus.write(reg);
        bus.stop();
    }

    static void write (uint8_t reg, uint8_t val) {
        bus.start(soilAddr);
        bus.write(reg);
        bus.write(val);
        bus.stop();
    }

    static uint8_t read8 (uint8_t reg) {
        bus.start(soilAddr);
        bus.write(reg);
        bus.start(soilAddr|1);
        return bus.read(true);
    }

    static uint16_t read16 (uint8_t reg) {
        bus.start(soilAddr);
        bus.write(reg);
        bus.start(soilAddr|1);
        uint16_t val = bus.read(false) << 8;
        return val | bus.read(true);
    }
};

Soil soil;
DHT22<PinA<15>> dht22;

int main () {
    led.mode(Pinmode::out);
    Iwdg watchdog (6);  // approx 13s

    fullSpeedClock();
    console.init();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    light.mode(Pinmode::out);
    light = 0;
    lcd.init();
    lcd.clear();

    wait_ms(500);  // soil sensor start up
    detectI2c(bus);

    dht22.init();
    soil.write(6);  // reset

    spi.init();
    if (sd.init()) {
        printf("sdhc %d\n", sd.sdhc);
        showf("sdhc %d\n", sd.sdhc);
    }

    int n = 0, sver, stemp, scapa;
    int16_t atemp, ahumi;
    bool ambok;

    while (true) {
        watchdog.reset();

        n = (n+1) % 10;
        switch (n) {
            case 4:
                ambok = dht22.read(atemp, ahumi);
                sver = soil.read8(7);
                stemp = soil.read16(5);
                scapa = soil.read16(0);
                printf("%d\tsoil v%x.%x: %d.%d °C, cap %d"
                        "\tamb %d: %d.%d °C, %d.%d %%RH\n",
                    ticks,
                    sver/16, sver%16, stemp/10, stemp%10, scapa,
                    ambok, atemp/10, atemp%10, ahumi/10, ahumi%10);
                showf("\f%d\tsoil v%x.%x: %d.%d C, cap %d"
                        "\tamb %d: %d.%d C, %d.%d %%RH",
                    ticks,
                    sver/16, sver%16, stemp/10, stemp%10, scapa,
                    ambok, atemp/10, atemp%10, ahumi/10, ahumi%10);
#if 0
                soil.write(3); // measure light
                break;
            case 9:
                printf("%d\tlight %d\n", ticks, soil.read16(4));
#endif
                soil.write(8);  // sleep
                break;
        }

        led.toggle();
        wait_ms(250);
    }
}
