#include <jee.h>
#include <jee/spi-ili9325.h>
#include <jee/text-font.h>

PinA<1> led;

// use SpiGpio for bit-banged SPI, or SpiHw to use the built-in SPI hardware
#if 1
// SpiGpio< PinB<5>, PinB<4>, PinB<3>, PinB<0>, 1 > spi;
SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4>, 1 > spi;
#else
// SpiHw< PinB<5>, PinB<4>, PinB<3>, PinB<0>, 1 > spi;
SpiHw< PinA<7>, PinA<6>, PinA<5>, PinA<4>, 1 > spi;
#endif
ILI9325< decltype(spi) > lcd;

// use the serial port or the lcd as console for printf
#if 1
UartDev< PinA<9>, PinA<10> > console;
#else
TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > console;
#endif

TextLcd< decltype(lcd) > text;
Font5x7< decltype(text) > cons;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    fullSpeedClock();
    led.mode(Pinmode::out);

#if 0  // HyTiny with LCD on FPC-12 connector
    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    // rtp touch screen is on the same SPI bus, make sure it's disabled
    PinB<2> rtpcs;
    rtpcs = 1;
    rtpcs.mode(Pinmode::out);

    // the following is needed to use SPI1 with pins B5..B3/A15 iso A7..A4
    MMIO32(afio + 0x04) |= (1<<0);  // SPI1_REMAP in AFIO's MAPR
#else
    PinA<8> reset;
    reset.mode(Pinmode::out);
    reset = 0;
    wait_ms(2);
    reset = 1;
#endif

    spi.init();
    lcd.init();
    lcd.write(0x01, 0);  // fix scan line dir of HY28A-LCD[AB] (default 0x0100)

    uint32_t start = ticks;
    lcd.clear();
    printf("%d ms\n", ticks - start);
    wait_ms(500);

    while (true) {
        for (char c = '!'; c <= '~'; ++c)
            cons.putc(c);
        printf("%d\n", ticks);
        led.toggle();
        wait_ms(500);
    }
}
