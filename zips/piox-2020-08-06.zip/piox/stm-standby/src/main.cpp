#include <jee.h>

PinC<13> led;
//RTC now;
Iwdg dog (6);  // approx 26s

static void powerDown () {
    //MMIO32(Periph::rcc + 0x04) = 0;     // revert to HSI @ 8 MHz, no PLL
    //MMIO32(Periph::rcc + 0x00) = 0x81;  // turn off HSE and PLL, power-up value
    //MMIO32(Periph::usb + 0x40) |= 1<<1;  // set USB PWDN
    MMIO32(Periph::pwr) |= 1<<1 | 1<<0;  // set PDDS and LPDS

    constexpr uint32_t scr = 0xE000ED10;
    MMIO32(scr) |= 1<<2;  // set SLEEPDEEP

    __asm("cpsid i");
    __asm("wfi");
}

int main () {
    enableSysTick();

    led.mode(Pinmode::out);
    led = 0;
    wait_ms(100);
    led = 1;

    //now.init();

    //dog.reset();
    powerDown();
}
