// Data capture setup for RF69, using a 16 MB SPI flash chip.

#include <jee.h>
#include <jee/spi-rf69.h>

UartDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

SpiHw< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
RF69< decltype(spi) > rf;

PinC<13> led;

int main() {
    Iwdg dog;  // will reset whenever no packet has been received within 26s

    fullSpeedClock();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    led.mode(Pinmode::out);

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    // (PB3/PB4 are tied to DIO pins of the RFM69 module)
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    spi.init();
    rf.init(63, 6, 8686);     // node 63, group 6, 868.6 MHz
    rf.writeReg(0x29, 0xE4);  // lower RSSI threshold
    // rf.writeReg(0x58, 0x29);  // high sensitivity mode

    while (true) {
        uint8_t rxBuf [66];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            dog.reset();

            led.toggle();

            printf("RF69 r%d l%d a%d %d>%d ",
                    rf.rssi, rf.lna, rf.afc, rxBuf[1] & 0x3F, rxBuf[0] & 0x3F);
            for (int i = 0; i < rxLen; ++i)
                printf("%02x", rxBuf[i]);
            printf("\n");
        }
    }
}
