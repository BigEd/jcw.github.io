#include <jee.h>
#include <string.h>

PinB<9> led;   // F103VE "circle" board with µSD socket on the bottom

#include "usb.h"

UsbDev< PinA<12> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    led.mode(Pinmode::out);

    while (true) {
        if (ticks % 5000 == 0) {
            for (int i = 0; i < 68; ++i)
                console.putc(' '+i);
            console.putc('\n');
        }

        if (ticks % 500 == 0) {
            led.toggle();
            console.putc('0' + (ticks/500)%10);
        }

        console.poll();

        while (console.readable())
            console.putc(console.getc() ^ 1);

        wait_ms(1);
    }
}
