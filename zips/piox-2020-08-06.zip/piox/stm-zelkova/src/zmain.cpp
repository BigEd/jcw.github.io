// see [1] https://jeelabs.org/ref/STM32F1-RM0008.pdf

#include <jee.h>
#include <jee/dio-dht22.h>
#include <jee/spi-flash.h>
#include <jee/spi-rf69.h>

UartBufDev< PinA<9>, PinA<10>, 100 > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinC<13> led;       // "1" to turn on yellow LED

ADC<1> adc;
PinB<1> batAdc;
PinB<2> sunAdc;
PinB<2> usbAdc;  // FIXME PB3

RTC rtc;
Iwdg dog (6);  // approx 26s
SysTick<defaultHz> tick;

DHT22<PinA<15>> dht22;

I2cBus< PinB<7>, PinB<6>, 2 > bus1;
I2cBus< PinB<9>, PinB<8>, 2 > bus2;
I2cBus< PinB<11>, PinB<10>, 2 > bus3;

SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi1;
SpiFlash< decltype(spi1) > flash;

SpiGpio< PinB<15>, PinB<14>, PinB<13>, PinB<12> > spi2;
RF69< decltype(spi2) > rf;

static void powerDown () {
    MMIO32(Periph::rcc + 0x04) = 0;     // revert to HSI @ 8 MHz, no PLL
    MMIO32(Periph::rcc + 0x00) = 0x81;  // turn off HSE and PLL, power-up value
    MMIO32(Periph::usb + 0x40) |= 1<<1;  // set USB PWDN
    MMIO32(Periph::pwr) |= 1<<1 | 1<<0;  // set PDDS and LPDS

    constexpr uint32_t scr = 0xE000ED10;
    MMIO32(scr) |= 1<<2;  // set SLEEPDEEP

    __asm("cpsid i");
    __asm("wfi");
}

template< typename T >
void detectI2c (T bus) {
    for (int i = 0; i < 128; i += 16) {
        printf("%02x:", i);
        for (int j = 0; j < 16; ++j) {
            int addr = i + j;
            if (0x08 <= addr && addr <= 0x77) {
                bool ack = bus.start(addr<<1);
                bus.stop();
                printf(ack ? " %02x" : " --", addr);
            } else
                printf("   ");
        }
        printf("\n");
    }
}

template< typename I2C >
struct Soil {
    constexpr static int soilAddr = 0x20 << 1;

    bool present () {
        bool ack = I2C::start(soilAddr);
        I2C::stop();
        return ack;
    }

    void write (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::stop();
    }

    void write (uint8_t reg, uint8_t val) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::write(val);
        I2C::stop();
    }

    uint8_t read8 (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::start(soilAddr|1);
        return I2C::read(true);
    }

    uint16_t read16 (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::start(soilAddr|1);
        uint16_t val = I2C::read(false) << 8;
        return val | I2C::read(true);
    }

    bool reading () {
        bool ack = I2C::start(soilAddr);
        I2C::stop();
        if (ack) {
            sver = read8(7);
            stemp = read16(5);
            scapa = read16(0);
        }
        return ack;
    }

    uint8_t sver;
    uint16_t stemp, scapa;
};

Soil< decltype(bus1) > soil1;
Soil< decltype(bus2) > soil2;
Soil< decltype(bus3) > soil3;

struct AppState {
    enum {
        Check,
        Version,
        Next,
    };

    static bool isValid () {
        uint16_t sum = 1;
        for (int i = 0; i < 10; ++i)
            sum += rtc.getData(i);
        return sum == 0;
    }

    static void clearState () {
        for (int i = 0; i < 10; ++i)
            rtc.setData(i, 0);
    }

    static void forceValid () {
        uint16_t sum = 0;
        for (int i = 1; i < 10; ++i)
            sum += rtc.getData(i);
        rtc.setData(Check, ~sum);
    }
};

AppState app;

struct Reading {
    // 0
    uint32_t rtc;                   // seconds since power-up
    // 4
    uint8_t version :4;             // firmware version
    uint8_t type :4;                // reading type, see union below
    uint8_t flags;                  // status flags
    uint16_t events;                // events since previous entry
    // 8
    union {
        uint32_t _ [6];
        struct {                    // type 1: sensor reading
            // 8
            uint8_t vUsb;           // USB voltage Vx10
            uint8_t vSun;           // solar voltage Vx10
            uint16_t mvBat;         // LiPo voltage Vx1000
            // 12
            struct {                // soil sensors:
                int16_t temp;       //  temperature Cx10
                int16_t capa;       //  capacitance 0..1023
            } soil [3];
            // 24
            int16_t aTemp;          // ambient temperature Cx10
            uint16_t aHumi;         // ambient humidity RHx10
            // 28
            int16_t iTemp;          // internal temperature Cx10
            uint16_t cycles;        // reset cycle count
            // 32
        } sensors;
        struct {                    // type 2: configuration
            // 8
            uint32_t sec1970;       // date set, timestamp
            // 12
            uint16_t yr;            // date set, year
            uint8_t mo;             // date set, month
            uint8_t dy;             // date set, day
            uint8_t hh;             // date set, hour
            uint8_t mm;             // date set, minute
            uint8_t ss;             // date set, second
            // 23
            uint8_t soilVers [3];   // soil sensor version x10
            // 26
            uint16_t flashFill;     // flash fill pointer, bytes
            uint32_t sdcardFill;    // sd card fill pointer, bytes
            // 32
        } config;
        struct {                    // type 3: message
            // 8
            uint16_t num;           // message number
            uint16_t code;          // message code
            char text [20];         // message text
            // 32
        } message;
    };
    // 32
};

int main () {
    enableSysTick();
    console.init();
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    // ensure that the RTC hardware is running, or restart it if not
    // use RTC_DIVL, since that changes 32768x/sec if the RTC is running
    constexpr static uint32_t divl = Periph::rtc + 0x14;
    uint16_t start = MMIO16(divl);
    wait_ms(2);
    if (MMIO16(divl) == start) {
        wait_ms(1000);  // wait a bit so that console terminal sees this
        printf("RTC init\n");
        rtc.init();
    }

#if 0
    // use a 5s watchdog timeout during the first 20s after power-up
    // this forces the min 2x retries needed to pick up the SD card (why???)
    if (rtc < 20) {
        printf("short watchdog\n");
        dog.reload(0x300);
    }
#endif

    led.mode(Pinmode::out);
    led = 1;

#if 0
    detectI2c(bus1);
    detectI2c(bus2);
    detectI2c(bus3);
#endif

    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    constexpr uint32_t afio = 0x40010000;
    MMIO32(afio + 0x04) |= 1 << 25;

    // allow SWD upload while stopped - i.e. anytime in the first 60s
    // this also has to be cleared, since it's not affected by a reset
    // it prevents clock-less sleep mode, don't just leave it on forever
    constexpr uint32_t dbgmcu = 0xE0042000;  // [1] p.1101
    if (rtc < 60) {
        printf("swd active\n");
        MMIO32(dbgmcu + 0x04) = 0b111;
    } else
        MMIO32(dbgmcu + 0x04) = 0;

    printf("%d: started @ %d ms\n", (int) rtc, ticks);

#if 0
    int t = rtc;
    while (t == rtc) ;  // wait for second counter to change
    t = rtc;
    uint32_t s = tick.micros();
    while (t == rtc) ;  // wait for the next second
    printf("rtc %d us, %d ms\n", tick.micros() - s, ticks);
#endif

    dht22.init();
    int16_t atemp, ahumi;
    if (dht22.read(atemp, ahumi))
        printf("amb %d.%d °C, %d.%d %%RH\n",
                atemp/10, atemp%10, ahumi/10, ahumi%10);

    if (soil1.reading())
        printf("soil1 v%x.%x: %d.%d °C, cap %d\n",
                soil1.sver/16, soil1.sver%16,
                soil1.stemp/10, soil1.stemp%10, soil1.scapa);

    if (soil2.reading())
        printf("soil2 v%x.%x: %d.%d °C, cap %d\n",
                soil2.sver/16, soil2.sver%16,
                soil2.stemp/10, soil2.stemp%10, soil2.scapa);

    if (soil3.reading())
        printf("soil3 v%x.%x: %d.%d °C, cap %d\n",
                soil3.sver/16, soil3.sver%16,
                soil3.stemp/10, soil3.stemp%10, soil3.scapa);

    adc.init();
    (void) adc.read(usbAdc);  // throw away first ADC reading

    int vUsb = (adc.read(usbAdc) * 3300 * 3) / 4095;
    int vBat = (adc.read(batAdc) * 3300 * 3) / 4095;
    int vSun = (adc.read(sunAdc) * 3300 * 3) / 4095;
    printf("vUsb %d mV, vBat %d mV, vSun %d mV\n", vUsb, vBat, vSun);

    //printf("spi1 init @ %d ms\n", ticks);
    spi1.init();
    flash.init();
    // flashSetup();

    //printf("spi2 init @ %d ms\n", ticks);
    spi2.init();
    //rf.init(1, 6, 8686);
    //rf.receive(0, 0);

    printf("%d: power down @ %d ms\n", (int) rtc, ticks);
    wait_ms(10);  // let console output finish
    dog.kick();
    powerDown();
}
