#if NATIVE || ESP32
#include <cstdio>
#endif

#if STM32F4
#include <jee.h>
UartBufDev< PinA<2>, PinA<30> > console;
int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}
#endif

#if ESP8266
#include <Arduino.h>
#define printf Serial.printf
#endif

struct Calls {
    void f1 (int a) { stackCheck(); printf("f1: %d\n", a); f2(++a); }
    void f2 (int a) { stackCheck(); printf("f2: %d\n", a); f3(++a); }
    void f3 (int a) { stackCheck(); printf("f3: %d\n", a); f4(++a); }
    void f4 (int a) { stackCheck(); printf("f4: %d\n", a); f5(++a); }
    void f5 (int a) { stackCheck(); printf("f5: %d\n", a); }

    void stackCheck () {
        int i;
        printf("%p ", &i);
    }
};

#if ESP8266
void setup () {
#elif ESP32
extern "C" int app_main () {
#else
int main () {
#endif

#if STM32F4
    console.init();
    console.baud(115200, fullSpeedClock() / 4);
#endif
#if ESP8266
    Serial.begin(115200);
#endif

    Calls c;
    c.f1(100);

#if !NATIVE
    while (true) {}
#endif
}

void loop () {}
