# preactx

Explorations using Preact-based web apps

* uses [Preact](https://preactjs.com/) as progressive/reactive web framework
* uses [preact-cli](https://github.com/developit/preact-cli) as build system
* mostly intended for very board-specific code
