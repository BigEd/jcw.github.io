In order of exploration:

* **mqtt** - a "minimally-blocking" MQTT client (µPy & CPy)
* **iotser** - a line-oriented bridge between serial and MQTT (CPy)
* **http** - webserver with static file and websocket support (µPy)
* **ftp** - a basic (and minimally-blocking) FTP file server (µPy)
* **nrf24** - async streaming through a pair of nRF24L01+ modules (µPy)
* **si5351** - driver for the Si5351 frequency generator (µPy)
* **dumper** - a (partial) attempt to decode bytecode files (C++)
* **freezer** - linking to frozen bytecode without the µPy runtime (C++)
* **toypy** - (obsolete, moved to <https://git.jeelabs.org/jcw/monty>)
