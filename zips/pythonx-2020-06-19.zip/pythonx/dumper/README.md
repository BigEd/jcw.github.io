This is a - _partial!_ - attempt to decode `.mpy` bytecode files.

The file format is fairly tricky in some places (interleaving some small ints  
to fit them into the minimum number of varint bytes - bit-shaving, wow ...).

A few parts were extracted and adapted from the MicroPython source code, see  
`mp_raw_code_load()` in the `persistencode.c` source, which can be found at:  
<https://github.com/micropython/micropython/blob/master/py/persistentcode.c>  
(be warned: the path through the code is full of twisty little passages!).

This dumper code is written in C++11 and compiled with PlatformIO on MacOS.

Sample input:

```text
$ cat hello.py
print('hello')
$
```


Sample output:

```text
$ make
pio run
[...]
.pio/build/native/program hello.mpy
version 5
features 0x02
intbits 31
qstr 32
type 0 size 18 (72)
n_state        2
n_exc_stack    0
scope_flags    0
n_pos_args     0
n_kwonly_args  0
n_def_pos_args 0
code_info_size 0
n_info 5 n_cell 0
q:hello.py
q:hello
  Q: 0x10
  V: 0x34 1
  B: 0x59
  B: 0x51
  B: 0x63
  B: 0x00
   x 0x00
$
```

Known issues:

* decoding is not quite right, this code is merely a starting point

-jcw, 2020-06-10
