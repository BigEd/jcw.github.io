#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

uint8_t buffer [10000];

class Dumper {
    const uint8_t* ptr;
    const uint8_t* end;
public:

    struct Prelude {
        uint32_t n_state;
        uint32_t n_exc_stack;
        uint32_t scope_flags;
        uint32_t n_pos_args;
        uint32_t n_kwonly_args;
        uint32_t n_def_pos_args;
        uint32_t n_info;
        uint32_t n_cell;

        int load (Dumper& d) {
            uint8_t z = d.next(); /* xSSSSEAA */
            n_state = (z >> 3) & 0xf;
            n_exc_stack = (z >> 2) & 0x1;
            scope_flags = 0;
            n_pos_args = z & 0x3;
            n_kwonly_args = 0;
            n_def_pos_args = 0;
            for (int n = 0; z & 0x80; ++n) {
                z = d.next(); /* xFSSKAED */
                n_state |= (z & 0x30) << (2 * n);
                n_exc_stack |= (z & 0x02) << n;
                scope_flags |= ((z & 0x40) >> 6) << n;
                n_pos_args |= (z & 0x4) << n;
                n_kwonly_args |= ((z & 0x08) >> 3) << n;
                n_def_pos_args |= (z & 0x1) << n;
            }
            n_state += 1;
            printf("n_state        %d\n", n_state);
            printf("n_exc_stack    %d\n", n_exc_stack);
            printf("scope_flags    %d\n", scope_flags);
            printf("n_pos_args     %d\n", n_pos_args);
            printf("n_kwonly_args  %d\n", n_kwonly_args);
            printf("n_def_pos_args %d\n", n_def_pos_args);

            n_info = 0;
            n_cell = 0;
            z = 0x80;
            for (int n = 0; z & 0x80; ++n) {
                z = d.next(); /* xIIIIIIC */
                n_cell |= (z & 1) << n;
                n_info |= ((z & 0x7e) >> 1) << (6 * n);
            }
            printf("n_info         %d\n", n_info);
            printf("n_cell         %d\n", n_cell);
            return n_info + n_cell;
        }
    } prelude;

    Dumper (const uint8_t* buf, size_t len) : ptr (buf), end (buf+len) {
        assert(next() == 'M');
        printf("version %d\n", next());
        printf("features 0x%02X\n", next());
        printf("intbits %d\n", next());
        printf("qstr %u\n", varint());
        loadRaw();
    }

    uint8_t next ()
        { return *ptr++; }

    uint32_t varint () {
        uint32_t v = 0;
        uint8_t b = 0x80;
        int i;
        for (i = 0; b & 0x80; i += 7) {
            b = next();
            v |= (b & 0x7F) << i;
        }
        //printf("v%d:%d ", i/7, v);
        return v;
    }

    void loadRaw () {
        uint8_t typsiz = varint();
        printf("type %d size %d (%d)\n", typsiz & 3, typsiz >> 2, typsiz);

        uint8_t* buf = (uint8_t*) malloc(typsiz >> 2);
        prelude.load(*this);
        (void) loadQstr();
        (void) loadQstr();
        next(); next(); next(); next();
        loadBC();
        loadBC();
    }

    uint8_t loadQstr() {
        uint8_t len = varint();
        if (len == 0)
            return next();
        if (len & 1)
            return 2; //?
        len >>= 1;
        uint8_t buf [128];
        for (int i = 0; i < len; ++i)
            buf[i] = next();
        buf[len] = 0;
        printf("q:%s\n", buf);
        return 3; //?
    }

    void loadBC () {
        constexpr auto MP_BC_MASK_EXTRA_BYTE = 0x9e;
        constexpr auto MP_BC_FORMAT_BYTE     = 0;
        constexpr auto MP_BC_FORMAT_QSTR     = 1;
        constexpr auto MP_BC_FORMAT_VAR_UINT = 2;
        constexpr auto MP_BC_FORMAT_OFFSET   = 3;

        while (ptr < end) {
            uint8_t op = next();
            // see #define MP_BC_FORMAT(op) in py/pc0.h
            int f = (0x000003a4 >> 2*(op>>4)) & 3;
            switch (f) {
                case MP_BC_FORMAT_BYTE:
                    printf("  B: 0x%02X\n", op);
                    break;
                case MP_BC_FORMAT_QSTR: {
                    auto n = loadQstr();
                    //next(); next(); // are these at the end?
                    printf("  Q: 0x%02X %u\n", op, n);
                    break;
                }
                case MP_BC_FORMAT_VAR_UINT: {
                    printf("  V: 0x%02X %d\n", op, varint());
                    break;
                }
                case MP_BC_FORMAT_OFFSET: {
                    uint8_t op1 = 0; //next();
                    uint8_t op2 = 0; //next();
                    printf("  O: 0x%02X %02X %02X\n", op, op1, op2);
                    break;
                }
            }
            if (f != MP_BC_FORMAT_QSTR && (op & MP_BC_MASK_EXTRA_BYTE) == 0)
                printf("   x 0x%02X\n", next());
        }
    }
};

int main (int argc, const char** argv) {
    for (int i = 1; i < argc; ++i) {
        FILE* fp = fopen(argv[i], "rb");
        assert(fp != 0);
        size_t n = fread(buffer, 1, sizeof buffer, fp);
        fclose(fp);

        Dumper dumper (buffer, n);
    }
    return 0;
}
