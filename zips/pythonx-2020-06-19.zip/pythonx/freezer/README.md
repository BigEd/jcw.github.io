An exploration of frozen bytecode without the MicroPython runtime and VM.

It takes quite a bit of header file boilerplate-extraction to make this work.  
See `src/py/mpconfig.h` which has copies of all the necessary definitions.  
These were copied from numerous places inside the MicroPython codebase,  
i.e. the <https://github.com/micropython/micropython/blob/master/py/> area.

This freezer code is written in C++11 and compiled with PlatformIO on MacOS.

An extract of the generated output (the complete output is in `dump.txt`):

```text
$ make | tee dump.txt
[...]
.pio/build/native/program
module #0 name: src/hello.py
module #1 name: src/features.py
qstr pool length: 202
[...]
  qstr #6 len 8:
       0: 3C6D6F64 756C653E                   |<module>        |
  qstr #7 len 1:
       0: 5F                                  |_               |
  qstr #8 len 8:
       0: 5F5F6361 6C6C5F5F                   |__call__        |
  qstr #9 len 9:
       0: 5F5F636C 6173735F 5F                |__class__       |
[...]
       0: 7372632F 68656C6C 6F2E7079          |src/hello.py    |
  qstr #166 len 5:
       0: 68656C6C 6F                         |hello           |
  qstr #167 len 15:
       0: 7372632F 66656174 75726573 2E7079   |src/features.py |
  qstr #168 len 4:
       0: 534B4950                            |SKIP            |
[...]
  qstr #201 len 1:
       0: 6E                                  |n               |
qstr pool bytes: 1438

module #0: '<module>' in 'src/hello.py'
  bytecode len 18 scope 0 args 0 obj 0 raw 0 skip 5
     0: 080A0600 A5000011 7A0010A6 00340159 |........z....4.Y|
    16: 5163                                |Qc              |

module #1: '<module>' in 'src/features.py'
  bytecode len 1260 scope 0 args 0 obj 2 raw 11 skip 142
     0: 349C0406 00A70023 53296840 24242929 |4......#S)h@$$))|
    16: 292F242E 24283329 27234C2B 7165202B |)/$.$(3)'#L+qe +|
[...]
  obj 0: STR len 20
     0: 64656620 666F6F28 293A2072 65747572 |def foo(): retur|
    16: 6E203338                            |n 38            |
  obj 1: STR len 20
     0: 64656620 62617228 293A2072 65747572 |def bar(): retur|
    16: 6E203430                            |n 40            |
  raw 2: 'ten' in 'src/features.py'
    bytecode len 11 scope 0 args 0 obj 0 raw 0
       0: 000EB400 A700801E 008A63            |..........c     |
[...]
  raw 12: 'u49' in 'src/features.py'
    bytecode len 12 scope 0 args 0 obj 0 raw 0
       0: 000EC600 A70080C9 00223163          |........."1c    |
```

Known issues:

* not every bit of information in a frozen module is decoded and printed

-jcw, 2020-06-10
