#include <stdio.h>
#include <strings.h>

extern "C" {
#include "py/mpconfig.h"
extern const mp_obj_type_t mp_type_str = {0};
extern const qstr_pool_t mp_qstr_const_pool = {0};

extern const qstr_pool_t mp_qstr_frozen_const_pool;
extern const char mp_frozen_mpy_names[];
extern const mp_raw_code_t *const mp_frozen_mpy_content[];
}

FILE* ofp;

void emitVarInt (uint32_t v, uint32_t flag =0) {
    if (v > 0x7F)
        emitVarInt(v >> 7, 0x80);
    putc((v & 0x7F) | flag, ofp);
}

void emitStr (const char* s) {
    fwrite(s, 1, strlen(s) + 1, ofp);
}

void emitBytes (const void* p, size_t n) {
    emitVarInt(n);
    fwrite(p, 1, n, ofp);
}

// adapted from dumper/src/main.cpp
struct Prelude {
    uint32_t n_state;
    uint32_t n_exc_stack;
    uint32_t scope_flags;
    uint32_t n_pos_args;
    uint32_t n_kwonly_args;
    uint32_t n_def_pos_args;
    size_t n_info;
    size_t n_cell;

    int load (const uint8_t*& ip) {
        uint8_t z = *ip++; /* xSSSSEAA */
        n_state = (z >> 3) & 0xf;
        n_exc_stack = (z >> 2) & 0x1;
        scope_flags = 0;
        n_pos_args = z & 0x3;
        n_kwonly_args = 0;
        n_def_pos_args = 0;
        for (int n = 0; z & 0x80; ++n) {
            z = *ip++; /* xFSSKAED */
            n_state |= (z & 0x30) << (2 * n);
            n_exc_stack |= (z & 0x02) << n;
            scope_flags |= ((z & 0x40) >> 6) << n;
            n_pos_args |= (z & 0x4) << n;
            n_kwonly_args |= ((z & 0x08) >> 3) << n;
            n_def_pos_args |= (z & 0x1) << n;
        }
        n_state += 1;
        //printf("n_state        %d\n", n_state       );
        //printf("n_exc_stack    %d\n", n_exc_stack   );
        //printf("scope_flags    %d\n", scope_flags   );
        //printf("n_pos_args     %d\n", n_pos_args    );
        //printf("n_kwonly_args  %d\n", n_kwonly_args );
        //printf("n_def_pos_args %d\n", n_def_pos_args);

        n_info = 0;
        n_cell = 0;
        z = 0x80;
        for (int n = 0; z & 0x80; ++n) {
            z = *ip++; /* xIIIIIIC */
            n_cell |= (z & 1) << n;
            n_info |= ((z & 0x7e) >> 1) << (6 * n);
        }
        //printf("n_info         %d\n", n_info);
        //printf("n_cell         %d\n", n_cell);
        return n_info + n_cell;
    }
} prelude;

void dumpHex (const uint8_t* ptr, size_t len, int indent =0) {
    for (size_t i = 0; i < len; i += 16) {
        printf("%*s  %4zu:", indent, "", i);
        for (int j = 0; j < 16; ++j) {
            if (j % 4 == 0)
                printf(" ");
            if (i + j < len)
                printf("%02X", ptr[i+j]);
            else
                printf("  ");
        }
        printf(" |");
        for (int j = 0; j < 16; ++j) {
            if (i + j < len) {
                uint8_t b = ptr[i+j];
                printf("%c", ' ' <= b && b <= '~' ? b : '.');
            } else
                printf(" ");
        }
        printf("|\n");
    }
}

const char* getQstr(const uint8_t*& ip) {
    int n = *ip++;
    n |= (*ip++ << 8);
    auto& qPool = mp_qstr_frozen_const_pool;
    return n < qPool.len ? (const char*) qPool.qstrs[n] + 2 : 0;
}

void dumpRaw (const mp_raw_code_t& bc, int indent =0) {
    auto ip = (const uint8_t*) bc.fun_data;
    auto skip = prelude.load(ip);
    auto name = getQstr(ip);
    auto file = getQstr(ip);
    printf("'%s' in '%s'\n", name, file);
    ip = ip - 4;

    printf("%*s  bytecode len %zu scope %x args %d obj %d raw %d skip %d\n",
           indent, "", bc.fun_data_len, bc.scope_flags, bc.n_pos_args,
           bc.n_obj, bc.n_raw_code, skip);
    //dumpHex(ip, 16, indent);
    dumpHex((const uint8_t*) bc.fun_data, bc.fun_data_len, indent);

    emitVarInt(prelude.n_state);
    emitVarInt(prelude.n_exc_stack);
    emitVarInt(bc.scope_flags);
    emitVarInt(bc.n_pos_args);
    emitVarInt(prelude.n_kwonly_args);
    emitVarInt(prelude.n_def_pos_args);
    emitVarInt(skip);
    emitBytes(ip, bc.fun_data_len - (ip - (const uint8_t*) bc.fun_data));

    auto ctab = (const mp_rom_obj_t*) bc.const_table;

    emitVarInt(bc.n_obj);
    emitVarInt(bc.n_raw_code);

    for (int j = 0; j < bc.n_obj; ++j) {
        auto& obj = *(const mp_obj_str_t*) ctab[j].u32.lo;
        auto type = obj.base.type == &mp_type_str ? "STR" : " ? ";
        printf("%*s  obj %d: %s len %zu\n", indent, "", j, type, obj.len);
        dumpHex(obj.data, obj.len, indent);
        emitBytes(obj.data, obj.len+1); // trailing zero byte
    }

    for (int j = 0; j < bc.n_raw_code; ++j) {
        auto& raw = *(mp_raw_code_t*) ctab[j+bc.n_obj].u32.lo;
        printf("%*s  raw %d: ", indent, "", j + bc.n_obj);
        dumpRaw(raw, indent+2);
    }
}

int main () {
    ofp = fopen("dump.bin", "wb");
    if (ofp == 0) {
        perror("dump.bin");
        exit(1);
    }

    emitVarInt(123); // just to identify this format for now

    size_t modCount = 0, modLen = 0;
    for (const char* s = mp_frozen_mpy_names; *s != 0; s += strlen(s) + 1) {
        printf("module #%zu name: %s\n", modCount, s);
        ++modCount;
        modLen += strlen(s) + 1;
    }

    emitVarInt(modCount);
    emitBytes(mp_frozen_mpy_names, modLen);

    auto& qPool = mp_qstr_frozen_const_pool;
    // --qPool.len; TODO off by one mistake, maybe because qstrs are 1-based
    printf("qstr pool length: %zu\n", qPool.len);

    const auto qstrNext = 166; // fixed table entries, see ../toypy/src/qstr.h
    int qstrSkip = 0;

    int qBytes = 0;
    for (int i = 0; i < qPool.len-1; ++i) {
        auto s = (const char*) qPool.qstrs[i] + 2;
        auto n = strlen(s);
        if (i+1 >= qstrNext) {
            printf("  qstr #%d len %zu:\n", i+1, n);
            dumpHex((const uint8_t*) s, n, 2);
            if (qstrSkip == 0)
                qstrSkip = qBytes;
        }
        qBytes += n + 1;
    }
    printf("qstr pool bytes %d skip %d\n", qBytes, qstrSkip);

    emitVarInt(qPool.len - qstrNext);
    emitVarInt(qBytes - qstrSkip);
    for (int i = qstrNext; i < qPool.len; ++i) {
        auto s = (const char*) qPool.qstrs[i-1] + 2;
        emitStr(s);
    }

    auto& frozen = mp_frozen_mpy_content;
    for (int i = 0; i < modCount; ++i) {
        printf("\nmodule #%d: ", i);
        dumpRaw(*mp_frozen_mpy_content[i]);
    }

    fclose(ofp);
    return 0;
}
