#include <stdlib.h>

typedef uint8_t byte;
typedef intptr_t mp_int_t; // must be pointer size
typedef uintptr_t mp_uint_t; // must be pointer size

#define STATIC static

#define MICROPY_LONGINT_IMPL 2
#define MPZ_DIG_SIZE 16
#define MICROPY_PERSISTENT_CODE_SAVE 1


enum {
    MP_QSTRnumber_of, // no underscore so it can't clash with any of the above
};

typedef size_t qstr;

typedef struct _qstr_pool_t {
    struct _qstr_pool_t *prev;
    size_t total_prev_len;
    size_t alloc;
    size_t len;
    const byte *qstrs[];
} qstr_pool_t;

typedef struct _mp_raw_code_t {
    mp_uint_t kind : 3; // of type mp_raw_code_kind_t
    mp_uint_t scope_flags : 7;
    mp_uint_t n_pos_args : 11;
    const void *fun_data;
    const mp_uint_t *const_table;
    #if MICROPY_PERSISTENT_CODE_SAVE
    size_t fun_data_len;
    uint16_t n_obj;
    uint16_t n_raw_code;
    #if MICROPY_PY_SYS_SETTRACE
    mp_bytecode_prelude_t prelude;
    mp_uint_t line_of_definition;
    #endif
    #if MICROPY_EMIT_MACHINE_CODE
    uint16_t prelude_offset;
    uint16_t n_qstr;
    mp_qstr_link_entry_t *qstr_link;
    #endif
    #endif
    #if MICROPY_EMIT_MACHINE_CODE
    mp_uint_t type_sig; // for viper, compressed as 2-bit types; ret is MSB, then arg0, arg1, etc
    #endif
} mp_raw_code_t;

typedef enum {
    MP_CODE_UNUSED,
    MP_CODE_RESERVED,
    MP_CODE_BYTECODE,
    MP_CODE_NATIVE_PY,
    MP_CODE_NATIVE_VIPER,
    MP_CODE_NATIVE_ASM,
} mp_raw_code_kind_t;

typedef union _mp_rom_obj_t {
    uint64_t u64;
    struct { const void *lo, *hi; } u32;
} mp_rom_obj_t;

#define MP_OBJ_NEW_QSTR(qst) ((mp_obj_t)(uintptr_t)((((mp_uint_t)(qst)) << 3) | 2))
#define MP_ROM_QSTR(q) {MP_OBJ_NEW_QSTR(q)}
#define MP_ROM_PTR(p) {.u32 = {.lo = (p), .hi = NULL}}

typedef struct _mp_obj_type_t mp_obj_type_t;

#define MICROPY_OBJ_BASE_ALIGNMENT

struct _mp_obj_base_t {
    const mp_obj_type_t *type MICROPY_OBJ_BASE_ALIGNMENT;
};
typedef struct _mp_obj_base_t mp_obj_base_t;

typedef struct _mp_obj_str_t {
    mp_obj_base_t base;
    mp_uint_t hash;
    // len == number of bytes used in data, alloc = len + 1 because (at the moment) we also append a null byte
    size_t len;
    const byte *data;
} mp_obj_str_t;

typedef void (*mp_print_strn_t)(void *data, const char *str, size_t len);

typedef struct _mp_print_t {
    void *data;
    mp_print_strn_t print_strn;
} mp_print_t;

typedef enum {
    PRINT_STR = 0,
    PRINT_REPR = 1,
    PRINT_EXC = 2, // Special format for printing exception in unhandled exception message
    PRINT_JSON = 3,
    PRINT_RAW = 4, // Special format for printing bytes as an undercorated string
    PRINT_EXC_SUBCLASS = 0x80, // Internal flag for printing exception subclasses
} mp_print_kind_t;

typedef void *mp_obj_t;

typedef struct _mp_map_elem_t {
    mp_obj_t key;
    mp_obj_t value;
} mp_map_elem_t;

typedef struct _mp_rom_map_elem_t {
    mp_rom_obj_t key;
    mp_rom_obj_t value;
} mp_rom_map_elem_t;

typedef struct _mp_map_t {
    size_t all_keys_are_qstrs : 1;
    size_t is_fixed : 1;    // a fixed array that can't be modified; must also be ordered
    size_t is_ordered : 1;  // an ordered array
    size_t used : (8 * sizeof(size_t) - 3);
    size_t alloc;
    mp_map_elem_t *table;
} mp_map_t;

typedef struct _mp_buffer_info_t {
    void *buf;      // can be NULL if len == 0
    size_t len;     // in bytes
    int typecode;   // as per binary.h
} mp_buffer_info_t;

typedef struct _mp_buffer_p_t {
    mp_int_t (*get_buffer)(mp_obj_t obj, mp_buffer_info_t *bufinfo, mp_uint_t flags);
} mp_buffer_p_t;

typedef mp_obj_t (*mp_fun_0_t)(void);
typedef mp_obj_t (*mp_fun_1_t)(mp_obj_t);
typedef mp_obj_t (*mp_fun_2_t)(mp_obj_t, mp_obj_t);
typedef mp_obj_t (*mp_fun_3_t)(mp_obj_t, mp_obj_t, mp_obj_t);
typedef mp_obj_t (*mp_fun_var_t)(size_t n, const mp_obj_t *);
// mp_fun_kw_t takes mp_map_t* (and not const mp_map_t*) to ease passing
// this arg to mp_map_lookup().
typedef mp_obj_t (*mp_fun_kw_t)(size_t n, const mp_obj_t *, mp_map_t *);

typedef enum {
    // These ops may appear in the bytecode. Changing this group
    // in any way requires changing the bytecode version.
    MP_UNARY_OP_POSITIVE,
    MP_UNARY_OP_NEGATIVE,
    MP_UNARY_OP_INVERT,
    MP_UNARY_OP_NOT,

    // Following ops cannot appear in the bytecode
    MP_UNARY_OP_BOOL, // __bool__
    MP_UNARY_OP_LEN, // __len__
    MP_UNARY_OP_HASH, // __hash__; must return a small int
    MP_UNARY_OP_ABS, // __abs__
    MP_UNARY_OP_INT, // __int__
    MP_UNARY_OP_SIZEOF, // for sys.getsizeof()
} mp_unary_op_t;

typedef enum {
    // The following 9+13+13 ops are used in bytecode and changing
    // them requires changing the bytecode version.

    // 9 relational operations, should return a bool; order of first 6 matches corresponding mp_token_kind_t
    MP_BINARY_OP_LESS,
    MP_BINARY_OP_MORE,
    MP_BINARY_OP_EQUAL,
    MP_BINARY_OP_LESS_EQUAL,
    MP_BINARY_OP_MORE_EQUAL,
    MP_BINARY_OP_NOT_EQUAL,
    MP_BINARY_OP_IN,
    MP_BINARY_OP_IS,
    MP_BINARY_OP_EXCEPTION_MATCH,

    // 13 inplace arithmetic operations; order matches corresponding mp_token_kind_t
    MP_BINARY_OP_INPLACE_OR,
    MP_BINARY_OP_INPLACE_XOR,
    MP_BINARY_OP_INPLACE_AND,
    MP_BINARY_OP_INPLACE_LSHIFT,
    MP_BINARY_OP_INPLACE_RSHIFT,
    MP_BINARY_OP_INPLACE_ADD,
    MP_BINARY_OP_INPLACE_SUBTRACT,
    MP_BINARY_OP_INPLACE_MULTIPLY,
    MP_BINARY_OP_INPLACE_MAT_MULTIPLY,
    MP_BINARY_OP_INPLACE_FLOOR_DIVIDE,
    MP_BINARY_OP_INPLACE_TRUE_DIVIDE,
    MP_BINARY_OP_INPLACE_MODULO,
    MP_BINARY_OP_INPLACE_POWER,

    // 13 normal arithmetic operations; order matches corresponding mp_token_kind_t
    MP_BINARY_OP_OR,
    MP_BINARY_OP_XOR,
    MP_BINARY_OP_AND,
    MP_BINARY_OP_LSHIFT,
    MP_BINARY_OP_RSHIFT,
    MP_BINARY_OP_ADD,
    MP_BINARY_OP_SUBTRACT,
    MP_BINARY_OP_MULTIPLY,
    MP_BINARY_OP_MAT_MULTIPLY,
    MP_BINARY_OP_FLOOR_DIVIDE,
    MP_BINARY_OP_TRUE_DIVIDE,
    MP_BINARY_OP_MODULO,
    MP_BINARY_OP_POWER,

    // Operations below this line don't appear in bytecode, they
    // just identify special methods.

    // This is not emitted by the compiler but is supported by the runtime.
    // It must follow immediately after MP_BINARY_OP_POWER.
    MP_BINARY_OP_DIVMOD,

    // The runtime will convert MP_BINARY_OP_IN to this operator with swapped args.
    // A type should implement this containment operator instead of MP_BINARY_OP_IN.
    MP_BINARY_OP_CONTAINS,

    // 13 MP_BINARY_OP_REVERSE_* operations must be in the same order as MP_BINARY_OP_*,
    // and be the last ones supported by the runtime.
    MP_BINARY_OP_REVERSE_OR,
    MP_BINARY_OP_REVERSE_XOR,
    MP_BINARY_OP_REVERSE_AND,
    MP_BINARY_OP_REVERSE_LSHIFT,
    MP_BINARY_OP_REVERSE_RSHIFT,
    MP_BINARY_OP_REVERSE_ADD,
    MP_BINARY_OP_REVERSE_SUBTRACT,
    MP_BINARY_OP_REVERSE_MULTIPLY,
    MP_BINARY_OP_REVERSE_MAT_MULTIPLY,
    MP_BINARY_OP_REVERSE_FLOOR_DIVIDE,
    MP_BINARY_OP_REVERSE_TRUE_DIVIDE,
    MP_BINARY_OP_REVERSE_MODULO,
    MP_BINARY_OP_REVERSE_POWER,

    // These 2 are not supported by the runtime and must be synthesised by the emitter
    MP_BINARY_OP_NOT_IN,
    MP_BINARY_OP_IS_NOT,
} mp_binary_op_t;

typedef struct _mp_obj_iter_buf_t {
    mp_obj_base_t base;
    mp_obj_t buf[3];
} mp_obj_iter_buf_t;

typedef void (*mp_print_fun_t)(const mp_print_t *print, mp_obj_t o, mp_print_kind_t kind);
typedef mp_obj_t (*mp_make_new_fun_t)(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *args);
typedef mp_obj_t (*mp_call_fun_t)(mp_obj_t fun, size_t n_args, size_t n_kw, const mp_obj_t *args);
typedef mp_obj_t (*mp_unary_op_fun_t)(mp_unary_op_t op, mp_obj_t);
typedef mp_obj_t (*mp_binary_op_fun_t)(mp_binary_op_t op, mp_obj_t, mp_obj_t);
typedef void (*mp_attr_fun_t)(mp_obj_t self_in, qstr attr, mp_obj_t *dest);
typedef mp_obj_t (*mp_subscr_fun_t)(mp_obj_t self_in, mp_obj_t index, mp_obj_t value);
typedef mp_obj_t (*mp_getiter_fun_t)(mp_obj_t self_in, mp_obj_iter_buf_t *iter_buf);

struct _mp_obj_type_t {
    mp_obj_base_t base;
    uint16_t flags;
    uint16_t name;
    mp_print_fun_t print;
    mp_make_new_fun_t make_new;
    mp_call_fun_t call;
    mp_unary_op_fun_t unary_op;
    mp_binary_op_fun_t binary_op;
    mp_attr_fun_t attr;
    mp_subscr_fun_t subscr;
    mp_getiter_fun_t getiter;
    mp_fun_1_t iternext;
    mp_buffer_p_t buffer_p;
    const void *protocol;
    const void *parent;
    struct _mp_obj_dict_t *locals_dict;
};

extern const mp_obj_type_t mp_type_str;
