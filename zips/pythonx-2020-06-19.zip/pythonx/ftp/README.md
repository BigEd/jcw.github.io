This is a small ftp fileserver.

As with the `../mqtt` code, this version minimally depends on async/await.  
There are no "awaitable" methods, but the eventloop needs to be running,  
because tasks are created under the hood to trigger when a socket becomes  
readable. All other socket I/O is synchronous, this assumes a perfect network  
environment. A watchdog can be used to reset the system in case of hiccups.

Here is a sample session using "lftp", which supports tab-completion:

```text
$ lftp 127.0.0.1:2222
lftp 127.0.0.1:~> cd subdir/
cd ok, cwd=subdir
lftp 127.0.0.1:subdir> ls
-rw-r--r--          30  2020-06-05 15:30:23  b.txt
lftp 127.0.0.1:subdir> cat b.txt
Fri Jun  5 15:30:23 CEST 2020
30 bytes transferred
lftp 127.0.0.1:subdir> cd ..
lftp 127.0.0.1:~> ls
drwxr-xr-x           -  2020-06-05 15:30:23  subdir
-rw-r--r--          30  2020-06-05 15:30:11  a.txt
lftp 127.0.0.1:~> cat a.txt
Fri Jun  5 15:30:11 CEST 2020
30 bytes transferred
lftp 127.0.0.1:~>
```

Known issues:

* fairly decent commands set, but _absolutely no access protections!_
* disconnects sometimes lead to a (harmless) stack trace
* file serving will block, if the underlying file system is not async-aware

-jcw, 2020-06-05
