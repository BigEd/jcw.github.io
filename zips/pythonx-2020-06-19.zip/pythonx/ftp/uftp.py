# Minimal ftp file server. No path access restrictions whatsoever.

import os, socket, sys
import uasyncio.stream

#print = lambda *_: None    # uncomment this to disable debug output

async def recvTrigger(session):
    stream = uasyncio.stream.StreamReader(session.sock)
    while True:
        await stream.read(0)
        if session.request() is True:
            break

async def acceptTrigger(server):
    stream = uasyncio.stream.StreamReader(server.listener)
    while True:
        await stream.read(0)
        uasyncio.create_task(recvTrigger(server.connect()))

# no async/await use beyond this point

class Server:
    root = './'

    def listen(self, iface, port):
        self.data = port - 1

        l = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        l.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        l.bind(socket.getaddrinfo(iface, port)[0][-1])
        l.listen(5)
        self.listener = l

        r = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        r.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        r.bind(socket.getaddrinfo(iface, self.data)[0][-1])
        r.listen(5)
        self.receiver = r

        uasyncio.create_task(acceptTrigger(self))

    def connect(self):
        return Session(self, *self.listener.accept())

class Session:
    def __init__(self, server, sess, addr):
        self.cwd = '.'
        self.server = server
        self.sock = sess
        #self.addr = addr # unused
        self.reply('220 Howdy.')

    def request(self):
        line = self.sock.readline().rstrip()
        if not line:
            return True
        cmd, *arg = line.decode().split(None, 1)
        print('req',cmd,arg)
        try:
            handler = getattr(self, cmd.upper())
            r = handler(*arg)
            if type(r) is int:
                r = '%d OK' % r
            if type(r) is str:
                self.reply(r)
            else:
                return r
        except OSError as e:
            self.reply('550 %s' % e)
        except AttributeError as e:
            print('cmd?',e)
            self.reply('500 No such command.')
        except Exception as e:
            sys.print_exception(e)

    def dataSession(self):
        return self.server.receiver.accept()[0]

    def reply(self, *msgs):
        for msg in msgs:
            print('rpy',msg)
            self.sock.write(msg + '\r\n')

    def path(self, name=''):
        # TODO needs better cleaning and access-limiting
        return (self.server.root + self.cwd + '/' + name).lstrip('./')

    def FEAT(self):
        self.reply('211-Features:', ' SIZE', '211 END')

    def USER(self, name):
        return 230

    def CWD(self, path=''):
        self.cwd = path
        return 250

    def PWD(self):
        return '257 "%s"' % self.cwd

    def PASV(self):
        d = self.server.data
        return '227 Passive Mode (0,0,0,0,%d,%d)' % (d >> 8, d & 0xFF)

    def LIST(self, name=''):
        # for formatting, see see https://cr.yp.to/ftp/list/eplf.html
        self.reply('150 List')
        conn = self.dataSession()
        try:
            for fnam, mode, *_ in os.ilistdir(self.path(name)):
                if fnam[0] != '.':
                    s = os.stat(self.path(name + '/' + fnam))
                    if mode & 0x4000:
                        conn.write('+/,m%d,\t%s\r\n' % (s[8], fnam))
                    elif mode & 0x8000:
                        conn.write('+r,m%d,s%d,\t%s\r\n' % (s[8], s[6], fnam))
            return 226
        finally:
            conn.close()

    def SIZE(self, name):
        s = os.stat(self.path(name))
        return '213 %d' % s[6]

    def RETR(self, name):
        conn = self.dataSession()
        try:
            with open(self.path(name), 'rb') as f:
                self.reply('150 Retrieve')
                while True:
                    data = f.read(1024)
                    if not data:
                        return 226
                    conn.write(data)
        finally:
            conn.close()

    def STOR(self, name):
        conn = self.dataSession()
        try:
            with open(self.path(name), 'wb') as f:
                self.reply('150 Store')
                while True:
                    data = conn.read(1024)
                    if not data:
                        return 226
                    f.write(data)
        finally:
            conn.close()

    def SYST(self):
        return '215 UNIX Type: L8'

    def TYPE(self, arg):
        return 200

    def MKD(self, name):
        os.mkdir(self.path(name))
        return '250 "%s"' % (self.cwd + '/' + name)

    def RMD(self, name):
        os.rmdir(self.path(name))
        return 250

    def DELE(self, name):
        os.remove(self.path(name))
        return 250

    def RNFR(self, name):
        self.rnfr = self.path(name)
        os.stat(self.rnfr) # check for presence
        return 350

    def RNTO(self, name):
        os.rename(self.rnfr, self.path(name))
        return 250

    def QUIT(self):
        self.reply('221 Bye!')
        self.sock.close()
        return True
