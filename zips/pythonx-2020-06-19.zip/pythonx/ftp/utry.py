#!/usr/bin/env micropython

import uasyncio, uftp

async def main():
    server = uftp.Server()
    server.root = 'demo/'
    server.listen('0.0.0.0', 2222)

    for n in range(60):
        print('zzz', n)
        await uasyncio.sleep(60)

uasyncio.run(main())
