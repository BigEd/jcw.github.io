This is a small webserver with static-file and websocket support.

As with the `../mqtt` code, this version minimally depends on async/await.  
There are no "awaitable" methods, but the eventloop needs to be running,  
because tasks are created under the hood to trigger when a socket becomes  
readable. All other socket I/O is synchronous, this assumes a perfect network  
environment. A watchdog can be used to reset the system in case of hiccups.

Sample output, with some test files from another project:

```text
$ ./utry.py
zzz 0
GET /index.html 306b
GET /global.css 962b
GET /build/bundle.css 1787b
GET /build/bundle.js 27681b
GET /favicon.ico 5430b
zzz 1
zzz 2
GET /index.html 306b
zzz 3
zzz 4
```

Known issues:

* closed websockets require dealing with b'\x03' bytes, no idea why
* there is an awful hack in the code to define websocket message boundaries
* file serving will block, if the underlying file system is not async-aware

-jcw, 2020-05-28
