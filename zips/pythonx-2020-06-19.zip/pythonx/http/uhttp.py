# Minimal web server for static files, and with websocket support.

import socket, websocket, websocket_helper
import uasyncio.stream

async def recvTrigger(session):
    stream = uasyncio.stream.StreamReader(session.sock)
    await stream.read(0)
    if session.request():
        while session.message(await stream.read(0)):
            pass

async def acceptTrigger(server):
    stream = uasyncio.stream.StreamReader(server.listener)
    while True:
        await stream.read(0)
        uasyncio.create_task(recvTrigger(server.connect()))

# no async/await use beyond this point

class Server:
    onRequest = print
    onMessage = print

    mimeMap = {
        'html': 'text/html',
        'css':  'text/css',
        'js':   'text/javascript',
        'txt':  'text/plain',
        'json': 'application/json',
        'map':  'application/json',
        'png':  'image/png',
        'jpg':  'image/jpeg',
        'svg':  'image/svg+xml',
    }

    def listen(self, iface, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(socket.getaddrinfo(iface, port)[0][-1])
        s.listen(5)
        self.listener = s
        uasyncio.create_task(acceptTrigger(self))

    def connect(self):
        return Session(self, *self.listener.accept())

class Session:
    def __init__(self, server, sess, addr):
        self.server = server
        self.sock = sess
        #self.addr = addr # unused

    def request(self):
        method, path, proto = self.sock.readline().rstrip().decode().split()
        hdrs = {}
        while True:
            line = self.sock.readline().rstrip().decode()
            if line == '':
                break
            if line == 'Upgrade: websocket':
                websocket_helper.server_handshake(self.sock)
                self.sock = websocket.websocket(self.sock)
                return True
            k, v = line.split(':', 1)
            k = k.strip().lower().replace('-', '_')
            try:
                v = int(v)
            except ValueError:
                v = v.strip()
            hdrs[k] = v # TODO doesn't handle repeated headers
        if callable(self.server.onRequest):
            self.server.onRequest(method, path, proto, hdrs, self)
        else:
            if path.endswith('/'):
                path += 'index.html'
            stat = self.sendFile(self.server.onRequest + path.lstrip('./'))
            print(method, path, stat)
        self.sock.close()

    def sendFile(self, path):
        try:
            with open(path, 'rb') as f:
                try:
                    ext = path.rsplit('.', 1)[1].lower()
                    hdr = 'content-type: ' + self.server.mimeMap[ext] + '\r\n'
                except:
                    hdr = ''
                self.sock.write('HTTP/1.0 200 Ok\r\n' + hdr + '\r\n')
                n = 0
                for data in f:
                    self.sock.write(data)
                    n += len(data)
                return '%db' % n
        except Exception as e:
            self.sock.write('HTTP/1.0 404 Not found\r\n\r\n')
            return e

    def message(self, data):
        while True:
            more = self.sock.read(1)
            if not more or more == b'\x03':
                break # TODO huh? (b'' in Safari, b'\x03' in Chrome)
            data += more
            if more == b']': # FIXME hack!
                break
        if data:
            return self.server.onMessage(data, self.sock)
        self.sock.close()
