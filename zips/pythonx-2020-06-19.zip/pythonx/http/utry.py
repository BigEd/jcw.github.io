#!/usr/bin/env micropython

import uasyncio, uhttp

def msgHandler(msg, reply):
    print('msg', msg)
    reply.write(b'["G",0,"number 123",{}]')
    return True

async def main():
    server = uhttp.Server()
    # send files if onRequest is not a callable function
    server.onRequest = 'public/'
    server.onMessage = msgHandler
    server.listen('0.0.0.0', 1111)

    for n in range(5):
        print('zzz', n)
        await uasyncio.sleep(3)

uasyncio.run(main())
