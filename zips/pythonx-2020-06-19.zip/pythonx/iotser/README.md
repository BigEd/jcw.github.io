This small utility ties a µPy board's serial port to MQTT. Or any other board.

Messages from `test/iotser/cmd` are copied to the serial port (with added  
carriage returns) and lines received from the serial port are published to  
`test/iotser/reply` (without line terminators).

This runs as Python3 script (and uses pySerial):

```text
$ ./iotser.py -h
usage: iotser.py [-h] [-b BAUD] [-c TOPIC] [-r TOPIC] [-s ADDR] port

positional arguments:
  port        serial port, e.g. /dev/tty...

optional arguments:
  -h, --help  show this help message and exit
  -b BAUD     serial baud rate (115200)
  -c TOPIC    used for commands to serial (test/iotser/cmd)
  -r TOPIC    used for replies from serial (test/iotser/reply)
  -s ADDR     MQTT server to use, i.e. broker (127.0.0.1)
```

To try this out, start an MQTT listener in a separate window:

    $ mosquitto_sub -t test/iotser/reply

Then (with a PyBoard attached), start this utility:

    $ ./iotser.py /dev/cu.usbmodem3550316C30372

As test, let's send a command to the board:

    $ mosquitto_pub -t test/iotser/cmd -m 'dir()'

The output in the `mosquitto_sub` window should then look something like:

```text
MicroPython v1.12-464-gcae77daf0-dirty on 2020-05-23; PYBD-SF2W with STM32F722IEK
Type "help()" for more information.
>>> dir()
['machine', '__name__', 'pyb', 'nic', 'network']
```

Known issues:

* only transfers complete lines, µPy's `>>>` prompt shows _after_ the next
  command has been sent
* serial input is obtained by polling once every 50 ms
* this uses `../mqtt/xmqtt.py`, which is in its infancy and may throw a fit

-jcw, 2020-05-27
