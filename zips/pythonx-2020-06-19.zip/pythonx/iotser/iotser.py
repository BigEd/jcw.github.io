#!/usr/bin/env python3

import argparse, serial, sys
sys.path.append('../mqtt')

import xmqtt as mqtt
import asyncio

ap = argparse.ArgumentParser()
ap.add_argument('port',
                help='serial port, e.g. /dev/tty...')
ap.add_argument('-b', metavar='BAUD', type=int, default=115200,
                help='serial baud rate (115200)')
ap.add_argument('-c', metavar='TOPIC', default='test/iotser/cmd',
                help='used for commands to serial (test/iotser/cmd)')
ap.add_argument('-r', metavar='TOPIC', default='test/iotser/reply',
                help='used for replies from serial (test/iotser/reply)')
ap.add_argument('-s', metavar='ADDR', default='127.0.0.1',
                help='MQTT server to use, i.e. broker (127.0.0.1)')
args = ap.parse_args()

ser = serial.Serial(args.port, baudrate=args.b)

def onReceive(msg):
    ser.write(msg.payload + b'\r')

async def recvTrigger(conn):
    stream = asyncio.StreamReader()
    proto = asyncio.StreamReaderProtocol(stream)
    loop = asyncio.get_event_loop()
    await loop.create_connection(lambda: proto, sock=conn.sock)
    stream._transport.max_size = 1
    while True:
        conn.process(await stream.read(1))

async def main():
    conn = mqtt.Client()
    conn.onMessage = onReceive
    conn.connect(args.s)

    asyncio.create_task(recvTrigger(conn))

    conn.subscribe(args.c)

    # use polling, PySerial's asyncio interface is just too painful to use
    ser.timeout = 0

    data = b''
    while True:
        more = ser.read(1000)
        if more:
            data += more
            lines = data.splitlines()
            data = lines.pop()
            for msg in lines:
                conn.publish(args.r, msg)
        else:
            await asyncio.sleep(0.05) # rinse and repeat every 50 ms

asyncio.run(main())
