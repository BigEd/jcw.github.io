This is a minimal implementation of an MQTT client.

Main purpose of this exploration is to come up with a version which is fully  
synchronous, yet can be used in an async/await manner. See the `ctry.py` (CPy3)  
and `utry.py` (µPy) examples. Tested on macOS and on a PyBoard-D SF2.

The main idea is that everything blocks, _except_ the reading of the first byte  
of each message received on a socket. This assumes a perfect network world, i.e.  
no major hiccups, no hangs, no loss of connectivity. For those cases, a hardware  
watchdog can be used to recover - with each restart dealing with network health  
issues, etc.

Note that only the "main" scripts use async/await, there are none in `xmqtt.py`.

Sample output (the poll/onReceive msgs have now been commented out, see source):
```text
$ ./utry.py
SUBACK b'\x90\x03\x00\x01\x00'
publish 0
poll 0x31 28 28 b'\x00\x0btest/mymqttHello World #7!'
onReceive test/mymqtt b'Hello World #7!' True
poll 0x30 20 20 b'\x00\x0btest/mymqtthello 0'
onReceive test/mymqtt b'hello 0' False
publish 1
poll 0x30 20 20 b'\x00\x0btest/mymqtthello 1'
onReceive test/mymqtt b'hello 1' False
publish 2
poll 0x30 20 20 b'\x00\x0btest/mymqtthello 2'
onReceive test/mymqtt b'hello 2' False
publish 3
poll 0x30 20 20 b'\x00\x0btest/mymqtthello 3'
onReceive test/mymqtt b'hello 3' False
publish 4
poll 0x30 20 20 b'\x00\x0btest/mymqtthello 4'
onReceive test/mymqtt b'hello 4' False
$
```

Known issues:

* it's minimal, which is also why it's so little code: only QoS 0, no SLL, no
  error handling
* something chokes when subscribing to '#" and receiving a dozen messages on
  connect - not sure what's going on here
* in PybD, every second run fails - it looks like it depends on whether WiFi
  setup just completed or was resumed from the last soft restart

-jcw, 2020-05-27
