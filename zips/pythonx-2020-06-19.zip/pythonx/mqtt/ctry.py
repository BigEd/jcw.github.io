#!/usr/bin/env python3

import xmqtt as mqtt
import asyncio

host  = '192.168.188.82'
topic = 'test/mymqtt'
#topic = '#'

def onReceive(msg):
    print('onReceive', msg.topic, msg.payload, msg.retain)

async def recvTrigger(conn):
    stream = asyncio.StreamReader()
    proto = asyncio.StreamReaderProtocol(stream)
    loop = asyncio.get_event_loop()
    await loop.create_connection(lambda: proto, sock=conn.sock)
    stream._transport.max_size = 1
    while True:
        conn.process(await stream.read(1))

async def main():
    conn = mqtt.Client()
    conn.onMessage = onReceive
    conn.connect(host)

    asyncio.create_task(recvTrigger(conn))

    conn.subscribe(topic)

    for n in range(5):
        print('publish', n)
        conn.publish(topic, 'hello %d' % n)
        await asyncio.sleep(3)

asyncio.run(main())
