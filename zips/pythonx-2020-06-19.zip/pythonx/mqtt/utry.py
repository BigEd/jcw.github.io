#!/usr/bin/env micropython

import xmqtt as mqtt
import uasyncio as asyncio
import uasyncio.stream

host  = '192.168.188.82'
topic = 'test/mymqtt'
#topic = '#'

def onReceive(msg):
    print('onReceive', msg.topic, msg.payload, msg.retain)

async def recvTrigger(conn):
    stream = asyncio.stream.StreamReader(conn.sock)
    while True:
        conn.process(await stream.read(0))

async def main():
    conn = mqtt.Client()
    conn.onMessage = onReceive
    conn.connect(host)

    asyncio.create_task(recvTrigger(conn))

    conn.subscribe(topic)

    for n in range(5):
        print('publish', n)
        conn.publish(topic, 'hello %d' % n)
        await asyncio.sleep(3)

asyncio.run(main())
