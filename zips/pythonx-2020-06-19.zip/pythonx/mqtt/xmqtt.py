# Minimal MQTT client without async/await, QoS 0 only, no SSL, bugs remain.

import socket

clientId = b'12345'

class Message:
    qos = 0
    dup = False
    retain = False

    def __init__(self, topic, payload):
        if isinstance(topic, bytes):
            topic = topic.decode()
        self.topic = topic
        self.payload = payload

class Client:
    onMessage = print
    pktId = 0

    def connect(self, host):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(socket.getaddrinfo(host, 1883)[0][-1])
        self.sock = s

        self.header(0x10, 10 + 2 + len(clientId))
        self.data += b'\0\4MQTT\4\2\0\0'
        self.addStr(clientId)

        s.send(self.data)

        if s.recv(128) != b'\x20\2\0\0':
            raise 'no CONNACK'

    def publish(self, topic, payload):
        if isinstance(topic, str):
            topic = topic.encode()
        if isinstance(payload, str):
            payload = payload.encode()

        self.header(0x30, 2 + len(topic) + len(payload))
        self.addStr(topic)

        self.sock.send(self.data)
        self.sock.send(payload)

    def subscribe(self, topic):
        if isinstance(topic, str):
            topic = topic.encode()

        self.pktId += 1

        self.header(0x82, 2 + 2 + len(topic) + 1)
        self.addShort(self.pktId)
        self.addStr(topic)
        self.data.append(0)

        self.sock.send(self.data)

        reply = self.sock.recv(128)
        #print('SUBACK', reply)

    def process(self, data=b''):
        hdr, cnt = self.recvHdr(data)
        data = self.sock.recv(cnt)
        #print('poll 0x%x' % hdr, cnt, len(data), data)
        if (hdr & 0xF0) == 0x30:
            tcnt = (data[0] << 8) + data[1]
            msg = Message(data[2:2+tcnt], data[2+tcnt:])
            msg.dup = (hdr & 0x08) != 0
            msg.retain = (hdr & 0x01) != 0
            msg.qos = (hdr & 0x06) >> 1
            self.onMessage(msg)
        else:
            print('recv? 0x%x' % hdr, cnt)

    def recvHdr(self, data):
        hdr = data[0] if data else self.sock.recv(1)[0]
        cnt, pos, val = (0, 0, 0x80)
        while val & 0x80:
            val = self.sock.recv(1)[0]
            cnt |= (val & 0x7F) << pos
            pos += 7
        return hdr, cnt

    def header(self, t, v):
        self.data = bytearray([t])
        while v > 0x7F:
            self.data.append(v & 0x7F | 0x80)
            v >>= 7
        self.data.append(v)

    def addShort(self, n):
        self.data.append(n >> 8)
        self.data.append(n)

    def addStr(self, s):
        self.addShort(len(s))
        self.data += s
