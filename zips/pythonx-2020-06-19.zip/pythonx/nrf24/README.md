This is a demo of stream-based communication using the nRF24L01+ radio modules.

![](setup.jpeg)

It's all based on Peter Hinch's asyncio-based streaming driver:
: <https://github.com/peterhinch/micropython-radio>

The core driver for this radio module is part of MicroPython:
: <https://github.com/micropython/micropython/tree/master/drivers/nrf24l01>

Some more information about the nRF24L01+ module:
: <https://lastminuteengineers.com/nrf24l01-arduino-wireless-communication/>

Hardware-wise, I'm using "Black F407" boards (AliExpress) and 2x nRF24L01+.  
The MicroPython builds use Mike Causer's excellent configuration and docs:

* the smaller board is <https://github.com/mcauser/BLACK_F407VE>
* the larger board is <https://github.com/mcauser/BLACK_F407ZG>

They have slightly different specs and pinouts, but Mike's custom MicroPython  
builds work out of the box, the process is well-documented in the README's.  
Included in this repository are the µPy `.dfu` firmware images I built & used.  
They have their SPI flash chips _disabled_ to avoid clashing with the radios.  
The respective startup greetings with version info are as follows:

* MicroPython v1.12-510-g1e6d18c91-dirty on 2020-06-07;  
  MCUDEV STM32F407VE with STM32F407VE
* MicroPython v1.12-510-g1e6d18c91-dirty on 2020-06-07;  
  MCUDEV STM32F407ZG with STM32F407ZG

Both boards have sockets for the nRF24L01+ modules, which is most convenient.  
Pinouts and connections can be found in the README's of the repositories above.

The boards are configured in two different roles. See the `board.py` file,  
which detects boards by their unique CPUID (adjust as needed for each case).

## Smoke testing

As a first test, there's the `uping.py` script, which needs to be launched on  
both boards. Also needed are `nrf24l01.py` and the (adjusted) `board.py`.  
Once set up, entering `import uping` on both boards should generate output:

```text
>>> import uping
send 0
        received b'msg # 03'
send 1
        received b'msg # 04'
send 2
        received b'msg # 05'
[etc]
```

The first board to start won't receive anything until the other end is up.  
Note also that packets may get lost (e.g. whenever the tranmissions clash).

There's no point trying anything else as long as this doesn't work correctly.

## Simple ASYNC

Peter Hinch's asyncio-based streaming implementation needs no other setup,  
once the above works. There is a custom `asconfig.py`, which re-uses the  
`board.py` settings to tie into his configuration mechanism.

The only step is to copy all the scripts to both boards. There's a `Makefile`  
which helps with this, as follows:

```sh
$ make DEST=/Volumes/F407VE/
cp -aL *.py /Volumes/F407VE/
$ make DEST=/Volumes/F407ZG/
cp -aL *.py /Volumes/F407ZG/
$
```

This is on MacOS, elsewhere the paths of the mounted USB drives will differ.

Then, one board can be launched up as master:

```text
>>> import as_nrf_simple
Test script for as_nrf_stream driver for nRF24l01 radios.
On master issue
as_nrf_simple.test(True)
On slave issue
as_nrf_simple.test(False)

>>> as_nrf_simple.test(True)
Received: b'Hello receiver\n'
Received: b'Hello receiver\n'
Received: b'Hello receiver\n'
[etc]
```

And the other as slave:

```text
>>> import as_nrf_simple
[...]
>>> as_nrf_simple.test(False)
Received: b'Hello receiver\n'
[...]
```

## More elaborate ASYNC

Peter's code also includes an `as_nrf_test.py` script, which sends packets of  
increasing length, and reports some statistics every once in a while.

Everything should already be in place after the steps described so far:

```text
>>> import as_nrf_test
Test script for as_nrf_stream driver for nRF24l01 radios.
On master issue
as_nrf_test.test(True)
On slave issue
as_nrf_test.test(False)

>>> as_nrf_test.test(True)
Received record no:     0 text:
Received record no:     1 text: a
Received record no:     2 text: ab
Received record no:     3 text: abc
[...]
Received record no:    19 text: abcdefghijklmnopqrs
Missed record count:   0 (local)   0 (remote).
Uptime:    0.01hrs Outages:   0
Remote statistics. Timeouts: RX 0 TX 0 Received packets: All 26 Non-duplicate data 26
Local statistics. Timeouts: RX 2 TX 0 Received packets: All 33 Non-duplicate data 33
Received record no:    20 text: abcdefghijklmnopqrst
[...]
```

With the same code on the other board, using `as_nrf_test.test(False)`.  
The output is essentially the same, but since the slave was started first, it  
will detect and report the initially-failing connection, and recover from it:

```text
>>> as_nrf_test.test(False)
Remote outage
Received record no:     0 text:
Remote has reconnected
Received record no:     1 text: a
Received record no:     2 text: ab
Received record no:     3 text: abc
[...]
```

So all in all, a really nice example of how to implement a robust streaming  
connection between two nodes, using unreliable radio communication based on  
packets of at most 32 bytes. With MicroPython's "uasyncio" module to make  
it all happen in the background, allowing the app to perform other tasks.

Known issues:

* The `radio` code needs a minor tweak to work with the modules I use:

    ```text
    $ git diff
    diff --git a/async/as_nrf_stream.py b/async/as_nrf_stream.py
    index a12794a..4062457 100644
    --- a/async/as_nrf_stream.py
    +++ b/async/as_nrf_stream.py
    @@ -107,6 +107,7 @@ class AS_NRF24L01(io.IOBase):

             self._tx_ms = config.tx_ms  # Max time master or slave can transmit
             radio = NRF24L01(config.spi, config.csn, config.ce, config.channel, 32)
    +        radio.set_power_speed(0x06, 0x08)
             radio.open_tx_pipe(self.pipes[master ^ 1])
             radio.open_rx_pipe(1, self.pipes[master])
             self._radio = radio
    $
    ```

-jcw, 2020-06-07
