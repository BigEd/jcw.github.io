# Config data for your hardware: adapt as required.
from machine import SPI, Pin
# config file instantiates a RadioSetup for each end of the link
class RadioSetup:  # Configuration for an nRF24L01 radio
    channel = 97  # Necessarily shared by both instances
    tx_ms = 200  # Max ms either end waits for successful transmission

    def __init__(self, spi, csn, ce, stats=False):
        self.spi = spi
        self.csn = csn
        self.ce = ce
        self.stats = stats

# the board file will pick the right settings for each board
from board import *

# Note: gathering statistics. as_nrf_test will display them.
config = RadioSetup(nrf_spi, nrf_cs, nrf_ce, True)  # Black F407 VE/ZG
config_master = config
config_slave = config
