# Detect the board and match hardware configuration accordingly.

import machine

if machine.unique_id() == b'+\x00(\x00\x11G647147': # my F407VE board
    role = 1
    nrf_ce = machine.Pin('B6')
    nrf_cs = machine.Pin('B7')
    nrf_irq = machine.Pin('B8') # unused
    nrf_spi = machine.SPI(3)

if machine.unique_id() == b'*\x00=\x00\x15PN3K59 ': # my F407ZG board
    role = 2
    nrf_ce = machine.Pin('G6')
    nrf_cs = machine.Pin('G7')
    nrf_irq = machine.Pin('G8') # unused
    nrf_spi = machine.SPI(3)
