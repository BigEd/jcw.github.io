# Radio ping test, this needs to run on two boards to make any sense.

import nrf24l01, time
from board import *

addr1 = b"\xE1\xF0\xF0\xF0\xF0" # little-endian, i.e. 0xF0F0F0F0E1
addr2 = b"\xD2\xF0\xF0\xF0\xF0" # little-endian, i.e. 0xF0F0F0F0D2

nrf = nrf24l01.NRF24L01(nrf_spi, nrf_cs, nrf_ce, payload_size=8)

# reduce power for better reception at close range, and bump the speed as well
nrf.set_power_speed(nrf24l01.POWER_1, nrf24l01.SPEED_2M)

if role == 1:
    nrf.open_tx_pipe(addr1)
    nrf.open_rx_pipe(1, addr2)

if role == 2:
    nrf.open_tx_pipe(addr2)
    nrf.open_rx_pipe(1, addr1)

for i in range(100):
    print('send', i)
    try:
        msg = b'msg # %02d' % i
        nrf.send(msg)
    except OSError:
        pass

    nrf.start_listening()
    for _ in range(100):
        if nrf.any():
            msg = nrf.recv()
            print('\treceived', msg)
        time.sleep_ms(10)
    nrf.stop_listening()
