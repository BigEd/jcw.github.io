This is a MicroPython driver for the Si5351 frequency synthesiser chip.

![](board.jpeg)

In this case, it's attached to a BLACK-F407VE board from AliExpress. There is  
a well-documented MicroPython build repository for this board, by Mike Causer:

* <https://github.com/mcauser/BLACK_F407VE>

The PDF datasheet for this chip is available from Silicon Labs:

* <https://www.silabs.com/documents/public/data-sheets/Si5351-B.pdf>

The connector pinout for this module is as follows, top to bottom:

* GND
* SCL - connected to PE2
* SDA - connected to PE4
* +5V
* GND (not connected)

The jumper is set to 3.3V I2C operation (not 5V), the crystal is 27 MHz.  
There are three independent clock outputs (0..2, left to right).  
The outputs are CMOS, i.e. essentially full 0 .. 3.3V swing.  
The chip is capable of generating 2.5 kHz to 200 MHz square waves.

That makes it a fun chip to play with: e.g. for driving logic circuits, or  
pushing microcontrollers past their rated specs, or even for amateur radio  
related experiments, if you're into that sort of thing (and are careful).

The driver is in `si5351.py` and a small demo in `utry.py` - sample output:

```text
>>> import utry
a 22 : 2 / 9 = 0.2222222 m 22.22222 f 600000000
a 33 : 1 / 3 = 0.3333333 m 33.33333 f 899999936
o 0 f 1234567 a 486 b 65 c 183212 d 486.0003
o 1 f 12345678 a 48 b 391451 c 652414 d 48.6
o 2 f 34567892 a 26 b 193 c 5403 d 26.03572
>>>
```

There's some interesting code in the driver to find the best divider ratios.

Known issues:

* not well-tested yet, I'm not convinced the calcuations are always right
* the output divisor is not yet properly constrained to 4/6/8..2048
* there's no way to disable outputs again, other than a total re-init

-jcw, 2020-06-09
