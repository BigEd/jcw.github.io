# Driver for the Si5351 frequency synthesiser chip.
#
# see https://www.silabs.com/documents/public/data-sheets/Si5351-B.pdf
# and https://www.silabs.com/documents/public/application-notes/AN619.pdf

#print = lambda *_: None    # uncomment this to disable debug output

class Si5351:
    xtal = 27000000

    def __init__(self, i2c, addr=0x60):
        self.i2c = i2c
        self.addr = addr
        self.vco = [0, 0]
        i2c.writeto_mem(addr, 3, b'\xFF')    # turn off all outputs
        i2c.writeto_mem(addr, 16, 8*b'\x80') # power down all output drivers
        #i2c.writeto_mem(addr, 183, b'\xD2')  # select 10 pF load (default)

    def setPLL(self, pll, freq):
        a = freq // self.xtal
        b, c = bestFraction(freq - self.xtal * a, self.xtal)
        if b == 0 and a%2 == 0:
            self.i2c.writeto_mem(self.addr, 22+pll, b'\x40')
        m = a+b/c
        f = self.xtal * m
        self.vco[pll] = int(f+0.5)
        self.i2c.writeto_mem(self.addr, 26+8*pll, packRegs(a, b, c))
        print('a',a,':',b,'/',c,'=',b/c,'m',m,'f',int(f))

    def setFreq(self, out, pll, freq):
        vco = self.vco[pll]
        a = vco // freq
        b, c = bestFraction(vco - freq * a, freq)
        r = 0
        d = a+b/c
        while d >= 2048:
            d /= 2
            r += 1
        f = (vco >> r) / d
        self.i2c.writeto_mem(self.addr, 42+8*out, packRegs(a, b, c, r))
        print('o',out,'f',int(f),'a',a,'b',b,'c',c,'d',d,'r',r)
        #assert 6 <= d <= 1800

        v = (pll<<5) | 0x0F # power up, select PLL, and set int mode
        if b == 0 and a%2 == 0:
            v += 0x40 # int mode
        self.i2c.writeto_mem(self.addr, 16+out, bytes((v,)))

        v = self.i2c.readfrom_mem(self.addr, 3, 1)[0]
        v &= ~(1 << out) # enable clock
        self.i2c.writeto_mem(self.addr, 3, bytes((v,)))

def packRegs(a, b, c, r=0):
    p1 = 128*a+int(128*b/c)-512
    p2 = 128*b-c*int(128*b/c)
    p3 = c
    v = bytearray(8)
    v[0], v[1], v[2], v[3] = p3>>8, p3, (r<<4) + (p1>>16), p1>>8
    v[4], v[5], v[6], v[7] = p1, (p3>>16)*16 + (p2>>16), p2>>8, p2
    return v


# see https://github.com/python/cpython/blob/3.8/Lib/fractions.py#L227-L280
def bestFraction(n, d):
    p0, q0, p1, q1 = 0, 1, 1, 0
    while d:
        a = n//d
        q2 = q0+a*q1
        if q2 > 1048575:
            break
        p0, q0, p1, q1 = p1, q1, p0+a*p1, q2
        n, d = d, n-a*d
    # TODO see original for further improvements w.r.t. the chosen result
    #k = (1048575-q0)//q1
    #print(p0+k*p1, q0+k*q1, (p0+k*p1) / (q0+k*q1), p1, q1, p1 / q1)
    return p1, q1
