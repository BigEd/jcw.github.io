# A quick demo of the Si3531 frequency synthesiser.

import machine
from si5351 import Si5351

i2c = machine.I2C(-1, scl=machine.Pin('E2'), sda=machine.Pin('E4'))

synth = Si5351(i2c)

synth.setPLL(0, 600000000)      # lower limit
synth.setPLL(1, 900000000)      # upper limit

synth.setFreq(0, 0, 1234567)    #  1.234,567 MHz
synth.setFreq(1, 0, 12345678)   # 12.345,678 MHz
synth.setFreq(2, 1, 34567890)   # 34.567,890 MHz
