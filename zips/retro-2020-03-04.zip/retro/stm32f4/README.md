Retrocomputing with Z80EMU on STM32F407.
