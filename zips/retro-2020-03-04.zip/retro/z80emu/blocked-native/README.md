This was adapted from `cpm2-native` to use 512-byte sectors.  
It can be used to test CP/M 2.2 blocking/deblocking.  
Should also be a good starting point for CP/M 3 and for FUZIX.  
Even CP/M 2.2 emulation under FUZIX will probably work.  
