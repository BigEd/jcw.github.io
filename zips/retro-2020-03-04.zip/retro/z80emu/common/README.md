Adapted from <https://github.com/anotherlin/z80emu>.
