See <https://jeelabs.org/2018/cpm-on-f407-part5/>.
