This is a Z80 emulator build for the STM32F407 µC, built from MacOS or Ubuntu.
It uses the command-line version of `PlatformIO` for simple toolchain use.

For the original version, see <https://jeelabs.org/2018/cpm-on-f407-part5/>.

The FUZIX OS is being adapted from the `z80pack` and `sbcv2` platforms.

_Work In Progress ... boots up, but the swap logic in FUZIX isn't right yet._
