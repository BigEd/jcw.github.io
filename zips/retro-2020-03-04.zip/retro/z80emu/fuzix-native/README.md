This is a native Z80 emulator build, used to compile under MacOS and Ubuntu.
It uses `PlatformIO` to keep the build setup the same as for embedded µCs.

For the original version, see <https://jeelabs.org/2018/cpm-on-f407-part5/>.

The FUZIX OS is being adapted from the `z80pack` and `sbcv2` platforms.

_Work In Progress ... boots up properly, but various issues remain._
