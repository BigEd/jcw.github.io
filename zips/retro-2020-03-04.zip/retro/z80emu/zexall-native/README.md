See <https://jeelabs.org/2018/z80-zexall-f407/>.
