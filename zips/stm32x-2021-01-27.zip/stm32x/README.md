# stm32x

Explorations using STM32-based boards

* uses [PlatformIO](https://platformio.org) as build system
* uses [JeeH](https://github.com/jeelabs/jeeh) as underlying code infrastructure
* mostly intended for very board-specific code
