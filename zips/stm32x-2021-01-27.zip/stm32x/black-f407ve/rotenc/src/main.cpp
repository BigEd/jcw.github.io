// Rotary knob decoder, no external debouncing capacitor needed.

#include <jee.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinA<6> led1;
PinA<7> led2;
PinB<3> encHigh; // TODO pushbutton not yet implemented
PinB<6> encDirA;
PinB<8> encDirB;

volatile int count;

// hard-coded for PinB<6> and PinB<8>
static void initRotEnc () {
    constexpr uint32_t syscfg    = 0x40013800;
    constexpr uint32_t exticr2   = syscfg + 0x0C;
    constexpr uint32_t exticr3   = syscfg + 0x10;

    constexpr uint32_t exti_imr  = Periph::exti + 0x00;
    constexpr uint32_t exti_rtsr = Periph::exti + 0x08;
    constexpr uint32_t exti_ftsr = Periph::exti + 0x0C;
    constexpr uint32_t exti_pr   = Periph::exti + 0x14;

    // see https://electronics.stackexchange.com/questions/99915/
    static int8_t const transitions [] = {0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};
    static uint8_t state = 0b11;

    encHigh.mode(Pinmode::in_pullup);
    encDirA.mode(Pinmode::in_pullup);
    encDirB.mode(Pinmode::in_pullup);

    // interrupt handler, called on every Dir A & B transition, incl bounces
    VTableRam().exti9_5 = []() {
        state = ((state << 2) | (encDirA << 1) | encDirB) & 0x0F;
        MMIO32(exti_pr) = (1<<8) | (1<<6); // clear pin 8 & 6 interrupts
        count += transitions[state];
    };

    Periph::bit(Periph::rcc+0x44, 14) = 1; // enable SYSCFG clock
    MMIO32(exticr2) = 1<<8;                // select P<B>6 pin
    MMIO32(exticr3) = 1<<0;                // select P<B>8 pin

    MMIO32(exti_imr) |= (1<<8) | (1<<6);   // enable pin 8 & 6 interrupts
    MMIO32(exti_rtsr) |= (1<<8) | (1<<6);  // trigger on pin 8 & 6 rising edge
    MMIO32(exti_ftsr) |= (1<<8) | (1<<6);  // trigger on pin 8 & 6 falling edge

    constexpr uint32_t nvic_en0r = 0xE000E100;
    MMIO32(nvic_en0r) = 1 << 23;           // enable exti 9..5 interrupt
}

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/2);
    printf("\r\n");

    led1.mode(Pinmode::out);
    led2.mode(Pinmode::out);

    initRotEnc();

    while (1) {
#if 0
        if (!encHigh)
            printf("press %d\n", ticks);
        led1 = encDirA;
        led2 = encDirB;
        wait_ms(10);
#else
        printf("%d +%d @%d\n", count>>2, count&3, (int) ticks);
        wait_ms(500);
    }
#endif
}
