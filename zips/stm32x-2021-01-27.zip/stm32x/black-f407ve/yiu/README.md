This is a minimal multi-tasking on STM32F407 (F4 Discovery).  
The example comes from Joseph Yiu's Cortex M3/M4 book, 3rd ed.
