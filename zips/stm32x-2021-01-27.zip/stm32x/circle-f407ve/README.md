More information about the "Circle F407VE" board:

* <https://github.com/mcauser/VCC_GND_F407VE>
* <https://docs.platformio.org/en/latest/boards/ststm32/blue_f407ve_mini.html>

This board has a 25 MHz crystal i.s.o. the usual 8 MHz.
