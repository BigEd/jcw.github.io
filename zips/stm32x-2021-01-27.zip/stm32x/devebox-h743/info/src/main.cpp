#include <jee.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinA<1> led;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/4);
    led.mode(Pinmode::out);

    wait_ms(1000);
    printf("\r\n");

    // see ARM docs for 0xE000* register addresses: https://developer.arm.com/documentation/ddi0489/b/system-control/register-summary

    // 0xRRRR6450:
    //  1001 = Revision Z
    //  1003 = Revision Y
    //  2001 = Revision X
    //  2003 = Revision V
    printf("      revision: %04x (hex)\n", MMIO32(0x5C001000)>>16);
    printf("     device id: %08x %08x %08x (hex)\n",
            MMIO32(0x1FF1E800), MMIO32(0x1FF1E804), MMIO32(0x1FF1E808));
    printf("    flash size: %d kB\n", (int) MMIO32(0x1FF1E880));
    printf("\n");
    printf("systick reload: %d\n", (int) MMIO32(0xE000E014));
    printf(" systick calib: %08x (hex)\n", MMIO32(0xE000E01C));
    printf("proc feature 1: %08x (hex)\n", MMIO32(0xE000ED40));
    printf("proc feature 2: %08x (hex)\n", MMIO32(0xE000ED44));
    printf("\n");

    while (true) {
        printf("%d\n", (int) ticks);
        led = 0;
        wait_ms(100);
        led = 1;
        wait_ms(400);
    }
}
