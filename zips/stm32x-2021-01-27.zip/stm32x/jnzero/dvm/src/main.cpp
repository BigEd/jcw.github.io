#include <jee.h>
#include <jee/i2c-ssd1306.h>
#include <jee/spi-rf69.h>
#include <jee/text-font.h>

I2cBus< PinB<7>, PinB<6> > bus;  // standard I2C pins for SDA and SCL
SSD1306< decltype(bus), false > oled;
Font11x16< decltype(oled) > console;
Font5x7< decltype(oled) > console2;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

template< typename I2C, int addr =0x68 >
struct MCP342x {
    void init (int bits =16, int pga =1) {
        int bitsCode = (bits-12)/2; // 12=0 .. 18=3
        int pgaCode = 0; // 1=0 .. 8=3
        while (pga > 1) {
            pga /= 2;
            ++pgaCode;
        }
        cmd = (1<<7) | (bitsCode << 2) | pgaCode;
    }

    int reading (int chan =1) {
        wait_ms(10);
        I2C::start(addr<<1);
        I2C::write(cmd | ((chan-1) << 5));
        I2C::stop();

        uint16_t value;
        uint8_t busy;
        do {
            wait_ms(10);
            I2C::start((addr<<1)+1);
            value = I2C::read(false) << 8;
            value |= I2C::read(false);
            busy = I2C::read(true) & 0x80;
            I2C::stop();
        } while (busy);
        return value;
    }

    uint8_t cmd;
};

MCP342x< decltype(bus) > adcs;

static void label (char tag, bool top, bool left) {
    console2.x = left ? 57 : 122;
    console2.y = top ? 8 : 24;
    console2.putc(tag);
}

static uint16_t measure (int chan, bool top, bool left) {
    console.x = left ? 1 : 66;
    console.y = top ? 0 : 16;
    int16_t r = adcs.reading(chan);
    printf("%5d", r);
    return r;
}

#if JNZ_V1
SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
#elif JNZ_V3
SpiGpio< PinA<7>, PinA<6>, PinB<3>, PinA<15> > spi;
#elif JNZ_V4
SpiGpio< PinB<5>, PinB<4>, PinB<3>, PinA<15> > spi;
#endif

RF69< decltype(spi) > rf;

struct {
    uint32_t id [3];
    uint16_t mv [4];
} payload;

int main () {
    fullSpeedClock();
    //enableSysTick();
    wait_ms(10);

    adcs.init();

    spi.init();
    rf.init(63, 42, 8683);  // node 63, group 42, 868.3 MHz
    rf.sleep();

    oled.init();
    oled.clear();

    label('1', 1, 1);
    label('2', 0, 1);
    label('3', 1, 0);
    label('4', 0, 0);

    constexpr uint32_t UID_BASE = 0x1FFFF7E8U;
    for (int i = 0; i < 3; ++i)
        payload.id[i] = ((uint32_t const*) UID_BASE)[i];

    int last = 0;
    while (true) {
        payload.mv[0] = measure(1, 1, 1);
        payload.mv[1] = measure(2, 0, 1);
        payload.mv[2] = measure(3, 1, 0);
        payload.mv[3] = measure(4, 0, 0);

        if (last != ticks/10000) {
            last = ticks/10000;
            //rf.send(0, &payload, sizeof payload);
            rf.sleep();
        }
    }
}
