#include <jee.h>
#include <jee/i2c-ssd1306.h>
#include <jee/text-font.h>

I2cBus< PinB<7>, PinB<6> > bus;  // standard I2C pins for SDA and SCL
SSD1306< decltype(bus), true > oled;
//Font5x7< decltype(oled) > console;
//Font5x8< decltype(oled) > console;
Font11x16< decltype(oled) > console;
//Font17x24< decltype(oled) > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

int main () {
    //enableSysTick();
    fullSpeedClock();

    wait_ms(10);
    oled.init();
    oled.clear();

    printf("ASCII character set:\n");
    wait_ms(1000);

#if 0
    for (int o = 32; o < 128; o += 16) {
        printf("\n%02x: ", o);
        for (int i = 0; i < 16; ++i)
            console.putc(o+i);
        wait_ms(500);
    }
#else
    for (int o = 32; o < 128; ++o) {
        console.putc(o);
        wait_ms(100);
    }
#endif
    wait_ms(1000);

    // start printing incrementing integers after 5 seconds
    int i = 0;
    while (true)
        printf(" %d", ++i);
}
