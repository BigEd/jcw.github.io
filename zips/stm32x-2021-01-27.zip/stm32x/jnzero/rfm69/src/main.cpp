#include <jee.h>
#include <jee/spi-rf69.h>

UartBufDev< PinA<9>, PinA<10> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

#if JNZ_V1
PinA<15> led; // JNZ v1
SpiGpio< PinA<7>, PinA<6>, PinA<5>, PinA<4> > spi;
#elif JNZ_V3
PinB<5> led; // JNZ v3
SpiGpio< PinA<7>, PinA<6>, PinB<3>, PinA<15> > spi;
#else // JNZ_V4
PinA<8> led; // JNZ v4
SpiGpio< PinB<5>, PinB<4>, PinB<3>, PinA<15> > spi;
#endif

RF69< decltype(spi) > rf;

int main() {
    console.init();
    //console.baud(115200, fullSpeedClock());
    enableSysTick();
    led.mode(Pinmode::out); led = 1;

    spi.init();
    rf.init(63, 42, 8686);  // node 63, group 42, 868.3 MHz
    rf.txPower(0);
    rf.listen();

    static int seq [14]; // 56 bytes, nicely distinguishable
    while (true) {
#if 1
        static int last = -1;
        if (last != ticks / 1000) {
            last = ticks / 1000;
            led = 0;
            wait_ms(1);
            rf.send(55, seq, sizeof seq); // send to 55
            ++seq[0];
            wait_ms(10);
            led = 1;
            rf.listen();
            continue;
        }
#endif

        uint8_t rxBuf [64];
        auto rxLen = rf.receive(rxBuf, sizeof rxBuf);

        if (rxLen >= 0) {
            rf.rssiCapture();
            led = 0;

            printf("RF69 #%d: ", rxLen);
            for (int i = 0; i < rxLen; ++i) {
                printf("%02x", rxBuf[i]);
                if (i < 2)
                    printf(" ");
            }
            printf(" r%4d l%2d a%4d\n", rf.rssi, rf.lna, rf.afc);

            led = 1;
        }
    }
}
