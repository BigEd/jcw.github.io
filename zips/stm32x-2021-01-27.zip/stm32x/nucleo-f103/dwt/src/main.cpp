#include <jee.h>
#include <setjmp.h>
#include <string.h>

UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

jmp_buf jb;
uint32_t buf1 [100], buf2 [100];

int dummyFun (int a) {
    volatile int x = a;
    return x;
}

int main() {
    console.init();
    enableSysTick();
    //console.baud(115200, fullSpeedClock());

    wait_ms(500);
    printf("\r \n");

    DWT::init();

    while (ticks % 1000 == 0) {}
    while (ticks % 1000 != 0) {}
    DWT::start();
    while (ticks % 1000 == 0) {}
    while (ticks % 1000 != 0) {}
    DWT::stop();
    int count = DWT::count();
    printf("%d cycles => %d MHz\n", count, (count+100)/1000000);

    DWT::start();
    if (setjmp(jb) == 0) {
        DWT::stop();
        printf("setjmp: %d cycles\n", DWT::count());
        DWT::start();
        longjmp(jb, 1);
    }
    DWT::stop();
    printf("longjmp: %d cycles\n", DWT::count());

    DWT::start();
    memcpy(buf1, buf2, sizeof buf1);
    DWT::stop();
    printf("memcpy 400 bytes: %d cycles\n", DWT::count());

    DWT::start();
    for (int i = 0; i < 100; ++i)
        buf1[i] = buf2[i];
    DWT::stop();
    printf("copy 100 ints: %d cycles\n", DWT::count());

    DWT::start();
    for (int i = 0; i < 100; i += 4) {
        buf1[i] = buf2[i];
        buf1[i+1] = buf2[i+1];
        buf1[i+2] = buf2[i+2];
        buf1[i+3] = buf2[i+3];
    }
    DWT::stop();
    printf("unroll 25x4 ints: %d cycles\n", DWT::count());

    DWT::start();
    int n = dummyFun(123);
    DWT::stop();
    printf("dummyFun: %d cycles (%d)\n", DWT::count(), n);

    DWT::start();
    DWT::stop();
    printf("nothing: %d cycles\n", DWT::count());

    while (true) {}
}
