See <https://github.com/khoih-prog/AsyncWebServer_STM32>.
