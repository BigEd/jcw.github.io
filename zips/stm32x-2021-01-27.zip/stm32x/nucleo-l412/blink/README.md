See <https://jeelabs.org/2018/standby-current-f103/>
