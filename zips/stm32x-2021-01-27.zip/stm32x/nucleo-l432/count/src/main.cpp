#include <jee.h>

UartBufDev< PinA<2>, PinA<15> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinB<3> led;

PinA<6> led1;
PinA<5> led2;
PinA<4> led3;
PinA<3> led4;
PinA<1> led5;
PinA<0> led6;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());
    led.mode(Pinmode::out);
    Port<'A'>::modeMap(0b1111011, Pinmode::out);

    while (true) {
        int n = ticks / 100;
        printf("%d\n", n);
        led  = n & (1 << 0);
        led1 = n & (1 << 1);
        led2 = n & (1 << 2);
        led3 = n & (1 << 3);
        led4 = n & (1 << 4);
        led5 = n & (1 << 5);
        led6 = n & (1 << 6);
        wait_ms(100);
    }
}
