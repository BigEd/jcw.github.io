#include <cstdio>
#include <ctime>

void led (int num, bool on) {
    static bool leds [5];
    if (leds[num] != on) {
        leds[num] = on;
        printf("\r  led1 %s  led2 %s  led3 %s  led4 %s  \r",
                leds[1] ? "H" : "-",
                leds[2] ? "H" : "-",
                leds[3] ? "H" : "-",
                leds[4] ? "H" : "-");
        fflush(stdout);
    }
}

void wait_ms (int ms) {
    timespec ts = { 0, 1000000 * ms };
    nanosleep(&ts, &ts);
}

int main () {
    for (int clicks = 0; ; ++clicks) {
        led(1, clicks % 3 == 0);
        led(2, clicks % 5 == 0);
        led(3, clicks % 7 == 0);
        led(4, clicks % 11 == 0);
        wait_ms(100);
    }
    return 0;
}
