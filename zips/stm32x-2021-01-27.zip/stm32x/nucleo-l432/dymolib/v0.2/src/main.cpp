#include <cassert>
#include <jee.h>

UartBufDev< PinA<2>, PinA<3> > console;

extern "C" int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

extern "C" void __assert_func (char const* f, int l, char const* n, char const* e) {
    printf("\nassert(%s) in %s\n\t%s:%d\n", e, n, f, l);
    while (true) {}
}

extern "C" void __assert (char const* f, int l, char const* e) {
    __assert_func(f, l, "-", e);
}

extern "C" void abort () {
    printf("\nabort\n");
    while (true) {}
}

int clicks;

struct Module {
    Module (char const* s) : name (s), next (last) {
        last = this;
    }
    virtual ~Module () {
        assert(last == this);
        last = next;
    }
    virtual void poll () = 0;

    static void forEach (void(*fun)(Module&)) {
        for (auto m = last; m != nullptr; m = m->next)
            fun(*m);
    }

    char const* name;
private:
    Module* next;
    static Module* last;
};

Module* Module::last = nullptr;

template< typename LED, int RATE >
struct Blinker : Module {
    Blinker (char const* name) : Module (name) {
        LED::mode(Pinmode::out);
    }
    ~Blinker () override {
        LED::mode(Pinmode::in_analog);
    }
    void poll () override {
        LED::write(clicks % RATE == 0);
    }
};

void run3s () {
    printf("run:");
    Module::forEach([](Module& m) { printf(" %s", m.name); });
    printf("\n");

    for (int i = 0; i < 30; ++i) {
        ++clicks;
        Module::forEach([](Module& m) { m.poll(); });
        wait_ms(100);
    }
}

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/4);

    // console output:
    //  run:
    //  run: 1
    //  run: 3 2 1
    //  run: 1
    //  run: 4 1
    //  run: 3b 2b 4 1
    //  run: 4 1
    //  run: 1
    //  run:

    run3s();
    {
        Blinker< PinD<12>, 3 > led1 ("1");
        run3s();
        {
            Blinker< PinD<13>, 5 > led2 ("2");
            Blinker< PinD<14>, 7 > led3 ("3");
            run3s();
        }
        run3s();
        {
            Blinker< PinD<15>, 11> led4 ("4");
            run3s();
            {
                Blinker< PinD<13>, 5 > led2 ("2b");
                Blinker< PinD<14>, 7 > led3 ("3b");
                run3s();
            }
            run3s();
        }
        run3s();
    }
    run3s();
}
