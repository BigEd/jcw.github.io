An application, compiled and linked into two separate pieces.

Build, upload, and run on STM32 F4 Discovery:

```text
pio run -e core -t upload
pio run -e app -t upload -t monitor
```

The "core" build creates a `core-syms.ld` file via the `pio-syms.py` script.  
This is used the pre-link the "app" build via the `pio-app.py` script.

Output (4 on-board LEDs will blink in varying patterns and change every 3s):

```text
1: etext 08000798 edata 20000000 ebss 200003B0 estack 20010000 app 08010659
20000090
2: etext 080107BC edata 20010068 ebss 2001008C estack 20020000 main 080104B5
memcpy 08000769 wait_ms 08000541 printf 08000215
run:
run: 1
run: 3 2 1
run: 1
run: 4 1
run: 3b 2b 4 1
run: 4 1
run: 1
run:
```

Part 1 consists mostly of startup code + printf:

```text
RAM:   [          ]   0.7% (used 944 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 1616 bytes from 1048576 bytes)
```

Part 2 has the application code, assert code, and an unused irq vector:

```text
RAM:   [          ]   0.1% (used 140 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 1980 bytes from 1048576 bytes)
```

Part 2 calls `printf`, `wait_ms`, and some more, but doesn't contain that code.
