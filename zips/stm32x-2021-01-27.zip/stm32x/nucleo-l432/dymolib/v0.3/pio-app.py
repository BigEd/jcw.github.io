Import("env")

env.Append(
  LINKFLAGS=[
    "-Wl,-R,core-syms.ld"
  ]
)
