#include <jee.h>
#include "core.h"
#include "string.h"

extern "C" int putchar (int ch) {
    return printf("%c", ch);
}

extern "C" int puts (char const* str) {
    return printf("%s\n", str);
}

extern "C" void __assert_func (char const* f, int l, char const* n, char const* e) {
    printf("\nassert(%s) in %s\n\t%s:%d\n", e, n, f, l);
    while (true) {}
}

extern "C" void __assert (char const* f, int l, char const* e) {
    __assert_func(f, l, "-", e);
}

extern "C" void abort () {
    printf("\nabort\n");
    while (true) {}
}

int clicks;

template< typename LED, int RATE >
struct Blinker : Module {
    Blinker (char const* name) : Module (name) {
        LED::mode(Pinmode::out);
    }
    ~Blinker () override {
        LED::mode(Pinmode::in_analog);
    }
    void poll () override {
        LED::write(clicks % RATE == 0);
    }
};

void run3s () {
    printf("run:");
    Module::forEach([](Module& m) { printf(" %s", m.name); });
    printf("\n");

    for (int i = 0; i < 30; ++i) {
        ++clicks;
        Module::forEach([](Module& m) { m.poll(); });
        wait_ms(100);
    }
}

extern "C" int _etext [], _edata [], _ebss [], _estack [];

int main () {
    printf("2: etext %p edata %p ebss %p estack %p main %p\n",
            _etext, _edata, _ebss, _estack, main);
    printf("memcpy %p wait_ms %p printf %p\n", memcpy, wait_ms, printf);

    run3s();
    {
        Blinker< PinD<12>, 3 > led1 ("1");
        run3s();
        {
            Blinker< PinD<13>, 5 > led2 ("2");
            Blinker< PinD<14>, 7 > led3 ("3");
            run3s();
        }
        run3s();
        {
            Blinker< PinD<15>, 11> led4 ("4");
            run3s();
            {
                Blinker< PinD<13>, 5 > led2 ("2b");
                Blinker< PinD<14>, 7 > led3 ("3b");
                run3s();
            }
            run3s();
        }
        run3s();
    }
    run3s();
}
