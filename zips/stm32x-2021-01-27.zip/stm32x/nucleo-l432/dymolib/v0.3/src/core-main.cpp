#include <jee.h>
#include "core.h"

extern UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

Module* Module::last = nullptr;

extern "C" int _etext [], _edata [], _ebss [], _estack [];

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/4);

    auto app = (void (*)()) *(uint32_t*) 0x08010004;

    wait_ms(500);
    printf("1: etext %p edata %p ebss %p estack %p app %p\n",
            _etext, _edata, _ebss, _estack, app);
    printf("%p\n", &Module::last); // TODO yuck, needed to force reference!
    wait_ms(100);

    app();
}

extern "C" void SystemInit () {}
