#include <cassert>

struct Module {
    Module (char const* s) : name (s), next (last) {
        last = this;
    }
    virtual ~Module () {
        assert(last == this);
        last = next;
    }
    virtual void poll () = 0;

    static void forEach (void(*fun)(Module&)) {
        for (auto m = last; m != nullptr; m = m->next)
            fun(*m);
    }

    char const* name;
//private:
    Module* next;
    static Module* last;
};
