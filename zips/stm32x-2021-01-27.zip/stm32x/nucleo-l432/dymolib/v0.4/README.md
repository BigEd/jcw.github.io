An application, compiled and linked into two separate pieces.  
See v0.3 for details, this build works mostly in the same way.

Build, upload, and run **App 1** on STM32 F4 Discovery:

```text
pio run -e core -t upload
pio run -e app1 -t upload -t monitor
```

Output (3 on-board LEDs will blink in varying patterns for 5s):

```text
1: etext 080008E8 edata 20000000 ebss 200003B0 estack 20020000 reg 0801004D
 0800028D 08000299 080002A5 080002BD 080002CD
Blinker create 2
Blinker create 3
Blinker create 5
2: etext 08010594 edata 20010068 ebss 200100AC estack 20020000 init 08010109
wait_ms 08000691 printf 08000269
in core-run
run: 3 2 1
Blinker init 5
Blinker init 3
Blinker init 2
Blinker deinit 5
Blinker deinit 3
Blinker deinit 2
leaving run
Blinker destroy 5
Blinker destroy 3
Blinker destroy 2
done
```

Now build, upload, and run **App 2** instead:

```text
pio run -e app2 -t upload -t monitor
```

Output (4 on-board LEDs will blink in varying patterns for 5s):

```text
1: etext 080008E8 edata 20000000 ebss 200003B0 estack 20020000 reg 0801004D
 0800028D 08000299 080002A5 080002BD 080002CD
Blinker create 6
Blinker create 7
Blinker create 8
Blinker create 9
2: etext 08010658 edata 20010068 ebss 200100B8 estack 20020000 init 08010131
wait_ms 08000691 printf 08000269
in core-run
run: D C B A
Blinker init 9
Blinker init 8
Blinker init 7
Blinker init 6
Blinker deinit 9
Blinker deinit 8
Blinker deinit 7
Blinker deinit 6
leaving run
Blinker destroy 9
Blinker destroy 8
Blinker destroy 7
Blinker destroy 6
done
```

This illustrates that the core remains the same, only the uploaded apps differ.

Core size:

```text
RAM:   [          ]   0.7% (used 944 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 2116 bytes from 1048576 bytes)
```

App 1 size:

```text
RAM:   [          ]   0.1% (used 172 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 1836 bytes from 1048576 bytes)
```

App 2 size:

```text
RAM:   [          ]   0.1% (used 184 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 2060 bytes from 1048576 bytes)
```
