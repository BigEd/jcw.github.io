#include <jee.h>
#include "core.h"

// same code in app1 and app2, although it need not be
template< typename LED, int RATE >
struct Blinker : Module {
    Blinker (char const* name) : Module (name) {
        printf("Blinker create %d\n", RATE);
    }
    ~Blinker () override {
        printf("Blinker destroy %d\n", RATE);
    }
    void init () override {
        printf("Blinker init %d\n", RATE);
        LED::mode(Pinmode::out);
    }
    void deinit () override {
        printf("Blinker deinit %d\n", RATE);
        LED::mode(Pinmode::in_analog);
    }
    void poll () override {
        extern int clicks;
        LED::write(clicks % RATE == 0);
    }
};

// app1 and app2 only differ in blink rates, module names, and number of leds
Blinker< PinD<12>, 2 > led1 ("1");
Blinker< PinD<13>, 3 > led2 ("2");
Blinker< PinD<14>, 5 > led3 ("3");

extern "C" void init () {
    extern int _etext [], _edata [], _ebss [], _estack [];
    printf("2: etext %p edata %p ebss %p estack %p init %p\n",
            _etext, _edata, _ebss, _estack, init);
    printf("wait_ms %p printf %p\n", wait_ms, printf);
}
