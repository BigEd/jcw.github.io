#include <jee.h>
#include "core.h"

extern UartBufDev< PinA<2>, PinA<3> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

extern "C" int putchar (int ch) {
    return printf("%c", ch);
}

extern "C" int puts (char const* str) {
    return printf("%s\n", str);
}

extern "C" void __assert_func (char const* f, int l, char const* n, char const* e) {
    printf("\nassert(%s) in %s\n\t%s:%d\n", e, n, f, l);
    while (true) {}
}

extern "C" void __assert (char const* f, int l, char const* e) {
    __assert_func(f, l, "-", e);
}

extern "C" void abort () {
    printf("\nabort\n");
    while (true) {}
}

Module* Module::last = nullptr;

int clicks;

extern "C" int _etext [], _edata [], _ebss [], _estack [];

void run () {
    printf("in core-run\n");

    printf("run:");
    Module::forEach([](Module& m) { printf(" %s", m.name); });
    printf("\n");

    Module::initAll();

    for (int i = 0; i < 50; ++i) {
        ++clicks;
        Module::pollAll();
        wait_ms(100);
    }

    Module::deinitAll();
    printf("leaving run\n");
}

int main() {
    console.init();
    console.baud(115200, fullSpeedClock()/4);
    wait_ms(500);

    auto reg = (void (*)()) *(uint32_t*) 0x08010004;
    auto dereg = (void (*)()) *(uint32_t*) 0x08010008;

    printf("1: etext %p edata %p ebss %p estack %p reg %p\n",
            _etext, _edata, _ebss, _estack, reg);
    printf(" %p %p %p %p %p\n", putchar, puts, __assert_func, __assert, abort);

    reg();
    run();
    dereg();

    printf("done\n");
    wait_ms(100);
}
