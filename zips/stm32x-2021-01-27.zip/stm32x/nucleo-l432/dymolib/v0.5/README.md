An application, compiled and linked into two separate pieces.  
See v0.3 and v0.4 for details, this build works mostly in the same way.  
Unlike v0.4, this code no longer manages modules in main, it's now per-app.

Build, upload, and run **App 1** on STM32 F4 Discovery:

```text
pio run -e core -t upload
pio run -e app1 -t upload -t monitor
```

Output (3 on-board LEDs will blink in varying patterns for 5s):

```text
1: etext 08000864 edata 20000000 ebss 200003B0 estack 20020000 reg 0800404D
 08000239 08000245 08000251 08000269 08000279
in main - registering
Blinker create 2
Blinker create 3
Blinker create 5
2: etext 08004650 edata 20001068 ebss 200010B4 estack 20020000 init 0800421D
wait_ms 080005CD printf 08000215
modules: 3 2 1
Blinker init 5
Blinker init 3
Blinker init 2
Blinker deinit 5
Blinker deinit 3
Blinker deinit 2
leaving app init
in main - deregistering
Blinker destroy 5
Blinker destroy 3
Blinker destroy 2
done
```

Now build, upload, and run **App 2** instead:

```text
pio run -e app2 -t upload -t monitor
```

Output (4 on-board LEDs will blink in varying patterns for 5s):

```text
1: etext 08000864 edata 20000000 ebss 200003B0 estack 20020000 reg 0800404D
 08000239 08000245 08000251 08000269 08000279
in main - registering
Blinker create 6
Blinker create 7
Blinker create 8
Blinker create 9
2: etext 08004714 edata 20001068 ebss 200010C0 estack 20020000 init 0800427D
wait_ms 080005CD printf 08000215
modules: D C B A
Blinker init 9
Blinker init 8
Blinker init 7
Blinker init 6
Blinker deinit 9
Blinker deinit 8
Blinker deinit 7
Blinker deinit 6
leaving app init
in main - deregistering
Blinker destroy 9
Blinker destroy 8
Blinker destroy 7
Blinker destroy 6
done
```

This illustrates that the core remains the same, only the uploaded apps differ.

Core size:

```text
RAM:   [          ]   0.7% (used 944 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 1936 bytes from 1048576 bytes)
```

App 1 size:

```text
RAM:   [          ]   0.1% (used 180 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 2148 bytes from 1048576 bytes)
```

App 2 size:

```text
RAM:   [          ]   0.1% (used 192 bytes from 131072 bytes)
Flash: [          ]   0.2% (used 2372 bytes from 1048576 bytes)
```
