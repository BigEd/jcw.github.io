import os

Import("env")

elf = "{PROJECT_BUILD_DIR}/{PIOENV}/{PROGNAME}.elf".format(**env)
out = "{PIOENV}-syms.ld".format(**env)

omit = [
    '_Min_Stack_Size',
    '_Min_Heap_Size',
    '__bss_start__',
    '__bss_end__',
    '__exidx_start',
    '__exidx_end',
    '__libc_init_array',
    '_etext',
    '_init',
    '_fini',
    '_sidata',
    '_sdata',
    '_edata',
    '_sbss',
    '_ebss',
    '_siccmram',
    '_sccmram',
    '_eccmram',
    'g_pfnVectors',
    'main',
]

def gensyms(source, target, env):
    print("Extracting symbols to '%s'" % out)
    with os.popen("arm-none-eabi-readelf -s '%s'" % elf) as ifd:
        with open(out, "w") as ofd:
            for line in ifd:
                fields = line.split()
                if len(fields) > 4 and fields[4] == 'GLOBAL':
                    name = fields[7]
                    value = fields[1]
                    if name not in omit:
                        print("%s = 0x%s;" % (name, value), file=ofd)

env.AddPostAction(elf, gensyms)
