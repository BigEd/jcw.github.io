#include <cassert>

struct Module {
    Module (char const* s) : name (s), next (last) {
        last = this;
    }
    virtual ~Module () {
        assert(last == this);
        last = next;
    }
    virtual void init () {}
    virtual void deinit () {}
    virtual void poll () = 0;

    static void forEach (void(*fun)(Module&)) {
        for (auto m = last; m != nullptr; m = m->next)
            fun(*m);
    }
    static void initAll () {
        forEach([](Module& m) { m.init(); });
    }
    static void deinitAll () {
        forEach([](Module& m) { m.deinit(); });
    }
    static void pollAll () {
        forEach([](Module& m) { m.poll(); });
    }

    char const* name;
private:
    Module* next;
    static Module* last;
};

template< typename LED, int RATE >
struct Blinker : Module {
    Blinker (char const* name) : Module (name) {
        printf("Blinker create %d\n", RATE);
    }
    ~Blinker () override {
        printf("Blinker destroy %d\n", RATE);
    }
    void init () override {
        printf("Blinker init %d\n", RATE);
        LED::mode(Pinmode::out);
    }
    void deinit () override {
        printf("Blinker deinit %d\n", RATE);
        LED::mode(Pinmode::in_analog);
    }
    void poll () override {
        extern int clicks;
        LED::write(clicks % RATE == 0);
    }
};
