#include <jee.h>

// same code in app1 and app2, although it need not be
#include "app.h"

int clicks;
Module* Module::last = nullptr;

// app1 and app2 only differ in blink rates, module names, and number of leds
Blinker< PinD<12>, 2 > led1 ("1");
Blinker< PinD<13>, 3 > led2 ("2");
Blinker< PinD<14>, 5 > led3 ("3");

extern "C" void init () {
    extern int _etext [], _edata [], _ebss [], _estack [];
    printf("2: etext %p edata %p ebss %p estack %p init %p\n",
            _etext, _edata, _ebss, _estack, init);
    printf("wait_ms %p printf %p\n", wait_ms, printf);

    printf("modules:");
    Module::forEach([](Module& m) { printf(" %s", m.name); });
    printf("\n");

    Module::initAll();

    for (int i = 0; i < 50; ++i) {
        ++clicks;
        Module::pollAll();
        wait_ms(100);
    }

    Module::deinitAll();
    printf("leaving app init\n");
}
