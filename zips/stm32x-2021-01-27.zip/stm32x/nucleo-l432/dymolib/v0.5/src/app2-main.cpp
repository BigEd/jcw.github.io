#include <jee.h>

// same code in app1 and app2, although it need not be
#include "app.h"

int clicks;
Module* Module::last = nullptr;

// app1 and app2 only differ in blink rates, module names, and number of leds
Blinker< PinD<12>, 6 > led1 ("A");
Blinker< PinD<13>, 7 > led2 ("B");
Blinker< PinD<14>, 8 > led3 ("C");
Blinker< PinD<15>, 9 > led4 ("D");

extern "C" void init () {
    extern int _etext [], _edata [], _ebss [], _estack [];
    printf("2: etext %p edata %p ebss %p estack %p init %p\n",
            _etext, _edata, _ebss, _estack, init);
    printf("wait_ms %p printf %p\n", wait_ms, printf);

    printf("modules:");
    Module::forEach([](Module& m) { printf(" %s", m.name); });
    printf("\n");

    Module::initAll();

    for (int i = 0; i < 50; ++i) {
        ++clicks;
        Module::pollAll();
        wait_ms(100);
    }

    Module::deinitAll();
    printf("leaving app init\n");
}
