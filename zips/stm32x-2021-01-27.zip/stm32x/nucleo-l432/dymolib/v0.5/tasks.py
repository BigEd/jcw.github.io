# see https://www.pyinvoke.org
from invoke import task

@task
def clean(c):
    """delete all build results"""
    c.run("pio run -t clean -s")

@task
def build(c):
    """build core, app1, app2, and show their sizes"""
    c.run("pio run")

@task
def core(c):
    """build and upload core (must be first)"""
    c.run("pio run -t clean -s") # get rid of apps, so they'll use new syms
    c.run("pio run -e core -t upload -s")

@task
def run(c, num=1):
    """build and upload app 1 or 2, then show serial ouput"""
    c.run(f"pio run -e app{num} -t upload -t monitor -s", pty=True)
