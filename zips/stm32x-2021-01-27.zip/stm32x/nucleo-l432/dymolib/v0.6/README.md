An application, compiled & linked as separate segments: boot, core, and devs.  
This code is for the Nucleo-L432 board, based on the 32-pin STM32L432KC µC.  
The builds for this example are based on [PyInvoke][INV] and [PlatformIO][PIO].

[INV]: https://www.pyinvoke.org
[PIO]: https://platformio.org/install/cli

The boot segment will "call" the core segment, which in turn "calls" the devs
segment. Devs then "returns" to core, which "returns" to boot. All C++ objects
defined in non-local scope will have their constructors called when the segment
call starts - and their destructors called when the segment call ends.

Global functions and vars in boot can be used in core, and likewise for core vs
devs.

To try this out:

1. to see what commands are available, type: `inv -l`
2. start a serial terminal in a separate shell window: `inv serial`
3. build and upload all three segments via the st-link: `inv zero boot`

Each upload will generate some serial output, the output block should look like:

```text
<RESET>
  cpuid 0x410FC241, 256 kB flash, package type 8
  devid 0x00500049-58415017-20333257, clock 80000 kHz
<EXIT>
<RESET>
  cpuid 0x410FC241, 256 kB flash, package type 8
  devid 0x00500049-58415017-20333257, clock 80000 kHz
  main -> regFun 080010B1
hello 123
goodbye 123
  main -> deregFun 080010F9
<EXIT>
<RESET>
  cpuid 0x410FC241, 256 kB flash, package type 8
  devid 0x00500049-58415017-20333257, clock 80000 kHz
  main -> regFun 080010B1
hello 123
  core -> regFun 0800185D
cheers 456
  core -> deregFun 080018A5
goodbye 123
  main -> deregFun 080010F9
<EXIT>
```

The "RESET" and "EXIT" lines come from `src/boot-main.cpp`.  
The "hello" and "goodbye" lines come from `src/core-main.cpp`.  
The "cheers" line comes from `src/devs-main.cpp`.  
The remaining lines contain some debug info from various places.

The **boot** segment is loaded at 0x08000000, and has this size:

```text
RAM:   [          ]   1.4% (used 908 bytes from 65536 bytes)
Flash: [          ]   0.7% (used 1908 bytes from 262144 bytes)
```

The **core** segment is loaded at 0x08001000, and has this size:

```text
RAM:   [          ]   0.0% (used 28 bytes from 65536 bytes)
Flash: [          ]   0.2% (used 440 bytes from 262144 bytes)
```

The **devs** segment is loaded at 0x08001800, and has this size:

```text
RAM:   [          ]   0.0% (used 28 bytes from 65536 bytes)
Flash: [          ]   0.1% (used 300 bytes from 262144 bytes)
```

Note that core and devs are very small, as they re-use boot's `printf`, etc.

The locations of these segments (both flash and ram) is automatically
configured in the `pio-syms.py` script which runs as `extra_script` in
PIO, and again in the C++ code, so that boot can figure out where core core
starts, and core can figure out where devs starts. These calculations must
match, obviously.
