import os
Import("env")

tag = "{PIOENV}".format(**env)
elf = "{PROJECT_BUILD_DIR}/{PIOENV}/{PROGNAME}.elf".format(**env)

flashSegSize = 2048 # STM32L4-specific

omit = [
    '_Min_Stack_Size',
    '_Min_Heap_Size',
    '__bss_start__',
    '__bss_end__',
    '__exidx_start',
    '__exidx_end',
    '__libc_init_array',
    '__libc_fini_array',
    '_etext',
    '_init',
    '_fini',
    '_sidata',
    '_sdata',
    '_edata',
    '_sbss',
    '_ebss',
    '_siccmram',
    '_sccmram',
    '_eccmram',
    'g_pfnVectors',
    'init',
    'main',
    'SystemInit',
]

def gensyms(source, target, env):
    print(f"Extracting symbols from '{tag}'")
    with os.popen(f"arm-none-eabi-readelf -s '{elf}'") as ifd:
        with open(f"{tag}-syms.ld", "w") as ofd:
            syms = {}
            for line in ifd:
                fields = line.split()
                if len(fields) > 4 and fields[4] == 'GLOBAL':
                    name = fields[7]
                    value = fields[1]
                    if name in omit:
                        syms[name] = int(value, 16)
                    else:
                        print(f"{name} = 0x{value};", file=ofd)

            # calculate and save flash + ram size to skip in next segment
            print(file=ofd)
            romSize = syms["_sidata"] - 0x08000000
            romAlign = "%08x" % (romSize + (-romSize & (flashSegSize-1)))
            print(f"SkipROM_{tag} = 0x{romAlign};", file=ofd)
            ramSize = syms["_ebss"] - 0x20000000
            ramAlign = "%08x" % (ramSize + (-ramSize & 7))
            print(f"SkipRAM_{tag} = 0x{ramAlign};", file=ofd)

env.AddPostAction(elf, gensyms)
