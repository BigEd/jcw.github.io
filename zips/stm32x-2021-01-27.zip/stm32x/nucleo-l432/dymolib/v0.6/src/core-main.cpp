#include <jee.h>

#if STM32L4
constexpr auto flashSegSize = 2048;
#endif

struct SegmentHdr {
    uint32_t magic;
    void (*regFun)();
    void (*deregFun)();
};

static auto nextSegment () -> SegmentHdr const& {
    extern uint8_t g_pfnVectors[], _sidata [];
    auto romSize = _sidata - g_pfnVectors;
    auto romAlign = romSize + (-romSize & (flashSegSize-1));
    auto romNext = g_pfnVectors + romAlign;
    return *(SegmentHdr const*) romNext;
}

extern "C" void init () {
    printf("hello %d\n", 123);

    auto hdr = nextSegment();
    if (hdr.magic == 0x12345678) {
        printf("  core -> regFun %p\n", hdr.regFun);
        hdr.regFun();
        printf("  core -> deregFun %p\n", hdr.deregFun);
        hdr.deregFun();
    }

    printf("goodbye %d\n", 123);
}
