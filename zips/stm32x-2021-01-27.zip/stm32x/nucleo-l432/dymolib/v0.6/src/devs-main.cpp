#include <jee.h>

extern "C" void init () {
    printf("cheers %d\n", 456);
}
