#!/usr/bin/env python3
# generate a morse-code encoding table

alphabet = """
    .-      A
    -...    B
    -.-.    C
    -..     D
    .       E
    ..-.    F
    --.     G
    ....    H
    ..      I
    .---    J
    -.-     K
    .-..    L
    --      M
    -.      N
    ---     O
    .--.    P
    --.-    Q
    .-.     R
    ...     S
    -       T
    ..-     U
    ...-    V
    .--     W
    -..-    X
    -.--    Y
    --..    Z

    .----   1
    ..---   2
    ...--   3
    ....-   4
    .....   5
    -....   6
    --...   7
    ---..   8
    ----.   9
    -----   0

    -.-.--  !
    .-..-.  "
    ...-..- $
    .----.  '
    --..--  ,
    -....-  -
    .-.-.-  .
    -..-.   /
    ---...  :
    -.-.-.  ;
    ..--..  ?
    .--.-.  @
    ..--.-  _
"""

# ..--.   ! (?)
# .-.-.     AR  (End of Message)
# .-...     AS  (Wait)
# -...-.-   BK  (Break)
# -...-     BT  (Pause, New Paragraph)
# -.-..-..  CL  (Clear, Going Off Air)
# -.-.-     CT  (Start Copying)
# -.--.     KN  (Invite Specific Station Only)
# ...-.-    SK  (End of Transmission)
# ...-.     SN  (Understood)
# ...---... SOS (SOS)
# -.-.--.-  CQ  (Invitation)
# ........  ERR (Error)

items = {
    " ": "            1, // <space>"
}

for line in alphabet.split("\n"):
    if line:
        code, sym = line.split()
        bits = "0b1"
        for x in reversed(code):
            bits += "1" if x == "-" else "0"
        items[sym] = f"{bits:>13}, // <{sym}> = {code}"

print("uint16_t const ditsAndDahs [] = {")
for i in range (32, 96):
    c = chr(i)
    if c in items:
        print(items[c])
        del items[c]
    else:
        print(f"            0, // <{c}> = 0x{i:02X}")
print("};")

assert len(items) == 0
