// Morse code encoder
//
// Sample output:
//  0       H.... E. L.-.. L.-.. O---   W.-- O--- R.-. L.-.. D-.. !-.-.--
//  18500   H.... E. L.-.. L.-.. O---   W.-- O--- R.-. L.-.. D-.. !-.-.--
//  37000   H.... E. L.-.. L.-.. O---   W.-- O--- R.-. L.-.. D-.. !-.-.--

#define DEBUG 0

#include <jee.h>

#if DEBUG
UartBufDev< PinA<2>, PinA<15> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}
#else
int printf(const char* fmt, ...) { return 0; }
extern "C" void SystemInit () {}
#endif

PinB<3> led;

constexpr auto WPM = 10; // morse code timing, as words per minute

// bits stored in low-to-high order, highest "1" bit marks end and is not sent
uint16_t const ditsAndDahs [] = {
            1, // <space>
    0b1110101, // <!> = -.-.--
    0b1010010, // <"> = .-..-.
            0, // <#> = 0x23
   0b11001000, // <$> = ...-..-
            0, // <%> = 0x25
            0, // <&> = 0x26
    0b1011110, // <'> = .----.
            0, // <(> = 0x28
            0, // <)> = 0x29
            0, // <*> = 0x2A
            0, // <+> = 0x2B
    0b1110011, // <,> = --..--
    0b1100001, // <-> = -....-
    0b1101010, // <.> = .-.-.-
     0b101001, // </> = -..-.
     0b111111, // <0> = -----
     0b111110, // <1> = .----
     0b111100, // <2> = ..---
     0b111000, // <3> = ...--
     0b110000, // <4> = ....-
     0b100000, // <5> = .....
     0b100001, // <6> = -....
     0b100011, // <7> = --...
     0b100111, // <8> = ---..
     0b101111, // <9> = ----.
    0b1000111, // <:> = ---...
    0b1010101, // <;> = -.-.-.
            0, // <<> = 0x3C
            0, // <=> = 0x3D
            0, // <>> = 0x3E
    0b1001100, // <?> = ..--..
    0b1010110, // <@> = .--.-.
        0b110, // <A> = .-
      0b10001, // <B> = -...
      0b10101, // <C> = -.-.
       0b1001, // <D> = -..
         0b10, // <E> = .
      0b10100, // <F> = ..-.
       0b1011, // <G> = --.
      0b10000, // <H> = ....
        0b100, // <I> = ..
      0b11110, // <J> = .---
       0b1101, // <K> = -.-
      0b10010, // <L> = .-..
        0b111, // <M> = --
        0b101, // <N> = -.
       0b1111, // <O> = ---
      0b10110, // <P> = .--.
      0b11011, // <Q> = --.-
       0b1010, // <R> = .-.
       0b1000, // <S> = ...
         0b11, // <T> = -
       0b1100, // <U> = ..-
      0b11000, // <V> = ...-
       0b1110, // <W> = .--
      0b11001, // <X> = -..-
      0b11101, // <Y> = -.--
      0b10011, // <Z> = --..
            0, // <[> = 0x5B
            0, // <\> = 0x5C
            0, // <]> = 0x5D
            0, // <^> = 0x5E
    0b1101100, // <_> = ..--.-
};

void send (char const* msg) {
    constexpr auto DIT = 1200/WPM, DAH = 3 * DIT;

    while (*msg) {
        auto ch = *msg++;
        if ('a' <= ch && ch <= 'z')
            ch += 'A' - 'a';
        uint16_t pattern = 32 <= ch && ch < 96 ? ditsAndDahs[ch-32] : 0;
        printf("%c", ch);
        if (pattern == 1)
            wait_ms(4*DIT);
        while (pattern > 1) {
            printf("%c", pattern & 1 ? '-' : '.');
            led = 1;
            wait_ms(pattern & 1 ? DAH : DIT);
            led = 0;
            wait_ms(DIT);
            pattern >>= 1;
        }
        printf(" ");
        wait_ms(3*DIT);
    }
    printf("\n");
}

int main() {
#if DEBUG
    console.init();
    console.baud(115200, fullSpeedClock());
#else
    enableSysTick();
#endif
    led.mode(Pinmode::out);

    while (true) {
        printf("%d\t", (int) ticks);
        send("Hello world!");
        wait_ms(500);
    }
}
