#include <jee.h>

UartBufDev< PinA<2>, PinA<15> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

extern "C" int puts (char const* s) {
    return printf("%s\n", s);
}

#include <cstdint>
#include <cstring>
#include <setjmp.h>

struct {
    int stack [1000];
    jmp_buf top;
    void (*task)();
} stacks [3], *current;

jmp_buf* caller;

void suspend () {
    int callee [1];
    if (setjmp(current->top) == 0) {
        // suspending: copy stack out and jump to caller
        memcpy(current->stack, callee, (uintptr_t) caller - (uintptr_t) callee);
        longjmp(*caller, 1);
    } else {
        // resuming: copy stack in and prevent re-resuming
        memcpy(callee, current->stack, (uintptr_t) caller - (uintptr_t) callee);
        memset(current->top, 0, sizeof current->top);
#if 1
        asm ("nop"); // FIXME without this, the code doesn't work (???)
#endif
    }
}

void resume (int num) {
    current = &stacks[num];
    jmp_buf bottom;
    caller = &bottom;
    if (setjmp(bottom) == 0) {
        // either call for the first time, or resume saved state
        if (current->task != nullptr)
            current->task();
        else
            longjmp(current->top, 1);
    }
    // state has been saved, return to caller
    current->task = nullptr;
}

void hiya () {
    while (true) {
        puts("hiya, dude");
        suspend();
    }
}

void gday () {
    while (true) {
        puts("gday, mate");
        suspend();
        puts("wuzzup?");
        suspend();
    }
}

void howdy () {
    while (true) {
        puts("howdy, folks");
        suspend();
        suspend();
    }
}

void demoGreetings () {
    stacks[0].task = hiya;
    stacks[1].task = gday;
    stacks[2].task = howdy;

    for (int i = 0; i < 12; ++i)
        resume(i % 3);
}

PinB<3> led;

void demoPinToggle () {
    led.mode(Pinmode::out);

    stacks[0].task = []() {
        while (true) {
            led = 1;
            suspend();
        }
    };

    stacks[1].task = []() {
        while (true) {
            led = 0;
            suspend();
        }
    };

    for (int i = 0; i < 1000000; ++i)
        resume(i % 2);
}

int main () {
    console.init();
    console.baud(115200, fullSpeedClock());
    printf("\r------------------ jmp_buf %db\n", sizeof (jmp_buf));

    demoGreetings();
    demoPinToggle();

    while (true) {}
}
