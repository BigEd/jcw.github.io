#include <jee.h>
#include <stdlib.h>
#include <unistd.h>

UartBufDev< PinA<2>, PinA<15> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

PinB<3> led;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());
    led.mode(Pinmode::out);

    while (true) {
        printf("%d\n", ticks);
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);

        // memory is NOT cleared, i.e. it will persist across resets
        // https://github.com/eblot/newlib/blob/master/libgloss/epiphany/sbrk.c

        auto p = (uint32_t*) sbrk(100);
        printf("%p %p %p %p\n", p, p[0], p[1], p[2]);

        auto q = (uint32_t*) malloc(100);
        printf("%p %p %p %p\n", q, q[0], q[1], q[2]);

        p[0] = 0x11111111;
        p[1] = 0x22222222;
        p[2] = 0x33333333;

        q[0] = 0xAAAAAAAA;
        q[1] = 0xBBBBBBBB;
        q[2] = 0xCCCCCCCC;
    }
}
