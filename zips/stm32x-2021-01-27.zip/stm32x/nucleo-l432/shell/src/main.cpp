#include <jee.h>

UartBufDev< PinA<2>, PinA<15> > console;

int printf(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(console.putc, fmt, ap); va_end(ap);
    return 0;
}

static void systemReset () {
    // ARM Cortex specific
    MMIO32(0xE000ED0C) = (0x5FA<<16) | (1<<2); // SCB AIRCR reset
    while (true) {}
}

static void uartForceReset () {
    constexpr auto ESC = 0x04; // trigger a reset on two ctrl-d's in a row

    // a template is used to "carry ESC into" the handler at compile-time
    auto handler = []() {
        if (console.base::readable()) {
            int c = console.base::getc();

            static char prev;
            if (c == ESC && prev == ESC) // detect two ESC's in a row
                systemReset();
            prev = c;

            if (console.recv.free())
                console.recv.put(c);
            // else buffer full, discard input
        }
        if (console.base::writable()) {
            if (console.xmit.avail() > 0)
                console.base::putc(console.xmit.get());
            else
                Periph::bitClear(console.cr1, 7);  // disable TXEIE
        }
    };

    switch (console.base::uidx) {
        case 0: VTableRam().usart1 = handler; break;
        case 1: VTableRam().usart2 = handler; break;
        case 2: VTableRam().usart3 = handler; break;
    }
}

PinB<3> led;

int main() {
    console.init();
    console.baud(115200, fullSpeedClock());
    led.mode(Pinmode::out);

    uartForceReset();

    while (true) {
        printf("%d\n", (int) ticks);
        led = 1;
        wait_ms(100);
        led = 0;
        wait_ms(400);
    }
}
