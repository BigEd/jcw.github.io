// Power down demo

#include <jee.h>

int main() {
    (void) fullSpeedClock;

    powerDown(true);
}

extern "C" void SystemInit () {}
