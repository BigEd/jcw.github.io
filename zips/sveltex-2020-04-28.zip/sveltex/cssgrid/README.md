# CSS Grid Demo

This project is based on <https://github.com/sveltejs/template>.
Setup and build instructions for this [Svelte](https://svelte.dev) app can be found there.

Live demo: <https://jeelabs.org/tools/cssgrid/>

Most information was gleaned from this excellent [CSS Grid guide](https://css-tricks.com/snippets/css/complete-guide-grid/).
