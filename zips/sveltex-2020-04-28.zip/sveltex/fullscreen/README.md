# CSS Grid Demo

This project is based on <https://github.com/sveltejs/template>.
Setup and build instructions for this [Svelte](https://svelte.dev) app can be found there.

Live demo: <https://jeelabs.org/tools/fullscreen/>

Slightly adapted from an [article](https://dev.to/codechips/let-s-build-a-svelte-fullscreen-component-32c6) by Ilia Mikhailov.

This is not perfect with MacOS: it does not detect when already in fullscreen
mode, or when fullscreen mode is cancelled.
