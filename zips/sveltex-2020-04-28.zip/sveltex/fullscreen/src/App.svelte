<svelte:head>
    <title>Fullscreen - JeeLabs</title>
</svelte:head>

<script>
    import Fullscreen from "./Fullscreen.svelte";
</script>

<!--
-->

<Fullscreen let:isFull>
    <div>
        <h1>Fullscreen Demo</h1>
        <p>Click the button in the lower right corner ...</p>
        <h1>
            {#if isFull}
                I am now in fullscreen!
            {/if}
        </h1>
        <p>See
<a href="https://git.jeelabs.org/jcw/sveltex/src/branch/master/fullscreen">git.jeelabs.org/jcw/sveltex/fullscreen</a>
        for details.</p>
    </div>
</Fullscreen>
