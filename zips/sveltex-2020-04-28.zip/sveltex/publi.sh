#!/bin/sh

name=$(basename `pwd`)

rm -r public/build &&
    npm run build &&
    rsync -av --delete public/ crappy:/var/www/jeelabs.org/tools/$name
