# RFM12B Command Calculator

This project is based on <https://github.com/sveltejs/template>.
Setup and build instructions for this [Svelte](https://svelte.dev) app can be found there.

Live demo: <https://jeelabs.org/tools/rfm12calc/>

An older Knockout version is described in this [weblog post](https://jeelabs.org/2011/09/18/rfm12b-command-calculator/).
