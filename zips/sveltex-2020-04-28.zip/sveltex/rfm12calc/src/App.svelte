<svelte:head>
    <title>RFM12B Calculator - JeeLabs</title>
</svelte:head>

<script>
    import Fieldset from './Fieldset.svelte';
    import Popup from './Popup.svelte';

    let range16 = [...Array(16).keys()];
    let caps = range16.map(x => 8.5+0.5*x);
    let lobats = range16.map(x => (22+x)/10);
    let devs = range16.map(x => (1+x)*15);
    let clocks = [1,1.25,1.66,2,2.5,3.33,5,10];
    let afcs = ["Auto mode off",
                "Runs once after each power-up",
                "Keep F-offset only during VDI=high",
                "Keep F-offset value"];
    let limits = ["No restrictions","+15 .. -16","+7 .. -8","+3 .. -4"];
    let rxbws = ["-",400,340,270,200,134,67];
    let drssis = [-103,-97,-91,-85,-79,-73];

    let toBin = d => ("0000000"+((d >>> 0).toString(2))).slice(-8);

    // reactive state, i.e. this is where all the live updates are defined

    let CS = { b: 1, t: true, x: 7, r: true };
    $: CS.v = 0x8000 | (CS.t << 7) | (CS.r << 6) | (CS.b << 4) | (CS.x);
    let baseFreq, baseStep;
    $: baseFreq = [430,860,900][CS.b];
    $: baseStep = 0.0025 * (CS.b+1);

    let PM = { r: 1, b: 1, t: 0, s: 1, o: 1, l: 1, w: 0, c: 1 };
    $: PM.v = 0x8200 | (PM.r << 7) | (PM.b << 6) | (PM.t << 5) | (PM.s << 4)
                     | (PM.o << 3) | (PM.l << 2) | (PM.w << 1) | (PM.c << 0);

    let SP = { b: "D4" };
    $: SP.v = 0xCE00 | (parseInt(SP.b, 16) & 0xFF);

    let AF = { m: 2, o: 0, a: 1, h: 0, s: 0, f: 1 };
    $: AF.v = 0xC400 | (AF.m << 6) | (AF.o << 4)
                     | (AF.s << 3) | (AF.h << 2) | (AF.f << 1) | (AF.a << 0);

    let FS = { f: 1600 };
    $: FS.v = 0xA000 | (FS.f & 0x0FFF);

    let TC = { s: 0, d: 5, p: 0 };
    $: TC.v = 0x9800 | (TC.s << 8) | (TC.d << 4) | (TC.p << 0);

    let DR = { p: 0, r: 6 };
    $: DR.v = 0xC600 | (DR.p << 7) | (DR.r << 0);

    let PS = { c: 2, p: 1, b: 1, e: 0 };
    $: PS.v = 0xCC02 | (PS.c << 5) | (PS.p << 4) | (PS.e << 3) | (PS.b << 2)
                     | (PS.p << 0);

    let RC = { n: 0, p: 1, r: 5, l: 0, d: 2 };
    $: RC.v = 0x9000 | (RC.p << 10) | (RC.n << 8) | (RC.r << 5) | (RC.l << 3)
                     | (RC.d << 0);

    let DC = { d: 0, e: 0 };
    $: DC.v = 0xC800 | (DC.d << 1) | (DC.e << 0);

    let WT = { m: 0, r: 0 };
    $: WT.v = 0xE000 | (WT.r << 8) | (WT.m << 0);

    let DF = { m: 1, s: 0, f: 0, q: 0 };
    $: DF.v = 0xC228 | (DF.m << 7) | (DF.s << 6) | (DF.f << 4) | ((DF.q+4) << 0);

    let FR = { l: 8, b: 1, f: 0, s: 1, e: 1 };
    $: FR.v = 0xCA00 | (FR.l << 4) | ((1-FR.b) << 3) | (FR.f << 2) | (FR.e << 1)
                     | (FR.s << 0);

    let LB = { p: 2, t: 9 };
    $: LB.v = 0xC000 | (LB.p << 5) | (LB.t << 0);

    let OC = { v: 0xB000 };

</script>

<header><h1>RFM12B Command Calculator</h1></header>

<main>

    <Fieldset legend="Configuration Settings" value={CS.v}>
        <Popup head='Band' opts={[433,868,915]} tail=MHz bind:value={CS.b} />
        <label><input type=checkbox bind:checked={CS.t}> TX Register</label>
        <Popup head='Xtal cap' opts={caps} tail=pF bind:value={CS.x} />
        <label><input type=checkbox bind:checked={CS.r}> RX FIFO Buffer</label>
    </Fieldset>

    <Fieldset legend="Synchronization Pattern" value={SP.v}>
        <div class=wide>
            Synchronization Byte (HEX)
            <input class=numin bind:value={SP.b}>
            : <code>{ toBin(SP.v & 0xFF) }</code>
        </div>
    </Fieldset>

    <Fieldset legend="Frequency Setting" value={FS.v}>
        <div>
            F =
            <input type=number class=numin bind:value={FS.f} >
            : {(baseFreq + FS.f * baseStep).toFixed(3)} MHz
        </div>
        <div>
            Fc = {baseFreq} + F * {baseStep} MHz
        </div>
    </Fieldset>

    <Fieldset legend="TX Control" value={TC.v}>
        <div>
            <Popup head='Frequency Shift' opts={["Pos","Neg"]} bind:value={TC.s} />
        </div>
        <div>
            <Popup head='Deviation' opts={devs} tail=kHz bind:value={TC.d} />
        </div>
    </Fieldset>

    <Fieldset legend="Power Management" value={PM.v}>
        <label>
            <input type=checkbox bind:checked={PM.r} > Enable Receiver
        </label>
        <label>
            <input type=checkbox bind:checked={PM.o} > Enable Crystal Osc
        </label>
        <label>
            <input type=checkbox bind:checked={PM.b} > Enable Base Band Block
        </label>
        <label>
            <input type=checkbox bind:checked={PM.l} > Enable Low-batt Detector
        </label>
        <label>
            <input type=checkbox bind:checked={PM.t} > Enable Transmitter
        </label>
        <label>
            <input type=checkbox bind:checked={PM.w} > Enable Wake-Up Timer
        </label>
        <label>
            <input type=checkbox bind:checked={PM.s} > Enable Synthesizer
        </label>
        <label>
            <input type=checkbox bind:checked={PM.c} > Disable Clock Output Pin
        </label>
    </Fieldset>

    <Fieldset legend="Automatic Frequency Control" value={AF.v}>
        <div class=wide>
            <Popup head='AFC Mode' opts={afcs} bind:value={AF.m} />
        </div>
        <div class=wide>
            <Popup head='Offset Register Limit' opts={limits} bind:value={AF.o} />
        </div>
        <label>
            <input type=checkbox bind:checked={AF.a} > Enable AFC
        </label>
        <label>
            <input type=checkbox bind:checked={AF.h} > High Accuracy (slower)
        </label>
        <label>
            <input type=checkbox bind:checked={AF.s} > Strobe
        </label>
        <label>
            <input type=checkbox bind:checked={AF.f} > Enable Freq Offset Reg
        </label>
    </Fieldset>

    <Fieldset legend="Data Rate" value={DR.v}>
        <label class=wide>
            <input type=checkbox bind:checked={DR.p} > Enable Prescale (1÷8)
        </label>
        <div>
            Enter a value for R
            <input type=number class=numin bind:value={DR.r} >
        </div>
        <div>
            Data Rate = { (10000.0/29/(DR.r+1)/(1+DR.p*7)).toFixed(3) } kHz
        </div>
    </Fieldset>

    <Fieldset legend="PLL Settings" value={PS.v}>
        <Popup head='Clock rise' opts={["Fast","Medium","Slow"]} bind:value={PS.c} />
        <label>
            <input type=checkbox bind:checked={PS.p} > Disable Dither in PLL
        </label>
        <Popup head='PLL Band' opts={[86,256]} tail=kbps bind:value={PS.b} />
        <label>
            <input type=checkbox bind:checked={PS.e} > Enable Phase Detector Delay
        </label>
    </Fieldset>

    <Fieldset legend="Receiver Control" value={RC.v}>
        <Popup head='LNA Gain' opts={["Max",-6,-14,-20]} tail=dB bind:value={RC.l} />
        <Popup head='Pin' opts={["nINT","VDI"]} bind:value={RC.p} />
        <Popup head='RX Bandwidth' opts={rxbws} tail=kHz bind:value={RC.r} />
        <Popup head='VDI' opts={["Fast","Medium","Slow","On"]} bind:value={RC.n} />
        <Popup head='DRSSI' opts={drssis} tail=dB bind:value={RC.d} />
    </Fieldset>

    <Fieldset legend="Low Duty-Cycle" value={DC.v}>
        <label>
            <input type=checkbox bind:checked={DC.e} > Enable
        </label>
        <div>
            DC = (D x 2 + 1) / M x 100%
        </div>
        <div>
            D =
            <input type=number class=numin bind:value={DC.d} >
        </div>
        <div>
            Duty Cycle = { ((DC.d * 2 + 1) / WT.m * 100).toFixed(1) } %
        </div>
    </Fieldset>

    <Fieldset legend="Data Filter and Clock Recovery" value={DF.v}>
        <Popup head='Filter Type' opts={["Digital","Analog"]} bind:value={DF.f} />
        <Popup head='Recovery Mode' opts={["Manual","Auto"]} bind:value={DF.m} />
        <Popup head='Quality Threshold' opts={[4,5,6,7]} bind:value={DF.q} />
        <Popup head='Recovery Speed' opts={["Slow","Fast"]} bind:value={DF.s} />
    </Fieldset>

    <Fieldset legend="Low Battery Detect and µC Clock" value={LB.v}>
        <div>
            <Popup head='Threshold' opts={lobats} tail=V bind:value={LB.t} />
        </div>
        <div>
            <Popup head='Clock Pin' opts={clocks} tail=MHz bind:value={LB.p} />
        </div>
    </Fieldset>

    <Fieldset legend="FIFO and Reset Mode" value={FR.v}>
        <Popup head='FIFO INT Level' opts={range16} bind:value={FR.l} />
        <Popup head='Sync on' opts={[1,2]} tail=bytes bind:value={FR.b} />
        <Popup head='FIFO Fill Start' opts={["Sync","Always"]} bind:value={FR.f} />
        <Popup head='Reset Sensitivity' opts={["High","Low"]} bind:value={FR.s} />
        <label>
            <input type=checkbox bind:checked={FR.e} > FIFO Fill Enabled
        </label>
    </Fieldset>

    <Fieldset legend="Other Commands" value={OC.v}>
        <div class=wide>
            <b><code>B000</code> : RX Read</b> - read 8 bits from the receiver FIFO
        </div>
        <div class=wide>
            <b><code>B8xx</code> : TX Write</b> - write 8 bits to the transmitter register
        </div>
    </Fieldset>

    <Fieldset legend="Wake-Up Timer" value={WT.v}>
        <div>
            M =
            <input type=number class=numin bind:value={WT.m} >
            R =
            <input type=number class=numin bind:value={WT.r} >
        </div>
        <div>
            Timeout = { (1.03 * WT.m * (1 << WT.r) + 0.5).toFixed(2) } ms
        </div>
    </Fieldset>

</main>

<footer><p>See
<a href="https://git.jeelabs.org/jcw/sveltex/src/branch/master/rfm12calc">git.jeelabs.org/jcw/sveltex/rfm12calc</a>
for details.</p></footer>

<style>
    main {
        display: grid;
        grid-template-columns: repeat(auto-fill, 460px);
        grid-gap: 1rem;
    }

    .numin { padding: 0 2px; width: 4em; }
    .wide { grid-column-end: span 2; }
</style>
