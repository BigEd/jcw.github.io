<script>
	export let legend, value;

    // see https://stackoverflow.com/a/13240395/968115
    let toHex = d => ("000"+((d >>> 0).toString(16))).slice(-4).toUpperCase();
</script>

<fieldset>
    <legend><code>[0x{toHex(value)}]</code> <b>{legend}</b></legend>
    <div class=fsgrid>
        <slot></slot>
    </div>
</fieldset>

<style>
    fieldset {
        border-radius: 5px;
    }
    .fsgrid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 2px 1rem;
    }
</style>
