<script>
	export let head='', opts, tail='', value;
</script>

<span>
    {head}
    <select bind:value={value}>
        {#each opts as o, i}
            <option value={i}>{o}</option>
        {/each}
    </select>
    {tail}
</span>
