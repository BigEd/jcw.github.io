# SVG Dragging Demo

This project is based on <https://github.com/sveltejs/template>.
Setup and build instructions for this [Svelte](https://svelte.dev) app can be found there.

Live demo: <https://jeelabs.org/tools/svgdemo/>

An older Reagent/React version is described in this [weblog post](https://jeelabs.org/2017/08/diving-into-clojurescript/).
