<svelte:head>
    <title>SVG Dragging - JeeLabs</title>
</svelte:head>

<script>
    import Diagram from './Diagram.svelte';
</script>

<header><h1>SVG Dragging Demo</h1></header>

<main>
    <Diagram />
</main>

<footer><p>See
<a href="https://git.jeelabs.org/jcw/sveltex/src/branch/master/svgdemo">git.jeelabs.org/jcw/sveltex/svgdemo</a>
for details.</p></footer>
