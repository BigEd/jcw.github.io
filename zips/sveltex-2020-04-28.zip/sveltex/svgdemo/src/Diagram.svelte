<script>
    import Gadget from './Gadget.svelte';

    let gadgets = [[100, 50, [], "bang"],
                   [150, 100, "obj", "print", 123],
                   [200, 50, [], "bang"],
                   [250, 100, "obj", "print", "abcde"]];

    let wires = [[0, 0, 1, 0],
                 [2, 0, 1, 0],
                 [2, 0, 3, 0]];

    let paths = wires.map(asPath);

    let selection = -1, position, svg;
    
    function getMousePos(evt) {
        if (evt.touches)
            evt = evt.touches[0];
        return { x: evt.clientX, y: evt.clientY };
    }

    function dragStart(evt) {
        let g = evt.target.parentElement;
        if (g.classList.contains('draggable')) {
            selection = g.id|0;
            position = getMousePos(evt);
            g.parentElement.lastElementChild.after(g); // move to front
        }
    }

    function dragMove(evt) {
        if (selection >= 0) {
            let { x, y } = getMousePos(evt);
            gadgets[selection][0] += x - position.x;
            gadgets[selection][1] += y - position.y;
            position.x = x;
            position.y = y;

            for (const [i, w] of wires.entries())
                if (selection == w[0] || selection == w[2])
                    paths[i] = asPath(w);
        }
    }

    function dragEnd(evt) {
        selection = -1;
    }

    function inletPos(g, i) {
        let [x,y] = gadgets[g];
        return [x,y-10];
    }

    function outletPos(g, o) {
        let [x,y] = gadgets[g];
        return [x,y+10];
    }

    function asPath(w) {
        let [x1,y1] = outletPos(w[0], w[1]);
        let [x2,y2] = inletPos(w[2], w[3]);
        return ['M',x1,y1,'C',x1,y1+25,x2,y2-25,x2,y2].join(' ');
    }

</script>

<svg width=500 height=300 bind:this={svg}
                          on:mousedown|preventDefault={dragStart}
                          on:mousemove={dragMove} 
                          on:mouseup={dragEnd} 
                          on:mouseleave={dragEnd}
                          on:touchstart|preventDefault={dragStart}
                          on:touchmove={dragMove} 
                          on:touchend={dragEnd} 
                          on:touchleave={dragEnd}
                          on:touchcancel={dragEnd} >
    {#each paths as d}
        <path {d} />
    {/each}
    {#each gadgets as info, id}
        <Gadget {info} {id} />
    {/each}
</svg>

<pre>
    {#each gadgets as g, i}
        {i}: {g}<br/>
    {/each}
</pre>

<pre>
    {#each paths as p, i}
        {i}: {p}<br/>
    {/each}
</pre>

<style>
    svg { background: #eee; }
    path { stroke: black; fill: none; }
</style>
