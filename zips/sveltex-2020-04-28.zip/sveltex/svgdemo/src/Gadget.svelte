<script>
    export let id, info;

    import { onMount } from 'svelte';

    let x, y, type, args;
    $: [x, y, type, ...args] = info;

    let textElt, labelWidth = 0;

    onMount(() => {
        if (textElt)
            labelWidth = textElt.getBBox().width;
    });
</script>

<g {id} class=draggable >
    {#if type == "obj"}
        <rect x={x-5} y={y-10} width={labelWidth+10} height=20 />
        <text x={x} y={y+4} bind:this={textElt} >{args.join(' ')}</text>
    {:else}
        <circle cx={x} cy={y} r=10 />
    {/if}
</g>

<style>
    circle, rect {
        stroke: black;
        fill: white;
    }
    .draggable { cursor: move; }
    text { pointer-events: none; }
</style>
