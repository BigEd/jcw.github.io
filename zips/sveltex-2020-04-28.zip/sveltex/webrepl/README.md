# WebREPL for µPy

This project is a variation on [micropython/webrepl](https://github.com/micropython/webrepl/blob/master/webrepl.html).
Setup and build instructions for this [Svelte](https://svelte.dev) app can be found there.

Live demo: <https://jeelabs.org/tools/webrepl/>
