# JeeBus base: AngularJS + Pure CSS

* bower used for main dependencies (angular, pure, d3, fontawesome)
* angular-ui-router downloaded separately
