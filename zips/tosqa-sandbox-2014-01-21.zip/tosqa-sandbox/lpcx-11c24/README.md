This area can be imported in the LPCxpresso IDE. It includes a copy of the
LPCOpen v2 library code for the LPC11C24 microcontroller from
http://www.lpcware.com/content/nxpfile/lpcopen-platform

The **stepOverCan** trial is described at
http://jeelabs.net/projects/tosca/wiki/StepOverCan
