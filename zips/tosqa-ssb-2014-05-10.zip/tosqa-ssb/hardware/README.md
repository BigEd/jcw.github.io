# Tosqa Single Stepper Board hardware  hardware files

Schematics (*.dsn) are done in [TinyCAD](http://sourceforge.net/projects/tinycad/), a Windows-only, open-source schematics editor. Layout and gerber files will be made available soon.

[![License][B]][L]

[B]: http://img.shields.io/badge/license-MIT-brightgreen.svg
[L]: http://opensource.org/licenses/MIT
