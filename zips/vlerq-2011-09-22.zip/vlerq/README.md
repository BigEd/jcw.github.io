Vlerq is an experiment in column-wise data, persistence, and scripting.

*See <http://equi4.com/vlerq.org/>*
