![](img/zelkova-logo.png)

# Zelkova Sensor Logger

See the [manual](manual.md) for usage details.  
The technical reference is called [techref](techref.md).

* `fw-logger/` is the firmware for the STM32F103 µC
* `fw-recover/` is a special build for the STM32F103 in ESP-recovery mode
* `fw-server/` is the firmware for the ESP8266 module
* `hw-pcb/` contains the design files for the custom PCB
* `img/` has some images for use in several documents
* `reference/` has datasheets for the various components

Project design & implementation by [JC](https://github.com/jcw)
(firmware) and [David](https://github.com/DavidMenting) (hardware).

## Release history

* v1.0 - 2018-05-31 - First official release.
* v1.1 - 2018-10-16 - Add support for SHT21 in slot 3, tweak DHT22 timing.
