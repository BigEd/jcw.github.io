# Zelkova Logger firmware

This is a `platformio` project. To install via an ST-Link attached to the Blue
Pill, use this command:

    pio run -t upload

This code is also embedded in `fw-server`, for use in over-the-air updates.

See also the `Makefile` in `fw-server/`.
