// Command handlers.

static bool hCmd (int argc, int*);  // forward

// config
static bool cCmd (int argc, int*) {
    uint32_t const* config = (uint32_t const*) configBase;

    for (int i = 0; i < 8; ++i)
        printf(" %d", config[i]);
    printf("\n");

    return true;
}

// dump
static bool dCmd (int argc, int* argv) {
    DateTime now (rtc);

    // d
    // mm d
    // yy mm d
    // yy mm nn d
    // 0 d          (special case to dump everything)

    if (argc == 1 && *argv == 0) {
        int next = logger.nextSlot();
        logger.dumpRange(0, next);
        return next > 0;
    }

    int yr = argc > 1 ? argv[0] : now.year();
    int mo = argc > 0 ? argv[argc>1] : now.month();
    if (yr < 2018 || yr >= 2038 || mo < 1 || mo > 12) {
        printf("year must be >= 2018, month must be 1..12\n");
        return false;
    }

    return logger.dumpMonth(yr, mo, argc > 2 ? argv[2] : 0);
}

// list
static bool lCmd (int argc, int*) {
    logger.listAll();
    return true;
}

// print
static bool pCmd (int argc, int*) {
    int n = logger.nextSlot();
    if (n > 0) {
        printReading(logger.reading(n-1));
        return true;
    }
    return false;
}

// reading
static bool rCmd (int argc, int*) {
    Reading r;
    oneReading(r);
    printReading(r);
    return true;
}

// time
static bool tCmd (int argc, int*) {
    DateTime dt (rtc);
    printf("%04d-%02d-%02d %02d:%02d:%02d rtc %d\n",
            dt.year(), dt.month(), dt.day(),
            dt.hour(), dt.minute(), dt.second(),
            dt.get());
    return true;
}

// version
static bool vCmd (int argc, int*) {
    printf("Zelkova v%d.%d pcb %d cpu %08x spi %06x next %d\n",
            version/10, version%10,
            pcbRevision(), chipId(), emem.devId(),
            logger.nextSlot());
    return true;
}

// extra
static bool xCmd (int argc, int* argv) {
    if (argc == 0) {
        printf("  1:fb 2:ns 3:df 4:ep\n");
        printf("  1x:wifi 3x:listen\n");
        printf("  5x:led 6x:solar 7x:vcc1 8x:vcc2 9x:vcc3\n");
    } else {
        bool on = *argv & 1;
        switch (*argv) {
            case 1:  // first entries in flashindex
                for (int i = 0; i < 10; ++i)
                    printf(" %d", logger.flashBase[i]);
                printf("\n");
                break;
            case 2:  // which slot will be filled next
                printf("%d\n", logger.nextSlot());
                break;
            case 3:  // start of dataflash, as hex dump
                for (int i = 0; i < 20; ++i) {
                    Reading const& r = logger.reading(i);
                    for (int j = 0; j < 32; ++j) {
                        if (j % 4 == 0)
                            printf(" ");
                        printf("%02x", ((uint8_t const*) &r)[j]);
                    }
                    printf("\n");
                }
                break;
            case 4:  // erase just the first part of flash
                emem.erase(0);
                logger.imem.erasePage(logger.flashBase);
                logger.init();
                break;
            case 10: case 11:  // turn wifi off/on
                if (on) {
                    espWake = 1;
                    espWake.mode(Pinmode::out);
                } else
                    espWake.mode(Pinmode::in_pulldown);
                break;
            case 30: case 31:  // turn listening mode off/on
                listening = on;
                break;
            case 50: case 51:  // turn led off/on
                nLed = !on;
                break;
            case 60: case 61:  // turn solar charge off/on
                nCharge = !on;
                break;
            case 70: case 71:  // turn power supply 1 off/on
                supply1 = on;
                break;
            case 72:  // scan bus 1
                detectI2c(bus1);
                break;
            case 80: case 81:  // turn power supply 2 off/on
                supply2 = on;
                break;
            case 82:  // scan bus 2
                detectI2c(bus2);
                break;
            case 90: case 91:  // turn power supply 3 off/on
                supply3 = on;
                break;
            case 92:  // scan bus 3
                detectI2c(bus3);
                break;
        }
    }
    return true;
}

// adjust
static bool ACmd (int argc, int* argv) {
    DateTime dt (rtc);
    int yr = dt.year(), mo = dt.month(), dy = dt.day();
    if (argc == 2) {
        yr = *argv / 10000;
        mo = (*argv / 100) % 100;
        dy = *argv % 100;
        ++argv;
    }
    int hh = *argv / 10000,
        mm = (*argv / 100) % 100,
        ss = *argv % 100;
    DateTime newdt (yr, mo, dy, hh, mm, ss);
    rtc = newdt.get();
    wait_ms(2);
    return tCmd(0, 0);  // display the new date
}

// flash
static bool FCmd (int argc, int* argv) {
    if (*argv < updateBase || *argv >= loggerBase || *argv % 4 != 0)
        return false;  // refuse to mess with current firmware or logger index

    uint32_t const* addr = (uint32_t const*) *argv;

    // erase page when the address starts on a page boundary
    // note: this assumes pages are 1K, but larger F103's have 2K pages!
    if (*argv % 1024 == 0)
        Flash::erasePage(addr);
    // write the 0..8 values provided as arguments in successive locations
    for (int i = 1; i < argc; ++i)
        Flash::write32(addr + i - 1, argv[i]);

    // verify writes and give positive confirmation
    bool ok = true;
    for (int i = 1; i < argc; ++i)
        if (addr[i-1] != (uint32_t) argv[i])
            ok = false;
    if (ok)
        printf("ok\n");

    return true;
}

// update
static bool UCmd (int argc, int* argv) {
    uint16_t crcLo = CRC16::calculate((void const*) 0, *argv);
    uint16_t crcHi = CRC16::calculate((void const*) updateBase, *argv);

    if (argc == 1) {
        printf("%05d %05d\n", crcLo, crcHi);
        return true;  // just report the CRCs
    }
    
    if (argv[1] != crcHi)
        return false;  // CRCs don't match, don't self-update

    if (argv[1] == crcLo)
        printf("redundant update\n");  // update anyway, in case of CRC clash

    printf("updating ...\n");
    wait_ms(10);

    SelfUpdater::go((uint16_t const*) updateBase, *argv/2);
    // this never returns, self-updates always end in a reset
    return true;
}

// wipe
static bool WCmd (int argc, int* argv) {
    if (*argv != 54321)
        return false;
    printf("Erasing flash, this may take up to a minute ... ");
    logger.eraseAll();
    printf("done.\n");
    logger.event(E_RTC_LOST);  // just to force a new entry right away
    logger.flushEvents();
    return true;
}

// reset
static bool ZCmd (int argc, int* argv) {
    if (*argv != 123)
        return false;
    printf("Forcing reset ... ");
    Iwdg dog (0);   // this will timeout very soon
    while (true) ;  // ... and then force a reset
}

struct {
    uint8_t min, max;
    char cmd;
    bool (*fun)(int,int*);
    char const* desc;
} const cmdTab [] = {
    0, 0, 'c', cCmd, "                  c : show configuration data",
    0, 3, 'd', dCmd, "  ?yyyy mm lastn? d : dump up to one month of saved data",
    0, 9, 'h', hCmd, "                  h : show this help text",
    0, 0, 'l', lCmd, "                  l : show a list of saved readings",
    0, 0, 'p', pCmd, "                  p : print last stored reading",
    0, 0, 'r', rCmd, "                  r : get a fresh set of readings",
    0, 0, 't', tCmd, "                  t : display current date and time",
    0, 0, 'v', vCmd, "                  v : display version and chip ID",
    0, 1, 'x', xCmd, "              ?n? x : debug extra's",
    1, 2, 'A', ACmd, "?yyyymmdd? hhmmss A : adjust current date/time",
    1, 9, 'F', FCmd, " addr ?v1 ... v8? F : store data into flash memory",
    1, 2, 'U', UCmd, "        len ?crc? U : check and optionally update flash",
    1, 1, 'W', WCmd, "            54321 W : wipe entire data flash",
    1, 1, 'Z', ZCmd, "              123 Z : full reset and server shutdown",
    0, 0, 0, 0, 0
};

static bool hCmd (int argc, int*) {
    for (auto p = cmdTab; p->fun != 0; ++p)
        printf("  %s\n", p->desc);
    return true;
}

struct {
    bool prompt;
    Command cmd;

    void init () {
        tCmd(0, 0);
        vCmd(0, 0);
        printf("Type 'h' for a list of commands.\n");
        prompt = true;
    }

    // process incoming commands without blocking
    void poll () {
        if (prompt)
            printf(listening ? "<+>\n" : "> ");
        prompt = false;

        if (!myReadable())
            return; // nothing to do

        int c = myGetc();
        if (c == '\n')
            prompt = true;
        else if (c < ' ')
            c = ' ';

        int in = cmd.parse(c);

        bool (*f)(int,int*) = 0;
        for (auto p = cmdTab; p->fun != 0; ++p)
            if (p->cmd == in) {
                if (p->min <= cmd.argc && cmd.argc <= p->max)
                    f = p->fun;
                else
                    printf(" (arg count?)\n  %s\n", p->desc);
                in = 0;
                break;
            }
        
        if (f != 0) {
            nLed = 0;  // LED on
            prompt = f(cmd.argc, cmd.args);
            nLed = 1;  // LED off
            return;
        }

        switch (in) {
            case 0:
                break; // incomplete
            default:
                printf(" ?");
                // fall through
            case '?':
                for (int i = 0; i < cmd.argc; ++i)
                    printf(" %d", cmd.args[i]);
                printf("\n");
                prompt = in == '?';
                break;
        }
    }

} cmdLine;
