// Logging to spi data flash.

struct Logger {
    Flash imem;
    uint16_t events;

    // internal flash for storing an index starting at 62K, far above the code
    int32_t const* const flashBase = (int32_t const*) loggerBase;

    // the index stores "slot numbers" into spi data flash, one per month
    // a slot is an index to a Reading, i.e. byte offset / sizeof (Reading)
    // Jan 2018 is the first entry, Feb 2018 the 2nd, etc - room for 20 years
    const int numEntries = 256;  // 256x4b = 1k, i.e. this uses one flash page

    // these must be static, they are accessed from msgPutc()
    static Reading rBuf;
    static uint8_t msgFill;

    void init () {
        // emem.init();  // does nothing
        events = 0;
    }

    void eraseAll () {
        imem.erasePage(flashBase);
        emem.wipe();
        init();  // re-init
    }

    int slotIndex (int yr, int mo) {
        return 12*(yr-2018) + (mo-1);
    }

    Reading const& reading (int slot) {
        constexpr int maxSlot = (1<<24) / sizeof rBuf;
        if (slot < maxSlot)
            emem.read(slot * sizeof rBuf, &rBuf, (int) sizeof rBuf);
        else
            rBuf.rtc = -1; // simulate an empty slot
        return rBuf;
    }

    static void msgPutc (int c) {
        if (msgFill < sizeof rBuf.message.text)
            rBuf.message.text[msgFill++] = c;
    }

    void addMessage (const char* fmt, ...) {
        msgFill = 0;

        va_list ap;
        va_start(ap, fmt);
        veprintf(msgPutc, fmt, ap);
        va_end(ap);

        while (msgFill < sizeof rBuf.message.text)
            msgPutc(0);
        rBuf.message.text[msgFill-1] = 0;

        Reading r = rBuf;
        r.type = 2;
        addReading(r);
    }

    void addReading (Reading& r) {
        r.rtc = rtc;          // fill in the timestamp for this reading
        r.version = version;  // and tag with current s/w version
        r.flags = 0;
        r.events = events;    // log any pending events
        events = 0;           // ... and clear them

        DateTime now (r.rtc);
        int yr = now.year();
        int mo = now.month();
        int nowIdx = slotIndex(yr, mo);

        // due to optimisation, total time to add will be under 6 ms @ 8 MHz
        int next = nextSlot();

        // if the last entry is not for the same month, add missing entries
        if (next > 0) {
            DateTime then (reading(next-1).rtc);
            int thenIdx = slotIndex(then.year(), then.month());
            while (thenIdx < nowIdx)
                imem.write32(flashBase + thenIdx++, next);

            // note: *NEVER* store readings marked older than the last one
            // in this case, we have to store an incorrect timestamp instead, 
            // but at some point the real time will catch up again
            if (r.rtc < then.get()) {
                r.flags |= 1<<F_OLD_CLOCK;  // we're trying to log in the past
                r.rtc = then.get() + 1;     // use last time + 1s instead
            }
        } else  // first time ever, just clear the first unused slots
            for (int i = 0; i < nowIdx; ++i)
                imem.write32(flashBase + i, 0);
        
        if (!nCharge)  // flag when the battery is being charged from solar
            r.flags |= 1<<F_SUN_CHARGE;
        if (listening)  // listening mode is currently enabled
            r.flags |= 1<<F_LISTENING;

        if (flashBase[nowIdx] < 0)
            imem.write32(flashBase + nowIdx, next);

        emem.write(next * sizeof r, &r, (int) sizeof r);
    }

    int nextSlot () {
        // go through all the stored offsets to find the first unused one
        int slot = -1;
        for (int i = 0; i < numEntries; ++i)
            if (flashBase[i] > slot)
                slot = flashBase[i] - 1;

        // starting from this slot, find the first unused entry in spi flash

        // to speed up the linear scan, each of which has to read some data
        // from spi flash, start with some quick look-aheads using bisection
        // the max number of entries per month is at 1-min rate, i.e. 31x1440
        for (int i = 1<<15; i > 0; i >>= 1)
            if (reading(slot+i).rtc >= 0)
                slot += i;

        // finish off by single-stepping to the very first unused slot
        while (reading(++slot).rtc >= 0) ;

        return slot;
    }

    void listAll () {
        int next = nextSlot();
        if (next <= 0) {
            printf("0 entries\n");
            return;
        }

        int months = 0;
        for (int i = 0; i < numEntries-1; ++i)
            if (flashBase[i] >= 0) {
                int32_t first = flashBase[i];
                int32_t limit = flashBase[i+1];
                if (limit < 0)
                    limit = next;
                if (first < limit) {
                    int yr = 2018 + i/12;
                    int mo = 1 + i%12;
                    printf("  %4d-%02d: %d entries\n", yr, mo, limit-first);
                    ++months;
                }
            }

        DateTime then (reading(next-1).rtc);
        printf("%d month%s, last entry: %04d-%02d-%02d %02d:%02d:%02d\n",
                months, months == 1 ? "" : "s",
                then.year(), then.month(), then.day(),
                then.hour(), then.minute(), then.second());
    }

    bool dumpMonth (int yr, int mo, int lastn) {
        int slot = slotIndex(yr, mo);

        int32_t first = flashBase[slot];
        int32_t limit = flashBase[slot+1];
        if (limit < 0)
            limit = nextSlot();
        if (first < 0 || first >= limit)
            return false;

        if (lastn > 0 && first < limit-lastn)
            first = limit-lastn;  // only report the last few entries

        dumpRange(first, limit);
        return true;
    }

    void dumpRange (int first, int limit) {
        printf("date,time,id,ver,type,flags,events,"
               "solar,batt,ivcc,itemp,atemp,ahumi,s1t,s1m,s2t,s2m,s3t,s3m\n");
        for (int slot = first; slot < limit; ++slot) {
            Reading const& r = reading(slot);
            DateTime dt (r.rtc);
            printf("%04d%02d%02d,%02d%02d%02d",
                    dt.year(), dt.month(), dt.day(),
                    dt.hour(), dt.minute(), dt.second());
            printf(",%d,%d,%d,%03b,%06b",
                    cfg.stationId(), r.version, r.type, r.flags, r.events);
            switch (r.type) {
                case 1:
                    printf(",%d,%d,%d,%d,%d,%d",
                        r.sensors.iSun, r.sensors.vCell,
                        r.sensors.iVcc, r.sensors.iTemp,
                        r.sensors.aTemp, r.sensors.aHumi);
                    for (int i = 0; i < 3; ++i)
                        printf(",%d,%d",
                            r.sensors.soil[i].temp, r.sensors.soil[i].capa);
                    break;
                case 2:
                    printf(",\"%s\"", r.message.text);
                    break;
            }
            printf("\n");

            // max line is under 100 chars @ 115200 baud = 9 ms
            if (slot % 1000 == 0)
                dog.kick();  // keep the watchdog happy
        }
        printf(".\n");
    }

    bool hasEvent (int e) {
        return (events & 1<<e) != 0;
    }

    void event (int e) {
        events |= 1<<e;
    }

    void flushEvents () {
        if (events != 0)
            addMessage("events");
    }

} logger;

Reading Logger::rBuf;
uint8_t Logger::msgFill;
