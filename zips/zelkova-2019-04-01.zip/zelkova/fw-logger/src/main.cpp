// Data logger for the Zelkova project, for use on a Blue Pill w/ SPI flash.
// for STM32 h/w details, see [1] https://jeelabs.org/ref/STM32F1-RM0008.pdf

// this can be defined in platformio.ini:
//#define BYPASS 0  // make the console always active when set to 1

#ifndef BYPASS
#define BYPASS 0
#endif

constexpr int version = 12;  // firmware version x 10, i.e. 1 = 0.1, 10 = 1.0

constexpr int updateBase = 0x06000;  // firware updates stored at 24K in flash
constexpr int configBase = 0x0E000;  // config details, stored at 56K in flash
constexpr int loggerBase = 0x0E800;  // logger index is stored at 58K in flash

// Header dependencies ---------------------------------------------------------

#include <jee.h>
#include <jee/dio-dht22.h>
#include <jee/i2c-sht2x.h>
#include <jee/parse-cmd.h>
#include <jee/spi-flash.h>
//#include <jee/spi-rf95.h>
#include <jee/util-crc.h>
#include <jee/util-date.h>
#include <string.h>

// GPIO pins and hardware peripherals ------------------------------------------

PinA<0> espWake;  // ESP power and Hall sensor wakeup
PinA<1> vCell;    // battery voltage, V/2
PinA<2> vSun;     // solar current when shorted
PinA<3> vRev;     // board revision, 0V = 1.0
PinA<15> nCharge; // solar charge, active low
PinB<0> supply2;  // enable soil 2 power supply
PinB<1> supply3;  // enable soil 3 power supply
PinB<3> supply1;  // enable soil 1 power supply
PinB<4> rfIrq;    // rfm95 DIO0 interrupt
PinB<5> rfReset;  // radio reset, active low
PinC<13> nLed;    // on-board LED, active low

//SysTick<defaultHz> tick;  // system ticks, microsec time
RTC rtc;          // internal real-time clock
ADC<1> adc;       // access to ADC1
Iwdg dog (6);     // approx 26s

SpiHw< PinA<7>, PinA<6>, PinA<5>, PinA<4> > fSpi;      // spi flash
SpiHw< PinB<15>, PinB<14>, PinB<13>, PinB<12> > rSpi;  // rfm95

SpiFlash< decltype(fSpi) > emem;               // external dataflash, W25Q128
DHT22< PinA<8>, defaultHz > ambient;           // ambient temp/humi, DHT22
UartBufDev< PinA<9>, PinA<10>, 100 > console;  // serial port with buffering

//RF95< decltype(rSpi) > rf;  // RFM95 module, if populated

I2cBus< PinB<7>, PinB<6>, 2 > bus1;    // I2C for soil 1
I2cBus< PinB<9>, PinB<8>, 2 > bus2;    // I2C for soil 2
I2cBus< PinB<11>, PinB<10>, 2 > bus3;  // I2C for soil 3

bool triggered;     // recorded state of hall sensor before latching it
bool listening;     // the console port is active, accept input from it
uint16_t lastVcc;   // last estimated Vcc value, for adc compensation

// Console and debug serial support --------------------------------------------

static char const* listenKey = "<{$}>";
static char const* listenPtr = listenKey;

static bool myReadable () {
    if (console.readable()) {
        if (listening)
            return true;

        // constantly look for a match to switch into listening mode
        if (console.getc() != *listenPtr)
            listenPtr = listenKey;
        else if (*++listenPtr == 0)
            listening = true;
    }
    return false;
}

static int myGetc () {
    if (console.readable() && listening) {
        int c = console.getc();
        if (c == '\r')           // this only occurs in the ESP's boot message
            listening = BYPASS;  // so stop listening now, until told otherwise
        return c;
    }
    return ' ';  // bit weird as return value
}

static void myPutc (int c) {
    if (listening)
        console.putc(c);
}

int printf (const char* fmt, ...) {
    va_list ap; va_start(ap, fmt); veprintf(myPutc, fmt, ap); va_end(ap);
    return 0;
}

// Various utility functions ---------------------------------------------------

static uint32_t chipId () {
    return MMIO32(0x1FFFF7E8) ^ MMIO32(0x1FFFF7EC) ^ MMIO32(0x1FFFF7F0);
}

template< typename T >
void detectI2c (T bus) {
    for (int i = 0; i < 128; i += 16) {
        printf("%02x:", i);
        for (int j = 0; j < 16; ++j) {
            int addr = i + j;
            if (0x08 <= addr && addr <= 0x77) {
                bool ack = bus.start(addr<<1);
                bus.stop();
                printf(ack ? " %02x" : " --", addr);
            } else
                printf("   ");
        }
        printf("\n");
    }
}

// Analog measurements ---------------------------------------------------------

template< typename T >
static uint16_t avgAdc (T chan) {
    adc.read(chan);  // ignore first reading
    uint16_t sum = 5;  // this will cause rounding
    for (int i = 0; i < 10; ++i)
        sum += adc.read(chan);
    return sum / 10;
}

static int vccEstimate () {
    // supply voltage can be estimated via the 1.2V bandgap reading
    lastVcc = (4095 * 1200) / avgAdc((uint8_t) 17);  // result in mV
    return lastVcc;
}

static int tempEstimate () {
    // Temperature (in °C) = {(V25 - VSENSE) / Avg_Slope} + 25, see [1] p.235
    // V25 = 1.34/1.43/1.52 V min/typ/max
    // Avg_Slope = 4.0/4.3/4.6 mV/°C min/typ/max

    // end up up with a temperature * 10 result
    return (143000 - (avgAdc((uint8_t) 16) * lastVcc * 100) / 4095) / 43 + 250;
}

static int cellVoltage () {
    return (avgAdc(vCell) * lastVcc * 2) / 4095;  // result in mV (1:2 divider)
}

static int sunLevel () {
    // estimated using short-circuit current through the solar cell
    // measured as voltage drop across 1 ohm sense R, should be 0..330 mV
    // this temporarily forces a short-circuit to enable measurement
    int prev = nCharge;
    nCharge = 1;     // turn the Nfet on
    wait_ms(50);     // and let the voltage drop settle (?)
    int v = (avgAdc(vSun) * lastVcc) / 4095;  // result in mA
    nCharge = prev;  // revert to previous state
    return v;
}

static int pcbRevision () {
    return (avgAdc(vRev) * 32 + 2048) / 4095;  // 32 steps, rounded
}

// Configuration for this unit -------------------------------------------------
//
// This is read-only info, changes are made with flash write commands from ESP.
// Always retrieve meaningful values here, used for all decisions and actions.

struct UnitConfig {
    int revision;
    int sid;
    int log;
    int adj;
    int max;

    // bool isValid () { return 0 < revision && revision < 1000; }

    int stationId   () const { return    1 <= sid && sid <= 99   ? sid : 0;    }
    int logInterval () const { return    1 <= log && log <= 240  ? log : 1;    }
    int tempAdjust  () const { return -100 <= adj && adj <= 100  ? adj : 0;    }
    int maxVbat     () const { return 3700 <= max && max <= 4200 ? max : 4000; }
};

UnitConfig const& cfg = *(UnitConfig const*) configBase;

// Data logging ----------------------------------------------------------------

enum {  // flag bits
    F_OLD_CLOCK,        // clock time is older than before
    F_SUN_CHARGE,       // solar is charging the battery
    F_LISTENING,        // listening mode is enabled
};

enum {  // event bits
    E_RTC_LOST,         // the RTC was no longer running
    E_AMB_FAIL,         // failed to read out ambient temp/humi
    E_SOIL1_FAIL,       // failed to read out soil sensor #1
    E_SOIL2_FAIL,       // failed to read out soil sensor #2
    E_SOIL3_FAIL,       // failed to read out soil sensor #3
    E_HALL_ON,          // hall sensor was triggered after reset
};

struct Reading {
    // 0
    int32_t rtc;                    // seconds since 2000-01-01
    // 4
    uint8_t version :6;             // firmware version (0.1-6.3)
    uint8_t type :2;                // reading type, see union below
    uint8_t flags;                  // status flags
    uint16_t events;                // events since previous entry
    // 8
    union {
        uint32_t _ [6];
        struct {                    // type 1: sensor reading
            // 8
            uint16_t iSun;          // solar short-circuit current mA
            uint16_t vCell;         // LiPo voltage mV
            // 12
            struct {                // soil sensors:
                int16_t temp;       //  temperature Cx10
                int16_t capa;       //  capacitance 0..1023
            } soil [3];
            // 24
            int16_t aTemp;          // ambient temperature Cx10
            int16_t aHumi;          // ambient humidity RHx10
            // 28
            int16_t iTemp;          // internal temperature Cx10
            int16_t iVcc;           // Vcc, estimated via bandgap
            // 32
        } sensors;
        struct {                    // type 2: message
            // 8
            char text [24];         // message text
            // 32
        } message;
    };
    // 32

    Reading () { memset(this, 0, sizeof *this); }
};

#include "logger.h"

// Soil sensor driver ----------------------------------------------------------

template< typename I2C >
struct Soil {
    constexpr static int soilAddr = 0x20 << 1;

    bool present () {
        bool ack = I2C::start(soilAddr);
        I2C::stop();
        return ack;
    }

    void write (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::stop();
    }

    void write (uint8_t reg, uint8_t val) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::write(val);
        I2C::stop();
    }

    uint8_t read8 (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::start(soilAddr|1);
        return I2C::read(true);
    }

    uint16_t read16 (uint8_t reg) {
        I2C::start(soilAddr);
        I2C::write(reg);
        I2C::start(soilAddr|1);
        uint16_t val = I2C::read(false) << 8;
        return val | I2C::read(true);
    }

    bool reading () {
        bool ack = I2C::start(soilAddr);
        I2C::stop();
        if (ack) {
            sver = read8(7);
            stemp = read16(5);
            scapa = read16(0);
        }
        return ack;
    }

    uint8_t sver;
    uint16_t stemp, scapa;
};

// note: it's a bit tedious to end up with different types for each sensor
//          (this makes it impossible to turn them into an array)
Soil< decltype(bus1) > soil1;
Soil< decltype(bus2) > soil2;
Soil< decltype(bus3) > soil3;
SHT2x< decltype(bus3) > amb3;  // alternative ambient temperature via SHT21

// Collect a complete reading --------------------------------------------------

void soilReadings (Reading& r) {
    if (soil1.reading()) {
        r.sensors.soil[0].temp = soil1.stemp;
        r.sensors.soil[0].capa = soil1.scapa;
    } else
        logger.event(E_SOIL1_FAIL);

    if (soil2.reading()) {
        r.sensors.soil[1].temp = soil2.stemp;
        r.sensors.soil[1].capa = soil2.scapa;
    } else
        logger.event(E_SOIL2_FAIL);

    if (soil3.reading()) {
        r.sensors.soil[2].temp = soil3.stemp;
        r.sensors.soil[2].capa = soil3.scapa;
    } else { // Oct 2018: add support for an SHT21 on 3rd I2C port
        bool ack = bus3.start(0x40<<1);  // SHT21 is at I2C address 0x40
        bus3.stop();
        if (ack) {  // sensor is present, use its readings instead of soil
            amb3.init();
            r.sensors.soil[2].temp = amb3.temp100();  // has higher resolution!
            r.sensors.soil[2].capa = amb3.humidity10();
        } else
            logger.event(E_SOIL3_FAIL);
    }
}

void oneReading (Reading& r) {
    r.type = 1;

    r.sensors.iVcc = vccEstimate();  // must be first to adjust the next values
    r.sensors.iSun = sunLevel();
    r.sensors.vCell = cellVoltage();
    r.sensors.iTemp = tempEstimate() + cfg.tempAdjust();

    ambient.init();
    if (!ambient.read(r.sensors.aTemp, r.sensors.aHumi)) {
        wait_ms(50);  // wait and try once more, just in case
        if (!ambient.read(r.sensors.aTemp, r.sensors.aHumi))
            logger.event(E_AMB_FAIL);
    }

    // turn all the soil sensors on
    supply1 = 1;
    supply2 = 1;
    supply3 = 1;

    // wait for them to start up
    wait_ms(1000);  // is 1 s appropriate?

    // collect and save a set of readings
    // read out twice to make sure the readings are really up to date
    // this is a quirk of the soil sensors, returning the *previous* reading
    soilReadings(r);
    wait_ms(1000);  // is 1 s appropriate?
    soilReadings(r);

    // turn sensor power off again
    supply1 = 0;
    supply2 = 0;
    supply3 = 0;
}

void periodicReading () {
    int next = logger.nextSlot();
    if (next > 0) {
        int last = logger.reading(next-1).rtc;
        int period = cfg.logInterval() * 60;
        // start readings on clean interval multiples, or shortly thereafter
        if (rtc/period <= last/period)
            return;
    }

    nLed = 0;  // turn the LED on
    Reading r;
    oneReading(r);
    logger.addReading(r);
    nLed = 1;  // turn the LED off
}

void printReading (Reading const& r) {
    if (r.type != 1)
        return;

    printf("solar: %d mA\n", r.sensors.iSun);
    printf("battery: %d mV\n", r.sensors.vCell);
    printf("internal vcc: %d mV\n", r.sensors.iVcc);
    printf("internal temp: %d.%d °C\n", r.sensors.iTemp/10, r.sensors.iTemp%10);

    if (r.sensors.aTemp != 0)  // FIXME valid temp!
        printf("ambient: %d.%d °C, %d.%d %%RH\n",
                r.sensors.aTemp/10, r.sensors.aTemp%10,
                r.sensors.aHumi/10, r.sensors.aHumi%10);

    if (soil1.sver > 0)  // version is from last actual read, not from flash
        printf("soil #1 v%x.%x: %d.%d °C, moisture %d\n",
                soil1.sver/16, soil1.sver%16,
                r.sensors.soil[0].temp/10, r.sensors.soil[0].temp%10,
                r.sensors.soil[0].capa);

    if (soil2.sver > 0)  // version is from last actual read, not from flash
        printf("soil #2 v%x.%x: %d.%d °C, moisture %d\n",
                soil2.sver/16, soil2.sver%16,
                r.sensors.soil[1].temp/10, r.sensors.soil[1].temp%10,
                r.sensors.soil[1].capa);

    if (soil3.sver > 0)  // version is from last actual read, not from flash
        printf("soil #3 v%x.%x: %d.%d °C, moisture %d\n",
                soil3.sver/16, soil3.sver%16,
                r.sensors.soil[2].temp/10, r.sensors.soil[2].temp%10,
                r.sensors.soil[2].capa);
}

// Self-update code ------------------------------------------------------------
// 
// Copy a specified number of uint16_t's from high-flash to low-flash.
// This has to run from RAM since it overwrites low flash memory, i.e. itself.
// Be careful to prevent any potential low-flash accesses, i.e. interrupts.
// The only way out of here is a reset, to start running the new code.

#define RAMFUNC __attribute__ ((noinline, long_call, section (".data")))

struct SelfUpdater {
    RAMFUNC static void go (uint16_t const* hiAddr, int count) {
        __asm("cpsid i");  // disable interrupts

        for (uint32_t loPos = 0; --count >= 0; loPos += 2) {
            if ((loPos & 0x3FF) == 0) {
                // new page boundary, erase it first
                unlock();
                MMIO32(Flash::cr) = 0x02;
                MMIO32(Flash::ar) = loPos | 0x08000000;
                MMIO32(Flash::cr) = 0x42;
                finish();
            }
            unlock();
            MMIO32(Flash::cr) = 0x01;
            MMIO16(loPos) = *hiAddr++;
            finish();
        }

        while (Iwdg::sr & (1<<0)) ;  // wait until !PVU
        MMIO32(Iwdg::kr) = 0x5555;   // unlock PR
        MMIO32(Iwdg::pr) = 0;        // min timeout, resets asap
        MMIO32(Iwdg::kr) = 0xCCCC;   // start watchdog

        while (true) ;  // wait for the inevitable reset...
    }

    RAMFUNC static void unlock () {
        MMIO32(Flash::keyr) = 0x45670123;
        MMIO32(Flash::keyr) = 0xCDEF89AB;
    }

    RAMFUNC static void finish () {
        while (MMIO32(Flash::sr) & (1<<0)) ;
        MMIO32(Flash::cr) = 0x80;
    }
};

// Low power logic -------------------------------------------------------------

void sleepySecond () {
    // set the pre-scaler to 64 to drop the AHB clock from 8 MHz to 125 kHz
    MMIO32(Periph::rcc + 0x04) = (MMIO32(Periph::rcc) & ~(0xF<<4)) | 0b1100<<4;
    wait_ms(16);  // this will wait 64x16, i.e. 1024 ms
    // set AHB back to 8 MHz and advance the ticks counter for "missing" ticks
    MMIO32(Periph::rcc + 0x04) = MMIO32(Periph::rcc) & ~(0xF<<4);
    ticks += 1024 - 16;
}

void powerDown () {
    MMIO32(Periph::rcc + 0x04) = 0;      // revert to HSI @ 8 MHz, no PLL
    MMIO32(Periph::rcc + 0x00) = 0x81;   // turn off HSE and PLL, power-up value
    MMIO32(Periph::usb + 0x40) |= 1<<1;  // set USB PWDN
    MMIO32(Periph::pwr) |= 1<<1 | 1<<0;  // set PDDS and LPDS

    constexpr uint32_t scr = 0xE000ED10;
    MMIO32(scr) |= 1<<2;                 // set SLEEPDEEP

    __asm("cpsid i");
    __asm("wfi");
}

// Command handlers ------------------------------------------------------------

#include "commands.h"

// Main app setup and loop -----------------------------------------------------

int main () {
    // disable JTAG in AFIO-MAPR to release PB3, PB4, and PA15
    MMIO32(Periph::afio + 0x04) |= 1<<25;  // MAPR [1] p.183

    enableSysTick();

    adc.init();  // enable ADC1, for use on channels 1..3
    MMIO32(adc.smpr2) = 6<<9 | 6<<6 | 6<<3;  // 71.5 cycle conv's [1] p.243

    // first of all, check for enough power, i.e. right after a minimal init
    // if Vcc drops under 3.1V, then Vcell is probably also around that value
    // this way, powering fron USB is ok, even when the battery is absent
    if (vccEstimate() < 3100)
        powerDown();  // go to standby mode, until next watchdog reset

    console.init();
    listening = BYPASS;  // can force console I/O to always be active
    printf("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    // ensure that the RTC hardware is running, or restart it if not
    // use RTC_DIVL, since that changes 32768x/sec when the RTC is running
    constexpr static uint32_t divl = Periph::rtc + 0x14;
    uint16_t start = MMIO16(divl);
    wait_ms(2);
    bool rtcLost = MMIO16(divl) == start;
    if (rtcLost)
        rtc.init();

    nLed.mode(Pinmode::out); nLed = 1;        // active low
    nCharge.mode(Pinmode::out); nCharge = 1;  // active low
    supply1.mode(Pinmode::out); supply1 = 0;
    supply2.mode(Pinmode::out); supply2 = 0;
    supply3.mode(Pinmode::out); supply3 = 0;
    rfReset.mode(Pinmode::out); rfReset = 1;  // active low

    rSpi.init();                  // deselect the RFM95
    MMIO32(rSpi.cr1) &= ~(7<<3);  // max speed, i.e. 4 MHz, [1] p.743
  //rf.init(1, 1, 868);           // initialise the radio ...
  //rf.sleep();                   // ... to put it to sleep

    fSpi.init();                  // deselect the W25Q128
    MMIO32(fSpi.cr1) &= ~(7<<3);  // max speed, i.e. 4 MHz, [1] p.743
    logger.init();                // based on fSpi, i.e. emem

    // clock consistency: never restart with RTC clock older than 2018-01-01
    DateTime minDate (2018, 1, 1);
    if (rtc < minDate.get()) {
        rtc = minDate.get();
        logger.event(E_RTC_LOST);
    }

    if (rtcLost) {
        int next = logger.nextSlot();
        if (next > 0) {
            Reading const& r = logger.reading(next-1);
            rtc = r.rtc + 1; // 1s after the last saved entry is best we can do
        }
        logger.event(E_RTC_LOST);
    }

    // check ESP power, i.e. hall sensor state, and then latch it
    espWake.mode(Pinmode::in_pulldown);
    triggered = espWake;
    if (triggered) {
        logger.event(E_HALL_ON);
        listening = true;
    }

    uint32_t last5s = 0;
    uint32_t last25s = 0;

    cmdLine.init();
    for (;;) {
        nLed = ticks & 0x3F0;  // 1.5% blips while this command loop runs

        if (last5s < ticks/5000) {  // triggers once per 5 seconds
            last5s = ticks/5000; 

            // log a new reading at the configured interval
            periodicReading();

            if (last25s < ticks/25000) {  // triggers once per 25 seconds
                last25s = ticks/25000; 

                // charge if vCell is low
                nCharge = !(cellVoltage() < cfg.maxVbat());
            }

            // everything is ok if the clock is running and Vcc is high enough
            // will cause a reset if this loop hangs or Vcell drops way too low
            // another "kick" is in logger.dumpRange(), which can take a while
            // all other paths through the logger code take at most a few secs
            if (vccEstimate() < 3100)
                powerDown();  // go to standby mode, until next watchdog reset
            else
                dog.kick();   // keep the watchdog happy
        }

        if (!espWake) {
            listening = BYPASS;

            if (!listening) {    // if there's no ESP comms, we may slow down
                nLed = 1;        // make sure the LED is off
                sleepySecond();  // slow down the clock for about 1 second
            }
        }

        cmdLine.poll();

        __asm("wfi");  // reduce power consumption
    }
}
