# Zelkova Recovery firmware

This is a `platformio` project. To install via an ST-Link attached to the Blue
Pill, use this command:

    pio run -t upload

This is used to _temporarily_ put the STM32F103 into a special USB <=> UART
"pass-through" mode, to allow re-flashing the ESP module from USB. Once done,
the `fw-logger/` code must the uploaded to make the logger functional again.

See also the `Makefile` in `fw-server/`.
