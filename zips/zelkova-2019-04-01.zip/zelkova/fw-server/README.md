# Zelkova Server firmware

This is a `platformio` project. See the `Makefile` for build options.
