//#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>

uint8_t const firmware [] = {
#include "firmware.h"
};

// Define WIFI_CONN as 1 to connect to an existing WiFi network, else this will
// configure itself as new access point. See also WIFI_SSID and WIFI_PASS.

#if RELEASE
#include "../ssidpass.h"
#else

#define WIFI_CONN 0
#define WIFI_SSID "testkova"
#define WIFI_PASS "testtest"

#endif

ESP8266WebServer server (80);
ESP8266HTTPUpdateServer updater;
IPAddress myIP (192, 168, 1, 1);

void setupWiFi () {
#if WIFI_CONN
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    Serial.printf("connecting to '%s' ", ssid);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println(" ok.");

    myIP = WiFi.localIP();
#else
    WiFi.mode(WIFI_AP);
    WiFi.softAPConfig(myIP, myIP, IPAddress(255, 255, 255, 0));
    WiFi.softAP(WIFI_SSID, WIFI_PASS);
#endif
}

bool processCmd (char const* cmd, void (*fun)(char const*)) {
    Serial.print(" # ");  // this clears the argument stack
    delay(2);
    while (Serial.available())
        Serial.read();
    Serial.print(cmd);

    char buf [200];
    size_t fill = 0;

    uint32_t start = millis();
    while (millis() < start + 3000)  // wait up to 3s for more reply chars
        if (Serial.available()) {
            start = millis();  // reset timeout

            int c = Serial.read();
            if (c == '\n') {
                buf[fill] = 0;
                fill = 0;

                //if (strcmp(buf, "<+>") == 0)
                if (strstr(buf, "<+>") != 0)
                    return true; // end marker seen

                fun(buf);

            } else if (fill < sizeof buf - 1)
                buf[fill++] = c;
        }

    return false;  // no end marker seen at end of reply
}

// pass incoming lines of text straight through as web content
void passThrough (char const* s) {
    server.sendContent(s);
    server.sendContent("\n");
}

// convert incoming lines of text to an html table
// if the line contains ": ", render it as two columns
void renderAsTable (char const* s) {
    char buf [100];
    strcpy(buf, s);
    char* p = strstr(buf, ": ");
    if (p != 0) {
        p[1] = 0;
        p += 2;
    } else
        p = (char*) "";
    server.sendContent("<tr><td align='right'>");
    server.sendContent(buf);
    server.sendContent("</td><td>");
    server.sendContent(p);
    server.sendContent("</td></tr>\n");
}

String reply;

// send a command and return the single-line result as a string
char const* getReply (char const* cmd) {
    reply = "";
    processCmd(cmd, [](char const *s) {
        reply = s;
    });
    return reply.c_str();
}

// from jee/util-crc.h
struct CRC16 {
    static uint16_t calculate (void const* ptr, int len, uint16_t sum =0xFFFF) {
        for (int i = 0; i < len; ++i) {
            uint8_t data = ((uint8_t const*) ptr)[i];
            sum = (uint16_t) ((sum>>4) ^ table[sum&0xF] ^ table[data&0xF]);
            sum = (uint16_t) ((sum>>4) ^ table[sum&0xF] ^ table[data>>4]);
        }
        return sum;
    }

    static uint16_t const table[];
};

uint16_t const CRC16::table[] = {
    0x0000, 0xCC01, 0xD801, 0x1400, 0xF001, 0x3C00, 0x2800, 0xE401,
    0xA001, 0x6C00, 0x7800, 0xB401, 0x5000, 0x9C01, 0x8801, 0x4400,
};

constexpr int configRev = 2;  // change this when the parameter layout changes

struct Config {
    int revision;
    int stationId;
    int logInterval;
    int tempAdjust;
    int maxVbat;

    bool load () {
        int n = sscanf(getReply("c"), "%d %d %d %d %d",
                    &revision, &stationId, &logInterval, &tempAdjust, &maxVbat);
        return n == 5;
    }

    bool save () {
        revision = configRev;

        char buf [100];
        sprintf(buf, "$%x %d %d %d $%x %d F", 0xE000,  // configBase
                        revision, stationId, logInterval, tempAdjust, maxVbat);
        return strcmp(getReply(buf), "ok") == 0;
    }
};

Config config;

// all the page handlers are in a separate file

#include "pages.h"

// main application startup

void setup () {
    Serial.begin(115200);
    Serial.println("\nin main");

    setupWiFi();

    server.on("/", homePageHandler);
    server.on("/conf", configPageHandler);
    server.on("/data", dataPageHandler);
    server.on("/x", executePageHandler);

    updater.setup(&server);
    server.begin();

    //String s = myIP.toString();
    //Serial.printf("HTTP server started at http://%s/\n", s.c_str());
    //Serial.printf("       to update, open http://%s/update\n", s.c_str());

    delay(1100);               // make sure the BP's clock is back up to speed
    Serial.printf("\n<{$}>");  // finish by enabling listening mode on the BP
}

void loop () {
    server.handleClient();
}
