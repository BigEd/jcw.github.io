void startHtmlHeader () {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    server.send(200, "text/html; charset=utf-8",
        "<html>"
          "<head>"
            "<title>Zelkova</title>"
            "<style>"
              "body { font-family: sans-serif; line-height: 1.5em; }"
            "</style>"
          "</head>"
          "<body>"
    );
}

void failureMessage () {
    server.sendContent("<h3 style='color: red'>Communication Failure</h3>");
}

void homePageHandler () {
    startHtmlHeader ();

    char buf [100];
    int id = config.load() ? config.stationId : -1;
    sprintf(buf, 
        "<h1>Zelkova #%d</h1>"
        "<form action='/conf'><button type='submit'>Configure</button></form>",
            id < 0 ? 0 : id);  // < 0 happens when never configured
    server.sendContent(buf);

    if (id < 0)
        return failureMessage();

    // sample serial output:
    //  > l
    //    2018-04: 21 entries
    //    2018-05: 395 entries
    //  2 months, last entry: 2018-05-16 20:48:16
    server.sendContent("<table><tbody>");
    processCmd("l", [](char const* s) {
        char buf [200];
        // turn a list of months into a table with clickable entries
        int yr, mo, num;
        if (sscanf(s, "%d-%d: %d", &yr, &mo, &num) == 3) {
            int last10 = num > 10 ? 10 : num;
            sprintf(buf, "<tr>"
                           "<td>"
                             "<b>%d-%02d</b>"
                             " - "
                           "</td>"
                           "<td align='center'>"
                             "<a href='/data?y=%d&m=%d'>%d entr%s</a>"
                           "</td>"
                           "<td>"
                             " - "
                             "<a href='/data?y=%d&m=%d&n=%d'>view last %d</a>"
                           "</td>"
                         "</tr>", yr, mo,
                                  yr, mo, num, num == 1 ? "y" : "ies",
                                  yr, mo, last10, last10);
            server.sendContent(buf);
        } else if ('0' <= *s && *s <= '9') {
            server.sendContent("</tbody></table><p>");
            server.sendContent(s);
            server.sendContent("</p>");
        }
        server.sendContent("\n");
    });
    // finish by showing the last reading from flash
    server.sendContent("<table><tbody>");
    processCmd("p", renderAsTable);
    server.sendContent("</tbody></table>");
}

void adjustDate () {
    int yr, mo, dy, hh, mm, ss;

    // bit of a hack: "yyyy-mm-dd" reads as a year and two negative values
    if (sscanf(server.arg("dt").c_str(), "%d%d%d", &yr, &mo, &dy) != 3)
        return;
    mo = -mo;
    dy = -dy;

    if (sscanf(server.arg("tm").c_str(), "%2d:%2d:%2d", &hh, &mm, &ss) != 3)
        return;

    char buf [30];
    sprintf(buf, "%04d%02d%02d %02d%02d%02d A", yr, mo, dy, hh, mm, ss);
    getReply(buf);  // result ignored, time will be fetched and shown again
}

void configPageHandler () {
    startHtmlHeader ();
    server.sendContent(
        "<h1>Zelkova configuration</h1>"
        "<form action='/'><button type='submit'>Home</button></form>"
    );

    uint16_t checksum = CRC16::calculate(firmware, sizeof firmware);
    char buf [200];

    if (!config.load())
        return failureMessage();

    if (server.hasArg("dt") && server.hasArg("tm"))
        adjustDate();

    auto getParam = [](char const* name, int& param, int lo, int hi) {
        int v = server.hasArg(name) ? server.arg(name).toInt() : param;
        if (v == param && lo <= v && v <= hi)
            return;
        param = v < lo ? lo : v > hi ? hi : v;
        config.revision = -1;  // this will force a save
    };

    getParam("id", config.stationId, 1, 99);
    getParam("lg", config.logInterval, 1, 240);
    getParam("ta", config.tempAdjust, -100, 100);
    getParam("mv", config.maxVbat, 3700, 4200);

    // save in flash if there are configuration changes
    if (config.revision != configRev && config.save())
        server.sendContent("<p><i>Configuration saved.</i></p>");

    // /conf?wdf=erase : erase all data from spi flash
    if (server.arg("wdf") == "erase") {
        server.sendContent(
            "<b>Erasing... wait 1 minute, then click 'Home'.</b>");
        getReply("54321 W");
        return;
    }

    // /conf?s2f=1 : send firmware to BP's high flash
    if (server.hasArg("s2f")) {
        const int updateBase = 0x6000;  // save new firmware here

        uint32_t v [8];  // intermediate buffer, needed for word alignment
        for (int i = 0; i < (int) sizeof firmware; i += 32) {
            memcpy(v, firmware + i, 32);
            sprintf(buf, "$%x $%x $%x $%x $%x $%x $%x $%x $%x F",
                i + updateBase,
                v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]);

            if (strcmp(getReply(buf), "ok") != 0) {
                sprintf(buf, "<p>*** Failed at %d ***</p>", i);
                server.sendContent(buf);
                break;
            }
        }
    }

    // /conf?h2l=1 : copy high to low flash and restart BP
    if (server.hasArg("h2l")) {
        sprintf(buf, "%d %d U", sizeof firmware, checksum);
        // generates a "help" message, weird but harmless
        //server.sendContent(getReply(buf));
        getReply(buf);
    }

    auto showParam = [](char const* name, int& param, int lo, int hi,
                        char const* unit, char const* desc) {
        char buf [200];
        sprintf(buf, "<tr>"
                       "<td align='right'>%s: </td>"
                       "<td><input type='number' size=4 "
                         "name='%s' value=%d min=%d max=%d></td>"
                       "<td>%s </td>"
                       "<td> (%d..%d)</td>"
                     "</tr>", desc, name, param, lo, hi, unit, lo, hi);
        server.sendContent(buf);
    };

    // present configuration as an editable form
    server.sendContent("<form action='/conf'>"
                         "<table>"
                           "<tbody>");

    showParam("id", config.stationId, 1, 99, "", "Station ID");
    showParam("lg", config.logInterval, 1, 240, "minutes", "Logging interval");
    showParam("ta", config.tempAdjust, -100, 100, "1/10°C", "Temp adjust");
    showParam("mv", config.maxVbat, 3700, 4200, "mV", "Battery charge cutoff");

    server.sendContent(      "<tr><td></td><td colspan=2>"
                               "<button type='submit'>Change</button>"
                             "</td></tr>"
                           "</tbody>"
                         "</table>"
                       "</form>");

    // show current clock time on the Blue Pill
    char sdate [12], stime [12];
    int secs;
    if (sscanf(getReply("t"), "%s %s rtc %d", sdate, stime, &secs) != 3)
        return failureMessage();

    //int yr, mo, dy, hh, mm, ss, secs;
    //if (sscanf(getReply("t"), "%d-%d-%d %d:%d:%d rtc %d",
    //                            &yr, &mo, &dy, &hh, &mm, &ss, &secs) != 7)

    sprintf(buf,
        "<form action='/conf'>"
          "Logger date: "
          "<input type='text' name='dt' size=10 value='%s'>"
          " time: "
          "<input type='text' name='tm' size=8 value='%s'>"
          "<button type='submit'>Set</button>"
        "</form>", sdate, stime);
    server.sendContent(buf);

    server.sendContent("<hr size-1><p style='color:red'>Danger Zone:</p>");

    server.sendContent(
        "<form action='/conf'>"
          " Enter 'erase' here: "
          "<input type='text' name='wdf' size=6>"
          " to "
          "<button type='submit'>Erase ALL logged data</button>"
        "</form>");

    server.sendContent(
        "<form method='POST' action='/update' enctype='multipart/form-data'>"
          "<input type='file' name='update'>"
          "<input type='submit' value='Install update'>"
        "</form>");

    // get the current crcLo and crcHi from BP
    sprintf(buf, "%d U", sizeof firmware);
    int crcLo, crcHi;
    if (sscanf(getReply(buf), "%d %d", &crcLo, &crcHi) != 2)
        return failureMessage();

    if (checksum != crcHi) {  // hi-flash in the BP is not the same as ESP
        server.sendContent(
            "<form action='/conf'>"
              "<input type='hidden' name='s2f' value=1>"
              "<button type='submit'>Finish update, part 1</button>"
            "</form>");
    } else if (checksum != crcLo) {  // step 2: lo-flash is not same as ESP
        server.sendContent(
            "<form action='/conf'>"
              "<input type='hidden' name='h2l' value=1>"
              "<button type='submit'>Finish update, part 2</button>"
            "</form>");
    }

    // show version info from the Blue Pill
    server.sendContent(getReply("v"));

    // show checksums of the three different firmware copies
    sprintf(buf, "<br>Firmware: esp %05d high %05d low %05d size %d",
                    checksum, crcHi, crcLo, sizeof firmware);
    server.sendContent(buf);
}

void dataPageHandler () {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    // full dumps are sent as CSV, limited dumps as plain text
    int argc = server.args();
    server.send(200, argc == 2 ? "text/csv" : "text/plain");
    String cmd;
    for (int i = 0; i < argc; ++i) {
        cmd += server.arg(i);
        cmd += " ";
    }
    cmd += "d";

    // sample serial output:
    //  > 2018 5 d
    //  date,time,version,type,flags,events,info
    //  20180516,112901,1,1,0,10,1116,2983,244,507,194,3269,0,0,0,0,0,0
    //  20180516,113041,1,1,0,8,969,2915,244,516,192,3267,0,0,0,0,0,0
    //  20180516,113221,1,1,0,8,1046,3231,244,511,190,3267,0,0,0,0,0,0
    //  [...]
    processCmd(cmd.c_str(), passThrough);
}

// this is a (potentially dangerous) handler for executing any BP cmd
void executePageHandler () {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    server.send(200, "text/plain");
    String cmd = server.arg("q");
    processCmd(cmd.c_str(), passThrough);
}
