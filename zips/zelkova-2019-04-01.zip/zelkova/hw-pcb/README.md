# Zelkova PCB hardware design

These files were created by KiCAD v4. The 1.0 version has been tagged as
`pcb-v1.0` in git, several newer changes have been made for a future revision.
