![](img/zelkova-logo.svg)

# <a name=top></a>Zelkova Sensor Logger
**User manual v1.0**

1. [Overview](#s1)
1. [Setup](#s2)
1. [Configuration](#s3)
1. [Readout](#s4)
1. [Data format](#s5)
1. [Troubleshooting](#s6)

## <a name=s1></a>[1. Overview](#top)

The Zelkova Sensor Logger is a 17x12x5 cm weather-proof box which periodically
collects and stores sensor data. Up to three soil temperature/humidity sensors
can be attached, as well as a sensor for ambient air temperature and humidity:

![](img/logger-box.jpg)

Sensor data is collected at a preset interval and stored in flash memory inside
the unit. Data can be extracted using a mobile phone, tablet, or laptop, and
then emailed or otherwise saved for further analysis, processing, and
visualisation.

All external access to the box is via Wi-Fi, with the box turning itself into a
password-protected access point when a magnet is placed near a specific spot on
the box.  Wi-Fi access consumes more power and should be kept to a minimum.

The logger enclosure is fully sealed, with a solar panel inside to regularly top
up the internal Lithium battery's charge. Only initial setup, battery
replacement, and last-resort recovery after a failed update requires the unit to
be opened up again.

## <a name=s2></a>[2. Setup](#top)

### 2.1. Quick operational check

Here's how to do a first check of each unit:

1. insert a LiPo battery, +/- as printed on the circuit board
2. hold a magnet near the green LED in the corner to enable WiFi
    * the green LED will turn on, and the red one will start blinking
3. connect your laptop or phone to the access point called "Zelkova"
4. point your web browser to http://192.168.1.1/
5. from that home page, go to the configuration page
6. adjust the date and time (it is lost whenever battery is removed)
7. remove the magnet once done, as WiFi draws a lot more current

Note that if you enable two nearby units at the same time, WiFi may get
confused.

Before connection the sensors, it is best to remove the battery again to avoid
accidental damage. This may require some force, since the protected LiPo
cells have a _very_ snug fit in these battery holders. One way to do it, is to
gently pry on the positive end using a small screwdriver.

### 2.2. Internal connectors

All the connectors inside this unit are located on one side of the printed
circuit board:

![](img/connectors.png)

The soil and ambient connections use solderless terminals which snugly grasp
onto four plain wires each, while the solar panel power input uses a polarised
2-pin JST connector.

### 2.3. Connecting the ambient air sensor

The ambient air sensor is a DHT22 with four wires, two for power, one for data,
and one not-connected. It should be attached to the main board as follows - note
that only three connections actually need to be made:

![](img/dht22.png)

The 50 cm 4-core cables attached to the initial DHT22 sensors are colour-coded
as follows:

* GND = green, N/C = white, DATA = yellow, 3.3V = red

For proper readings, the sensor has to be mounted outside the box, protected
from direct sun and rain. A watertight grommet/gasket has been included to pass
a round 4-core cable through.

### 2.4. Connecting the soil sensors

The soil sensors are made by [Catnip
Electronics](https://www.tindie.com/stores/miceuz/), in this case the
[RUGGED](https://www.tindie.com/products/miceuz/i2c-soil-moisture-sensor/)
version, with a weather-proof epoxy coating and sealed with heat-shrink tube.
The regular version comes with 1-meter cables, the 3-meter version used in this
project were made as a special request:

![](img/soil-sensor-rugged.png?width=516)

The cables have 4 colour-coded cores, which must be connected as follows:

![](img/soil.png)

Up to three sensors can be connected.
The wires can be routed through the mounting pipe supporting the
enclosure.

### 2.5. Fixing the board inside the box

The printed circuit board with all the electronics, battery, and connectors is
attached to the box with stand-offs, leaving ample room for the mounting of the
unit to some kind of pole or rod:

![](img/standoffs.png)

### 2.6. Inserting the battery

Once all the sensors have been connected and the circuit has been firmly
attached to the box, you can insert the battery. This is a **protected**
type-18650 LiPo cell with 2600 mAh capacity. A high-quality cell is used, to
withstand large temperature swings and provide a long battery life.
Additional cells can be purchased locally, or similar ones ordered [from the
Netherlands](https://www.nkon.nl/rechargeable/18650-size/eagletac-18650-2600.html).

When inserting the battery, pay extra attention to the polarity: it will only
work when inserted as marked on the circuit board. The cell holder is
mechanically keyed so that accidental reversal will not make contact with the
battery poles.

At this point, the unit is powered up and running, although no LEDs will be lit
to indicate this - the default low-power operating mode has a current draw of a
few mA.

### 2.7. Connecting via Wi-Fi

To enable Wi-Fi access, you need to place a magnet near the corner with the
green LEDs. When strong enough and sufficiently close, one green LED will light
up, and the red LED will start to blink, indicating that the unit is operational
and that Wi-Fi access is now enabled.


You will see a new Wi-Fi network appear, called "Zelkova". Enter its password
and go to the following URL in your browser: <http://192.168.1.1/>.  If all is
well, you will see the logger's homepage, similar to this one:

| Logger homepage: |
|------------------|
| ![](img/homepage.png) |

This shows that the unit is working properly. If this is not the case, please
see the "Troubleshooting" section below.

You can now remove the magnet to disable Wi-Fi. The LEDs will turn off, but the
logger will continue to collect readings.

### 2.8. Attaching the solar panel

The solar panel has a small polarised plug, which should be inserted into the
white socket on the circuit board. It can only be inserted in one way. Insertion
and removal work best by pushing cq pulling the plug straight down or up.

The built-in solar panel can provide up to 2W of power when exposed to bright
sunlight. It's nominally 6V @ 330mA, but in practice these panels produce a
somewhat higher voltage at a slightly lower current.

### 2.9. Closing the box

The logger is now ready for use. Close the box with its transparent lid and
tighten the 4 screws for an all-weather seal.

That's it. As long as everything is working properly, the box will not need to
be opened. Configuration, readout, and software updates can all be done through
Wi-Fi, i.e. by placing the magnet in the proper position. The magnet should not
be left there indefinitely since Wi-Fi access requires considerably more power
than data collection.

Note that all logger boxes present themselves as a single "Zelkova" Wi-Fi
network and can therefore not provide Wi-Fi access at the same time. This is
easily managed by using a single magnet and activating only one Wi-Fi unit at a
time.

## <a name=s3></a>[3. Configuration](#top)

### 3.1. The configuration screen

On the homepage, there's a "Configure" button which leads to this screen:

| Configuration page: |
|---------------------|
| ![](img/confpage.png) |

Let's go through each of these settings in turn.

### 3.2. Station ID

The station ID can be used to uniquely identify each logger unit. This number is
prominently shown on the homepage, and is also included in each data reading
reported by this unit. On new units, this value is set to "1".

### 3.3. Logging interval

The logging interval determines how often the logger wakes up to read out its
sensors. It can be set from 1 to 240 minutes. Note that storage room is limited
to about 65000 entries. This translates to the following storage capacities:

| Interval | Capacity |
|----------|----------|
| 1 min | over 1 month |
| 15 min | over 18 months |
| 60 min | over 7 years |
| 120 min | approx. 15 years |
| 240 min | approx. 30 years |

### 3.4. Temp adjust

This is a correction factor for the _internal_ temperature measurement of the
processor chip, which can be used as estimate for the temperature inside the
box. While the readings tend to be fairly accurate as is, there can be a small
offset from one processor to the next. This adjustment will be applied before
saving these values in flash memory.

One way to easily calibrate each unit, is to place it at room temperature for an
hour or so, and then compare the readout with the _ambient_ temperature sensor
readout, which is far more accurate. You can then enter a correction here to
bring the two values in line with each other.

This value is specified in tenths of °C, the total range is therefore ±10°C.

### 3.5. Battery charge cutoff

This is an important parameter. It determines the maximum voltage of the battery
at which solar charging will stop. Setting it too high will reduce the battery's
lifetime, while setting it too low may risk the battery running out in prolonged
periods with nearly no sunlight.

An excellent value to start with for normal outdoor use is 3950 mV.

### 3.6. Logger clock setup

The logger uses its built-in real-time clock to keep track of time and for
timestamping each collected reading.

This value should of course be set right away.

_Important notice_ - while **setting** the clock is an important step,
**changing** it should not be done lightly, at it can have a major impact on the
operation of the logger and the way it collects and timestamps its readings.

The first thing to note is that all readings are stored with an increasing
timestamp. The logger _cannot_ store readings in the past. Once a reading for
time T has been recorded, only readings with time T, T+1, etc can be added.

The consequence of this is that setting the clock back in time can lead to fewer
readings getting stored than expected. If the time is `Tnow` and you set it to 1
hour earlier, then the logger will dutifully adjust its internal clock to
`Tnow-1hr`. But for one hour, it won't log any new data, until the clock has
advanced past `Tnow` again, that is.

In the context of daylight saving time changes, this means that setting the
clock back one hour will cause the logger to stop logging for one hour. After
one hour, it will resume logging, and readings will be logged with the proper
(new) timestamps attached to them.

There is no issue with advancing the clock: it will simply create a gap in the
logged readings.

Given that the logger units are intended to run unattended all year round, with
no one present when daylight savings switches happen, it is probably best to
simply leave the clocks running on _either_ winter _or_ summer time, all year
round.

Note also that you need to be very careful when adjusting the clock. A huge step
forward by mistake can not easily be corrected afterwards!
Having said that, there is **one** way to set the clock back and have the logger
immediately start logging from there: by erasing all currently logged data.

### 3.7. Erasing all logged data

All readings are permanently stored in flash memory. Even if the battery fails
for some reason, existing data will be safe.

If you need to start with a clean slate, then this option is how to do it. Since
it has such a major impact, with potential data loss, there is an extra safety
measure to prevent _unintentional_ erasure: the "Erase ALL logged data" button
only has effect when the word "erase" has been manually entered in the field to
the left of it.

### 3.8. Software updates

The last option on the configuration page is for performing a software update.
Information about this process will be included when such an update is
available, along with the file you then need to upload to the logger.

All official releases are archived
[here](https://github.com/jcw/zelkova/releases).
Downgrading to an older version is not supported, only _upgrading_.

Software updates can be used to install software improvements and to add new
features.  They do not affect the stored readings, i.e. all stored data will
still be available after the update.

## <a name=s4></a>[4. Readout](#top)

All sensor readings are stored by month. The logger homepage gives a list of
the months in which data has been collected, with two links: one to view all the
data and one to view just the last few entries.

These are the steps to read out the data stored in a logger unit:

1. place the magnet to enable Wi-Fi, the green LED should turn on
2. connect to the (password-protected) "Zelkova" wireless network
3. go to this URL in your browser: <http://192.168.1.1/>
4. on the logger homepage, select the month to download
5. save this page on your device, or forward it as email, etc
6. go back to repeat steps 4 and 5 for additional months
7. remove the magnet to turn Wi-Fi access off again

That's it. Access is only possible with a magnet and the proper password.

## <a name=s5></a>[5. Data format](#top)

Data is reported as lines of text in Comma Separated Value (CSV) format.
Depending on the browser and platform you're using, these will show up as either
plain text or in tabular form:

| Sample data: |
|--------------|
| ![](img/csv-table.jpg) |

### 5.1. Columns

The columns in this table have the following meaning:

| Name | Description | Format / Unit |
|------|-------------|---------------|
| date | date of this reading | `yyyymmdd` |
| time | time of this reading | `hhmmdd` |
| id | station ID, as set on the configuration page | 1..99 |
| ver | software version at time of reading | `xx` |
| type | type of entry: 1=data 2=message | 1..2 |
| flags | logger state, see below | `xxx` |
| events | special conditions, see below | `xxxxxx` |
| solar | approximate solar intensity | mA |
| batt | battery voltage | mV |
| ivcc | internal Vcc, should be 3250..3300 | mV |
| itemp | internal temperature, after adjustment | 1/10 °C |
| atemp | ambient temperature | 1/10 °C |
| ahumi | ambient humidity | 1/10 %RH |
| s1t | soil sensor #1 temperature | 1/10 °C |
| s1m | soil sensor #1 moisture (via capacitance) | ≈ 200..700 |
| s2t | soil sensor #2 temperature | 1/10 °C |
| s2m | soil sensor #2 moisture (via capacitance) | ≈ 200..700 |
| s3t | soil sensor #3 temperature | 1/10 °C |
| s3m | soil sensor #3 moisture (via capacitance) | ≈ 200..700 |

### 5.2. Flags

Flags are 0/1 indicators of of the logger state at the time of measurement.
The three flags are concatenated into one number:

| Flag | Position | Value |
|------|----------|-------|
| clock | `..X` | 1=catching-up 0=actual |
| charge | `.X.` | 1=charging 0=disabled |
| wifi | `X..` | 1=on 0=off |

Normally, flags should be either `010` or `000`, depending on whether the battery
is currently charging or not.

### 5.3. Events

Events are special states which have occured since the last reading, but not
necessarily at the time a reading is saved:

| Flag | Position | Value |
|------|----------|-------|
| real-time clock | `.....X` | 1=reset 0=valid |
| ambient sensor | `....X.` | 1=failed 0=valid |
| soil sensor #1 | `...X..` | 1=failed 0=valid |
| soil sensor #2 | `..X...` | 1=failed 0=valid |
| soil sensor #3 | `.X....` | 1=failed 0=valid |
| magnet sensor | `X.....` | 1=triggered 0=idle |

During normal unattended data collection, events should be `000000` (unless not
all 4 sensors have been connected).

## <a name=s6></a>[6. Troubleshooting](#top)

[TBD]
