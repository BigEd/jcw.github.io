![](img/zelkova-logo.svg)

# <a name=top></a>Zelkova Sensor Logger
**Technical Reference v1.0**

1. [Overview](#s01)
1. [System design](#s02)
1. [STM "Blue Pill"](#s03)
1. [ESP "Wroom-02"](#s04)
1. [Power management](#s05)
1. [Electronics & PCB](#s06)
1. [Command processor](#s07)
1. [Web server](#s08)
1. [Software tools](#s09)
1. [Firmware updates](#s10)
1. [Recovery procedure](#s11)
1. [Revision notes](#s12)

## <a name=s01></a> 1. [Overview](#top)

The Zelkova Sensor Logger is a 17x12x5 cm weather-proof box which periodically
collects and stores sensor data. Up to three soil temperature/humidity sensors
can be attached, as well as a sensor for ambient air temperature and humidity.

Sensor data is collected at a preset interval and stored in flash memory inside
the unit. Data can be extracted using a mobile phone, tablet, or laptop, and
then emailed or otherwise saved for further analysis, processing, and
visualisation.

All external access to the box is via Wi-Fi, with the box turning itself into a
password-protected access point when a magnet is placed near a specific spot on
the box.  Wi-Fi access consumes more power and should be kept to a minimum.

The logger enclosure is fully sealed, with a solar panel inside to regularly top
up the internal Lithium battery's charge. Only initial setup, battery
replacement, and last-resort recovery after a failed update requires the unit to
be opened up again.

## <a name=s02></a> 2. [System design](#top)

The Zelkova Logger setup consists of the following components:

![](img/overview.png)

> _Note that the LoRa module is optional, and has **not** been fitted in this
> version._

Up to **one** ambient and **three** soil sensors can be attached, these must be
mounted externally.

There are two independent microcontrollers: the STM32 always runs in low-power
mode, and takes care of periodically reading out the sensors and saving the
measurements in SPI flash memory. The ESP is a Wi-Fi module which acts as
access point when enabled, and which communicates with the STM32 via a serial
connection inside the logger.

## <a name=s03></a> 3. [STM "Blue Pill"](#top)

The STM32F103 microcontroller is a widely used model, and in this case it's part
of a little breakout board known as a "Blue Pill". It has 64 KB flash memory for
the code and 20 KB RAM for data. It also has a real-time clock, and over 20 I/O
pins for connection to the outside world.

![](img/Bluepillpinout.gif)

The USART1 serial port is connected to the ESP, and the USB connector is only
used for the recovery procedure of the ESP, as described in another section
later on.

The STM32 also manages solar charging, and tracks various voltages and other
aspects of the system.

### Pin assignments

| Pin  | Connected to | Device | &nbsp; – &nbsp; | Pin | Connected to | Device |
|------|--------------|--------|-----------------|-----|--------------|--------|
| PA0  | ESP power + Hall | wkup | | PB0  | soil 2 power | - |
| PA1  | ADC: Vcell | adc | | PB1  | soil 3 power | - |
| PA2  | ADC: Vrev | adc | | PB3  | soil 1 power | - |
| PA3  | ADC: Vsun | adc | | PB4  | radio IRQ: DIO0 | - |
| PA4  | flash nSEL | spi | | PB5  | radio nRESET | - |
| PA5  | flash SCLK | spi | | PB6  | soil 1: SCL | i2c |
| PA6  | flash MISO | spi | | PB7  | soil 1: SDA | i2c |
| PA7  | flash MOSI | spi | | PB8  | soil 2: SCL | - |
| PA8  | DHT22 I/O | - | | PB9  | soil 2: SDA | - |
| PA9  | TX to ESP | uart | | PB10 | soil 3: SCL | i2c |
| PA10 | RX from ESP | uart | | PB11 | soil 3: SDA | i2c |
| PA11 | (USB D-) | usb | | PB12 | radio nSEL | spi |
| PA12 | (USB D+) | usb | | PB13 | radio SCLK | spi |
| PA13 | (SWDIO) | swd | | PB14 | radio MISO | spi |
| PA14 | (SWCLK) | swd | | PB15 | radio MOSI | spi |
| PA15 | solar power | - | | PC13 | (nLED) | on-board |
| | | | | PC14 | (OSC32 in) | on-board |
| | | | | PC15 | (OSC32 out) | on-board |

## <a name=s04></a> 4. [ESP "Wroom-02"](#top)

The ESP8266 module is also very widely used, it contains a powerful 32-bit
microcontroller and all the software to act as Wi-Fi access point and web
server. Due to its high power consumption during use, the ESP is kept off most
of the time.

![](img/esp-wroom-02-pinout.png)

A special mode has to be used to program the ESP for the first time, after
that it can be updated using Wi-Fi.

## <a name=s05></a> 5. [Power management](#top)

The STM32 draws about 10 mA when running at 8 Mhz (it can go up to 72 MHz). To
reduce operating current by a few mA, the on-board power LED has been removed.
To further reduce operating current, the STM32 switches into "sleep mode"
whenever it is idle, and turns its clock down to 125 kHz for 1s at a time when
there is no active power to the ESP, since it won't need to respond to serial
I/O.

The ESP draws around 80 mA while active, but this drops to under 100 µA when
powered down via its "enable" pin.

The total current consumption of the Zelkova Logger while waiting for the next
readout time is around 3 mA. Further power reductions were not deemed necessary
at this stage.

The battery is a common 18650 LiPo battery (18x65 mm), with a nominal capacity
of 2600 mAh. The battery must have **built-in protection** against
under-/over-voltage and over-current. Such units are fairly common, but note
that they are slightly longer, leading to a very snug fit in the battery holder.

The solar panel can produce up to 2W of power under optimal solar conditions,
and is rated 6V @ 330 mA. The solar panel is a current source, and as such it
can directly charge the LiPo battery.

The STM32 continuously monitors the
battery voltage to avoid over-charging.
It does this by shorting out the solar cell through a 1 Ω sense resistor. While
shorted out, the voltage across the sense resistor is measured, which provides a
useful estimate of the amount of solar energy coming in.

The maximum battery voltage at which the STM32 will cut off the charge circuit
is adjustable as configuration parameter.
For maximum battery life, this value should be set to 3950 mV, which leaves the
battery partially-charged at all times.

Given the current consumption, the battery will have enough energy to power the
logger for many days, even when no solar charging is taking place, e.g. a series
of cloudy winter days. But most of the time, the battery will simply remain
charged and will be topped up each day, as soon as the sun comes out.

During actual readout, the logger can draw up to 30 mA for a few seconds, given
that an active soil sensor draws around 8 mA. Once done, the soil sensor power
is completely switched off by the STM32.

## <a name=s06></a> 6. [Electronics & PCB](#top)

The schematic design for the circuit board used in the Zelkova logger can be
found in the [hw-pcb/](hw-pcb/) folder.

This design has a number of features which are not being used at the moment:

* there is an (untested) on-board reverse-battery protection circuit in the
lower-right corner, which is not needed because the battery holders will
mechanically prevent a reversed battery from making contact
* there is room for an RFM95 LoRa wireless module in the lower-left corner -
this has not been installed, as only local logging to SPI flash and on-site
readout via Wi-Fi is currently used

Here is a rendering of the entire PCB layout:

![](img/zelkova-pcb-v1.0.png)

### Connector pinouts

Left to right (bottom right to top right in above image) view towards pcb edge,
components on top:

* soil 1..3: gnd/black, scl/yellow, sda/blue, vcc/red
* ambient: gnd, n/c, data, vcc
* esp-01: rx, gpio0, gpio2, gnd (front), vcc, rst, ena, tx (back)
* solar charge: gnd, vcc

## <a name=s07></a> 7. [Command processor](#top)

The STM32 microcontroller runs a continuous loop, while occasionally entering
low-power modes to somewhat reduce its idle current consumption. In short, the
following takes place inside this loop:

* keep the activity LED blinking with very short "blips"
* check when a new reading is due, and store all the results in flash
* every 25s, decide whether to enable or disable battery charging
* keep the watchdog happy, i.e. prevent a reset if all is working properly
* if the ESP is not on (via magnet/hall-sensor), sleep for 1s with reduced clock
* process commands received over the serial link from the ESP

The following commands are implemented in the STM32:

```text
                  c : show configuration data
  ?yyyy mm lastn? d : dump up to one month of saved data
                  h : show this help text
                  l : show a list of saved readings
                  p : print last stored reading
                  r : get a fresh set of readings
                  t : display current date and time
                  v : display version and chip ID
              ?n? x : debug extra's
?yyyymmdd? hhmmss A : adjust current date/time
 addr ?v1 ... v8? F : store data into flash memory
        len ?crc? U : check and optionally update flash
            54321 W : wipe entire data flash
              123 Z : full reset and server shutdown
```

These commands can also be entered via the web (as long as the ESP is powered
up), for testing and debugging
purposes. For example, to check the version information:

```text
$ curl http://192.168.1.1/x?q=v
Zelkova v0.7 pcb 0 cpu D3013B4B spi EF4018 next 11172
$
```

To start a reading, and return its results:

```text
$ curl http://192.168.1.1/x?q=r
solar: 66 mA
battery: 3694 mV
internal vcc: 3254 mV
internal temp: 44.5 °C
ambient: 45.3 °C, 49.2 %RH
soil #1 v2.6: 21.9 °C, moisture 371
soil #2 v2.6: 36.9 °C, moisture 298
$
```

Here is a summary of the data currently stored in SPI flash memory:

```text
$ curl http://192.168.1.1/x?q=l
  2018-01: 17 entries
  2018-05: 11153 entries
2 months, last entry: 2018-05-29 14:28:06
$
```

And here, a dump of the data stored for January 2018:

```text
$ curl http://192.168.1.1/x?q=2018+1+d
date,time,id,ver,type,flags,events,solar,batt,ivcc,itemp,atemp,ahumi,s1t,s1m,s2t,s2m,s3t,s3m
20180102,010513,92,3,1,100,111000,0,3768,3256,220,241,433,0,0,0,0,0,0
20180102,010514,92,3,1,101,1111011,0,3727,3256,248,236,451,0,0,0,0,0,0
20180102,010515,92,3,1,101,111010,0,3726,3256,248,235,462,0,0,0,0,0,0
20180102,010516,92,3,1,101,111010,0,3726,3256,246,236,462,0,0,0,0,0,0
20180102,010517,92,3,1,101,111000,0,3731,3256,235,236,463,0,0,0,0,0,0
20180102,010518,92,3,1,101,011000,0,3735,3254,235,237,445,0,0,0,0,0,0
20180102,010519,92,3,1,101,011000,0,3737,3256,233,236,449,0,0,0,0,0,0
20180102,010520,92,3,1,101,111000,0,3734,3256,231,236,453,0,0,0,0,0,0
20180102,010521,92,3,1,101,111000,0,3732,3256,231,236,450,0,0,0,0,0,0
20180102,010522,92,3,1,101,111000,0,3737,3256,231,236,451,0,0,0,0,0,0
20180102,010523,92,3,1,101,111000,0,3732,3256,231,236,447,0,0,0,0,0,0
20180102,010524,92,3,1,101,111110,0,3735,3256,231,0,0,0,0,0,0,0,0
20180102,010525,92,3,1,101,111110,0,3732,3256,229,0,0,0,0,0,0,0,0
20180102,010526,92,3,1,101,111110,0,3739,3256,229,0,0,0,0,0,0,0,0
20180102,010527,92,3,1,101,011110,0,3734,3256,227,0,0,0,0,0,0,0,0
20180102,010528,92,3,1,101,111110,0,3740,3256,227,0,0,0,0,0,0,0,0
20180102,010529,92,3,1,101,111110,0,3731,3256,227,0,0,0,0,0,0,0,0
.
$
```

For a description of the data fields, see [section 5 of the
User Manual](manual.md#s5).

> Note that large datasets can take a while,
since all the information has to go through the 115.2 kBaud serial link.

To force a reset of the STM32 (all "dangerous" commands are in uppercase):

```text
$ curl http://192.168.1.1/x?q=123+Z
Forcing reset ... �2018-05-29 14:55:15 rtc 580920915
Zelkova v0.7 pcb 0 cpu D2203414 spi EF4018 next 1414
Type 'h' for a list of commands.
$
```

So the ESP simply passes all `/x?q=...` requests through to the
STM32, and returns the results as plain text.

## <a name=s08></a> 8. [Web server](#top)

The ESP also implements a small web server, for more convenient access to the
Zelkoval Logger. This is purely an extra front-end for the above command-line
interface of the STM32, i.e. all the page requests get their data and control
the STM32 through the same commands as listed above.

The web server produces three different pages:

* `/` - the homepage, with the station ID, a summary of the months, and the last
saved reading
* `/conf` the configuration page, to adjusting settings, change the clock,
erase all data, and upload new firmware
* `/data?y=2018&m=5&n=10` - this reports the stored data as text, using
comma-separated value (CSV) conventions (with a third argument, the returned
mime type will be `text/plain`, else `text/csv`)

> Note: as special case, `/data?y=0` will generate a full dump of **all** data
stored in the logger. Depending on how much information has been stored, this
may take several minutes to complete (up to about 5 MB for 65000 log entries).

The last line of a data report is always a single dot (".") to indicate proper
completion.

For a description of the configuration options, see [section 3 of the
User Manual](manual.md#s5).

## <a name=s09></a> 9. [Software tools](#top)

All the software is built with [PlatformIO](https://platformio.org), which will
also automatically take care of downloading and installing all the necessary
toolchains and libraries.

To install PlatformIO on your machine (Windows, MacOS, or Linux), see the
Getting Started on their [documentation
site](http://docs.platformio.org/en/latest/). PlatformIO can be installed either
as part of the Atom or VSCode IDE, or as command-line tool. The following
information assumes the command-line install and was used on MacOS during the
development of this project.

There are three independent projects, each with their own directory on GitHub,
where all the software is saved:

* [fw-logger/](https://github.com/jcw/zelkova/tree/master/fw-logger) is the
main logger application for the STM32
* [fw-recovery/](https://github.com/jcw/zelkova/tree/master/fw-recovery) is a
special recovery utility for the STM32 (as described later on)
* [fw-server/](https://github.com/jcw/zelkova/tree/master/fw-server) is the
main web server application for the ESP

To build the software, go to the proper directory and enter `pio run`.

The ESP firmware includes a _copy_ of the `fw_logger` code, to allow
re-flashing the STM32 after a Wi-Fi based update of the ESP (this process is
described in the next section).

For this reason, it is better to perform all the build and upload activity through
the `Makefile` in `fw-server/`. The following commands are available:

```text
# development:
#   make                  - esp02 dev build with wifi upload
#   make release          - esp02 release build with wifi upload
#   make c|d|h|l|p|r|t|v  - send various commands to the BP via curl
#
# setup and recovery:
#   make recover  - upload pass-through code to the Blue Pill using ST-Link
#   make loadesp  - upload ESP code via the Blue Pill in pass-through mode
#   make loadstm  - upload the logger app to the Blue Pill using ST-Link
```

A plain `make` in the `fw-server/` directory will re-build the STM32 code,
generate the proper header for inclusion in ESP, then build a new ESP firmware
image, and finally upload that image - if you are currently connected by Wi-Fi
to a specific Zelkova Logger that is.

Here is the transcript of such a complete build and upload:

```text
$ make
cd ../fw-logger/ && \
        pio run -s && \
        xxd -i <.pioenvs/bluepill/firmware.bin >../fw-server/src/firmware.h
pio run -s
cp .pioenvs/esp02/firmware.bin esp02.bin
curl -F "image=@esp02.bin" 192.168.1.1/update
<META http-equiv="refresh" content="15;URL=/">Update Success! Rebooting...
$
```

A few seconds later, you should see a re-connect to the ESP access point.

> Note that the above procedure is for a **development build** - the settings
> for such builds cause the ESP to come up as an access point with SSID
> "testkova", password "testtest" and **not** the official release SSID, which
> is "Zelkova"!

## <a name=s10></a> 10. [Firmware updates](#top)

The above firware update process is intended for use during development and
testing, and assumes that you have PlatformIO installed. This is not needed for
regular in-the-field updates. In this case, you will have received an updated
firmware image, which can be uploaded via the Logger's web interface:

1. Go to the logger's configuration page, which shows this section at the
bottom:

    ![](img/fw-updates.png)

2. Click on "Choose File" and select the firmware image, which is a file
ending in ".bin", then click on "Install update".

3. After a few seconds, you will see the message "**Update Success!
Rebooting...**". Wait a bit longer.

4. After the ESP restarts (and you have been reconnected to the access point),
you will see the home page again.

5. Almost there, but no cigar just yet: please go to the Configuraton page
_again_.

6. Depending on the type of update, there may be a button "Finish update, part
1" - if so, click it and wait a few seconds. If you now see _another_ button
called "Finish update, part 2", click that as well.

7. The new update has now been installed. These final steps
installed the update _through_ the ESP _onto_ the STM32.

All official releases are archived on GitHub, see the [Release
page](https://github.com/jcw/zelkova/releases). For intermediate testing and
debugging purposes, other releases may be provided, but the mechanism for
updating each Zelkova Logger unit is always the same.

## <a name=s11></a> 11. [Recovery procedure](#top)

Wi-Fi based firmware upgrades can only be used when both the ESP and STM32
operate more-or-less normally. However, if they have crashed and refuse to start
up properly after a complete power cycle (by re-inserting the battery), a
more elaborate procedure must be used. This requires some additional tools and
can only be done by removing the PCB from its enclosure. This is also how the
firmware is installed for the first time, after intitial assembly.

The following two accessories are needed to perform a recovery upload:

1. A low-cost "ST-Link" programmer for STM32 µCs - these are available from
eBay:

    ![](img/st-link-v2.jpg)

    They come with a 4-wire hookup cable, which needs to connect to the four
    "SWD" pins on the side of the Blue Pill board, opposite its USB connector.
    This is used to upload software to the STM32. These are the four
    connections:

    | 1: | 2: | 3: | 4: |
    |---|---|---|---|
    | 3V3 | SWDIO | SWCLK | GND |

    The pins on the ST-Link side differ from one model to another,
    unfortunately. Please be very careful to connect to the proper pins and
    never to the 5V pin, as this could damage the Zelkova Logger.

2. A small custom header "plug", which temporarily connects a few GPIO pins of
the ESP Wroom-02 with Vcc and ground, through 10 kΩ pull-up / pull-down
resistors.  This requires either soldering or creating a small plug which firmly
pushes against the plated-through holes on the PCB of a 2x4 header with the
following pinout:

    | 7: | 5: | 3: | 1: |
    |---|---|---|---|
    | **3V3** | (RST) | (EN) | (TX) |
    | (RX) | **GPIO0** | **GPIO2** | **GND** |

    Two 10 kΩ resistors are needed: one between **3V3** and **GPIO2**, the other
    between **GPIO0** and **GND**. Here is the recovery setup,
    i.e. the ST-Link connected to the Blue Pill, and the two resistors
    attached via a yellow 2x4 header:

    ![](img/recovery.jpg)

3. A USB cable should be connected to the USB jack on the Blue Pill, as shown
above. Both this cable _and_ the ST-Link need to be plugged into your laptop
(and preferably no other USB device!).

> Note: there may be **no** other source of power: the battery and
solar panel must be **disconnected** during recovery!

A full recovery (or a first-time upload, which is essentially the same thing)
can be performed with the following 10 steps:

1. make sure the above configuration has been very carefully set up
1. plug both the ST-Link and the USB cable into your laptop
    * this will also supply power to the logger
1. move the _upper_ yellow jumper on the Blue Pill from the left to the right
two pins
1. briefly press the little reset button next to it, just underneath
1. put the yellow jumper back in its original position
1. go to the `fw-server/` directory and type `make recover`
    * if all is well, you should see a `*Verify OK*` message, among others
1. now type `make loadesp`
    * this will start uploading the server code into the ESP
1. finally, type `make loadstm`
    * this replaces the recovery utility on the Blue Pill with the logger
      application
1. if any of the above doesn't work, please double-check and retry a few times
1. remove the USB cable, the ST-Link + cable, and the two resistors

That's it. The STM32 and the ESP should now both have working firmware images
again. To verify proper operation, you can insert a battery and hold a magnet
next to the Hall sensor - the on-board and red LEDs should start to flash and
the Wi-Fi access point should show up.

## <a name=s12></a> 12. [Revision notes](#top)

[TBD]
